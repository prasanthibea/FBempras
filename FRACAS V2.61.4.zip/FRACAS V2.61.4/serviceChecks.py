from PySide6.QtWidgets import QVBoxLayout, QLabel, QTableWidget, QHBoxLayout, QDateEdit, QFileDialog, QPushButton, QComboBox, QGridLayout, QSizePolicy, QMessageBox, QScrollArea, QHeaderView, QFormLayout, QDateTimeEdit, QAbstractItemView, QSpacerItem
from PySide6.QtWidgets import QWidget
from functions import TableWidget, CustomDateTimeEdit
from PySide6.QtCore import Qt,QDateTime, QDate, QTime
from PySide6.QtGui import QIcon
from datetime import datetime, date
from PySide6.QtWidgets import QTableWidget, QTableWidgetItem
from scData import onButtonClicked_SC
import calendar
import pandas as pd


def SCUI(self,tab):
	from PySide6.QtWidgets import QApplication
	self.SCMainLayout = QVBoxLayout()
	tab.setLayout(self.SCMainLayout)

	formlayout_SC = QFormLayout()

	startingYear = int(self.config.get('startingYearMonth', 'startingYear'))
	startingMonth = int(self.config.get('startingYearMonth', 'startingMonth'))

	query = 'SELECT COUNT(*) FROM service_checks'
	self.cursor.execute(query)
	result = self.cursor.fetchone()
	if result[0] != 0:
		query = """SELECT year, month
		FROM service_checks
		ORDER BY year DESC, month DESC
		LIMIT 1;
		"""
		self.cursor.execute(query)
		result =self.cursor.fetchone()
		if result[1] != 12:
			cbYear = result[0]
			cbMonth = result[1] + 1
		else:
			cbYear = result[0] + 1
			cbMonth = 1
	else:
		cbYear = startingYear
		cbMonth = startingMonth

	self.createComboBox([str(cbYear)], 'yearCombobox_SC')
	formlayout_SC.addRow('Year:<font color="red">*</font>', self.yearCombobox_SC)

	self.createComboBox([str(cbMonth)], 'monthCombobox_SC')
	# formlayout_SC.addRow('Month:<font color="red">*</font>', self.monthCombobox_SC)


	#####################################################################
	HLayoutOfSC = QHBoxLayout()
	self.createPushButton('importButton_SC', '', self.currentTheme.get('importDataIcon'), tooltip='Import SC Data')
	self.importButton_SC.setFixedWidth(35)
	self.importButton_SC.setFixedHeight(25)

	self.createPushButton('templateButton_SC', '', self.currentTheme.get('exportTemplateIcon'), tooltip='Export Template')
	self.templateButton_SC.setFixedWidth(29)
	self.templateButton_SC.setFixedHeight(25)
	
	HLayoutOfSC.addWidget(self.monthCombobox_SC)

	spacerItem = QSpacerItem(20, 1, QSizePolicy.Expanding, QSizePolicy.Fixed)
	HLayoutOfSC.addItem(spacerItem)

	HLayoutOfSC.addWidget(self.templateButton_SC, alignment = Qt.AlignRight)
	HLayoutOfSC.addWidget(self.importButton_SC, alignment = Qt.AlignRight)

	formlayout_SC.addRow('Month:<font color="red">*</font>', HLayoutOfSC)


	########################################################################

	self.SCMainLayout.addLayout(formlayout_SC)

	self.tablewidget_SC = TableWidget(len(self.trainsetsList),10)
	self.tablewidget_SC.setStyleSheet(self.tableWidgetQSS)
	self.tablewidget_SC.horizontalHeader().setStyleSheet(self.headerHorizontalQSS)
	# self.tablewidget_SC.verticalHeader().setStyleSheet(self.headerVerticalQSS)
	self.tablewidget_SC.setAlternatingRowColors(True)
	self.tablewidget_SC.setShowGrid(False)
	self.tablewidget_SC.setEditTriggers(QAbstractItemView.NoEditTriggers)
	self.tablewidget_SC.verticalHeader().setSectionResizeMode(QHeaderView.ResizeToContents)
	tableHeaderLabels_SC = ["Train", "A Check-I", "A Check-II", "A Check-III", "B1 Check-I", "B1 Check-II", "B4 Check", "B8 Check", "C1", "C2"]
	self.tablewidget_SC.setHorizontalHeaderLabels(tableHeaderLabels_SC)

	self.SCMainLayout.addWidget(self.tablewidget_SC)

	for i in range(1, self.tablewidget_SC.columnCount()):
		self.tablewidget_SC.setColumnWidth(i, int(0.1 * QApplication.primaryScreen().availableGeometry().width()))

	self.tablewidget_SC.setMinimumHeight(int(0.69 * QApplication.primaryScreen().availableGeometry().height()))


	layoutForSubmitandCancelBtns = QHBoxLayout()

	self.createPushButton('submitButton_SC', 'Submit')
	layoutForSubmitandCancelBtns.addWidget(self.submitButton_SC, alignment = Qt.AlignRight)
	self.createPushButton('cancelButton_SC', 'Cancel')
	layoutForSubmitandCancelBtns.addWidget(self.cancelButton_SC, alignment = Qt.AlignLeft)

	self.SCMainLayout.addLayout(layoutForSubmitandCancelBtns)
	
	for i, train in enumerate(self.trainsetsList):
		label= QLabel(train)
		label.setAlignment(Qt.AlignCenter)
		self.tablewidget_SC.setCellWidget(i, 0, label)

	# allDateTimeEdits = []
	for i in range (len(self.trainsetsList)) :
		for j in range (1, 10):
			widgetForCell = QWidget()
			hboxLayoutInCell_SC = QHBoxLayout()
			widgetForCell.setLayout(hboxLayoutInCell_SC)

			plusButtonInCell_SC = QPushButton('+')
			plusButtonInCell_SC.setStyleSheet(self.pushbuttonQSS)
			plusButtonInCell_SC.setMaximumWidth(int(0.017 * QApplication.primaryScreen().availableGeometry().width()))
			hboxLayoutInCell_SC.addWidget(plusButtonInCell_SC)
			

			dateTimeEditInCell_SC = CustomDateTimeEdit()
			# allDateTimeEdits.append(dateTimeEditInCell_SC)
			dateTimeEditInCell_SC.setStyleSheet(self.dateTimeEditBoxQSS)
			dateTimeEditInCell_SC.setDisplayFormat("dd-MM-yyyy HH:mm")
			dateTimeEditInCell_SC.setVisible(False)
			dateTimeEditInCell_SC.setButtonSymbols(QDateTimeEdit.NoButtons)
			min_dateTime = QDateTime(QDate(cbYear, cbMonth, 1), QTime(0, 0))
			dateTimeEditInCell_SC.setMinimumDateTime(min_dateTime)

			_, last_day = calendar.monthrange(cbYear, cbMonth)
			max_dateTime = QDateTime(QDate(cbYear, cbMonth, last_day), QTime(23, 59))
			dateTimeEditInCell_SC.setMaximumDateTime(max_dateTime)


			dateTimeEditInCell_SC.setFixedWidth(int(0.07 * QApplication.primaryScreen().availableGeometry().width()))
			hboxLayoutInCell_SC.addWidget(dateTimeEditInCell_SC)

			crossButtonInCell_SC = QPushButton('X')
			# crossButtonInCell_SC.setStyleSheet(self.pushbuttonQSS)
			crossButtonInCell_SC.setStyleSheet(f'''{self.pushbuttonQSS} QPushButton {{ background: red; }}
			QPushButton:hover {{background: red;
				}}
				QPushButton:pressed {{
					background: red;
				}}''')
			crossButtonInCell_SC.setVisible(False)
			hboxLayoutInCell_SC.addWidget(crossButtonInCell_SC)
			crossButtonInCell_SC.setMaximumWidth(int(0.017 * QApplication.primaryScreen().availableGeometry().width()))

			
			def unhide_Dateeditandcrossbutton(plus_button, cross_button, dateTimeEdit):
				if plus_button.isVisible():
					plus_button.setVisible(False)
					cross_button.setVisible(True)
					dateTimeEdit.setVisible(True)
				else:
					plus_button.setVisible(True)
					cross_button.setVisible(False)
					dateTimeEdit.setVisible(False)

			plusButtonInCell_SC.clicked.connect(lambda plus_button=plusButtonInCell_SC, cross_button=crossButtonInCell_SC, dateEdit = dateTimeEditInCell_SC: unhide_Dateeditandcrossbutton(plus_button, cross_button, dateEdit))
			crossButtonInCell_SC.clicked.connect(lambda plus_button=plusButtonInCell_SC, cross_button=crossButtonInCell_SC, dateEdit = dateTimeEditInCell_SC: unhide_Dateeditandcrossbutton(plus_button, cross_button, dateEdit))
			

			self.tablewidget_SC.setCellWidget(i, j, widgetForCell) 


	# def settingMinimumDate_SC(year, month):
	# 	for dateTimeEdit in allDateTimeEdits:
	# 		min_dateTime = QDateTime(QDate(year, month, 1), QTime(0, 0))
	# 		dateTimeEdit.setMinimumDateTime(min_dateTime)

	# def onChangingYearCombobox_sc():

	self.tablewidget_SC.setColumnHidden(3, True)
	self.tablewidget_SC.setColumnHidden(5, True)
	self.tablewidget_SC.setColumnHidden(8, True)
	self.tablewidget_SC.setColumnHidden(9, True)


	###############################################################


	def onClickingimportButton_SC( ):

		if self.monthCombobox_SC.currentIndex() == -1:
			self.monthCombobox_SC.setProperty("error", True)
			self.monthCombobox_SC.setStyleSheet(self.comboBoxQSS)
		else:
			self.monthCombobox_SC.setProperty("error", False)
			self.monthCombobox_SC.setStyleSheet(self.comboBoxQSS)
			
		if self.yearCombobox_SC.currentIndex() == -1:		
			self.yearCombobox_SC.setProperty("error", True)
			self.yearCombobox_SC.setStyleSheet(self.comboBoxQSS)
		else:
			self.yearCombobox_SC.setProperty("error", False)
			self.yearCombobox_SC.setStyleSheet(self.comboBoxQSS)

		if self.monthCombobox_SC.currentIndex() != -1 and self.yearCombobox_SC.currentIndex() != -1:	
			file_path, _ = QFileDialog.getOpenFileName(self, "Select Excel File", "", "Excel Files (*.xlsx)")
			if file_path:
				df = pd.read_excel(file_path)

				excelHeaders = df.columns.tolist()
				
				excelDataMappingWindowWidth = int(0.275* QApplication.primaryScreen().availableGeometry().width())
				excelDataMappingWindowHeight = int(0.32 * QApplication.primaryScreen().availableGeometry().height())

				self.excelAndTableColumnsMappingWindow = QWidget()
				self.excelAndTableColumnsMappingWindow.setWindowIcon(QIcon('Media/ramsify.png'))
				self.excelAndTableColumnsMappingWindow.setWindowTitle('Map Columns')
				self.excelAndTableColumnsMappingWindow.setStyleSheet(self.widgetQSS)
				# self.excelAndTableColumnsMappingWindow.setFixedHeight(excelDataMappingWindowHeight)
				# self.excelAndTableColumnsMappingWindow.setFixedWidth(excelDataMappingWindowWidth)
				self.excelAndTableColumnsMappingWindow.resize(excelDataMappingWindowWidth,excelDataMappingWindowHeight)

				VLayoutForColumnsMappingWindow = QVBoxLayout()

				columnsMappingHeaderLabel = QLabel('Map Columns')
				columnsMappingHeaderLabel.setAlignment(Qt.AlignHCenter)
				# columnsMappingHeaderLabel.setContentsMargins(20, 0, 0, 0)


				scrollArea_ExcelImportWindow = QScrollArea()
				scrollArea_ExcelImportWindow.setStyleSheet(self.scrollAreaQSS)
				scrollArea_ExcelImportWindow.setWidgetResizable(True)
				

				VLayoutForColumnsMappingWindow.addWidget(columnsMappingHeaderLabel)


				excelColumnsWithTableColumnsWidget = QWidget()
				# excelColumnsWithTableColumnsWidget.setAlignment(Qt.AlignTop)

				scrollArea_ExcelImportWindow.setWidget(excelColumnsWithTableColumnsWidget)


				excelAndTableColumnsGridLayout = QGridLayout()

				widgetHeadersLabel = QLabel('Fields')
				widgetHeadersLabel.setStyleSheet("font-size: 11pt;")

				excelHeadersLabel = QLabel('Imported Excel Columns')
				excelHeadersLabel.setStyleSheet("font-size: 11pt;")

				

				excelAndTableColumnsGridLayout.addWidget(widgetHeadersLabel, 0, 0)
				excelAndTableColumnsGridLayout.addWidget(excelHeadersLabel, 0, 1)

				column_names = []
				for column in range(self.tablewidget_SC.columnCount()):
					if not self.tablewidget_SC.isColumnHidden(column): 
						header_item = self.tablewidget_SC.horizontalHeaderItem(column)
						if header_item is not None:
							column_names.append(header_item.text())

				# print(column_names)

				
				for i in range(len(column_names)):
					fieldLabel_mappingWindow = QLabel(column_names[i])
					excelAndTableColumnsGridLayout.addWidget(fieldLabel_mappingWindow, i + 1, 0)

					self.createComboBox(excelHeaders, 'excelColumnNames')
					# if i < len(excelHeaders):
					if str(column_names[i]).lower() in [s.lower() for s in excelHeaders]:
						self.excelColumnNames.setCurrentText(column_names[i])

					excelAndTableColumnsGridLayout.addWidget(self.excelColumnNames, i + 1, 1)
				
				excelColumnsWithTableColumnsWidget.setLayout(excelAndTableColumnsGridLayout)
				VLayoutForColumnsMappingWindow.addWidget(scrollArea_ExcelImportWindow)


				self.excelAndTableColumnsMappingWindow.setLayout(VLayoutForColumnsMappingWindow)

				# self.excelAndTableColumnsMappingWindow.close()

				self.createPushButton('submitImportedExcelData', 'SUBMIT', width=int(0.050 * QApplication.primaryScreen().availableGeometry().width()))
				self.submitImportedExcelData.setFixedHeight(30)
				# self.submitImportedExcelData.clicked.connect(lambda: self.excelAndTableColumnsMappingWindow.close())

				self.createPushButton('cancelImportedExcelData', 'CANCEL', width=int(0.050 * QApplication.primaryScreen().availableGeometry().width()))
				self.cancelImportedExcelData.setFixedHeight(30)
				self.cancelImportedExcelData.clicked.connect(lambda: self.excelAndTableColumnsMappingWindow.close())



				submitAndCancelBtnOfExcelImportWindow = QHBoxLayout()
				submitAndCancelBtnOfExcelImportWindow.addWidget(self.submitImportedExcelData, alignment=Qt.AlignRight)
				submitAndCancelBtnOfExcelImportWindow.addWidget(self.cancelImportedExcelData, alignment=Qt.AlignLeft)
				
				VLayoutForColumnsMappingWindow.addLayout(submitAndCancelBtnOfExcelImportWindow)


				def mapData():

					excelIndices = []
					for i in range(excelAndTableColumnsGridLayout.rowCount()):
						if excelAndTableColumnsGridLayout.itemAtPosition(i, 1):
							if excelAndTableColumnsGridLayout.itemAtPosition(i, 1).widget():
								if isinstance(excelAndTableColumnsGridLayout.itemAtPosition(i, 1).widget(), QComboBox):
									excelIndices.append(excelAndTableColumnsGridLayout.itemAtPosition(i, 1).widget().currentIndex())
									
					df_ = df.iloc[:, excelIndices]
						
					indices = [0,1,2,4,6,7]
					for i in range(df_.shape[0]):
						for j in range(1, df_.shape[1]):
							plus_button = self.tablewidget_SC.cellWidget(i, indices[j]).layout().itemAt(0).widget()
							date_edit = self.tablewidget_SC.cellWidget(i, indices[j]).layout().itemAt(1).widget()
							cross_button = self.tablewidget_SC.cellWidget(i, indices[j]).layout().itemAt(2).widget()
			 	
							if pd.isna(df_.iloc[i, j]):
								plus_button.setVisible(True)
								cross_button.setVisible(False)
								date_edit.setVisible(False) 				
								
							else:
								plus_button.setVisible(False)
								cross_button.setVisible(True)
								date_edit.setVisible(True)
								if isinstance(df_.iloc[i, j], datetime):
									datedit = df_.iloc[i, j]
									year = datedit.year
									month = datedit.month
									day = datedit.day
									hour = datedit.hour
									minute = datedit.minute
									q_date_time = QDateTime(QDate(year, month, day), QTime(hour, minute))
									# print(i, j, df_.iloc[i, j], q_date_time)
									date_edit.setDateTime(q_date_time)  
									
					self.excelAndTableColumnsMappingWindow.close()

					scMsgBox = QMessageBox()
					scMsgBox.setIcon(QMessageBox.Information) 
					scMsgBox.setText('SC Data Imported Successfully')
					scMsgBox.setWindowTitle("Message")
					scMsgBox.setWindowIcon(QIcon('Media/ramsify.png'))
					scMsgBox.setStandardButtons(QMessageBox.Ok)
					scMsgBox.exec_()
				

				
				self.submitImportedExcelData.clicked.connect(mapData)	

				self.excelAndTableColumnsMappingWindow.show()
			

	self.importButton_SC.clicked.connect(onClickingimportButton_SC)
	


	def exportSCInputTemplate():
		file_path, _ = QFileDialog.getSaveFileName(None, "Save Excel File", "", "Excel Files (*.xlsx)")

		if file_path:

			headersOfSCImportTableTemplate = []
			for j in range(self.tablewidget_SC.columnCount()):  
				if not self.tablewidget_SC.isColumnHidden(j):
					header_item = self.tablewidget_SC.horizontalHeaderItem(j)
					if header_item is not None:
						headersOfSCImportTableTemplate.append(header_item.text())      

			df = pd.DataFrame([headersOfSCImportTableTemplate])

			df.to_excel(file_path, index=False, header=False)

			msg = QMessageBox()
			msg.setIcon(QMessageBox.Information)
			msg.setText("Exported Successfully")
			msg.setWindowTitle("Message")
			msg.setWindowIcon(QIcon('Media/ramsify.png'))
			msg.exec_()

	self.templateButton_SC.clicked.connect(exportSCInputTemplate)

	###############################################################


	def showSummaryWidget():
		if self.yearCombobox_SC.currentText() != '':
			self.yearCombobox_SC.setProperty("error", False)
			self.yearCombobox_SC.setStyleSheet(self.comboBoxQSS)
			if self.monthCombobox_SC.currentText() != '':
				self.monthCombobox_SC.setProperty("error", False)
				self.monthCombobox_SC.setStyleSheet(self.comboBoxQSS)

				self.summaryWidget_SC = QWidget()
				self.summaryWidget_SC.setGeometry(100, 100, 1100, 600) 
				self.summaryWidget_SC.setWindowTitle("Summary")
				self.summaryWidget_SC.setWindowIcon(QIcon('Media/ramsify.png'))

				tableWidgetInPopUp_SC = TableWidget(len(self.trainsetsList), 8)
				tableWidgetInPopUp_SC.setHorizontalHeaderLabels(['Trains', 'A', 'B1', 'B4', 'B8', 'C1', 'C2','Downtime (hours)'])
				tableWidgetInPopUp_SC.setEditTriggers(QAbstractItemView.NoEditTriggers)
				tableWidgetInPopUp_SC.setStyleSheet(self.tableWidgetQSS)
				tableWidgetInPopUp_SC.horizontalHeader().setStyleSheet(self.headerHorizontalQSS)
				tableWidgetInPopUp_SC.setAlternatingRowColors(True)
				tableWidgetInPopUp_SC.setShowGrid(False)

				




				for i, train in enumerate(self.trainsetsList):
					item = QTableWidgetItem(train)
					tableWidgetInPopUp_SC.setItem(i, 0, item)
			   
			
				for row in range(self.tablewidget_SC.rowCount()):
					# Initialize counts for each category
					count_a = 0
					count_b1 = 0
					count_b4 = 0
					count_b8 = 0
					count_c1 = 0
					count_c2 = 0

					for col in range(1, 4): 
						cell_widget = self.tablewidget_SC.cellWidget(row, col)
						if cell_widget:
							date_edit = cell_widget.layout().itemAt(1).widget()
							if date_edit.isVisible():
								count_a += 1
							
					for col in range(4, 6): 
						cell_widget = self.tablewidget_SC.cellWidget(row, col)
						if cell_widget:
							date_edit = cell_widget.layout().itemAt(1).widget()
							if date_edit.isVisible():
									count_b1 += 1
				   

					cell_widget = self.tablewidget_SC.cellWidget(row, 6)
					if cell_widget:
						date_edit = cell_widget.layout().itemAt(1).widget()
						if date_edit.isVisible():
							count_b4 += 1


					cell_widget = self.tablewidget_SC.cellWidget(row, 7)
					if cell_widget:
						date_edit = cell_widget.layout().itemAt(1).widget()
						if date_edit.isVisible():
							count_b8 += 1
			

					cell_widget = self.tablewidget_SC.cellWidget(row, 8)
					if cell_widget:
						date_edit = cell_widget.layout().itemAt(1).widget()
						if date_edit.isVisible():
							count_c1 += 1
				

					cell_widget = self.tablewidget_SC.cellWidget(row, 9)
					if cell_widget:
						date_edit = cell_widget.layout().itemAt(1).widget()
						if date_edit.isVisible():
							count_c2 += 1


					tableWidgetInPopUp_SC.setItem(row, 1, QTableWidgetItem(str(count_a)))
					tableWidgetInPopUp_SC.setItem(row, 2, QTableWidgetItem(str(count_b1)))
					tableWidgetInPopUp_SC.setItem(row, 3, QTableWidgetItem(str(count_b4)))
					tableWidgetInPopUp_SC.setItem(row, 4, QTableWidgetItem(str(count_b8)))
					tableWidgetInPopUp_SC.setItem(row, 5, QTableWidgetItem(str(count_c1)))
					tableWidgetInPopUp_SC.setItem(row, 6, QTableWidgetItem(str(count_c2)))
							
					downtime = (count_a * self.ASCHours) + (count_b1 * self.B1SCHours) + (count_b4 * self.B4SCHours) + (count_b8 * self.B8SCHours) + (count_c1 * self.C1SCHours) + (count_c2 * self.C2SCHours)
					tableWidgetInPopUp_SC.setItem(row, 7, QTableWidgetItem(str(downtime)))

				tableWidgetInPopUp_SC.setColumnHidden(5, True)
				tableWidgetInPopUp_SC.setColumnHidden(6, True)

				for row in range(tableWidgetInPopUp_SC.rowCount()):
					for col in range(tableWidgetInPopUp_SC.columnCount()):
						item = tableWidgetInPopUp_SC.item(row, col)
						if item:
							item.setFlags(item.flags() ^ Qt.ItemIsEditable)


				for row in range(tableWidgetInPopUp_SC.rowCount()):
					for col in range(1,tableWidgetInPopUp_SC.columnCount()):
						item = tableWidgetInPopUp_SC.item(row, col)
						if item:
							item.setTextAlignment(Qt.AlignCenter)

				VLayoutForPopUp_SC = QVBoxLayout(self.summaryWidget_SC)
				VLayoutForPopUp_SC.addWidget(tableWidgetInPopUp_SC)

				self.createPushButton('saveButtonInPopUp_SC', 'Save')
				VLayoutForPopUp_SC.addWidget(self.saveButtonInPopUp_SC, alignment = Qt.AlignCenter)
			
			
				def saveData_SC():
					year_SC = int(self.yearCombobox_SC.currentText())
					month_SC = int(self.monthCombobox_SC.currentText())

					sc_id = 'SC' + '_' + datetime.now().strftime("%Y%m%d%H%M%S%f")[:-4]

					for tablRow in range(self.tablewidget_SC.rowCount()): 
						rowData = [year_SC, month_SC, sc_id]
						for cols in range(1, self.tablewidget_SC.columnCount()):
							cellWidget_ = self.tablewidget_SC.cellWidget(tablRow, cols)
							
							if cellWidget_:
								dateEdit_ = cellWidget_.layout().itemAt(1).widget()
								if dateEdit_.isVisible():
									dateTimeValue = dateEdit_.dateTime().toString("yyyy-MM-dd HH:mm")
									rowData.append(dateTimeValue)
								else:
									rowData.append(None)

						item = tableWidgetInPopUp_SC.item(tablRow, 7)
						rowData.append(float(item.text()))
						rowData.append(self.user_id)

						rowData.append(self.tablewidget_SC.cellWidget(tablRow,0).text())

						query = """
						INSERT INTO service_checks
						(year, month, sc_id, trainset_id, A_1, A_2, A_3, B1_1, B1_2, B4, B8, C1, C2, downtime, user_id)
						SELECT %s, %s, %s, trainsets.id, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s
						FROM trainsets
						WHERE trainsets.trainset = %s;
						"""
						
						self.cursor.execute(query, tuple(rowData))
					self.mydb.commit()

					scMsgBox = QMessageBox()
					scMsgBox.setIcon(QMessageBox.Information) 
					scMsgBox.setText(f'Data submitted successfully.\nID:{sc_id}')
					scMsgBox.setWindowTitle("Message")
					scMsgBox.setWindowIcon(QIcon('Media/ramsify.png'))
					scMsgBox.setStandardButtons(QMessageBox.Ok)
					scMsgBox.exec_()

					self.summaryWidget_SC.close()
					yearInCB = int(self.yearCombobox_SC.currentText())
					monthInCB = int(self.monthCombobox_SC.currentText())

					if monthInCB != 12:
						self.yearCombobox_SC.clear()
						self.monthCombobox_SC.clear()
						self.yearCombobox_SC.addItem(str(yearInCB))
						self.monthCombobox_SC.addItem(str(monthInCB+1))

						for row in range(self.tablewidget_SC.rowCount()):
							for col in range(1, self.tablewidget_SC.columnCount()): 
								cell_widget = self.tablewidget_SC.cellWidget(row, col)
								if cell_widget:
									dateTimeEdit = cell_widget.layout().itemAt(1).widget()
									min_dateTime = QDateTime(QDate(yearInCB, monthInCB+1, 1), QTime(0, 0))
									dateTimeEdit.setMinimumDateTime(min_dateTime)

									_, last_day = calendar.monthrange(yearInCB, monthInCB+1)
									max_dateTime = QDateTime(QDate(yearInCB, monthInCB+1, last_day), QTime(23, 59))
									dateTimeEdit.setMaximumDateTime(max_dateTime)

					else:
						self.yearCombobox_SC.clear()
						self.monthCombobox_SC.clear()
						self.yearCombobox_SC.addItem(str(yearInCB+1))
						self.monthCombobox_SC.addItem(str(1))

						for row in range(self.tablewidget_SC.rowCount()):
							for col in range(1, self.tablewidget_SC.columnCount()): 
								cell_widget = self.tablewidget_SC.cellWidget(row, col)
								if cell_widget:
									dateTimeEdit = cell_widget.layout().itemAt(1).widget()
									min_dateTime = QDateTime(QDate(yearInCB+1, 1, 1), QTime(0, 0))
									dateTimeEdit.setMinimumDateTime(min_dateTime)

									_, last_day = calendar.monthrange(yearInCB+1, 1)
									max_dateTime = QDateTime(QDate(yearInCB+1, 1, last_day), QTime(23, 59))
									dateTimeEdit.setMaximumDateTime(max_dateTime)





					self.cancelButton_SC.click()

					totalDownTime = 0
					for r in range(tableWidgetInPopUp_SC.rowCount()):
						totalDownTime += float(tableWidgetInPopUp_SC.item(r, 7).text())
					self.scDataTable.setRowCount(self.scDataTable.rowCount()+1)
					new_data = [year_SC, month_SC, totalDownTime]
					
					button = QPushButton(str(sc_id))
					button.setStyleSheet("QPushButton { text-decoration: none; }"
						"QPushButton:hover { text-decoration: underline; }")
					button.setCursor(Qt.PointingHandCursor)
					self.scDataTable.setCellWidget(self.scDataTable.rowCount()-1, 0, button)
					button.clicked.connect(lambda : onButtonClicked_SC(self, button.text()))


					for c, value in enumerate(new_data):
						item = QTableWidgetItem(str(value))
						item.setTextAlignment(Qt.AlignCenter)
						item.setFlags(item.flags() ^ Qt.ItemIsEditable)
						self.scDataTable.setItem(self.scDataTable.rowCount()-1, c+1, item)

				self.saveButtonInPopUp_SC.clicked.connect(saveData_SC)

				self.summaryWidget_SC.show()
			else:
				self.monthCombobox_SC.setProperty("error", True)
				self.monthCombobox_SC.setStyleSheet(self.comboBoxQSS)
		else:
			self.yearCombobox_SC.setProperty("error", True)
			self.yearCombobox_SC.setStyleSheet(self.comboBoxQSS)
	self.submitButton_SC.clicked.connect(showSummaryWidget)


	def onClcickingCancel_sc():
		for row in range(self.tablewidget_SC.rowCount()):
			for col in range(1, self.tablewidget_SC.columnCount()): 
				cell_widget = self.tablewidget_SC.cellWidget(row, col)
				if cell_widget:
					crossBtn = cell_widget.layout().itemAt(2).widget()
					if crossBtn.isVisible():
						crossBtn.click()

		self.monthCombobox_SC.setCurrentIndex(-1)
		self.yearCombobox_SC.setCurrentIndex(-1)



	self.cancelButton_SC.clicked.connect(onClcickingCancel_sc)