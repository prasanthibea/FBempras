from functions import *
from configuration import *
from settings import *

def settingThemeFunction(self):
	self.widget_1.setStyleSheet('#scrollArea_1{border: 0px solid white; border-top-left-radius: 25px; border-top-right-radius: 0px; border-bottom-right-radius: 0px}')
	self.widget_2.setStyleSheet('#scrollArea_2{border: 0px solid white; border-top-left-radius: 25px; border-top-right-radius: 0px; border-bottom-right-radius: 0px}')
	self.widget_3.setStyleSheet('#scrollArea_3{border: 0px solid white; border-top-left-radius: 25px; border-top-right-radius: 0px; border-bottom-right-radius: 0px}')
	self.widget_4.setStyleSheet('#scrollArea_4{border: 0px solid white; border-top-left-radius: 25px; border-top-right-radius: 0px; border-bottom-right-radius: 0px}')
	self.widget_5.setStyleSheet('#scrollArea_5{border: 0px solid white; border-top-left-radius: 25px; border-top-right-radius: 0px; border-bottom-right-radius: 0px}')
	self.widget_6.setStyleSheet('#scrollArea_6{border: 0px solid white; border-top-left-radius: 25px; border-top-right-radius: 0px; border-bottom-right-radius: 0px}')
	self.widget_7.setStyleSheet('#scrollArea_7{border: 0px solid white; border-top-left-radius: 25px; border-top-right-radius: 0px; border-bottom-right-radius: 0px}')
	self.widget_8.setStyleSheet('#scrollArea_8{border: 0px solid white; border-top-left-radius: 25px; border-top-right-radius: 0px; border-bottom-right-radius: 0px}')
	self.widget_9.setStyleSheet('#scrollArea_9{border: 0px solid white; border-top-left-radius: 25px; border-top-right-radius: 0px; border-bottom-right-radius: 0px}')
	self.widget_10.setStyleSheet('#scrollArea_10{border: 0px solid white; border-top-left-radius: 25px; border-top-right-radius: 0px; border-bottom-right-radius: 0px}')
	self.widget_11.setStyleSheet('#scrollArea_11{border: 0px solid white; border-top-left-radius: 25px; border-top-right-radius: 0px; border-bottom-right-radius: 0px}')
	self.widget_12.setStyleSheet('#scrollArea_12{border: 0px solid white; border-top-left-radius: 25px; border-top-right-radius: 0px; border-bottom-right-radius: 0px}')
	self.widget_13.setStyleSheet('#scrollArea_13{border: 0px solid white; border-top-left-radius: 25px; border-top-right-radius: 0px; border-bottom-right-radius: 0px}')
	self.widget_14.setStyleSheet('#scrollArea_14{border: 0px solid white; border-top-left-radius: 25px; border-top-right-radius: 0px; border-bottom-right-radius: 0px}')
 	

	self.leftMenuWidget.setStyleSheet(self.leftMenuQSS)
	self.settingsWidget.setStyleSheet(self.widgetQSS)
	self.fontCombobox.setStyleSheet(self.comboBoxQSS)
	self.themeCombobox.setStyleSheet(self.comboBoxQSS)
	self.setStyleSheet(self.mainWindowQSS)
	self.sideMenuTree.setStyleSheet(self.sideMenuTreeQSS)
	self.toolBar.setStyleSheet(self.toolBarQSS)
	self.menuBtn.setIcon(QIcon(self.currentTheme.get('menuIcon')))
	

	image_path = 'Media/ramsify2.png'
	pixmap = QPixmap(image_path)

	self.logoLabel.setPixmap(pixmap)