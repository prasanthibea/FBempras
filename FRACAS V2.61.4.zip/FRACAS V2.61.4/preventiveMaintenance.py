from PySide6.QtWidgets import (QVBoxLayout, QFormLayout, QLabel, QWidget, QPushButton, QGroupBox, QLineEdit, QSpacerItem, QSizePolicy, QScrollArea, QApplication,
							QGridLayout,QHBoxLayout, QComboBox, QTextEdit, QTimeEdit, QDateEdit, QMessageBox, QFileDialog, QSpinBox, QTableWidgetItem, QAbstractItemView)
from PySide6.QtCore import Qt, QDateTime
from PySide6.QtGui import QIcon, QBrush, QColor

from datetime import datetime, timedelta, time, date
from dateutil.relativedelta import relativedelta
from PySide6.QtCore import Qt, QDate, QTime, QDateTime
import pandas as pd

from QSSS import *

from functions import createLineEditBox, createTextEditBox,  createLayout, createDateEditBox, createTimeEditBox, createSpinBox, TableWidget, logErrors, CustomComboBox, timeLineEdit
from databaseData import databaseData
from opmData import onButtonClicked_opmData
import os
import shutil

def OPMUI(self, tab):
	from PySide6.QtWidgets import QApplication
	self.OPMMainLayout = QVBoxLayout()

	# Create a label for the page
	# self.labelOfOPMForm = QLabel('Preventive Maintenance', tab)
	# self.OPMMainLayout.addWidget(self.labelOfOPMForm, alignment = Qt.AlignCenter)

	## To open OPM table:
	self.createPushButton('openOPMtableButton_OPM', 'Import',  width=int(0.075 * QApplication.primaryScreen().availableGeometry().width()), tooltip='Import OPM From Excel')
	self.OPMMainLayout.addWidget(self.openOPMtableButton_OPM, alignment = Qt.AlignRight)


	## Type of OPM :
	self.typeOfOPMList = ['Cyclic Check', 'Fleet Check', 'HECP', 'SECP', 'Testing', 'Others']


	OPMTabwidget = QWidget(tab)
	self.OPMMainLayout.addWidget(OPMTabwidget)

	OPMTabVLayout = QVBoxLayout(OPMTabwidget)

	
	#######################################################
	## Create a form with the fields which will get the OPM input data:
	formLayout_OPM = QFormLayout()
	OPMTabVLayout.addLayout(formLayout_OPM)


	self.createDateEditBox('eventDateEdit_OPM')
	currentYear = datetime.now().year
	currentMonth = datetime.now().month

	firstDayOfCurrentMonth = datetime(currentYear, currentMonth, 1).date()
	lastDateOfPreviousMonth = (firstDayOfCurrentMonth - relativedelta(days=1))

	firstDateOfPreviousMonth = QDate(lastDateOfPreviousMonth.year, lastDateOfPreviousMonth.month, 1)
	
	if firstDateOfPreviousMonth < QDate(self.startingYear, self.startingMonth, 1):
		firstDateOfPreviousMonth = QDate(self.startingYear, self.startingMonth, 1)

	# if self.userRole != 0:
	# 	self.eventDateEdit_OPM.setMinimumDate(firstDateOfPreviousMonth)

	# if (self.userName == 'Ravikumar') and (self.editableOptionMaxDate > datetime.now().date()):
	# 	self.eventDateEdit_OPM.setMinimumDate(QDate(self.startingYear, self.startingMonth, 1))

	self.createTimeEditBox('eventTimeEdit_OPM')
	self.createComboBox2(self.depotsList, 'depotCombobox_OPM')
	self.createCheckableComboBox(self.trainsetsList, 'trainCombobox_OPM')
	self.createCheckableComboBox(self.carsList, 'carCombobox_OPM')
	self.createComboBox2(self.typeOfOPMList, 'typeOf_OPM')
	self.createTextEditBox('faultDetailsTextBox_OPM')
	self.createTextEditBox('workdoneTextBox_OPM')
	self.createComboBox2(self.BOMSystemDictionary.keys(), 'systemComboBox_OPM')
	self.systemComboBox_OPM.setFixedWidth(int(0.15 * QApplication.primaryScreen().availableGeometry().width()))
	self.createComboBox2([], 'subSystemComboBox_OPM')
	self.subSystemComboBox_OPM.setFixedWidth(int(0.15 * QApplication.primaryScreen().availableGeometry().width()))

	self.createLineEditBox('othersubsystemLineEdit_OPM')
	self.createNumberLineEditBox('quantity_OPM')
	

	self.createDateEditBox('workStartDate_OPM')
	# if self.userRole != 0:
	# 	self.workStartDate_OPM.setMinimumDate(firstDateOfPreviousMonth)
		
	# if (self.userName == 'Ravikumar') and (self.editableOptionMaxDate > datetime.now().date()):
	# 	self.workStartDate_OPM.setMinimumDate(QDate(self.startingYear, self.startingMonth, 1))

	self.createTimeEditBox('workStartTime_OPM')
	self.createDateEditBox('workEndDate_OPM')
	# if self.userRole != 0:
	# 	self.workEndDate_OPM.setMinimumDate(firstDateOfPreviousMonth)

	# if (self.userName == 'Ravikumar') and (self.editableOptionMaxDate > datetime.now().date()):
	# 	self.workEndDate_OPM.setMinimumDate(QDate(self.startingYear, self.startingMonth, 1))

	self.createTimeEditBox('workEndTime_OPM')
	self.downTime_opm = QLabel('0')

	self.createLineEditBox('jobcardLineEdit_OPM')
	self.createAttachmentWidget('mianAttachment_OPM')
	self.mianAttachment_OPM.fileListWidget.setMinimumHeight(140)
	
	
	self.listOfWidgets_OPM = [self.eventDateEdit_OPM, self.eventTimeEdit_OPM, self.depotCombobox_OPM, self.trainCombobox_OPM, self.carCombobox_OPM, self.typeOf_OPM,
					self.faultDetailsTextBox_OPM, self.workdoneTextBox_OPM, self.systemComboBox_OPM, self.subSystemComboBox_OPM, self.othersubsystemLineEdit_OPM, self.jobcardLineEdit_OPM, self.workStartDate_OPM, self.workStartTime_OPM,
					self.workEndDate_OPM, self.workEndTime_OPM, self.downTime_opm, self.quantity_OPM]


	
	self.trainCombobox_OPM.setEnabled(False)
	self.subSystemComboBox_OPM.setEnabled(False)

	## Function to dynamically update the trainset combobox based on the depo selection:
	def onChangingDepotCombobox_OPM():

		selected_depot = self.depotCombobox_OPM.currentText()
		if selected_depot:
			self.trainCombobox_OPM.setEnabled(True)
			self.trainCombobox_OPM.clear()
			self.trainCombobox_OPM.addItems(self.depotTrainDictionary[selected_depot])
	
	self.depotCombobox_OPM.currentIndexChanged.connect(onChangingDepotCombobox_OPM)

	## Function to dynamically update the subsytem combobox based on the system selection:
	def onSystemComboboxChanged_OPM():

		selected_system = self.systemComboBox_OPM.currentText()
		if selected_system:
			self.subSystemComboBox_OPM.setEnabled(True)
			self.subSystemComboBox_OPM.clear()
			self.subSystemComboBox_OPM.addItems(self.BOMSystemDictionary[selected_system])
	
	self.systemComboBox_OPM.currentIndexChanged.connect(onSystemComboboxChanged_OPM)


	def onSubsystemComboboxChanged_OPM():
		selected_subsystem = self.subSystemComboBox_OPM.currentText()

		if selected_subsystem =='Others':
			self.othersubsystemLineEdit_OPM.setEnabled(True)
		else:
			self.othersubsystemLineEdit_OPM.clear()
			self.othersubsystemLineEdit_OPM.setEnabled(False)

	self.subSystemComboBox_OPM.currentIndexChanged.connect(onSubsystemComboboxChanged_OPM)


	## Function to dynamically update the time based on the change of datetime edit:
	def onWorkDateTimeChanged_OPM():

		workStartDate = self.workStartDate_OPM.date().toPython()
		workStartTime = self.workStartTime_OPM.time().toPython().replace(second=0, microsecond=0)
		workEndDate = self.workEndDate_OPM.date().toPython()
		workEndTime = self.workEndTime_OPM.time().toPython().replace(second=0, microsecond=0)

		startDateTime = datetime.combine(workStartDate, workStartTime)
		endDateTime = datetime.combine(workEndDate, workEndTime)

		timeDifference = endDateTime - startDateTime
		minutesDifference = timeDifference.total_seconds() / 60

		if endDateTime < startDateTime:
			self.workEndDate_OPM.setDate(self.workStartDate_OPM.date())
			self.workEndTime_OPM.setTime(self.workStartTime_OPM.time())

			endDateTime = datetime.combine(workStartDate, workStartTime)
			timeDifference = endDateTime - startDateTime
			minutesDifference = timeDifference.total_seconds() / 60

		self.downTime_opm.setText(str(int(minutesDifference)))
		

	self.workStartDate_OPM.dateChanged.connect(onWorkDateTimeChanged_OPM)
	self.workStartTime_OPM.timeChanged.connect(onWorkDateTimeChanged_OPM)
	self.workEndDate_OPM.dateChanged.connect(onWorkDateTimeChanged_OPM)
	self.workEndTime_OPM.timeChanged.connect(onWorkDateTimeChanged_OPM)


	hLayoutForEventDateTime_OPMTab = QHBoxLayout()
	hLayoutForEventDateTime_OPMTab.addWidget(self.eventDateEdit_OPM)
	hLayoutForEventDateTime_OPMTab.addWidget(self.eventTimeEdit_OPM)

	hLayoutForWorkStartDateAndTime_OPMTab = QHBoxLayout()
	hLayoutForWorkStartDateAndTime_OPMTab.addWidget(self.workStartDate_OPM)
	hLayoutForWorkStartDateAndTime_OPMTab.addWidget(self.workStartTime_OPM)


	hLayoutForWorkEndDateAndTime_OPMTab = QHBoxLayout()
	hLayoutForWorkEndDateAndTime_OPMTab.addWidget(self.workEndDate_OPM)
	hLayoutForWorkEndDateAndTime_OPMTab.addWidget(self.workEndTime_OPM)



	#######################################################

	hLayoutForSubSystemAndOtherSubsystem_OPMTab = QHBoxLayout()
	hLayoutForSubSystemAndOtherSubsystem_OPMTab.addWidget(self.subSystemComboBox_OPM)
	hLayoutForSubSystemAndOtherSubsystem_OPMTab.addWidget(self.othersubsystemLineEdit_OPM)
	self.othersubsystemLineEdit_OPM.setEnabled(False)

	#######################################################

	formLayout_OPM.addRow('Event Date & Time:<font color="red">*</font>', hLayoutForEventDateTime_OPMTab)
	formLayout_OPM.addRow('Depot:<font color="red">*</font>', self.depotCombobox_OPM)
	formLayout_OPM.addRow('Trainset:<font color="red">*</font>', self.trainCombobox_OPM)
	formLayout_OPM.addRow('Car No:', self.carCombobox_OPM)
	formLayout_OPM.addRow('Type of OPM:<font color="red">*</font>', self.typeOf_OPM)
	formLayout_OPM.addRow('Fault Details/Nature of work:', self.faultDetailsTextBox_OPM)
	formLayout_OPM.addRow('Investigation/Workdone details:', self.workdoneTextBox_OPM)
	formLayout_OPM.addRow('System:<font color="red">*</font>', self.systemComboBox_OPM)
	formLayout_OPM.addRow('Sub-Sytem:<font color="red">*</font>', hLayoutForSubSystemAndOtherSubsystem_OPMTab)
	formLayout_OPM.addRow('Quantity:<font color="red">*</font>', self.quantity_OPM)
	formLayout_OPM.addRow('Work Start Date & Time:<font color="red">*</font>', hLayoutForWorkStartDateAndTime_OPMTab)
	formLayout_OPM.addRow('Work End Date & Time:<font color="red">*</font>', hLayoutForWorkEndDateAndTime_OPMTab)
	formLayout_OPM.addRow('Actual Downtime (Minutes):', self.downTime_opm)
	formLayout_OPM.addRow('Jobcard No:', self.jobcardLineEdit_OPM)
	formLayout_OPM.addRow('Attachments:', self.mianAttachment_OPM)


	self.createPushButton('submit_OPM', 'SUBMIT', '', int(0.075 * QApplication.primaryScreen().availableGeometry().width()))
	self.createPushButton('cancel_OPM', 'CANCEL', '', int(0.075 * QApplication.primaryScreen().availableGeometry().width()))

	self.layoutForSubmitAndCancelBtnsOfOPM = QHBoxLayout()
	self.layoutForSubmitAndCancelBtnsOfOPM.addWidget(self.submit_OPM, alignment = Qt.AlignRight)
	self.layoutForSubmitAndCancelBtnsOfOPM.addWidget(self.cancel_OPM, alignment = Qt.AlignLeft)

	self.OPMMainLayout.addLayout(self.layoutForSubmitAndCancelBtnsOfOPM)



	

	
	def openOPMTableWindow():
		
		OPMImportWindowWidth = int(0.8* QApplication.primaryScreen().availableGeometry().width())
		OPMImportWindowHeight = int(0.6 * QApplication.primaryScreen().availableGeometry().height())

		self.OPMImportWindow = QWidget()
		self.OPMImportWindow.setWindowIcon(QIcon('Media/ramsify.png'))
		self.OPMImportWindow.setWindowTitle('OPM Data Input')
		self.OPMImportWindow.setStyleSheet(self.widgetQSS)
		self.OPMImportWindow.resize(OPMImportWindowWidth, OPMImportWindowHeight )
		self.OPMImportWindowLayout = QVBoxLayout()


		self.headingLabelOfOPMDataImport = QLabel('Preventive Maintenance Data Input Table')
		self.headingLabelOfOPMDataImport.setStyleSheet("font-size: 18pt;")
		self.headingLabelOfOPMDataImport.setContentsMargins(20, 0, 0, 0)

		self.OPMImportWindowLayout.addWidget(self.headingLabelOfOPMDataImport, alignment=Qt.AlignCenter)

		layoutForButtons_OPMImport = QHBoxLayout()
		self.OPMImportWindowLayout.addLayout(layoutForButtons_OPMImport)


		headersOfOPMImportTable = ['Event Date', 'Event Time', 'Depot', 'Trainset', 'Car Number', 'Type of OPM' ,'Nature of Work', 'Workdone Details', 'System', 'Sub-System', 'Other Sub-System', 'Jobcard No',
									'Attachments', 'Workstart Date', 'Workstart Time', 'Workend Date', 'Workend Time', 'Work Downtime(Mins)', '']
		
		HLayoutForTableAndMissingFileds_OPM = QHBoxLayout()
		self.OPMImportWindowLayout.addLayout(HLayoutForTableAndMissingFileds_OPM)

		self.OPMImportTable = TableWidget()
		self.OPMImportTable.setColumnCount(len(headersOfOPMImportTable))
		self.OPMImportTable.setHorizontalHeaderLabels(headersOfOPMImportTable)
		self.OPMImportTable.setStyleSheet(self.tableWidgetQSS)
		self.OPMImportTable.horizontalHeader().setStyleSheet(self.headerHorizontalQSS)
		# self.OPMImportTable.verticalHeader().setStyleSheet(self.headerVerticalQSS)
		self.OPMImportTable.setAlternatingRowColors(True)
		self.OPMImportTable.setShowGrid(False)
		HLayoutForTableAndMissingFileds_OPM.addWidget(self.OPMImportTable)
		self.OPMImportTable.setEditTriggers(QAbstractItemView.NoEditTriggers)

		self.OPMImportWindow.setLayout(self.OPMImportWindowLayout)

		self.OPMImportTable.setColumnWidth(0, int(0.07 * QApplication.primaryScreen().availableGeometry().width()))
		self.OPMImportTable.setColumnWidth(1, int(0.06 * QApplication.primaryScreen().availableGeometry().width()))
		self.OPMImportTable.setColumnWidth(2, int(0.07 * QApplication.primaryScreen().availableGeometry().width()))
		self.OPMImportTable.setColumnWidth(3, int(0.07 * QApplication.primaryScreen().availableGeometry().width()))
		self.OPMImportTable.setColumnWidth(4, int(0.07 * QApplication.primaryScreen().availableGeometry().width()))
		self.OPMImportTable.setColumnWidth(5, int(0.07 * QApplication.primaryScreen().availableGeometry().width()))
		self.OPMImportTable.setColumnWidth(6, int(0.09 * QApplication.primaryScreen().availableGeometry().width()))
		self.OPMImportTable.setColumnWidth(7, int(0.08 * QApplication.primaryScreen().availableGeometry().width()))
		self.OPMImportTable.setColumnWidth(8, int(0.15 * QApplication.primaryScreen().availableGeometry().width()))
		self.OPMImportTable.setColumnWidth(9, int(0.15 * QApplication.primaryScreen().availableGeometry().width()))
		self.OPMImportTable.setColumnWidth(10, int(0.1 * QApplication.primaryScreen().availableGeometry().width()))
		self.OPMImportTable.setColumnWidth(11, int(0.1 * QApplication.primaryScreen().availableGeometry().width()))
		self.OPMImportTable.setColumnWidth(12, int(0.08 * QApplication.primaryScreen().availableGeometry().width()))
		self.OPMImportTable.setColumnWidth(13, int(0.08 * QApplication.primaryScreen().availableGeometry().width()))
		self.OPMImportTable.setColumnWidth(14, int(0.08 * QApplication.primaryScreen().availableGeometry().width()))
		self.OPMImportTable.setColumnWidth(15, int(0.08 * QApplication.primaryScreen().availableGeometry().width()))
		self.OPMImportTable.setColumnWidth(16, int(0.08 * QApplication.primaryScreen().availableGeometry().width()))
		self.OPMImportTable.setColumnWidth(17, int(0.12 * QApplication.primaryScreen().availableGeometry().width()))
		self.OPMImportTable.setColumnWidth(18, int(0.02 * QApplication.primaryScreen().availableGeometry().width()))






		scrollForMissingFields_OPM = QScrollArea()
		scrollForMissingFields_OPM.setWidgetResizable(True)
		scrollForMissingFields_OPM.setStyleSheet(self.scrollAreaQSS)

		scrollForMissingFields_OPM.setMaximumWidth(250)


		self.missingFieldsWidget_OPM = QWidget(self)
		missingFieldsMainLayout_OPM = QVBoxLayout()
		missingFieldsGridLayout_OPM = QGridLayout()
		self.missingFieldsWidget_OPM.setLayout(missingFieldsMainLayout_OPM)
		missingFieldsMainLayout_OPM.addLayout(missingFieldsGridLayout_OPM)
		
		HLayoutForTableAndMissingFileds_OPM.addWidget(scrollForMissingFields_OPM)

		scrollForMissingFields_OPM.setWidget(self.missingFieldsWidget_OPM)
		scrollForMissingFields_OPM.hide()


		self.createLineEditBox('selectFolderForAttachmentsLineEdit_OPMImport')
		self.createPushButton('selectFolderButton_OPMImport', 'Select Folder')
		self.createPushButton('attachButton_OPMImport', 'Attach')

		self.createPushButton('templateButton_OPMImport', '', self.currentTheme.get('exportTemplateIcon'))
		self.templateButton_OPMImport.setToolTip('Export template')
		self.templateButton_OPMImport.setFixedWidth(29)
		self.templateButton_OPMImport.setFixedHeight(25)

		self.createPushButton('importIconButton_OPMImport', '', self.currentTheme.get('importDataIcon'))
		self.importIconButton_OPMImport.setToolTip('Import OPM data')
		self.importIconButton_OPMImport.setFixedWidth(29)
		self.importIconButton_OPMImport.setFixedHeight(25)

		layoutForButtons_OPMImport.addWidget(self.selectFolderForAttachmentsLineEdit_OPMImport)
		self.selectFolderForAttachmentsLineEdit_OPMImport.setEnabled(False)
		layoutForButtons_OPMImport.addWidget(self.selectFolderButton_OPMImport)
		layoutForButtons_OPMImport.addWidget(self.attachButton_OPMImport)
		layoutForButtons_OPMImport.addItem(QSpacerItem(1, 1, QSizePolicy.Expanding, QSizePolicy.Fixed))


		def onClickingSelectFolder_OPMImport():
			folder_path = QFileDialog.getExistingDirectory(self, "Select Folder")
			if folder_path:
				self.selectFolderForAttachmentsLineEdit_OPMImport.setText(str(folder_path))
				
		
				

		self.selectFolderButton_OPMImport.clicked.connect(onClickingSelectFolder_OPMImport)


		def onClickingAttachButton_OPMImport():
			for r in range(self.OPMImportTable.rowCount()):
				item = self.OPMImportTable.item(r, 12)
				if item is not None:
					# self.OPMImportTable.removeItemWidget(item)
					self.OPMImportTable.setItem(r, 12, None)
					del item

			path = self.selectFolderForAttachmentsLineEdit_OPMImport.text()
		
			if os.path.exists(path):
				files = [f for f in os.listdir(path) if os.path.isfile(os.path.join(path, f))]

				for r in range(self.OPMImportTable.rowCount()):
					JCItem = self.OPMImportTable.item(r, 11)
					if JCItem:
						allFiles = []
						for file in files:
							file_name, file_ext = os.path.splitext(file)
							if file_name == JCItem.text():
								allFiles.append(file)

						if len(allFiles) > 0:
							self.OPMImportTable.setItem(r, 12, QTableWidgetItem(str(allFiles)))
						else:
							pass

				
			else:
				QMessageBox.warning(self, "Path Check", f"The path {path} does not exist.")



		self.attachButton_OPMImport.clicked.connect(onClickingAttachButton_OPMImport)


		layoutForButtons_OPMImport.addWidget(self.templateButton_OPMImport)
		layoutForButtons_OPMImport.addWidget(self.importIconButton_OPMImport)


		# Create submit form push button
		self.createPushButton('submitBtnOfImportOPM', 'SUBMIT', width=int(0.050 * QApplication.primaryScreen().availableGeometry().width()) )
		self.submitBtnOfImportOPM.setFixedHeight(30)

		# Create import excel file push button
		self.createPushButton('cancelBtnOfImportOPM', 'CANCEL', width=int(0.050 * QApplication.primaryScreen().availableGeometry().width()))
		self.cancelBtnOfImportOPM.setFixedHeight(30)


		# #Create a horizontal layout to keep the add and import button:
		self.layoutForSubmitAndCancelBtnsOfOPMImport = QHBoxLayout()
		self.layoutForSubmitAndCancelBtnsOfOPMImport.addWidget(self.submitBtnOfImportOPM, alignment = Qt.AlignRight)
		self.layoutForSubmitAndCancelBtnsOfOPMImport.addWidget(self.cancelBtnOfImportOPM, alignment = Qt.AlignLeft)

		
		self.OPMImportWindowLayout.addLayout(self.layoutForSubmitAndCancelBtnsOfOPMImport)



		def onClickingSubmitOPMImportWindow():
			# self.listOfimportedOPMRows = []
			currentDateTimeValue = datetime.now()
			self.missingFields_OPM = []

			mandatorySuccess_OPM = True
			mandatoryFieldsOfImportedExcelRows_OPM = [0, 1, 2, 3, 5, 8, 9, 13, 14, 15, 16]
			self.allSysSubSysListInImport_OPM = []


			if self.OPMImportTable.rowCount() > 0:
				for row_index in range(self.OPMImportTable.rowCount()):
					opm_id_string = 'OPM' + '_' + currentDateTimeValue.strftime("%Y%m%d%H%M%S%f")[:-4]
					currentDateTimeValue += timedelta(milliseconds=10)
					singleRowData_OPM = [opm_id_string]
					
					sysSubsys_OPM = []

					for col_index in range(self.OPMImportTable.columnCount()-1):

						if col_index in [0, 13, 15]:
							if self.OPMImportTable.cellWidget(row_index, col_index):
								widget = self.OPMImportTable.cellWidget(row_index, col_index).layout().itemAt(0).widget()
								if isinstance(widget, QLineEdit):
									if widget.text() != '':
										date = widget.text()
										widget = self.OPMImportTable.cellWidget(row_index, col_index)
										self.OPMImportTable.removeCellWidget(row_index, col_index)
										del widget
										self.OPMImportTable.setItem(row_index, col_index, QTableWidgetItem(str(date)))
									else:
										mandatorySuccess_OPM = False
										self.missingFields_OPM.append((row_index+1, headersOfOPMImportTable[col_index]))


						if col_index in [1, 14, 16]:
							widget = self.OPMImportTable.cellWidget(row_index, col_index)
							if widget:
								if isinstance(widget, QLineEdit):
									if len(widget.text()) == 5:
										time = widget.text()
										self.OPMImportTable.removeCellWidget(row_index, col_index)
										del widget
										self.OPMImportTable.setItem(row_index, col_index, QTableWidgetItem(str(time)))
									else:
										mandatorySuccess_OPM = False
										self.missingFields_OPM.append((row_index+1, headersOfOPMImportTable[col_index]))


						if col_index in [2, 3, 5, 8, 9]:
							widget = self.OPMImportTable.cellWidget(row_index, col_index)
							if widget:
								if widget.isEnabled():
									if isinstance(widget, QComboBox):
										if widget.currentText() != '':
											comboboxText = widget.currentText()
											self.OPMImportTable.removeCellWidget(row_index, col_index)
											del widget
											self.OPMImportTable.setItem(row_index, col_index, QTableWidgetItem(str(comboboxText)))
										else:
											mandatorySuccess_OPM = False
											self.missingFields_OPM.append((row_index+1, headersOfOPMImportTable[col_index]))
								else:
									mandatorySuccess_OPM = False
									self.missingFields_OPM.append((row_index+1, headersOfOPMImportTable[col_index]))
				
						# if col_index in [12]:
						# 	widget = self.OPMImportTable.cellWidget(row_index, col_index)
						# 	if widget:
						# 		if isinstance(widget, QLineEdit):
						# 			if widget.text() == '':
						# 				mandatorySuccess_OPM = False
						# 			else:
						# 				lineEditText = widget.text()
						# 				self.OPMImportTable.removeCellWidget(row_index, col_index)
						# 				del widget
						# 				self.OPMImportTable.setItem(row_index, col_index, QTableWidgetItem(str(lineEditText)))
							

					startDate = None
					startTime = None
					endDate = None
					endTime = None

					# Start Date
					if self.OPMImportTable.item(row_index, self.OPMImportTable.columnCount()-6):
						date_string = self.OPMImportTable.item(row_index, self.OPMImportTable.columnCount()-6).text()
						date_object = datetime.strptime(date_string, "%d-%m-%Y")
						startDate = QDate(date_object.year, date_object.month, date_object.day)

					elif isinstance(self.OPMImportTable.cellWidget(row_index, self.OPMImportTable.columnCount()-6).layout().itemAt(0).widget(), QLineEdit):
						lineEdit = self.OPMImportTable.cellWidget(row_index, self.OPMImportTable.columnCount()-6).layout().itemAt(0).widget()
						startDate_ = lineEdit.text()
						if startDate_ != '':
							startDate = QDate.fromString(startDate_, "dd-MM-yyyy")


					# Start Time
					if self.OPMImportTable.item(row_index, self.OPMImportTable.columnCount()-5):
						time_string = self.OPMImportTable.item(row_index, self.OPMImportTable.columnCount()-5).text()
						time_object = datetime.strptime(time_string, "%H:%M")
						startTime = QTime(time_object.hour, time_object.minute)

					elif isinstance(self.OPMImportTable.cellWidget(row_index, self.OPMImportTable.columnCount()-5), QLineEdit):
						lineEdit = self.OPMImportTable.cellWidget(row_index, self.OPMImportTable.columnCount()-5)
						startTime_ = lineEdit.text()
						if len(startTime_) == 5:
							startTime = QTime.fromString(time_string, "HH:mm")

					

					

					# End Date
					if self.OPMImportTable.item(row_index, self.OPMImportTable.columnCount()-4):
						date_string = self.OPMImportTable.item(row_index, self.OPMImportTable.columnCount()-4).text()
						date_object = datetime.strptime(date_string, "%d-%m-%Y")
						endDate = QDate(date_object.year, date_object.month, date_object.day)

					elif isinstance(self.OPMImportTable.cellWidget(row_index, self.OPMImportTable.columnCount()-4).layout().itemAt(0).widget(), QLineEdit):
						lineEdit = self.OPMImportTable.cellWidget(row_index, self.OPMImportTable.columnCount()-4).layout().itemAt(0).widget()
						endDate_ = lineEdit.text()
						if endDate_ != '':
							endDate = QDate.fromString(endDate_, "dd-MM-yyyy")
					

					# End Time
					if self.OPMImportTable.item(row_index, self.OPMImportTable.columnCount()-3):
						time_string = self.OPMImportTable.item(row_index, self.OPMImportTable.columnCount()-3).text()
						time_object = datetime.strptime(time_string, "%H:%M")
						endTime = QTime(time_object.hour, time_object.minute)

					elif isinstance(self.OPMImportTable.cellWidget(row_index, self.OPMImportTable.columnCount()-3), QLineEdit):
						lineEdit = self.OPMImportTable.cellWidget(row_index, self.OPMImportTable.columnCount()-3)
						startTime_ = lineEdit.text()
						if len(startTime_) == 5:
							endTime = QTime.fromString(time_string, "HH:mm")
			


					
					if startDate and startTime and endDate and endTime:
						startDateTime = QDateTime(startDate, startTime)
						endDateTime = QDateTime(endDate, endTime)

						difference_seconds = startDateTime.secsTo(endDateTime)
						minutes = int(difference_seconds/60)
						if minutes >= 0:
							self.OPMImportTable.setItem(row_index, self.OPMImportTable.columnCount()-2, QTableWidgetItem(str(minutes)))
						else:
							mandatorySuccess_OPM = False
							for colInd in [self.OPMImportTable.columnCount()-4, self.OPMImportTable.columnCount()-6]:
								calenderWidget = QWidget()
								calenderWidget.setStyleSheet('')
								layout = QHBoxLayout()
								calenderWidget.setLayout(layout)
								calenderWidget.setFixedWidth(140)
								layout.setSpacing(0)
								layout.setContentsMargins(0, 0, 0, 0)
								# self.dateBox = QDateEdit()
								# self.dateBox.setCalendarPopup(True)

								self.createDateEditBox('dateBox')
								self.dateBox.setFixedHeight(24)
								self.dateBox.setFixedWidth(19)
								self.dateBox.setButtonSymbols(QDateEdit.NoButtons)
								
								# if self.userRole != 0:
								# 	self.dateBox.setMinimumDate(firstDateOfPreviousMonth)

								# if (self.userName == 'Ravikumar') and (self.editableOptionMaxDate > datetime.now().date()):
								# 	self.dateBox.setMinimumDate(QDate(self.startingYear, self.startingMonth, 1))


								self.dateBox.setStyleSheet("""
									QDateEdit {
									color: transparent;
									border: 1px solid transparent;
									border-radius: 0px;
									}
									QDateEdit:hover {
									border: 1px solid transparent;
									}
									QDateEdit::drop-down{
									border-bottom-right-radius: 1px;
									}
									QDateEdit::down-arrow{
									width: 24px;
									height: 24px;
									image: url('Media/calendar.png');
									}
									""")

								self.createLineEditBox('lineBoxInCalenderWidget')
								self.lineBoxInCalenderWidget.setReadOnly(True)
								self.lineBoxInCalenderWidget.setFixedHeight(24)
								self.lineBoxInCalenderWidget.setFixedWidth(110)
								self.lineBoxInCalenderWidget.setProperty("error", True)
								self.lineBoxInCalenderWidget.setStyleSheet(self.lineEditBoxQSS)
								layout.addWidget(self.lineBoxInCalenderWidget)
								layout.addWidget(self.dateBox)


								def dateChangedd(dateEdit, lineEdit):
									lineEdit.setText(str(dateEdit.date().toString("dd-MM-yyyy")))

								def dateEditFunctionInCell(dateEdit, lineEdit):

									dateEdit.dateChanged.connect(lambda: dateChangedd(dateEdit, lineEdit))

								dateEditFunctionInCell(self.dateBox, self.lineBoxInCalenderWidget)
								


								item = self.OPMImportTable.takeItem(row_index, colInd)
								del item
								self.OPMImportTable.setCellWidget(row_index, colInd, calenderWidget)
								self.missingFields_OPM.append((row_index+1, headersOfOPMImportTable[colInd]))



							for colInd in [self.OPMImportTable.columnCount()-3, self.OPMImportTable.columnCount()-5]:
								TimeLineEdit = timeLineEdit()
								TimeLineEdit.setFixedHeight(28)
								TimeLineEdit.setFixedWidth(120)
								TimeLineEdit.setProperty("error", True)
								TimeLineEdit.setStyleSheet(self.lineEditBoxQSS)
								TimeLineEdit.setStyleSheet(self.lineEditBoxQSS)

								item = self.OPMImportTable.takeItem(row_index, colInd)
								del item
								self.OPMImportTable.setCellWidget(row_index, colInd, TimeLineEdit)
								self.missingFields_OPM.append((row_index+1, headersOfOPMImportTable[colInd]))
				
				if len(self.missingFields_OPM) > 0:
					for index, field in enumerate(self.missingFields_OPM):
						missingFieldsGridLayout_OPM.addWidget(QLabel(str(field[0])), index, 0)
						missingFieldsGridLayout_OPM.addWidget(QLabel(str(field[1])), index, 1)
					missingFieldsGridLayout_OPM.addItem(QSpacerItem(1, 1, QSizePolicy.Fixed, QSizePolicy.Expanding), len(self.missingFields_OPM), 0)
					scrollForMissingFields_OPM.show()
				else:
					scrollForMissingFields_OPM.hide()


				for row in range(self.OPMImportTable.rowCount()):
					for col in range(self.OPMImportTable.columnCount()):
						item = self.OPMImportTable.item(row, col)
						if item:
							item.setToolTip(item.text())

				
				if mandatorySuccess_OPM:
					print('You can save')
					for r in range(self.OPMImportTable.rowCount()):
						opm_id_string = 'OPM' + '_' + currentDateTimeValue.strftime("%Y%m%d%H%M%S%f")[:-4]
						currentDateTimeValue += timedelta(milliseconds=10)
						singleRowData_OPM = [opm_id_string]
						
						sysSubsys_OPM = []

						for c in range(self.OPMImportTable.columnCount()-1):
							if c in [0, 13, 15]:
								item = self.OPMImportTable.item(r, c)
								if item:
									dateString = item.text()
									timeItem = self.OPMImportTable.item(r, c+1)
									if timeItem:
										timeString = timeItem.text()
										datetimeObject = datetime.strptime(dateString + " " + timeString, "%d-%m-%Y %H:%M")
										singleRowData_OPM.append(datetimeObject)

							elif c in [1, 14, 16]:
								pass


							elif c == 8:
								item = self.OPMImportTable.item(r, c)
								if item:
									systemString = item.text()
									query = "SELECT id FROM bom WHERE equipment = %s AND parent_id = 0"
									self.cursor.execute(query, (systemString,))
									result = self.cursor.fetchone()
									singleRowData_OPM.append(result[0])

							elif c == 9:
								item = self.OPMImportTable.item(r, c)
								if item:
									subSystemString = item.text()
									query = "SELECT id FROM bom WHERE parent_id = (SELECT id FROM bom WHERE equipment = %s AND parent_id = 0) AND equipment = %s"
									self.cursor.execute(query, (self.OPMImportTable.item(r, c-1).text(), subSystemString))
									result = self.cursor.fetchone()
									singleRowData_OPM.append(result[0])


							elif c == 27:
								item = self.OPMImportTable.item(r, c)
								attachedFilesList = []
								vall = 0
								if item:
									folder_path = self.selectFolderForAttachmentsLineEdit_OPMImport.text()
									dest_folder = "C:\\ProgramData\\RAMSify\\Attachments"

									if not os.path.exists(dest_folder):
										os.makedirs(dest_folder)

									if os.path.exists(folder_path):
										for filename in os.listdir(folder_path):
											base_name, extension = os.path.splitext(filename)
											if base_name == self.OPMImportTable.item(r, 11).text():
												src_file = os.path.join(folder_path, filename)

												fVal = str(vall)
												if len(str(vall)) == 1:
													fVal = '00'+str(vall)
												elif len(str(vall)) == 2:
													fVal = '0'+str(vall)
												else:
													fVal = str(vall)


												new_filename = f"{base_name}_{datetime.now().strftime('%Y%m%d%H%M%S')}{fVal}{extension}"
												attachedFilesList.append(new_filename)
												dest_file = os.path.join(dest_folder, new_filename)

												shutil.copy(src_file, dest_file)
												vall += 1

									singleRowData_OPM.append(str(attachedFilesList))
								else:
									singleRowData_OPM.append(None)



							else:
								item = self.OPMImportTable.item(r, c)
								if item:
									itemText = item.text()
									singleRowData_OPM.append(itemText)
								else:
									singleRowData_OPM.append(None)	



						insert_query = """
							INSERT INTO other_preventive_maintenance (
							opm_id, event_datetime, depot_id, trainset_id, car_number, opm_type, opm_fault_details, 
							opm_investigation_details, system_id, subsystem_id, other_subsystem, jobcard, attachments, work_start_at, work_end_at, downtime, user_id
							) SELECT
								%s, %s, %s, trainsets.id, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s
							FROM
								trainsets
							WHERE
								trainsets.trainset = %s
						"""

						singleRowData_OPM.append(self.user_id)
						trainset = singleRowData_OPM.pop(3)
						singleRowData_OPM.append(trainset)
						self.cursor.execute(insert_query, tuple(singleRowData_OPM))
						self.mydb.commit()



					msg = QMessageBox()
					msg.setIcon(QMessageBox.Information)
					msg.setText(f"{self.OPMImportTable.rowCount()} OPM's added Successfully")
					msg.setWindowTitle("Message")
					msg.setWindowIcon(QIcon('Media/ramsify.png'))
					msg.exec_()

					self.OPMImportWindow.close()
					self.apply_OPMDT.click()
			

				else:
					msg = QMessageBox()
					msg.setIcon(QMessageBox.Information)
					msg.setText("Please Enter All the Mandatory Fields")
					msg.setWindowTitle("Message")
					msg.setWindowIcon(QIcon('Media/ramsify.png'))
					msg.exec_()
	

			else:
				msg = QMessageBox()
				msg.setIcon(QMessageBox.Information)
				msg.setText("Please Import the Data")
				msg.setWindowTitle("Message")
				msg.setWindowIcon(QIcon('Media/ramsify.png'))
				msg.exec_()

		self.cancelBtnOfImportOPM.clicked.connect(lambda: self.OPMImportWindow.close())
		self.submitBtnOfImportOPM.clicked.connect(onClickingSubmitOPMImportWindow)



		### Export the table into excel file:
		def exportOPMInputTemplate():
			file_path, _ = QFileDialog.getSaveFileName(None, "Save Excel File", "", "Excel Files (*.xlsx)")

			if file_path:
				headersForExcelTemplate_OPM = ['Event Date', 'Event Time', 'Depot', 'Trainset', 'Car Number', 'Type of OPM' ,'Nature of Work', 'Workdone Details', 'System', 'Sub-System', 'Other Sub-System',
												'Quantity', 'Jobcard No', 'Workstart Date', 'Workstart Time', 'Workend Date', 'Workend Time']
				
				df = pd.DataFrame([headersForExcelTemplate_OPM])
				df.to_excel(file_path, index=False, header=False)

				msg = QMessageBox()
				msg.setIcon(QMessageBox.Information)
				msg.setText("Exported Successfully")
				msg.setWindowTitle("Message")
				msg.setWindowIcon(QIcon('Media/ramsify.png'))
				msg.exec_()

		self.templateButton_OPMImport.clicked.connect(exportOPMInputTemplate)


		## Import multiple data from the excel:
		def importOPMDataFromExceltoTable():

			file_path, _ = QFileDialog.getOpenFileName(None, "Select Excel File", "", "Excel Files (*.xlsx)")

			if file_path:
				dataf = pd.read_excel(file_path)
				dataf = dataf.map(lambda x: x.strip() if isinstance(x, str) else x)

				excelHeaders = dataf.columns.tolist()

				excelDataMappingWindowWidth = int(0.3* QApplication.primaryScreen().availableGeometry().width())
				excelDataMappingWindowHeight = int(0.6 * QApplication.primaryScreen().availableGeometry().height())

				self.excelAndTableColumnsMappingWindow = QWidget()
				self.excelAndTableColumnsMappingWindow.setWindowIcon(QIcon('Media/ramsify.png'))
				self.excelAndTableColumnsMappingWindow.setWindowTitle('Map Columns')
				self.excelAndTableColumnsMappingWindow.setStyleSheet(self.widgetQSS)
				self.excelAndTableColumnsMappingWindow.setFixedHeight(excelDataMappingWindowHeight)
				self.excelAndTableColumnsMappingWindow.setFixedWidth(excelDataMappingWindowWidth)

				VLayoutForColumnsMappingWindow = QVBoxLayout()

				columnsMappingHeaderLabel = QLabel('Map Columns')
				columnsMappingHeaderLabel.setAlignment(Qt.AlignHCenter)
				columnsMappingHeaderLabel.setContentsMargins(20, 0, 0, 0)


				scrollArea_ExcelImportWindow = QScrollArea()
				scrollArea_ExcelImportWindow.setStyleSheet(self.scrollAreaQSS)
				scrollArea_ExcelImportWindow.setWidgetResizable(True)
				

				VLayoutForColumnsMappingWindow.addWidget(columnsMappingHeaderLabel)


				excelColumnsWithTableColumnsWidget = QWidget()
				# excelColumnsWithTableColumnsWidget.setAlignment(Qt.AlignTop)

				scrollArea_ExcelImportWindow.setWidget(excelColumnsWithTableColumnsWidget)


				excelAndTableColumnsGridLayout = QGridLayout()

				widgetHeadersLabel = QLabel('Fields')
				widgetHeadersLabel.setStyleSheet("font-size: 13pt;")

				excelHeadersLabel = QLabel('Imported Excel Columns')
				excelHeadersLabel.setStyleSheet("font-size: 13pt;")

				

				excelAndTableColumnsGridLayout.addWidget(widgetHeadersLabel, 0, 0)
				excelAndTableColumnsGridLayout.addWidget(excelHeadersLabel, 0, 1)

				headersForMappingWindow =['Event Date', 'Event Time', 'Depot', 'Trainset', 'Car Number', 'Type of OPM' ,'Nature of Work', 'Workdone Details', 'System', 'Sub-System', 'Other Sub-System', 'Quantity', 'Jobcard No',
								'Workstart Date', 'Workstart Time', 'Workend Date', 'Workend Time']
			
				for i in range(len(headersForMappingWindow)):
					fieldLabel_mappingWindow = QLabel(headersForMappingWindow[i])
					excelAndTableColumnsGridLayout.addWidget(fieldLabel_mappingWindow, i + 1, 0)

					self.createComboBox(excelHeaders, 'excelColumnNames')

					if (headersForMappingWindow[i]).lower() in [s.lower() for s in excelHeaders]:
						for d, header in enumerate(excelHeaders):
							if headersForMappingWindow[i].lower() == header.lower():
								self.excelColumnNames.setCurrentText(excelHeaders[d])
					else:
						self.excelColumnNames.setProperty('error', True)
						self.excelColumnNames.setStyleSheet(self.comboBoxQSS)

					excelAndTableColumnsGridLayout.addWidget(self.excelColumnNames, i + 1, 1)


				excelColumnsWithTableColumnsWidget.setLayout(excelAndTableColumnsGridLayout)

				VLayoutForColumnsMappingWindow.addWidget(scrollArea_ExcelImportWindow)



				self.createPushButton('submitImportedExcelData', 'SUBMIT', width=int(0.050 * QApplication.primaryScreen().availableGeometry().width()))
				self.submitImportedExcelData.setFixedHeight(30)

				self.createPushButton('cancelImportedExcelData', 'CANCEL', width=int(0.050 * QApplication.primaryScreen().availableGeometry().width()))
				self.cancelImportedExcelData.setFixedHeight(30)



				def mapData():
					allSelected = True
					for c in range(excelAndTableColumnsGridLayout.rowCount()):
						if isinstance(excelAndTableColumnsGridLayout.itemAtPosition(c, 1).widget(), QComboBox):

							if excelAndTableColumnsGridLayout.itemAtPosition(c, 1).widget().currentText() != '':
								excelAndTableColumnsGridLayout.itemAtPosition(c, 1).widget().setProperty('error', False)
								excelAndTableColumnsGridLayout.itemAtPosition(c, 1).widget().setStyleSheet(self.comboBoxQSS)
							else:
								allSelected = False


					if allSelected:
						self.excelAndTableColumnsMappingWindow.close()
						excelIndices = []
						for i in range(excelAndTableColumnsGridLayout.rowCount()):
							if excelAndTableColumnsGridLayout.itemAtPosition(i, 1):
								if excelAndTableColumnsGridLayout.itemAtPosition(i, 1).widget():
									if isinstance(excelAndTableColumnsGridLayout.itemAtPosition(i, 1).widget(), CustomComboBox):
										excelIndices.append(excelAndTableColumnsGridLayout.itemAtPosition(i, 1).widget().currentIndex())

						dataf_ = dataf.iloc[:, excelIndices]


						current_date_ = datetime.now()

						currentYear = current_date_.year
						currentMonth = current_date_.month
						firstDayOfCurrentMonth = datetime(currentYear, currentMonth, 1).date()
						lastDateOfPreviousMonth = (firstDayOfCurrentMonth - relativedelta(days=1))
						firstDateOfPreviousMonth = datetime(lastDateOfPreviousMonth.year, lastDateOfPreviousMonth.month, 1).date()

						six_months_ago = current_date_ - relativedelta(months=6)
						firstDateOfSixMonthsAgo_ = six_months_ago.replace(day=1)
						firstDateOfSixMonthsAgo = datetime(firstDateOfSixMonthsAgo_.year, firstDateOfSixMonthsAgo_.month, 1).date()

						if self.userRole == 0:
							minDateToEnter = datetime(self.startingYear, self.startingMonth, 1).date()

						if self.userRole == 1:
							minDateToEnter = firstDateOfSixMonthsAgo

						if self.userRole in [2, 3]:
							minDateToEnter = firstDateOfPreviousMonth
						

						if ((self.userName == 'Ravikumar') and (self.editableOptionMaxDate > datetime.now().date())):
							minDateToEnter = datetime(self.startingYear, self.startingMonth, 1).date()

						def addOPMRow(rowData, color= None):
							for col_index, value in enumerate(rowData):
								if col_index in [0, 13, 15]:

									try:
										if isinstance(value, datetime) and (minDateToEnter < value.date()):
											date_value = value.date()
											formatted_date = date_value.strftime('%d-%m-%Y')
											item = QTableWidgetItem(str(formatted_date))
											if col_index == 0:
												self.OPMImportTable.setItem(self.OPMImportTable.rowCount()-1, col_index, item)
											else:
												self.OPMImportTable.setItem(self.OPMImportTable.rowCount()-1, col_index, item)

										else:

											calenderWidget = QWidget()
											layout = QHBoxLayout()
											calenderWidget.setLayout(layout)
											calenderWidget.setFixedWidth(140)
											layout.setSpacing(0)
											layout.setContentsMargins(0, 0, 0, 0)
											# self.dateBox = QDateEdit()
											# self.dateBox.setCalendarPopup(True)

											self.createDateEditBox('dateBox')
											self.dateBox.setButtonSymbols(QDateEdit.NoButtons)
											self.dateBox.setFixedHeight(24)
											self.dateBox.setFixedWidth(19)


											self.dateBox.setStyleSheet("""
												QDateEdit {
												color: transparent;
												border: 1px solid transparent;
												border-radius: 0px;
												}
												QDateEdit:hover {
												border: 1px solid transparent;
												}
												QDateEdit::drop-down{
												border-bottom-right-radius: 1px;
												}
												QDateEdit::down-arrow{
												width: 24px;
												height: 24px;
												image: url('Media/calendar.png');
												}
												""")

											self.createLineEditBox('lineBoxInCalenderWidget')
											self.lineBoxInCalenderWidget.setReadOnly(True)
											self.lineBoxInCalenderWidget.setFixedHeight(24)
											self.lineBoxInCalenderWidget.setFixedWidth(110)
											self.lineBoxInCalenderWidget.setProperty("error", True)
											self.lineBoxInCalenderWidget.setStyleSheet(self.lineEditBoxQSS)

											# if self.userRole != 0:
											# 	self.dateBox.setMinimumDate(firstDateOfPreviousMonth)

											# if (self.userName == 'Ravikumar') and (self.editableOptionMaxDate > datetime.now().date()):
											# 	self.dateBox.setMinimumDate(QDate(self.startingYear, self.startingMonth, 1))

											layout.addWidget(self.lineBoxInCalenderWidget)
											layout.addWidget(self.dateBox)


											def dateChangedd(dateEdit, lineEdit):
												lineEdit.setText(str(dateEdit.date().toString("dd-MM-yyyy")))

											def dateEditFunctionInCell(dateEdit, lineEdit):

												dateEdit.dateChanged.connect(lambda: dateChangedd(dateEdit, lineEdit))

											dateEditFunctionInCell(self.dateBox, self.lineBoxInCalenderWidget)
											
											if col_index == 0:
												self.OPMImportTable.setCellWidget(self.OPMImportTable.rowCount()-1, col_index, calenderWidget)
												self.missingFields_OPM.append((self.OPMImportTable.rowCount(), headersOfOPMImportTable[col_index]))
											else:
												self.OPMImportTable.setCellWidget(self.OPMImportTable.rowCount()-1, col_index, calenderWidget)
												self.missingFields_OPM.append((self.OPMImportTable.rowCount(), headersOfOPMImportTable[col_index]))

									except ValueError:
										self.createDateEditBox('dateBox')
										# if self.userRole != 0:
										# 	self.dateBox.setMinimumDate(firstDateOfPreviousMonth)

										# if (self.userName == 'Ravikumar') and (self.editableOptionMaxDate > datetime.now().date()):
										# 	self.dateBox.setMinimumDate(QDate(self.startingYear, self.startingMonth, 1))
										if col_index == 0:
											self.OPMImportTable.setCellWidget(self.OPMImportTable.rowCount()-1, col_index, self.dateBox)
											self.missingFields_OPM.append((self.OPMImportTable.rowCount(), headersOfOPMImportTable[col_index]))
										else:
											self.OPMImportTable.setCellWidget(self.OPMImportTable.rowCount()-1, col_index, self.dateBox)
											self.missingFields_OPM.append((self.OPMImportTable.rowCount(), headersOfOPMImportTable[col_index]))


								if col_index in [1, 14, 16]:
									try:
										if str(type(value)) == "<class 'datetime.time'>":
											formatted_time = value.strftime('%H:%M')
											item = QTableWidgetItem(str(formatted_time))
											if col_index == 1:
												self.OPMImportTable.setItem(self.OPMImportTable.rowCount()-1, col_index, item)
											else:
												self.OPMImportTable.setItem(self.OPMImportTable.rowCount()-1, col_index, item)

										else:
											# self.createTimeEditBox('timeBox')
											TimeLineEdit = timeLineEdit()
											TimeLineEdit.setFixedHeight(28)
											TimeLineEdit.setFixedWidth(120)
											TimeLineEdit.setProperty("error", True)
											TimeLineEdit.setStyleSheet(self.lineEditBoxQSS)
											TimeLineEdit.setStyleSheet(self.lineEditBoxQSS)
											if col_index == 1:
												self.OPMImportTable.setCellWidget(self.OPMImportTable.rowCount()-1, col_index, TimeLineEdit)
												self.missingFields_OPM.append((self.OPMImportTable.rowCount(), headersOfOPMImportTable[col_index]))
											else:
												self.OPMImportTable.setCellWidget(self.OPMImportTable.rowCount()-1, col_index, TimeLineEdit)
												self.missingFields_OPM.append((self.OPMImportTable.rowCount(), headersOfOPMImportTable[col_index]))

									except ValueError:
										TimeLineEdit = timeLineEdit()
										TimeLineEdit.setFixedHeight(28)
										TimeLineEdit.setFixedWidth(120)
										TimeLineEdit.setStyleSheet(self.lineEditBoxQSS)
										if col_index == 1:
											self.OPMImportTable.setCellWidget(self.OPMImportTable.rowCount()-1, col_index, TimeLineEdit)
											self.missingFields_OPM.append((self.OPMImportTable.rowCount(), headersOfOPMImportTable[col_index]))
										else:
											self.OPMImportTable.setCellWidget(self.OPMImportTable.rowCount()-1, col_index, TimeLineEdit)
											self.missingFields_OPM.append((self.OPMImportTable.rowCount(), headersOfOPMImportTable[col_index]))

								if col_index == 2:
									invalidVal = True
									for depo in self.depotsList:
										if str(value).lower() == depo.lower():
											item = QTableWidgetItem(depo)
											self.OPMImportTable.setItem(self.OPMImportTable.rowCount()-1, col_index, item)
											invalidVal = False
											break
									if invalidVal:
										self.createComboBox(self.depotsList, 'depoComboBox')
										self.depoComboBox.setProperty("error", True)
										self.depoComboBox.setStyleSheet(self.comboBoxQSS)
										self.OPMImportTable.setCellWidget(self.OPMImportTable.rowCount()-1, col_index, self.depoComboBox)
										self.missingFields_OPM.append((self.OPMImportTable.rowCount(), headersOfOPMImportTable[col_index]))

								if col_index == 3:
									invalidVal = True
									for train in self.trainsetsList:
										if str(value).lower() == train.lower():
											item = QTableWidgetItem(train)
											self.OPMImportTable.setItem(self.OPMImportTable.rowCount()-1, col_index, item)
											invalidVal = False
											break
									if invalidVal:
										self.createComboBox(self.trainsetsList, 'trainComboBox')
										self.trainComboBox.setProperty("error", True)
										self.trainComboBox.setStyleSheet(self.comboBoxQSS)
										self.OPMImportTable.setCellWidget(self.OPMImportTable.rowCount()-1, col_index, self.trainComboBox)
										self.missingFields_OPM.append((self.OPMImportTable.rowCount(), headersOfOPMImportTable[col_index]))

								if col_index == 4:
									for car in self.carsList:
										if str(value).lower() == car.lower():
											item = QTableWidgetItem(car)
											self.OPMImportTable.setItem(self.OPMImportTable.rowCount()-1, col_index, item)
											break

								

								if col_index == 5:
									invalidVal = True
									for optio in self.typeOfOPMList:
										if str(value).lower() == optio.lower():
											item = QTableWidgetItem(optio)
											self.OPMImportTable.setItem(self.OPMImportTable.rowCount()-1, col_index, item)
											invalidVal = False
											break
									if invalidVal:
										self.createComboBox(self.typeOfOPMList, 'typeOfOPM_a')
										self.typeOfOPM_a.setProperty("error", True)
										self.typeOfOPM_a.setStyleSheet(self.comboBoxQSS)
										self.OPMImportTable.setCellWidget(self.OPMImportTable.rowCount()-1, col_index, self.typeOfOPM_a)
										self.missingFields_OPM.append((self.OPMImportTable.rowCount(), headersOfOPMImportTable[col_index]))




								# if col_index == 5:
								# 	if not pd.isna(value):
								# 		item = QTableWidgetItem(str(value))
								# 		self.OPMImportTable.setItem(self.OPMImportTable.rowCount()-1, col_index, item)

								if col_index in [6, 7]:
									if not pd.isna(value):
										item = QTableWidgetItem(str(value))
										self.OPMImportTable.setItem(self.OPMImportTable.rowCount()-1, col_index, item)


								if col_index == 12:
									if not pd.isna(value):
										item = QTableWidgetItem(str(value).split('.')[0])
										self.OPMImportTable.setItem(self.OPMImportTable.rowCount()-1, col_index-1, item)


								# if col_index in [6, 7]:
								# 	if not pd.isna(value):
								# 		if not str(value) == '':
								# 			item = QTableWidgetItem(str(value))
								# 			self.OPMImportTable.setItem(self.OPMImportTable.rowCount()-1, col_index-1, item)
								# 		else:
								# 			self.createLineEditBox('lineBox')
								# 			self.lineBox.setProperty("error", True)
								# 			self.lineBox.setStyleSheet(self.lineEditBoxQSS)
								# 			self.OPMImportTable.setCellWidget(self.OPMImportTable.rowCount()-1, col_index-1, self.lineBox)
								# 	else:
								# 		self.createLineEditBox('lineBox')
								# 		self.lineBox.setProperty("error", True)
								# 		self.lineBox.setStyleSheet(self.lineEditBoxQSS)
								# 		self.OPMImportTable.setCellWidget(self.OPMImportTable.rowCount()-1, col_index-1, self.lineBox)




								if col_index == 8:
									invalidVal = True
									for systemOption in list(self.BOMSystemDictionary.keys()):
										if str(value).lower() == systemOption.lower():
											item = QTableWidgetItem(systemOption)
											self.OPMImportTable.setItem(self.OPMImportTable.rowCount()-1, col_index, item)
											invalidVal = False


											invalidVal2 = True
											subSysOptions = self.BOMSystemDictionary[systemOption]
											for subSystemOption in subSysOptions:
												subSys = rowData.iloc[col_index + 1]
												if str(subSys).lower() == subSystemOption.lower():
													item2 = QTableWidgetItem(subSystemOption)
													self.OPMImportTable.setItem(self.OPMImportTable.rowCount()-1, col_index + 1, item2)
													invalidVal2 = False
													break
											if invalidVal2:
												self.createComboBox(subSysOptions, 'subsystComboBox')
												self.subsystComboBox.setProperty("error", True)
												self.subsystComboBox.setStyleSheet(self.comboBoxQSS)
												self.OPMImportTable.setCellWidget(self.OPMImportTable.rowCount()-1, col_index + 1, self.subsystComboBox)
												self.missingFields_OPM.append((self.OPMImportTable.rowCount(), headersOfOPMImportTable[col_index + 1]))

											break
									if invalidVal:
										self.createComboBox(list(self.BOMSystemDictionary.keys()), 'systComboBox')
										self.systComboBox.setProperty("error", True)
										self.systComboBox.setStyleSheet(self.comboBoxQSS)
										self.OPMImportTable.setCellWidget(self.OPMImportTable.rowCount()-1, col_index, self.systComboBox)
										self.missingFields_OPM.append((self.OPMImportTable.rowCount(), headersOfOPMImportTable[col_index]))

										self.createComboBox([], 'subsystComboBox')
										self.subsystComboBox.setProperty("error", True)
										self.subsystComboBox.setStyleSheet(self.comboBoxQSS)
										self.subsystComboBox.setEnabled(False)
										self.OPMImportTable.setCellWidget(self.OPMImportTable.rowCount()-1, col_index + 1, self.subsystComboBox)
										self.missingFields_OPM.append((self.OPMImportTable.rowCount(), headersOfOPMImportTable[col_index + 1]))

										def onChangingSysCombobox_OPMImport2(sysOPMCB, subSysOPMCB):
											subSysOPMCB.setEnabled(True)
											subSysOPMCB.clear()
											if sysOPMCB.currentText() != '':
												subSysOPMCB.addItems(self.BOMSystemDictionary[sysOPMCB.currentText()])
											else:
												subSysOPMCB.setEnabled(False)

										def functionalityOfSystemSubsysCB_OPMI2(sysOPMCB, subSysOPMCB):
											sysOPMCB.currentTextChanged.connect(lambda:onChangingSysCombobox_OPMImport2(sysOPMCB, subSysOPMCB))

										functionalityOfSystemSubsysCB_OPMI2(self.systComboBox, self.subsystComboBox)

								if col_index == 10:
									if not pd.isna(value):
										if not pd.isna(rowData.iloc[col_index - 1]):
											if rowData.iloc[col_index - 1].lower() == 'others':
												
												item = QTableWidgetItem(str(value))
												self.OPMImportTable.setItem(self.OPMImportTable.rowCount()-1, col_index, item)

							
							startDate = None
							startTime = None
							endDate = None
							endTime = None

							# Start Date
							if self.OPMImportTable.item(self.OPMImportTable.rowCount()-1, self.OPMImportTable.columnCount()-6):
								date_string = self.OPMImportTable.item(self.OPMImportTable.rowCount()-1, self.OPMImportTable.columnCount()-6).text()
								date_object = datetime.strptime(date_string, "%d-%m-%Y")
								startDate = QDate(date_object.year, date_object.month, date_object.day)

							elif isinstance(self.OPMImportTable.cellWidget(self.OPMImportTable.rowCount()-1, self.OPMImportTable.columnCount()-6).layout().itemAt(0).widget(), QLineEdit):
								lineEdit = self.OPMImportTable.cellWidget(self.OPMImportTable.rowCount()-1, self.OPMImportTable.columnCount()-6).layout().itemAt(0).widget()
								startDate_ = lineEdit.text()
								if startDate_ != '':
									startDate = QDate.fromString(startDate_, "dd-MM-yyyy")


							# Start Time
							if self.OPMImportTable.item(self.OPMImportTable.rowCount()-1, self.OPMImportTable.columnCount()-5):
								time_string = self.OPMImportTable.item(self.OPMImportTable.rowCount()-1, self.OPMImportTable.columnCount()-5).text()
								time_object = datetime.strptime(time_string, "%H:%M")
								startTime = QTime(time_object.hour, time_object.minute)

							elif isinstance(self.OPMImportTable.cellWidget(self.OPMImportTable.rowCount()-1, self.OPMImportTable.columnCount()-5), QLineEdit):
								lineEdit = self.OPMImportTable.cellWidget(self.OPMImportTable.rowCount()-1, self.OPMImportTable.columnCount()-5)
								startTime_ = lineEdit.text()
								if len(startTime_) == 5:
									startTime = QTime.fromString(time_string, "HH:mm")




							# End Date
							if self.OPMImportTable.item(self.OPMImportTable.rowCount()-1, self.OPMImportTable.columnCount()-4):
								date_string = self.OPMImportTable.item(self.OPMImportTable.rowCount()-1, self.OPMImportTable.columnCount()-4).text()
								date_object = datetime.strptime(date_string, "%d-%m-%Y")
								endDate = QDate(date_object.year, date_object.month, date_object.day)

							elif isinstance(self.OPMImportTable.cellWidget(self.OPMImportTable.rowCount()-1, self.OPMImportTable.columnCount()-4).layout().itemAt(0).widget(), QLineEdit):
								lineEdit = self.OPMImportTable.cellWidget(self.OPMImportTable.rowCount()-1, self.OPMImportTable.columnCount()-4).layout().itemAt(0).widget()
								endDate_ = lineEdit.text()
								if endDate_ != '':
									endDate = QDate.fromString(endDate_, "dd-MM-yyyy")
							

							# End Time
							if self.OPMImportTable.item(self.OPMImportTable.rowCount()-1, self.OPMImportTable.columnCount()-3):
								time_string = self.OPMImportTable.item(self.OPMImportTable.rowCount()-1, self.OPMImportTable.columnCount()-3).text()
								time_object = datetime.strptime(time_string, "%H:%M")
								endTime = QTime(time_object.hour, time_object.minute)

							elif isinstance(self.OPMImportTable.cellWidget(self.OPMImportTable.rowCount()-1, self.OPMImportTable.columnCount()-3), QLineEdit):
								lineEdit = self.OPMImportTable.cellWidget(self.OPMImportTable.rowCount()-1, self.OPMImportTable.columnCount()-3)
								startTime_ = lineEdit.text()
								if len(startTime_) == 5:
									endTime = QTime.fromString(time_string, "HH:mm")

							

							if startDate and startTime and endDate and endTime:
								startDateTime = QDateTime(startDate, startTime)
								endDateTime = QDateTime(endDate, endTime)

								difference_seconds = startDateTime.secsTo(endDateTime)
								minutes = int(difference_seconds/60)
								if minutes >= 0:
									self.OPMImportTable.setItem(self.OPMImportTable.rowCount()-1, self.OPMImportTable.columnCount()-2, QTableWidgetItem(str(minutes)))
								else:
									for colInd in [self.OPMImportTable.columnCount()-4, self.OPMImportTable.columnCount()-6]:
										calenderWidget = QWidget()
										calenderWidget.setStyleSheet('')
										layout = QHBoxLayout()
										calenderWidget.setLayout(layout)
										calenderWidget.setFixedWidth(140)
										layout.setSpacing(0)
										layout.setContentsMargins(0, 0, 0, 0)
										# self.dateBox = QDateEdit()
										# self.dateBox.setCalendarPopup(True)
										self.createDateEditBox('dateBox')
										self.dateBox.setFixedHeight(24)
										self.dateBox.setFixedWidth(19)
										self.dateBox.setButtonSymbols(QDateEdit.NoButtons)
										
										# if self.userRole != 0:
										# 	self.dateBox.setMinimumDate(firstDateOfPreviousMonth)

										# if (self.userName == 'Ravikumar') and (self.editableOptionMaxDate > datetime.now().date()):
										# 	self.dateBox.setMinimumDate(QDate(self.startingYear, self.startingMonth, 1))


										self.dateBox.setStyleSheet("""
											QDateEdit {
											color: transparent;
											border: 1px solid transparent;
											border-radius: 0px;
											}
											QDateEdit:hover {
											border: 1px solid transparent;
											}
											QDateEdit::drop-down{
											border-bottom-right-radius: 1px;
											}
											QDateEdit::down-arrow{
											width: 24px;
											height: 24px;
											image: url('Media/calendar.png');
											}
											""")

										self.createLineEditBox('lineBoxInCalenderWidget')
										self.lineBoxInCalenderWidget.setReadOnly(True)
										self.lineBoxInCalenderWidget.setFixedHeight(24)
										self.lineBoxInCalenderWidget.setFixedWidth(110)
										self.lineBoxInCalenderWidget.setProperty("error", True)
										self.lineBoxInCalenderWidget.setStyleSheet(self.lineEditBoxQSS)
										layout.addWidget(self.lineBoxInCalenderWidget)
										layout.addWidget(self.dateBox)


										def dateChangedd(dateEdit, lineEdit):
											lineEdit.setText(str(dateEdit.date().toString("dd-MM-yyyy")))

										def dateEditFunctionInCell(dateEdit, lineEdit):

											dateEdit.dateChanged.connect(lambda: dateChangedd(dateEdit, lineEdit))

										dateEditFunctionInCell(self.dateBox, self.lineBoxInCalenderWidget)
										


										item = self.OPMImportTable.takeItem(self.OPMImportTable.rowCount()-1, colInd)
										del item
										self.OPMImportTable.setCellWidget(self.OPMImportTable.rowCount()-1, colInd, calenderWidget)
										self.missingFields_OPM.append((self.OPMImportTable.rowCount(), headersOfOPMImportTable[colInd]))



									for colInd in [self.OPMImportTable.columnCount()-3, self.OPMImportTable.columnCount()-5]:
										TimeLineEdit = timeLineEdit()
										TimeLineEdit.setFixedHeight(28)
										TimeLineEdit.setFixedWidth(120)
										TimeLineEdit.setProperty("error", True)
										TimeLineEdit.setStyleSheet(self.lineEditBoxQSS)
										TimeLineEdit.setStyleSheet(self.lineEditBoxQSS)

										item = self.OPMImportTable.takeItem(self.OPMImportTable.rowCount()-1, colInd)
										del item
										self.OPMImportTable.setCellWidget(self.OPMImportTable.rowCount()-1, colInd, TimeLineEdit)
										self.missingFields_OPM.append((self.OPMImportTable.rowCount(), headersOfOPMImportTable[colInd]))


							for row in range(self.OPMImportTable.rowCount()):
								for col in range(self.OPMImportTable.columnCount()):
									item = self.OPMImportTable.item(row, col)
									if item:
										item.setToolTip(item.text())

							

							self.createPushButton('minusButn', '', 'Media/delete.png', 35, 'Remove')
							self.minusButn.setStyleSheet(f'''{self.pushbuttonQSS} QPushButton {{ background: transparent; }}
																	QPushButton:hover {{background: transparent;
																		}}
																		QPushButton:pressed {{
																			background: transparent;
																		}}''')
							self.minusButn.clicked.connect(self.onClickingRemoveButn_OPM)
							self.OPMImportTable.setCellWidget(self.OPMImportTable.rowCount()-1, self.OPMImportTable.columnCount()-1, self.minusButn)
						

							if color:
								for col in range(self.OPMImportTable.columnCount()):
									item = self.OPMImportTable.item(self.OPMImportTable.rowCount()-1, col)
									if item:
										item.setForeground(QColor(color))



						def onSelectingMultipleTrainsAndCars(rowData, multiTrainsSelected, multiCarsSelected):
							if multiTrainsSelected and multiCarsSelected:
								listOfTrains = rowData.iloc[3].split(',')
								cleanedListOfTrains = [s.strip() for s in listOfTrains]
								allTrainsListLower = [item.lower() for item in self.trainsetsList]
								validListOfTrains = [item for item in cleanedListOfTrains if item.lower() in allTrainsListLower]



								listOfCars = rowData.iloc[4].split(',')
								cleanedListOfCars = [s.strip() for s in listOfCars]
								allCarsListLower = [item.lower() for item in self.carsList]
								validListOfCars = [item for item in cleanedListOfCars if item.lower() in allCarsListLower]

								numberOfTrainsSelectedOPM = len(validListOfTrains)
								numberOfCarsSelectedOPM = len(validListOfCars)

								quantity = rowData.iloc[11]
								quantityInt = 1
								try:
									quantityInt = int(quantity)
								except ValueError:
									quantityInt = 1

								if numberOfCarsSelectedOPM == 0:
									numberOfCarsSelectedOPM = 1

								totalRows = numberOfTrainsSelectedOPM * numberOfCarsSelectedOPM * quantityInt

								repeated_rows = []
								
								date_valid = (pd.to_datetime(rowData.iloc[13], errors='coerce') is not pd.NaT and 
												pd.to_datetime(rowData.iloc[15], errors='coerce') is not pd.NaT)

								time_valid = isinstance(rowData.iloc[14], time) and isinstance(rowData.iloc[16], time)

								if date_valid and time_valid:
									workStartDateTime = pd.to_datetime(rowData.iloc[13].strftime('%Y-%m-%d') + ' ' + str(rowData.iloc[14]))
									workEndDateTime = pd.to_datetime(rowData.iloc[15].strftime('%Y-%m-%d') + ' ' + str(rowData.iloc[16]))

									# Calculate duration
									duration = workEndDateTime - workStartDateTime
									

									# Split duration into totalRows parts
									duration_parts = pd.to_timedelta([(duration.total_seconds() / (totalRows))*1000000000])


								for u in range(totalRows):
									new_row = rowData.copy()
									# new_row.iloc[3] = validListOfTrains[p]
									if date_valid and time_valid:
										new_row.iloc[13] = (workStartDateTime + u * duration_parts[0])
										new_row.iloc[14] = (workStartDateTime + u * duration_parts[0]).time()
										new_row.iloc[15] = (workStartDateTime + (u + 1) * duration_parts[0])
										new_row.iloc[16] = (workStartDateTime + (u + 1) * duration_parts[0]).time()
									else:
										new_row.iloc[13] = ''
										new_row.iloc[14] = ''
										new_row.iloc[15] = ''
										new_row.iloc[16] = ''


									repeated_rows.append(new_row.to_frame().T)

								# Concatenate the list of rows into a new DataFrame
								repeatedDF = pd.concat(repeated_rows, ignore_index=True)


								val = 0
								for j in range(numberOfCarsSelectedOPM):
									for q in range(numberOfTrainsSelectedOPM):
										for k in range(quantityInt):
											repeatedDF.iloc[val, 4] = cleanedListOfCars[j]
											val += 1


								val = 0
								for j in range(numberOfCarsSelectedOPM):
									for i in range(numberOfTrainsSelectedOPM):
										for k in range(quantityInt):
											if cleanedListOfTrains != []:
												repeatedDF.iloc[val, 3] = cleanedListOfTrains[i]
												val += 1



								for row_index, repeatedRowData in repeatedDF.iterrows():
									self.OPMImportTable.insertRow(self.OPMImportTable.rowCount())
									addOPMRow(repeatedRowData, 'green')



							
							elif multiTrainsSelected:
								listOfTrains = rowData.iloc[3].split(',')
								cleanedListOfTrains = [s.strip() for s in listOfTrains]

								allTrainsListLower = [item.lower() for item in self.trainsetsList]
								validListOfTrains = [item for item in cleanedListOfTrains if item.lower() in allTrainsListLower]
								numberOfTrainsSelectedOPM = len(validListOfTrains)


								quantity = rowData.iloc[11]
								quantityInt = 1
								try:
									quantityInt = int(quantity)
								except ValueError:
									quantityInt = 1

								totalRows = numberOfTrainsSelectedOPM * quantityInt

								repeated_rows = []
								
								date_valid = (pd.to_datetime(rowData.iloc[13], errors='coerce') is not pd.NaT and 
												pd.to_datetime(rowData.iloc[15], errors='coerce') is not pd.NaT)

								time_valid = isinstance(rowData.iloc[14], time) and isinstance(rowData.iloc[16], time)

								if date_valid and time_valid:

									# workStartDateTime = pd.to_datetime(rowData.iloc[12].strftime('%Y-%m-%d') + ' ' + str(rowData.iloc[13]))
									workStartDateTime = pd.to_datetime(rowData.iloc[13].strftime('%Y-%m-%d') + ' ' + str(rowData.iloc[14]))

									workEndDateTime = pd.to_datetime(rowData.iloc[15].strftime('%Y-%m-%d') + ' ' + str(rowData.iloc[16]))

									# Calculate duration
									duration = workEndDateTime - workStartDateTime

									# Split duration into len(validListOfTrains) parts
									duration_parts = pd.to_timedelta([(duration.total_seconds() / (totalRows))*1000000000])
								
								

								# Create new rows for each duration part
								for u in range(totalRows):
									new_row = rowData.copy()
									# new_row.iloc[3] = validListOfTrains[p]
									# print(workStartDateTime)
									if date_valid and time_valid:
										new_row.iloc[13] = (workStartDateTime + u * duration_parts[0])
										new_row.iloc[14] = (workStartDateTime + u * duration_parts[0]).time()
										new_row.iloc[15] = (workStartDateTime + (u + 1) * duration_parts[0])
										new_row.iloc[16] = (workStartDateTime + (u + 1) * duration_parts[0]).time()
									else:
										new_row.iloc[13] = ''
										new_row.iloc[14] = ''
										new_row.iloc[15] = ''
										new_row.iloc[16] = ''
									

									repeated_rows.append(new_row.to_frame().T)


								# Concatenate the list of rows into a new DataFrame
								repeatedDF = pd.concat(repeated_rows, ignore_index=True)


								val = 0
								for i in range(numberOfTrainsSelectedOPM):
									for j in range(quantityInt):
										if cleanedListOfTrains != []:
											repeatedDF.iloc[val, 3] = cleanedListOfTrains[i]
											val += 1

								for row_index, repeatedRowData in repeatedDF.iterrows():
									self.OPMImportTable.insertRow(self.OPMImportTable.rowCount())
									addOPMRow(repeatedRowData, 'green')



							elif multiCarsSelected:
								listOfCars = rowData.iloc[4].split(',')
								cleanedListOfCars = [s.strip() for s in listOfCars]


								allCarsListLower = [item.lower() for item in self.carsList]
								validListOfCars = [item for item in cleanedListOfCars if item.lower() in allCarsListLower]

								numberOfCarsSelectedOPM = len(validListOfCars)

								quantity = rowData.iloc[11]
								quantityInt = 1
								try:
									quantityInt = int(quantity)
								except ValueError:
									quantityInt = 1

								totalRows = numberOfCarsSelectedOPM * quantityInt

								repeated_rows = []
								date_valid = (pd.to_datetime(rowData.iloc[13], errors='coerce') is not pd.NaT and 
												pd.to_datetime(rowData.iloc[15], errors='coerce') is not pd.NaT)

								time_valid = isinstance(rowData.iloc[14], time) and isinstance(rowData.iloc[16], time)

								if date_valid and time_valid:
									workStartDateTime = pd.to_datetime(rowData.iloc[13].strftime('%Y-%m-%d') + ' ' + str(rowData.iloc[14]))
									
									workEndDateTime = pd.to_datetime(rowData.iloc[15].strftime('%Y-%m-%d') + ' ' + str(rowData.iloc[16]))
									# Calculate duration
									duration = workEndDateTime - workStartDateTime
								
									# Split duration into len(validListOfCars) parts
									duration_parts = pd.to_timedelta([(duration.total_seconds() / (totalRows))*1000000000])
								


								# Create new rows for each duration part


								for u in range(totalRows):
									new_row = rowData.copy()
									# new_row.iloc[4] = validListOfCars[u]
									if date_valid and time_valid:
										new_row.iloc[13] = (workStartDateTime + u * duration_parts[0])
										new_row.iloc[14] = (workStartDateTime + u * duration_parts[0]).time()
										new_row.iloc[15] = (workStartDateTime + (u + 1) * duration_parts[0])
										new_row.iloc[16] = (workStartDateTime + (u + 1) * duration_parts[0]).time()
									else:
										new_row.iloc[13] = ''
										new_row.iloc[14] = ''
										new_row.iloc[15] = ''
										new_row.iloc[16] = ''


									repeated_rows.append(new_row.to_frame().T)

								# Concatenate the list of rows into a new DataFrame
								repeatedDF = pd.concat(repeated_rows, ignore_index=True)


								val = 0
								for i in range(quantityInt):
									for j in range(numberOfCarsSelectedOPM):
										if cleanedListOfCars != []:
											repeatedDF.iloc[val, 4] = cleanedListOfCars[j]
											val += 1


								for row_index, repeatedRowData in repeatedDF.iterrows():
									self.OPMImportTable.insertRow(self.OPMImportTable.rowCount())
									addOPMRow(repeatedRowData, 'green')

						
						self.missingFields_OPM = []
						for row_index, rowData in dataf_.iterrows():
							multiTrainsSelected = False
							multiCarsSelected = False
							if not pd.isna(rowData.iloc[3]):
								if ',' in rowData.iloc[3]:
									multiTrainsSelected = True
							if not pd.isna(rowData.iloc[4]):
								if ',' in rowData.iloc[4]:
									multiCarsSelected = True


							if multiTrainsSelected or multiCarsSelected:
								onSelectingMultipleTrainsAndCars(rowData, multiTrainsSelected, multiCarsSelected)
								continue
							else:
								repeated_rows = []
								# if isinstance(rowData.iloc[13], date):
								# 	if isinstance(rowData.iloc[14], time):
								# 		if isinstance(rowData.iloc[15], date):
								# 			if isinstance(rowData.iloc[16], time):

								quantity = rowData.iloc[11]
								quantityInt = 1

								try:
									quantityInt = int(quantity)
								except ValueError:
									quantityInt = 1

								totalRows = quantityInt

								date_valid = (pd.to_datetime(rowData.iloc[13], errors='coerce') is not pd.NaT and 
												pd.to_datetime(rowData.iloc[15], errors='coerce') is not pd.NaT)

								time_valid = isinstance(rowData.iloc[14], time) and isinstance(rowData.iloc[16], time)

								if date_valid and time_valid:
									workStartDateTime = pd.to_datetime(rowData.iloc[13].strftime('%Y-%m-%d') + ' ' + str(rowData.iloc[14]))
									workEndDateTime = pd.to_datetime(rowData.iloc[15].strftime('%Y-%m-%d') + ' ' + str(rowData.iloc[16]))

									duration = workEndDateTime - workStartDateTime
									duration_parts = pd.to_timedelta([(duration.total_seconds() / (totalRows))*1000000000])
								
								for v in range(totalRows):
									new_row = rowData.copy()
									# new_row.iloc[4] = validListOfCars[i]
									if date_valid and time_valid:
										new_row.iloc[13] = (workStartDateTime + v * duration_parts[0])
										new_row.iloc[14] = (workStartDateTime + v * duration_parts[0]).time()
										new_row.iloc[15] = (workStartDateTime + (v + 1) * duration_parts[0])
										new_row.iloc[16] = (workStartDateTime + (v + 1) * duration_parts[0]).time()
									else:
										new_row.iloc[13] = ''
										new_row.iloc[14] = ''
										new_row.iloc[15] = ''
										new_row.iloc[16] = ''

									repeated_rows.append(new_row.to_frame().T)


								repeatedDF = pd.concat(repeated_rows, ignore_index=True)

						
								if repeatedDF.shape[0] > 1:
									for row_index, repeatedRowData in repeatedDF.iterrows():
										self.OPMImportTable.insertRow(self.OPMImportTable.rowCount())
										addOPMRow(repeatedRowData, 'green')
								else:
									for row_index, repeatedRowData in repeatedDF.iterrows():
										self.OPMImportTable.insertRow(self.OPMImportTable.rowCount())
										addOPMRow(repeatedRowData)
						
						for ro in range(self.OPMImportTable.rowCount()):
							for co in range(self.OPMImportTable.columnCount()):
								item = self.OPMImportTable.item(ro, co)
								if item is not None:
									item.setTextAlignment(Qt.AlignCenter)

						if len(self.missingFields_OPM) > 0:

							for index, field in enumerate(self.missingFields_OPM):
								missingFieldsGridLayout_OPM.addWidget(QLabel(str(field[0])), index, 0)
								missingFieldsGridLayout_OPM.addWidget(QLabel(str(field[1])), index, 1)
							missingFieldsGridLayout_OPM.addItem(QSpacerItem(1, 1, QSizePolicy.Fixed, QSizePolicy.Expanding), len(self.missingFields_OPM), 0)
							
							scrollForMissingFields_OPM.show()
						else:
							scrollForMissingFields_OPM.hide()
								

				self.submitImportedExcelData.clicked.connect(mapData)
				self.cancelImportedExcelData.clicked.connect(lambda: self.excelAndTableColumnsMappingWindow.close())


				submitAndCancelBtnOfExcelImportWindow = QHBoxLayout()
				submitAndCancelBtnOfExcelImportWindow.addWidget(self.submitImportedExcelData, alignment=Qt.AlignRight)
				submitAndCancelBtnOfExcelImportWindow.addWidget(self.cancelImportedExcelData, alignment=Qt.AlignLeft)

				VLayoutForColumnsMappingWindow.addLayout(submitAndCancelBtnOfExcelImportWindow)

				self.excelAndTableColumnsMappingWindow.setLayout(VLayoutForColumnsMappingWindow)
				
				self.excelAndTableColumnsMappingWindow.show()

			else:
				pass
				
		self.importIconButton_OPMImport.clicked.connect(importOPMDataFromExceltoTable)

		# self.cancelBtnOfImportOPM.clicked.connect(lambda: self.OPMImportWindow.close())
		# self.submitBtnOfImportOPM.clicked.connect(onClickingSubmitOPMImportWindow)


		
		self.OPMImportWindow.show()


	self.openOPMtableButton_OPM.clicked.connect(openOPMTableWindow)

	














	def onClickingSubmit_OPM():
		mandatoryVerification_OPM = True
		mandatoryIndexes_OPM = [0, 1, 2, 3, 5, 8, 9, 12, 13, 14, 15, 17]

		trainMultiSelected = False
		carMultiSelected = False

		currentDateTimeValue = datetime.now()
		
		OPM_Row = []
		OPM_id = 'OPM' + '_' + currentDateTimeValue.strftime("%Y%m%d%H%M%S%f")[:-4]
		OPM_Row.append(OPM_id)


		for i, wid in enumerate(self.listOfWidgets_OPM):
			if isinstance(wid, QDateEdit):
				if isinstance(self.listOfWidgets_OPM[i+1], QTimeEdit):
					datetime_ = QDateTime(wid.date(), self.listOfWidgets_OPM[i+1].time())
					OPM_Row.append(datetime_.toPython())

			elif isinstance(wid, QComboBox):
				if wid.isEnabled():
					if wid.currentText() == '':
						OPM_Row.append(None)

						if i in mandatoryIndexes_OPM:
							mandatoryVerification_OPM = False
							wid.setProperty("error", True)
							wid.setStyleSheet(self.comboBoxQSS)

					else:

						if i == 3:
							OPM_Row.append(wid.currentText())
							wid.setProperty("error", False)
							wid.setStyleSheet(self.comboBoxQSS)

							if ', ' in wid.currentText():
								trainMultiSelected = True

						elif i == 4:
							OPM_Row.append(wid.currentText())
							wid.setProperty("error", False)
							wid.setStyleSheet(self.comboBoxQSS)

							if ', ' in wid.currentText():
								carMultiSelected = True

						elif i == 8:
							query = "SELECT id FROM bom WHERE equipment = %s AND parent_id = 0"
							self.cursor.execute(query, (wid.currentText(),))
							result = self.cursor.fetchone()
							OPM_Row.append(result[0])
							wid.setProperty("error", False)
							wid.setStyleSheet(self.comboBoxQSS)
						
						elif i == 9:
							query = "SELECT id FROM bom WHERE parent_id = (SELECT id FROM bom WHERE equipment = %s AND parent_id = 0) AND equipment = %s"
							self.cursor.execute(query, (self.listOfWidgets_OPM[8].currentText(), wid.currentText()))
							result = self.cursor.fetchall()
							OPM_Row.append(result[0][0])
							wid.setProperty("error", False)
							wid.setStyleSheet(self.comboBoxQSS)

						else:
							OPM_Row.append(wid.currentText())
							wid.setProperty("error", False)
							wid.setStyleSheet(self.comboBoxQSS)

				else:
					OPM_Row.append(None)

			elif isinstance(wid, QLineEdit):
				if wid.text() == '':
					OPM_Row.append(None)

					if i in mandatoryIndexes_OPM:
						mandatoryVerification_OPM = False
						wid.setProperty("error", True)
						wid.setStyleSheet(self.lineEditBoxQSS)

				else:
					if i == 17:
						if int(wid.text()) == 0:
							mandatoryVerification_OPM = False
							wid.setProperty("error", True)
							wid.setStyleSheet(self.lineEditBoxQSS)
						else:
							wid.setProperty("error", False)
							wid.setStyleSheet(self.lineEditBoxQSS)
							OPM_Row.append(int(wid.text()))
					else:
						OPM_Row.append(wid.text())

			elif isinstance(wid, QTextEdit):
				if wid.toPlainText() == '':
					OPM_Row.append(None)
				else:
					OPM_Row.append(wid.toPlainText())

			elif isinstance(wid, QLabel):
				OPM_Row.append(int(wid.text()))

		if not mandatoryVerification_OPM:
			pass

		else:


			############################################################################

			from PySide6.QtWidgets import QApplication


			self.OPMWindow_ = QWidget()
			# self.OPMWindow_.move(400, 200)
			self.OPMWindow_.move(150, 150)
			self.OPMWindow_.resize(1700, 600)

			self.OPMWindow_.setWindowIcon(QIcon('Media/ramsify.png'))
			self.OPMWindow_.setWindowTitle('OPM Data')
			self.OPMWindow_.setStyleSheet(self.widgetQSS)
			
			self.OPMWindowLayout_ = QVBoxLayout()

			self.opm_table_widget  = TableWidget()
			HeadersOfOPM = ['Event Date', 'Event Time', 'Depot', 'Trainset', 'Car Number', 'Type of OPM' ,'Nature of Work', 'Workdone Details', 'System', 'Sub-System', 'Other Sub-System', 'Jobcard No', 'Attachments',
							'Workstart Date', 'Workstart Time', 'Workend Date', 'Workend Time', 'Work Downtime(Mins)']
			

			self.opm_table_widget.setColumnCount(len(HeadersOfOPM))
			self.opm_table_widget.setHorizontalHeaderLabels(HeadersOfOPM)
			self.opm_table_widget.setStyleSheet(self.tableWidgetQSS)
			self.opm_table_widget.horizontalHeader().setStyleSheet(self.headerHorizontalQSS)

			self.OPMWindowLayout_.addWidget(self.opm_table_widget)
			self.OPMWindow_.setLayout(self.OPMWindowLayout_)


			self.opm_table_widget.setColumnWidth(0, int(0.07 * QApplication.primaryScreen().availableGeometry().width()))
			self.opm_table_widget.setColumnWidth(1, int(0.06 * QApplication.primaryScreen().availableGeometry().width()))
			self.opm_table_widget.setColumnWidth(2, int(0.07 * QApplication.primaryScreen().availableGeometry().width()))
			self.opm_table_widget.setColumnWidth(3, int(0.07 * QApplication.primaryScreen().availableGeometry().width()))
			self.opm_table_widget.setColumnWidth(4, int(0.07 * QApplication.primaryScreen().availableGeometry().width()))
			self.opm_table_widget.setColumnWidth(5, int(0.07 * QApplication.primaryScreen().availableGeometry().width()))
			self.opm_table_widget.setColumnWidth(6, int(0.09 * QApplication.primaryScreen().availableGeometry().width()))
			self.opm_table_widget.setColumnWidth(7, int(0.08 * QApplication.primaryScreen().availableGeometry().width()))
			self.opm_table_widget.setColumnWidth(8, int(0.15 * QApplication.primaryScreen().availableGeometry().width()))
			self.opm_table_widget.setColumnWidth(9, int(0.15 * QApplication.primaryScreen().availableGeometry().width()))
			self.opm_table_widget.setColumnWidth(10, int(0.1 * QApplication.primaryScreen().availableGeometry().width()))
			self.opm_table_widget.setColumnWidth(11, int(0.1 * QApplication.primaryScreen().availableGeometry().width()))
			self.opm_table_widget.setColumnWidth(12, int(0.08 * QApplication.primaryScreen().availableGeometry().width()))
			self.opm_table_widget.setColumnWidth(13, int(0.08 * QApplication.primaryScreen().availableGeometry().width()))
			self.opm_table_widget.setColumnWidth(14, int(0.08 * QApplication.primaryScreen().availableGeometry().width()))
			self.opm_table_widget.setColumnWidth(15, int(0.08 * QApplication.primaryScreen().availableGeometry().width()))
			self.opm_table_widget.setColumnWidth(16, int(0.08 * QApplication.primaryScreen().availableGeometry().width()))
			self.opm_table_widget.setColumnWidth(17, int(0.12 * QApplication.primaryScreen().availableGeometry().width()))



			numberOfTrainsSelected_OPM = 1
			numberOfCarsSelected_OPM = 1

			quantity = int(self.quantity_OPM.text())
			if quantity == 0:
				quantity = 1

			if ',' in OPM_Row[3]:
				selectedListOfTrains_OPM = OPM_Row[3].split(',')
				cleanedListOfSelectedTrains_OPM = [s.strip() for s in selectedListOfTrains_OPM]
				numberOfTrainsSelected_OPM = len(cleanedListOfSelectedTrains_OPM)
			else:
				cleanedListOfSelectedTrains_OPM = [OPM_Row[3]]
				numberOfTrainsSelected_OPM = len(cleanedListOfSelectedTrains_OPM)


			if OPM_Row[4]:
				if ',' in OPM_Row[4]:
					selectedListOfCars_OPM = OPM_Row[4].split(',')
					cleanedListOfSelectedCars_OPm = [s.strip() for s in selectedListOfCars_OPM]
					numberOfCarsSelected_OPM = len(cleanedListOfSelectedCars_OPm)
				else:
					cleanedListOfSelectedCars_OPm = [OPM_Row[4]]
					numberOfCarsSelected_OPM = len(cleanedListOfSelectedCars_OPm)

			else:
				cleanedListOfSelectedCars_OPm = []
				numberOfCarsSelected_OPM = 1


			totalRows = numberOfTrainsSelected_OPM * numberOfCarsSelected_OPM * quantity
			self.opm_table_widget.setRowCount(totalRows)

			workStartDateValue = self.workStartDate_OPM.date()
			workStartTimeValue = self.workStartTime_OPM.time()
			workStartDateTimeObject = QDateTime(workStartDateValue, workStartTimeValue)

			workEndDateValue = self.workEndDate_OPM.date()
			workEndTimeValue = self.workEndTime_OPM.time()
			workEndDateTimeObject = QDateTime(workEndDateValue, workEndTimeValue)


			workDuration = workStartDateTimeObject.secsTo(workEndDateTimeObject)

			eachRowWorkDuration = int(workDuration/totalRows)



			for m in range(totalRows):
				self.createDateEditBox('eventDateEdit_OPM_IOPM_')
				currentYear = datetime.now().year
				currentMonth = datetime.now().month

				firstDayOfCurrentMonth = datetime(currentYear, currentMonth, 1).date()
				lastDateOfPreviousMonth = (firstDayOfCurrentMonth - relativedelta(days=1))

				firstDateOfPreviousMonth = QDate(lastDateOfPreviousMonth.year, lastDateOfPreviousMonth.month, 1)
				
				if firstDateOfPreviousMonth < QDate(self.startingYear, self.startingMonth, 1):
					firstDateOfPreviousMonth = QDate(self.startingYear, self.startingMonth, 1)

				# if self.userRole != 0:
				# 	self.eventDateEdit_OPM_IOPM_.setMinimumDate(firstDateOfPreviousMonth)

				# if (self.userName == 'Ravikumar') and (self.editableOptionMaxDate > datetime.now().date()):
				# 	self.eventDateEdit_OPM_IOPM_.setMinimumDate(QDate(self.startingYear, self.startingMonth, 1))

				self.opm_table_widget.setCellWidget( m, 0, self.eventDateEdit_OPM_IOPM_ )

				date_edit_widget = hLayoutForEventDateTime_OPMTab.itemAt(0).widget()
				self.eventDateEdit_OPM_IOPM_.setDate(date_edit_widget.date())

				self.eventDateEdit_OPM_IOPM_.setFixedWidth(int(0.07 * QApplication.primaryScreen().availableGeometry().width()))


				## event time label and timeedit widget:
				self.createTimeEditBox('eventTimeEdit_OPM_IOPM_')
				self.opm_table_widget.setCellWidget( m, 1, self.eventTimeEdit_OPM_IOPM_)
				
				time_edit_widget = hLayoutForEventDateTime_OPMTab.itemAt(1).widget()
				self.eventTimeEdit_OPM_IOPM_.setTime(time_edit_widget.time())


				self.eventTimeEdit_OPM_IOPM_.setFixedWidth(int(0.06 * QApplication.primaryScreen().availableGeometry().width()))

				## Depot name and label combobox:
				self.createComboBox(self.depotsList, 'depotNameCombobox_IOPM_')
				self.opm_table_widget.setCellWidget( m, 2, self.depotNameCombobox_IOPM_)
				self.depotNameCombobox_IOPM_.setFixedWidth(int(0.07 * QApplication.primaryScreen().availableGeometry().width()))


				## trainset name label and combobox widget:
				self.createComboBox([], 'trainsetCombobox_IOPM_')
				self.opm_table_widget.setCellWidget( m, 3, self.trainsetCombobox_IOPM_)
				self.trainsetCombobox_IOPM_.setEnabled(False)
				self.trainsetCombobox_IOPM_.setFixedWidth(int(0.07 * QApplication.primaryScreen().availableGeometry().width()))

				## Function to dynamically update the trainset combobox based on the depo selection:
				def onChangingDepotCombobox_OPMImport(depotCB_, trainsetCB_):
					trainsetCB_.setEnabled(True)
					trainsetCB_.clear()
					if depotCB_.currentText() != '':
						trainsetCB_.addItems(self.depotTrainDictionary[depotCB_.currentText()])
					else:
						trainsetCB_.setEnabled(False)

				def functionalityOfDepoTrainCB_(depotCB_, trainsetCB_):
					depotCB_.currentTextChanged.connect(lambda:onChangingDepotCombobox_OPMImport(depotCB_, trainsetCB_))

				functionalityOfDepoTrainCB_(self.depotNameCombobox_IOPM_, self.trainsetCombobox_IOPM_)


				DepotData = self.depotCombobox_OPM.currentText()  
				self.depotNameCombobox_IOPM_.setCurrentText(DepotData)

				Trainset_Data = self.trainCombobox_OPM.currentText() 
				self.trainsetCombobox_IOPM_.setCurrentText(Trainset_Data)


				## car number label and combobox widget:
				self.createComboBox(self.carsList, 'carNumberCombobox_IOPM_')
				self.opm_table_widget.setCellWidget( m, 4, self.carNumberCombobox_IOPM_)

				CarNoData = self.carCombobox_OPM.currentText()  
				self.carNumberCombobox_IOPM_.setCurrentText(CarNoData)
				self.carNumberCombobox_IOPM_.setFixedWidth(int(0.07 * QApplication.primaryScreen().availableGeometry().width()))


				## OPM type label and combobox widget:
				self.createComboBox(self.typeOfOPMList, 'typeOfOPMCombobox_IOPM_')
				self.opm_table_widget.setCellWidget( m, 5, self.typeOfOPMCombobox_IOPM_)

				TypeOPMData = self.typeOf_OPM.currentText()  
				self.typeOfOPMCombobox_IOPM_.setCurrentText(TypeOPMData)
				self.typeOfOPMCombobox_IOPM_.setFixedWidth(int(0.07 * QApplication.primaryScreen().availableGeometry().width()))


				## Fault description label and text edit widget:
				self.createLineEditBox('faultDetailsTextBox_OPM_IOPM_')
				self.opm_table_widget.setCellWidget( m, 6, self.faultDetailsTextBox_OPM_IOPM_)


				def onFDTextChanged_(FDLineEdit_):
					FDLineEdit_.setToolTip(FDLineEdit_.text())

				def setToolTipsOfFD_(FDLineEdit_):
					FDLineEdit_.textChanged.connect(lambda:onFDTextChanged_(FDLineEdit_))

				setToolTipsOfFD_(self.faultDetailsTextBox_OPM_IOPM_)

				FaultDetails_Data = self.faultDetailsTextBox_OPM.toPlainText()
				self.faultDetailsTextBox_OPM_IOPM_.setText(FaultDetails_Data)
				# self.faultDetailsTextBox_OPM_IOPM_.setFixedWidth(int(0.07 * QApplication.primaryScreen().availableGeometry().width()))



				## Workdone description label and text edit widget:
				self.createLineEditBox('workdoneTextBox_OPM_IOPM_')
				self.opm_table_widget.setCellWidget( m, 7, self.workdoneTextBox_OPM_IOPM_)



				def onWDTextChanged_(WDLineEdit_):
					WDLineEdit_.setToolTip(WDLineEdit_.text())

				def setToolTipsOfWD_(WDLineEdit_):
					WDLineEdit_.textChanged.connect(lambda:onWDTextChanged_(WDLineEdit_))

				setToolTipsOfWD_(self.workdoneTextBox_OPM_IOPM_)

				Workdone_Data = self.workdoneTextBox_OPM.toPlainText()
				self.workdoneTextBox_OPM_IOPM_.setText(Workdone_Data)
				# self.workdoneTextBox_OPM_IOPM_.setFixedWidth(int(0.07 * QApplication.primaryScreen().availableGeometry().width()))

				
		
				## system type label and lineedit widget:
				self.createComboBox(self.BOMSystemDictionary.keys(),'systemCombobox_IOPM_')
				self.opm_table_widget.setCellWidget( m, 8, self.systemCombobox_IOPM_)
				self.systemCombobox_IOPM_.setFixedWidth(int(0.15 * QApplication.primaryScreen().availableGeometry().width()))


				## sub-system type label and lineedit widget:
				self.createComboBox([],'subSystemCombobox_IOPM_')
				self.opm_table_widget.setCellWidget( m, 9, self.subSystemCombobox_IOPM_)
				self.subSystemCombobox_IOPM_.setEnabled(False)
				self.subSystemCombobox_IOPM_.setFixedWidth(int(0.15 * QApplication.primaryScreen().availableGeometry().width()))

				def onChangingSysCombobox_OPMImport(sysCB_, subSysCB_):
					subSysCB_.setEnabled(True)
					subSysCB_.clear()
					if sysCB_.currentText() != '':
						subSysCB_.addItems(self.BOMSystemDictionary[sysCB_.currentText()])
					else:
						subSysCB_.setEnabled(False)
				def functionalityOfSystemSubsysCB_(sysCB_, subSysCB_):
					sysCB_.currentTextChanged.connect(lambda:onChangingSysCombobox_OPMImport(sysCB_, subSysCB_))

				functionalityOfSystemSubsysCB_(self.systemCombobox_IOPM_, self.subSystemCombobox_IOPM_)


				Systemcombobox_Data = self.systemComboBox_OPM.currentText()
				self.systemCombobox_IOPM_.setCurrentText(Systemcombobox_Data)

				Subsystemcombobox_Data = self.subSystemComboBox_OPM.currentText()
				self.subSystemCombobox_IOPM_.setCurrentText(Subsystemcombobox_Data)

				
				self.createLineEditBox('othersubsystemLineEdit_OPM_')
				self.opm_table_widget.setCellWidget(m, 10, self.othersubsystemLineEdit_OPM_)			
				
				Othersubsystem_Data = self.othersubsystemLineEdit_OPM.text()
				self.othersubsystemLineEdit_OPM_.setText(Othersubsystem_Data)

				# self.othersubsystemLineEdit_OPM_.setFixedWidth(int(0.07 * QApplication.primaryScreen().availableGeometry().width()))



				self.createLineEditBox('jobcardLineEdit_OPM_')
				self.opm_table_widget.setCellWidget(m, 11, self.jobcardLineEdit_OPM_)			
				
				jobcardData = self.jobcardLineEdit_OPM.text()
				self.jobcardLineEdit_OPM_.setText(jobcardData)

				# self.jobcardLineEdit_OPM_.setFixedWidth(int(0.07 * QApplication.primaryScreen().availableGeometry().width()))


				selected_files = [self.mianAttachment_OPM.fileListWidget.item(i).text() for i in range(self.mianAttachment_OPM.fileListWidget.count())]

				if len(selected_files)>0:
					self.opm_table_widget.setCellWidget(m, 12, QLabel(str(selected_files)))
					self.opm_table_widget.cellWidget(m, 12).setToolTip(str(selected_files))
					# attachmentsItem.setToolTip(str(listOfAttachmentsNames))
				else:
					self.opm_table_widget.setCellWidget(m, 12, QLabel(''))



				




				startDatee = self.workStartDate_OPM.date()
				startTimee = self.workStartTime_OPM.time()

				startDateTimee = QDateTime(startDatee, startTimee)
				
				startDateTimeOfCurrentRow = startDateTimee.addSecs(eachRowWorkDuration*m)

				if startDateTimeOfCurrentRow.time().second() >= 30:
					startDateTimeOfCurrentRow = startDateTimeOfCurrentRow.addSecs(60 - startDateTimeOfCurrentRow.time().second())
				else:
					startDateTimeOfCurrentRow = startDateTimeOfCurrentRow.addSecs(-startDateTimeOfCurrentRow.time().second())


				startDateOfCurrentRow = startDateTimeOfCurrentRow.date()
				startTimeOfCurrentRow = startDateTimeOfCurrentRow.time()


				endDateTimeOfCurrentRow = startDateTimee.addSecs(eachRowWorkDuration*(m+1))

				if endDateTimeOfCurrentRow.time().second() >= 30:
					endDateTimeOfCurrentRow = endDateTimeOfCurrentRow.addSecs(60 - endDateTimeOfCurrentRow.time().second())
				else:
					endDateTimeOfCurrentRow = endDateTimeOfCurrentRow.addSecs(-endDateTimeOfCurrentRow.time().second())


				endDateOfCurrentRow = endDateTimeOfCurrentRow.date()
				endTimeOfCurrentRow = endDateTimeOfCurrentRow.time()







				## work start date label and dateedit widget:
				self.createDateEditBox('workStartDate_OPM_IOPM_')
				# if self.userRole != 0:
				# 	self.workStartDate_OPM_IOPM_.setMinimumDate(firstDateOfPreviousMonth)

				# if (self.userName == 'Ravikumar') and (self.editableOptionMaxDate > datetime.now().date()):
				# 	self.workStartDate_OPM_IOPM_.setMinimumDate(QDate(self.startingYear, self.startingMonth, 1))

				self.opm_table_widget.setCellWidget(m, 13, self.workStartDate_OPM_IOPM_)

				# self.workStartDate_OPM_IOPM_.setDate(self.workStartDate_OPM.date())
				self.workStartDate_OPM_IOPM_.setFixedWidth(int(0.07 * QApplication.primaryScreen().availableGeometry().width()))
				

				## work start time label and timeedit widget:
				self.createTimeEditBox('workStartTime_OPM_IOPM_')
				self.opm_table_widget.setCellWidget( m, 14, self.workStartTime_OPM_IOPM_)

				# self.workStartTime_OPM_IOPM_.setTime(self.workStartTime_OPM.time())

				## work end date label and dateedit widget:
				self.createDateEditBox('workEndDate_OPM_IOPM_')
				# if self.userRole != 0:
				# 	self.workEndDate_OPM_IOPM_.setMinimumDate(firstDateOfPreviousMonth)

				# if (self.userName == 'Ravikumar') and (self.editableOptionMaxDate > datetime.now().date()):
				# 	self.workEndDate_OPM_IOPM_.setMinimumDate(QDate(self.startingYear, self.startingMonth, 1))

				self.opm_table_widget.setCellWidget( m, 15, self.workEndDate_OPM_IOPM_)

				# self.workEndDate_OPM_IOPM_.setDate(self.workEndDate_OPM.date())
				self.workEndDate_OPM_IOPM_.setFixedWidth(int(0.07 * QApplication.primaryScreen().availableGeometry().width()))



				## work end time label and timeedit widget:
				self.createTimeEditBox('workEndTime_OPM_IOPM_')
				self.opm_table_widget.setCellWidget( m, 16, self.workEndTime_OPM_IOPM_)
				# self.workEndTime_OPM_IOPM_.setTime(self.workEndTime_OPM.time())

				## Actual down time value label and lineedit widget:
				self.actualDowntimeInMinutes_ = QLabel('0')
				self.opm_table_widget.setCellWidget( m, 17, self.actualDowntimeInMinutes_)

				Downtimelabel_Text = self.downTime_opm.text()
				self.actualDowntimeInMinutes_.setText(Downtimelabel_Text)
				self.actualDowntimeInMinutes_.setAlignment(Qt.AlignCenter)


				def onChangingDateTimeWidgets_OPMImport(workStartDate_, workStartTime_, workEndDate_, workEndTime_, downTimeLabel_):

					workStartDatetime_IOPM_ = QDateTime(workStartDate_.date(), workStartTime_.time())
					workEndDatetime_IOPM_ = QDateTime(workEndDate_.date(), workEndTime_.time())

					if workEndDatetime_IOPM_ < workStartDatetime_IOPM_:
						workEndDate_.setDate(workStartDate_.date())
						workEndTime_.setTime(workStartTime_.time())

					# Calculate the time difference in minutes
					time_difference_IOPM_ = workStartDatetime_IOPM_.secsTo(workEndDatetime_IOPM_) / 60

					# Convert the time difference to an integer
					time_difference_IOPM_ = int(time_difference_IOPM_)

					# Update the actual downtime value if it's not negative
					if time_difference_IOPM_ >= 0:
						downTimeLabel_.setText(str(time_difference_IOPM_))
					else:
						downTimeLabel_.setText("0")  # or any default value
					

				def functionalityOfOPMDowntime_(workStartDate, workStartTime, workEndDate, workEndTime, downTimeLabel):
					workStartDate.dateChanged.connect(lambda:onChangingDateTimeWidgets_OPMImport(workStartDate, workStartTime, workEndDate, workEndTime, downTimeLabel ))
					workStartTime.timeChanged.connect(lambda:onChangingDateTimeWidgets_OPMImport(workStartDate, workStartTime, workEndDate, workEndTime, downTimeLabel))
					workEndDate.dateChanged.connect(lambda:onChangingDateTimeWidgets_OPMImport(workStartDate, workStartTime, workEndDate, workEndTime, downTimeLabel))
					workEndTime.timeChanged.connect(lambda:onChangingDateTimeWidgets_OPMImport(workStartDate, workStartTime, workEndDate, workEndTime, downTimeLabel))

				functionalityOfOPMDowntime_(self.workStartDate_OPM_IOPM_, self.workStartTime_OPM_IOPM_, self.workEndDate_OPM_IOPM_, self.workEndTime_OPM_IOPM_, self.actualDowntimeInMinutes_)

				self.workStartDate_OPM_IOPM_.setDate(startDateOfCurrentRow)
				self.workStartTime_OPM_IOPM_.setTime(startTimeOfCurrentRow)
				self.workEndDate_OPM_IOPM_.setDate(endDateOfCurrentRow)
				self.workEndTime_OPM_IOPM_.setTime(endTimeOfCurrentRow)



			val = 0
			for i in range(numberOfTrainsSelected_OPM):
				for j in range(numberOfCarsSelected_OPM):
					for k in range(quantity):
						self.opm_table_widget.cellWidget(val, 3).setCurrentText(cleanedListOfSelectedTrains_OPM[i])
						val += 1


			val = 0
			for i in range(numberOfTrainsSelected_OPM):
				for j in range(numberOfCarsSelected_OPM):
					if cleanedListOfSelectedCars_OPm != []:
						for k in range(quantity):
							self.opm_table_widget.cellWidget(val, 4).setCurrentText(cleanedListOfSelectedCars_OPm[j])
							val += 1





			# Create submit form push button
			self.createPushButton('submitBtnInImportOPM_', 'SUBMIT', width=int(0.050 * QApplication.primaryScreen().availableGeometry().width()) )
			self.submitBtnInImportOPM_.setFixedHeight(30)

			# Create import excel file push button
			self.createPushButton('cancelBtnInImportOPM_', 'CANCEL', width=int(0.050 * QApplication.primaryScreen().availableGeometry().width()))
			self.cancelBtnInImportOPM_.setFixedHeight(30)


			# #Create a horizontal layout to keep the add and import button:
			self.layoutForSubmitAndCancelBtnsOfOPMImport_ = QHBoxLayout()
			self.layoutForSubmitAndCancelBtnsOfOPMImport_.addWidget(self.submitBtnInImportOPM_, alignment = Qt.AlignRight)
			self.layoutForSubmitAndCancelBtnsOfOPMImport_.addWidget(self.cancelBtnInImportOPM_, alignment = Qt.AlignLeft)

			
			self.OPMWindowLayout_.addLayout(self.layoutForSubmitAndCancelBtnsOfOPMImport_)

			def submitopmdata():
			
				mandatorySuccess_OPM = True
				mandatoryFieldsOfImportedExcelRows_OPM = [0, 1, 2, 3, 5, 8, 9, 13, 14, 15, 16]
				currentDateTimeValue = datetime.now()

				self.listOfimportedOPMRows_OPMTable = []
				# self.allSysSubSysListInImport_OPMTable = []
	
				
				for j in range(self.opm_table_widget.rowCount()):
					opm_id_string = 'OPM' + '_' + currentDateTimeValue.strftime("%Y%m%d%H%M%S%f")[:-4]
					currentDateTimeValue += timedelta(milliseconds=10)
					singleRowData_OPMTable = [opm_id_string]
				
					# sysSubsys_OPMTable = []

					for k in range(self.opm_table_widget.columnCount()):
						widget = self.opm_table_widget.cellWidget(j, k)
						
						if k in [0, 13, 15]:
							datetime_ = QDateTime(widget.date(), self.opm_table_widget.cellWidget(j, k+1).time())
							singleRowData_OPMTable.append(datetime_.toPython())

						if k in [1, 14, 16]:
							pass


						if widget.isEnabled():
							if isinstance(widget, QComboBox):
								if widget.currentText() == '':
									singleRowData_OPMTable.append(None)
									if col_index in mandatoryFieldsOfImportedExcelRows_OPM:
										widget.setProperty("error", True)
										widget.setStyleSheet(self.comboBoxQSS)
										mandatorySuccess_OPM = False
								else:
									if k == 8:
										query = "SELECT id FROM bom WHERE equipment = %s AND parent_id = 0"
										self.cursor.execute(query, (widget.currentText(),))
										result = self.cursor.fetchone()
										singleRowData_OPMTable.append(result[0])
										widget.setProperty("error", False)
										widget.setStyleSheet(self.comboBoxQSS)
										# sysSubsys_OPMTable.append(widget.currentText())
									
									elif k == 9:
										query = "SELECT id FROM bom WHERE parent_id = (SELECT id FROM bom WHERE equipment = %s AND parent_id = 0) AND equipment = %s"
										self.cursor.execute(query, (self.opm_table_widget.cellWidget(j, k-1).currentText(), widget.currentText()))
										result = self.cursor.fetchone()
										singleRowData_OPMTable.append(result[0])
										widget.setProperty("error", False)
										widget.setStyleSheet(self.comboBoxQSS)
										# sysSubsys_OPMTable.append(widget.currentText())

									else:
										singleRowData_OPMTable.append(widget.currentText())
										widget.setProperty("error", False)
										widget.setStyleSheet(self.comboBoxQSS)

							elif isinstance(widget, QLineEdit):
								if widget.text() == '':
									if k in mandatoryFieldsOfImportedExcelRows_OPM:
										mandatorySuccess_OPM = False
										singleRowData_OPMTable.append(None)
										widget.setProperty("error", True)
										widget.setStyleSheet(self.lineEditBoxQSS)
									else:
										singleRowData_OPMTable.append(None)
								else:
									singleRowData_OPMTable.append(widget.text())
									widget.setProperty("error", False)
									widget.setStyleSheet(self.lineEditBoxQSS)

							elif isinstance(widget, QLabel):
								singleRowData_OPMTable.append(widget.text())
					
						else:
							singleRowData_OPMTable.append(None)
			
					self.listOfimportedOPMRows_OPMTable.append(singleRowData_OPMTable)			
					# self.allSysSubSysListInImport_OPMTable.append(sysSubsys_OPMTable)

				# print('Table data is:', self.listOfimportedOPMRows_OPMTable)
			
				if mandatorySuccess_OPM:


					dest_folder = "C:\\ProgramData\\RAMSify\\Attachments"
					selected_files = [self.mianAttachment_OPM.fileListWidget.item(i).text() for i in range(self.mianAttachment_OPM.fileListWidget.count())]
					listOfAttachmentsNames = []
					for f, file_path in enumerate(selected_files):
						if os.path.exists(file_path):
							file_name = os.path.basename(file_path)
							file_extension = os.path.splitext(file_name)[1]
							current_datetime = datetime.now().strftime("%Y%m%d%H%M%S")
							
							fVal = str(f)
							if len(str(f)) == 1:
								fVal = '00'+str(f)
							elif len(str(f)) == 2:
								fVal = '0'+str(f)
							else:
								fVal = str(f)

							new_file_name = f"{os.path.splitext(file_name)[0]}_{current_datetime}{fVal}{file_extension}"
							listOfAttachmentsNames.append(new_file_name)

							dest_path = os.path.join(dest_folder, new_file_name)
							shutil.copy(file_path, dest_path)
						else:
							QMessageBox.warning(self, "Warning", f"File {file_path} does not exist.", QMessageBox.Ok)


				
					for singleRowData_OPMTable in self.listOfimportedOPMRows_OPMTable:
						
						insert_query = """
							INSERT INTO other_preventive_maintenance (
							opm_id, event_datetime, depot_id, trainset_id, car_number, opm_type, opm_fault_details, 
							opm_investigation_details, system_id, subsystem_id, other_subsystem, jobcard, attachments, work_start_at, work_end_at, downtime, user_id
							) SELECT
								%s, %s, %s, trainsets.id, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s
							FROM
								trainsets
							WHERE
								trainsets.trainset = %s
						"""
						
						singleRowData_OPMTable[12] = str(listOfAttachmentsNames)
						singleRowData_OPMTable.append(self.user_id)
						trainset = singleRowData_OPMTable.pop(3)
						singleRowData_OPMTable.append(trainset)
						
						self.cursor.execute(insert_query, tuple(singleRowData_OPMTable))
						self.mydb.commit()


					opmMsgBox = QMessageBox()
					opmMsgBox.setIcon(QMessageBox.Information) 
					opmMsgBox.setText(f'{self.opm_table_widget.rowCount()} OPMs saved successfully')
					opmMsgBox.setWindowTitle("Message")
					opmMsgBox.setWindowIcon(QIcon('Media/ramsify.png'))
					opmMsgBox.setStandardButtons(QMessageBox.Ok)
					opmMsgBox.exec_()

					self.apply_OPMDT.click()
					self.cancel_OPM.click()

				self.OPMWindow_.close()

			self.submitBtnInImportOPM_.clicked.connect(submitopmdata)
			self.cancelBtnInImportOPM_.clicked.connect(lambda: self.OPMWindow_.close())

			self.OPMWindow_.show()
		
	self.submit_OPM.clicked.connect(onClickingSubmit_OPM)
	


	def onClickingCancel_OPM():

		currentDateTime = datetime.now()
		self.eventDateEdit_OPM.setDate(self.eventDateEdit_OPM.minimumDate())
		self.eventTimeEdit_OPM.setTime(QTime(0, 0))
		self.depotCombobox_OPM.setCurrentIndex(-1)
		self.trainCombobox_OPM.setCurrentIndex(-1)
		for i in range(self.trainCombobox_OPM.model().rowCount()):
			item = self.trainCombobox_OPM.model().item(i)

			inactive_brush = QBrush(QColor('#f6f8fc'))
			item.setBackground(inactive_brush)
			item.setForeground(QColor("black"))
		self.trainCombobox_OPM.lineEdit().setToolTip(None)

		self.carCombobox_OPM.setCurrentIndex(-1)
		for i in range(self.carCombobox_OPM.model().rowCount()):
			item = self.carCombobox_OPM.model().item(i)
			inactive_brush = QBrush(QColor('#f6f8fc'))
			item.setBackground(inactive_brush)
			item.setForeground(QColor("black"))
		self.carCombobox_OPM.lineEdit().setToolTip(None)

		self.jobcardLineEdit_OPM.clear()
		self.quantity_OPM.clear()
		self.mianAttachment_OPM.fileListWidget.clear()
		self.mianAttachment_OPM.fileListWidget.hide()
		self.mianAttachment_OPM.removeButton.setEnabled(False)

		self.typeOf_OPM.setCurrentIndex(-1)
		self.faultDetailsTextBox_OPM.clear()
		self.workdoneTextBox_OPM.clear()
		self.systemComboBox_OPM.setCurrentIndex(-1)
		self.subSystemComboBox_OPM.setCurrentIndex(-1)
		self.workStartDate_OPM.setDate(self.workStartDate_OPM.minimumDate())
		self.workStartTime_OPM.setTime(QTime(0, 0))
		self.workEndDate_OPM.setDate(self.workEndDate_OPM.minimumDate())
		self.workEndTime_OPM.setTime(QTime(0, 0))
		self.downTime_opm.setText('0')


		self.trainCombobox_OPM.setEnabled(False)
		self.subSystemComboBox_OPM.setEnabled(False)
	
	self.cancel_OPM.clicked.connect(onClickingCancel_OPM)


	tab.setLayout(self.OPMMainLayout)