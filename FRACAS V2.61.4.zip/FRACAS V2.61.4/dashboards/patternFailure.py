from PySide6.QtWidgets import (QTableWidgetItem, QPushButton, QWidget, QHBoxLayout, QVBoxLayout, QFormLayout, QLabel, QComboBox, QDateEdit, QTimeEdit, QSizePolicy, 
		QSpacerItem, QLineEdit, QDialog, QDialogButtonBox, QMessageBox, QAbstractItemView, QApplication)
from PySide6.QtGui import QIcon, QFont, QColor, QBrush
from functions import TableWidget

from datetime import datetime, timedelta
import calendar
from PySide6.QtCore import Qt, QDateTime, QDate, QTime
import time
from dateutil.relativedelta import relativedelta



##Function to display the 'Pattern Failure' dashboard:
def patternFailureUi(self):
	
	self.layoutForFilters_PF = QHBoxLayout()

	self.fromFormLayout_PF = QFormLayout()
	self.toFormLayout_PF = QFormLayout()


	currentYear = datetime.now().year
	currentMonth = datetime.now().month

	firstDayOfNextMonth = (datetime(currentYear, currentMonth, 1) + relativedelta(months=1)).date()
	lastDayOfCurrentMonth = (firstDayOfNextMonth - relativedelta(days=1))
	
	start_date = datetime(self.startingYear, self.startingMonth, 1).date()
	end_date = lastDayOfCurrentMonth

	current_date = start_date
	yearMonthStringsForCalculations = []
	yearMonthValuesForCalculations = []

	while current_date <= end_date:
		if (current_date.month != currentMonth) or (current_date.year != currentYear):
			yearMonthValuesForCalculations.append((current_date.year, current_date.month))
			formatted_month = current_date.strftime('%b - %Y')
			yearMonthStringsForCalculations.append(formatted_month)
		current_date += relativedelta(months=1)

	self.createComboBox(yearMonthStringsForCalculations, 'fromCombobox_PF') 
	self.createComboBox(yearMonthStringsForCalculations, 'toCombobox_PF')

	self.fromFormLayout_PF.addRow(QLabel('From: '), self.fromCombobox_PF)
	self.toFormLayout_PF.addRow(QLabel('To: '), self.toCombobox_PF)


	clearFilterIconPath = self.currentTheme.get('clearTableFilterIcon')
	refreshTableIconPath = self.currentTheme.get('refreshIcon')

	self.createPushButton('clearAllFiltersButton_PF', '', clearFilterIconPath, 35, 'Clear filters')

	self.createPushButton('refreshBtn_PF','', refreshTableIconPath, 35, 'Refresh')

	self.refreshBtn_PF.clicked.connect(lambda: self.onClickingRefresh_PF(self.mainVerticalLayout_PatternFailDash))



	self.layoutForFilters_PF.addItem(QSpacerItem(1, 0, QSizePolicy.Expanding, QSizePolicy.Minimum))
	self.layoutForFilters_PF.addLayout(self.fromFormLayout_PF)
	self.layoutForFilters_PF.addLayout(self.toFormLayout_PF)
	self.layoutForFilters_PF.addWidget(self.clearAllFiltersButton_PF, alignment = Qt.AlignRight)
	self.layoutForFilters_PF.addWidget(self.refreshBtn_PF, alignment = Qt.AlignRight)

	self.mainVerticalLayout_PatternFailDash.addLayout(self.layoutForFilters_PF)





########################################################################################################################################
	

	patternFailureTableHeaders = ['System / Subsystem', 'Quantity per\ntrainset', 
								'Item MDBCF\n(Equip-km/failure)', 'Item Failure Rate\n(Failure/km)'] + yearMonthStringsForCalculations + ['Predicted Failure\nNo', 'Last 3M Failures', 
								'Inconsistent with\n Predicted Failure', 'Pattern Failure']


	## Query to fetch the equipments /system and subsytem names:
	equipmentSqlQuery = 'SELECT id, parent_id, equipment, quantity, item_mdbcf FROM bom'
	self.cursor.execute(equipmentSqlQuery)
	BOMData_PF = self.cursor.fetchall()



	## Create a tablewidget to display MDBCF data:
	self.tableForPFDashboard = TableWidget(len(BOMData_PF), len(patternFailureTableHeaders))
	self.tableForPFDashboard.setStyleSheet(self.tableWidgetQSS)
	self.tableForPFDashboard.horizontalHeader().setStyleSheet(self.headerVerticalQSS)
	self.tableForPFDashboard.setAlternatingRowColors(True)
	self.tableForPFDashboard.setShowGrid(False)
	self.tableForPFDashboard.setFixedHeight(int(0.77 * QApplication.primaryScreen().availableGeometry().height()))
	self.tableForPFDashboard.setCornerButtonEnabled(False)
	self.tableForPFDashboard.setEditTriggers(QAbstractItemView.NoEditTriggers)
	self.tableForPFDashboard.setHorizontalHeaderLabels(patternFailureTableHeaders)
	self.tableForPFDashboard.verticalHeader().hide()



	headingLabel_PF = QLabel('Pattern Failure')
	headingLabel_PF.setStyleSheet("font-size: 14pt;")
	
	self.mainVerticalLayout_PatternFailDash.addWidget(headingLabel_PF)
	self.mainVerticalLayout_PatternFailDash.addWidget(self.tableForPFDashboard)


	self.tableForPFDashboard.setColumnWidth(0, int(0.16 * QApplication.primaryScreen().availableGeometry().width()))
	self.tableForPFDashboard.setColumnWidth(1, int(0.07 * QApplication.primaryScreen().availableGeometry().width()))
	self.tableForPFDashboard.setColumnWidth(2, int(0.1 * QApplication.primaryScreen().availableGeometry().width()))
	self.tableForPFDashboard.setColumnWidth(3, int(0.09 * QApplication.primaryScreen().availableGeometry().width()))
	for col in range(4, self.tableForPFDashboard.columnCount()-4):
		self.tableForPFDashboard.setColumnWidth(col, int(0.06 * QApplication.primaryScreen().availableGeometry().width()))

	self.tableForPFDashboard.setColumnWidth(self.tableForPFDashboard.columnCount()-4, int(0.08 * QApplication.primaryScreen().availableGeometry().width()))
	self.tableForPFDashboard.setColumnWidth(self.tableForPFDashboard.columnCount()-3, int(0.08 * QApplication.primaryScreen().availableGeometry().width()))
	self.tableForPFDashboard.setColumnWidth(self.tableForPFDashboard.columnCount()-2, int(0.08 * QApplication.primaryScreen().availableGeometry().width()))
	self.tableForPFDashboard.setColumnWidth(self.tableForPFDashboard.columnCount()-1, int(0.08 * QApplication.primaryScreen().availableGeometry().width()))




	systemEquipmentBg = QColor(self.currentTheme.get('parentComponentTextColor'))
	

	systemsInPF = []
	for i in range(len(BOMData_PF)):

		systemNameItem = QTableWidgetItem(str(BOMData_PF[i][2]))
		if BOMData_PF[i][1] == 0:
			systemNameItem.setForeground(systemEquipmentBg)
			systemsInPF.append(i)


		self.tableForPFDashboard.setItem(i, 0, systemNameItem)

		## Add quantity Values to the quantity Values column:
		if BOMData_PF[i][3] is not None:
			item = QTableWidgetItem(str(BOMData_PF[i][3]))
			item.setTextAlignment(Qt.AlignCenter)
			self.tableForPFDashboard.setItem(i, 1, item)

		else:
			item = QTableWidgetItem('')
			item.setTextAlignment(Qt.AlignCenter)
			self.tableForPFDashboard.setItem(i, 1, item)



		## Add MDBCF Trget Values to the MDBCF Trget Values column:
		if BOMData_PF[i][4] is not None:
			item = QTableWidgetItem(str(BOMData_PF[i][4]))
			item.setTextAlignment(Qt.AlignCenter)
			self.tableForPFDashboard.setItem(i, 2, item)


		## Calculate the Item Failure rate for each component and add to the table:
		if BOMData_PF[i][4] is not None:
			
			## Calculate the item failure rate for each component:
			itemFailureRate = 1 / BOMData_PF[i][4]

			# Use format to represent small numbers without rounding to 0.0
			formatted_itemFailureRate = format(itemFailureRate, '.2E')
			
			item = QTableWidgetItem(str(formatted_itemFailureRate))
			item.setTextAlignment(Qt.AlignCenter)
			self.tableForPFDashboard.setItem(i, 3, item)

		# if BOMData_PF[i][4] is not None:
		# 	predictedFailureNo = itemFailureRate * BOMData_PF[i][3] * last3MonthsRunningMileage
		# 	item = QTableWidgetItem(str(int(predictedFailureNo)))
		# 	item.setTextAlignment(Qt.AlignCenter)
		# 	self.tableForPFDashboard.setItem(i, 4, item)


	#############################################################################################################
	



	for i, YM in enumerate(yearMonthValuesForCalculations):

		from datetime import date

		year, month = YM[0], YM[1]

		for j, equipmentDetails in enumerate(BOMData_PF):
			if self.tableForPFDashboard.item(j, 2):
				query = f'''SELECT COUNT(*)
							FROM corrective_maintenance cm
							JOIN trainsets t ON cm.trainset_id = t.id
							WHERE
								(cm.failure_type = 'Service Failure' OR cm.failure_type = 'Relevant Failure')
								AND YEAR(cm.work_start_at) = {year}
								AND MONTH(cm.work_start_at) = {month}
								AND cm.verification = 'Yes'
								AND cm.failure_responsibility = 'BEML'
								AND t.stabilization < cm.work_start_at
								AND (cm.system_id = {equipmentDetails[0]} OR cm.subsystem_id = {equipmentDetails[0]})
							'''
				self.cursor.execute(query)
				noOfFails = self.cursor.fetchone()

				noOfFailsItem = QTableWidgetItem(str(noOfFails[0]))
				noOfFailsItem.setTextAlignment(Qt.AlignCenter)
				self.tableForPFDashboard.setItem(j, i+4, noOfFailsItem)

	


	dataRangePFDashInTable = range(4, 4+len(yearMonthStringsForCalculations))

	def findingResult():
		for i in range(self.tableForPFDashboard.rowCount()):
			self.tableForPFDashboard.setRowHidden(i, False)
			
		count_unhidden = 0
		lastDataColumn = 0
		for col in range(self.tableForPFDashboard.columnCount() - 1, -1, -1):
			if not self.tableForPFDashboard.isColumnHidden(col):
				count_unhidden += 1

				if count_unhidden == 5:
					lastDataColumn = col
					break
		if lastDataColumn in dataRangePFDashInTable:
			monthYearString = self.tableForPFDashboard.horizontalHeaderItem(lastDataColumn).text()
			date_obj = datetime.strptime(monthYearString, '%b - %Y')

			# Calculate the previous 3 months using relativedelta
			previous_months_list = [(date_obj.year, date_obj.month)]
			for i in range(1, 3):
				previous_month = date_obj - relativedelta(months=i)
				previous_months_list.append((previous_month.year, previous_month.month))


			listOfMonthlyRunningMileages = []
			for i, YM in enumerate(previous_months_list):
				from datetime import date

				year, month = YM[0], YM[1]
				last_day = calendar.monthrange(year, month)[1]
				last_date = date(year, month, last_day)

				sql_query = f"SELECT id FROM trainsets WHERE stabilization < '{last_date}'"
				self.cursor.execute(sql_query)
				trainIds_ = self.cursor.fetchall()
				trainIds = [idd[0] for idd in trainIds_]
				# print(trainIds)

				monthRunningMileage = 0
				for j, trainId in enumerate(trainIds):
					query = f"""
						SELECT tm.monthly_mileage
						FROM trainsets_mileage tm
						JOIN trainsets t ON tm.trainset_id = t.id
						WHERE
							tm.trainset_id = {trainId}
							AND tm.year = {year}
							AND tm.month = {month}
							AND t.stabilization < '{last_date}';
						"""

					self.cursor.execute(query)
					mileage = self.cursor.fetchone()
					if mileage:
						if mileage[0]:
							monthRunningMileage += mileage[0]

				listOfMonthlyRunningMileages.append(monthRunningMileage)

			last3MonthsRunningMileage = sum(listOfMonthlyRunningMileages)
		else:
			last3MonthsRunningMileage = 0


		for i in range(self.tableForPFDashboard.rowCount()):
			if self.tableForPFDashboard.item(i, 2):
				predictedFailureNo = float(self.tableForPFDashboard.item(i, 3).text()) * int(self.tableForPFDashboard.item(i, 1).text()) * last3MonthsRunningMileage
				item = QTableWidgetItem(str(int(predictedFailureNo)))
				item.setTextAlignment(Qt.AlignCenter)
				self.tableForPFDashboard.setItem(i, self.tableForPFDashboard.columnCount()-4, item)


				if lastDataColumn>=6:
					last3MonthsFailures = 0
					for j in range(lastDataColumn, lastDataColumn-3, -1):
						fails = int(self.tableForPFDashboard.item(i, j).text())
						last3MonthsFailures += fails

				else:
					last3MonthsFailures = 0
					for j in range(lastDataColumn, 3, -1):
						fails = int(self.tableForPFDashboard.item(i, j).text())
						last3MonthsFailures += fails

				# print(last3MonthsFailures)
				item = QTableWidgetItem(str(last3MonthsFailures))
				item.setTextAlignment(Qt.AlignCenter)

				self.tableForPFDashboard.setItem(i, self.tableForPFDashboard.columnCount()-3, item)

				consistantResult = 1
				if last3MonthsFailures > predictedFailureNo:
					item = QTableWidgetItem('Inconsistent')
				else:
					consistantResult = 0
					item = QTableWidgetItem('Consistent')
				item.setTextAlignment(Qt.AlignCenter)
				self.tableForPFDashboard.setItem(i, self.tableForPFDashboard.columnCount()-2, item)


				if last3MonthsFailures >= 3:
					threeOrMoreResult = 1
				else:
					threeOrMoreResult = 0

				if consistantResult:
					if threeOrMoreResult:
						patternFailureResult = 'Pattern Failure'
						item = QTableWidgetItem(patternFailureResult)
						item.setTextAlignment(Qt.AlignCenter)
						self.tableForPFDashboard.setItem(i, self.tableForPFDashboard.columnCount()-1, item)

						for g, details in enumerate(BOMData_PF):
							if details[0] == BOMData_PF[i][1]:
								self.tableForPFDashboard.setRowHidden(g, False)
					else:
						# pass
						# patternFailureResult = 'Not A Pattern Failure'
						# item = QTableWidgetItem(patternFailureResult)
						# item.setTextAlignment(Qt.AlignCenter)
						# self.tableForPFDashboard.setItem(i, self.tableForPFDashboard.columnCount()-1, item)

						self.tableForPFDashboard.setRowHidden(i, True)
				else:
					# pass
					# patternFailureResult = 'Not A Pattern Failure'
					# item = QTableWidgetItem(patternFailureResult)
					# item.setTextAlignment(Qt.AlignCenter)
					# self.tableForPFDashboard.setItem(i, self.tableForPFDashboard.columnCount()-1, item)

					self.tableForPFDashboard.setRowHidden(i, True)
			else:
				# pass
				self.tableForPFDashboard.setRowHidden(i, True)

		unHiddenRows_PF = []
		for i in range(self.tableForPFDashboard.rowCount()):
			if not self.tableForPFDashboard.isRowHidden(i):
				unHiddenRows_PF.append(i)

		self.systemsInPFDashboard = []
		for i, val in enumerate(unHiddenRows_PF):
			if val in systemsInPF:
				self.systemsInPFDashboard.append(i)



	def onChangingToCombobox_PF():
		fromIndex = self.fromCombobox_PF.currentIndex()
		toIndex = self.toCombobox_PF.currentIndex()

		for indx in dataRangePFDashInTable[fromIndex+toIndex+1:]:
			self.tableForPFDashboard.setColumnHidden(indx, True)

		for indx in dataRangePFDashInTable[fromIndex:fromIndex+toIndex+1]:
			self.tableForPFDashboard.setColumnHidden(indx, False)

		findingResult()

		headingLabel_PF.setText(f'Pattern Failure for {self.toCombobox_PF.currentText()}')

	def onChangingfromCombobox_PF():
		self.toCombobox_PF.clear()
		fromIndex = self.fromCombobox_PF.currentIndex()
		self.toCombobox_PF.addItems(yearMonthStringsForCalculations[fromIndex:])

		for indx in dataRangePFDashInTable[:fromIndex]:
			self.tableForPFDashboard.setColumnHidden(indx, True)


		for indx in dataRangePFDashInTable[fromIndex:]:
			self.tableForPFDashboard.setColumnHidden(indx, False)

		self.toCombobox_PF.setCurrentIndex(len(yearMonthStringsForCalculations[fromIndex:])-1)
		
	self.fromCombobox_PF.currentIndexChanged.connect(onChangingfromCombobox_PF)
	self.toCombobox_PF.currentIndexChanged.connect(onChangingToCombobox_PF)



	def settingToLastSixMonthsFilters():
		if len(yearMonthStringsForCalculations)<=3:
			self.fromCombobox_PF.setCurrentIndex(0)
		else:
			self.fromCombobox_PF.setCurrentIndex((len(yearMonthStringsForCalculations))-3)

		self.toCombobox_PF.setCurrentIndex(self.toCombobox_PF.count()-1)

	self.clearAllFiltersButton_PF.clicked.connect(settingToLastSixMonthsFilters)

	settingToLastSixMonthsFilters()



def deleteItems_PF(layout):
	if layout:
		while layout.count():
			item = layout.takeAt(0)
			widget = item.widget()
			if widget:
				widget.setParent(None)
			else:
				deleteItems_PF(item.layout())

def onClickingRefresh_PF(self, layout):
	deleteItems_PF(layout)
	self.patternFailureUi()