from PySide6.QtWidgets import (QTableWidgetItem, QPushButton, QWidget, QHBoxLayout, QVBoxLayout, QFormLayout, QLabel, QComboBox, QDateEdit, QTimeEdit, QSizePolicy, 
		QSpacerItem, QLineEdit, QDialog, QDialogButtonBox, QMessageBox, QAbstractItemView, QApplication)
from PySide6.QtGui import QIcon, QFont, QColor, QBrush
from functions import TableWidget

from datetime import datetime, timedelta, date
from dateutil.relativedelta import relativedelta
import calendar
from PySide6.QtCore import Qt, QDateTime, QDate, QTime
import time


def mttrDashboardUi(self):
	from PySide6.QtWidgets import QApplication
	self.layoutForFilters_MTTRDash = QHBoxLayout()
	self.fromFormLayout_MTTRDash = QFormLayout()
	self.toFormLayout_MTTRDash = QFormLayout()

	currentYear = datetime.now().year
	currentMonth = datetime.now().month

	firstDayOfNextMonth = (datetime(currentYear, currentMonth, 1) + relativedelta(months=1)).date()
	lastDayOfCurrentMonth = (firstDayOfNextMonth - relativedelta(days=1))
	
	start_date = datetime(self.startingYear, self.startingMonth, 1).date()
	end_date = lastDayOfCurrentMonth

	current_date = start_date
	yearMonthStringsForCalculations = []
	yearMonthValuesForCalculations = []

	while current_date <= end_date:
		if (current_date.month != currentMonth) or (current_date.year != currentYear):
			yearMonthValuesForCalculations.append((current_date.year, current_date.month))
			formatted_month = current_date.strftime('%b - %Y')
			yearMonthStringsForCalculations.append(formatted_month)
		current_date += relativedelta(months=1)

	self.createComboBox(yearMonthStringsForCalculations, 'fromCombobox_MTTR') 
	self.createComboBox(yearMonthStringsForCalculations, 'toCombobox_MTTR')

	self.fromFormLayout_MTTRDash.addRow(QLabel('From: '), self.fromCombobox_MTTR)
	self.toFormLayout_MTTRDash.addRow(QLabel('To: '), self.toCombobox_MTTR)


	clearFilterIconPath = self.currentTheme.get('clearTableFilterIcon')
	refreshTableIconPath = self.currentTheme.get('refreshIcon')

	self.createPushButton('clearAllFiltersButton_MTTRDash', '', clearFilterIconPath, 35, 'Clear Filters')
	self.createPushButton('refreshBtn_MTTRDash','', refreshTableIconPath, 35, 'Refresh')
	self.refreshBtn_MTTRDash.clicked.connect(lambda: self.onClickingRefresh_MTTR(self.mainVerticalLayout_MTTRDash))
	
	self.layoutForFilters_MTTRDash.addItem(QSpacerItem(1, 0, QSizePolicy.Expanding, QSizePolicy.Minimum))
	self.layoutForFilters_MTTRDash.addLayout(self.fromFormLayout_MTTRDash)
	self.layoutForFilters_MTTRDash.addLayout(self.toFormLayout_MTTRDash)
	self.layoutForFilters_MTTRDash.addWidget(self.clearAllFiltersButton_MTTRDash)
	self.layoutForFilters_MTTRDash.addWidget(self.refreshBtn_MTTRDash)

	self.mainVerticalLayout_MTTRDash.addLayout(self.layoutForFilters_MTTRDash)

	
	mttrTableHeadersLables = ['System', 'MTTR Target\n(Hour)'] + yearMonthStringsForCalculations + ['Result']
	# equipmentIdsList_ = [1, 2, 3, 4, 5, 6, 12, 13, 14, 15, 17, 31, 42, 55, 79, 80, 81, 83, 84, 85, 86, 92, 96, 97]
	equipmentIdsList_ = self.equipmentsListforMTTR
	equipmentIdsList = tuple(sorted(equipmentIdsList_))

	self.tableForMTTRDashboard = TableWidget(len(equipmentIdsList), len(mttrTableHeadersLables))
	self.tableForMTTRDashboard.setStyleSheet(self.tableWidgetQSS)
	self.tableForMTTRDashboard.horizontalHeader().setStyleSheet(self.headerVerticalQSS)
	self.tableForMTTRDashboard.setAlternatingRowColors(True)
	self.tableForMTTRDashboard.setShowGrid(False)
	self.tableForMTTRDashboard.setFixedHeight(int(0.77 * QApplication.primaryScreen().availableGeometry().height()))
	self.tableForMTTRDashboard.setCornerButtonEnabled(False)
	self.tableForMTTRDashboard.setEditTriggers(QAbstractItemView.NoEditTriggers)
	self.tableForMTTRDashboard.setHorizontalHeaderLabels(mttrTableHeadersLables)

	headingLabel_MTTR = QLabel('')
	headingLabel_MTTR.setStyleSheet("font-size: 14pt;")

	self.mainVerticalLayout_MTTRDash.addWidget(headingLabel_MTTR)
	self.mainVerticalLayout_MTTRDash.addWidget(self.tableForMTTRDashboard)


	self.tableForMTTRDashboard.setColumnWidth(0, int(0.2 * QApplication.primaryScreen().availableGeometry().width()))
	for i in range(1, self.tableForMTTRDashboard.columnCount()):
		self.tableForMTTRDashboard.setColumnWidth(i, int(0.07 * QApplication.primaryScreen().availableGeometry().width()))



	if len(equipmentIdsList) > 1:
		equipmentSqlQuery = f"SELECT id, parent_id, equipment, mttr_target FROM bom WHERE id IN {equipmentIdsList}"
	elif len(equipmentIdsList) == 1:
		equipmentSqlQuery = f"SELECT id, parent_id, equipment, mttr_target FROM bom WHERE id = {equipmentIdsList[0]}"
	
	self.cursor.execute(equipmentSqlQuery)
	bomEquipments = self.cursor.fetchall()


	systemEquipmentBg = QColor(self.currentTheme.get('parentComponentTextColor'))
	
	self.systemsInMTTRDashboard = []
	for i, equipmentDetails in enumerate(bomEquipments):
		if equipmentDetails[1] == 0:
			systemNameItem = QTableWidgetItem(str(equipmentDetails[2]))
			systemNameItem.setForeground(systemEquipmentBg)
			self.systemsInMTTRDashboard.append(i)
		else:
			systemNameItem = QTableWidgetItem(str(equipmentDetails[2]))

		self.tableForMTTRDashboard.setItem(i, 0, systemNameItem)

		if equipmentDetails[3]:
			mttrTargetItem = QTableWidgetItem(str(equipmentDetails[3])) 
			mttrTargetItem.setTextAlignment(Qt.AlignCenter)
			mttrTargetItem.setTextAlignment(Qt.AlignCenter)
			self.tableForMTTRDashboard.setItem(i, 1, mttrTargetItem)

	
	for i, YM in enumerate(yearMonthValuesForCalculations):
		year, month = YM[0], YM[1]
		# end_date = date(year, month, calendar.monthrange(year, month)[1])
		end_date = datetime(year, month, calendar.monthrange(year, month)[1], 23, 59, 59)
		start_date = date(year, month, 1) - relativedelta(months=5)
		

		for j, equipmentId in enumerate(equipmentIdsList):
			item = self.tableForMTTRDashboard.item(j, 1)
			if item:
				query = f"""
					SELECT cm.down_time
					FROM corrective_maintenance cm
					JOIN trainsets t ON cm.trainset_id = t.id
					WHERE
						cm.work_start_at BETWEEN '{start_date}' AND '{end_date}'
						AND (cm.failure_type = 'Service Failure' OR cm.failure_type = 'Relevant Failure')
						AND cm.verification = 'Yes'
						AND cm.failure_responsibility = 'BEML'
						AND t.stabilization < cm.work_start_at
						AND (cm.system_id = {equipmentId} OR cm.subsystem_id = {equipmentId})
					"""

				self.cursor.execute(query)
				downTimes = self.cursor.fetchall()


				total_downtime = sum(entry[0] for entry in downTimes)
				total_entries = len(downTimes)
				# print(year, month, equipmentId, total_downtime, total_entries)
				if total_entries:
					mttrValue = round((total_downtime/total_entries)/60, 2)
				else:
					mttrValue = 'No Failure'

				
				mttrValueItem = QTableWidgetItem(str(mttrValue)) 
				mttrValueItem.setTextAlignment(Qt.AlignCenter)
				mttrValueItem.setTextAlignment(Qt.AlignCenter)
				self.tableForMTTRDashboard.setItem(j, i+2, mttrValueItem)

				if i == len(yearMonthValuesForCalculations)-1:
					if mttrValue != 'No Failure':
						if float(mttrValue) <= float(item.text()):
							result = 'Pass'
						else:
							result = 'Fail'
					else:
						result = 'Pass'

					item = QTableWidgetItem(result)
					item.setTextAlignment(Qt.AlignCenter)
					self.tableForMTTRDashboard.setItem(j, i+3, item)




	def findingResult():

		redBg = QColor(self.currentTheme.get('redBGColor'))
		greenBg = QColor(self.currentTheme.get('greenBGColor'))

		count_unhidden = 0
		lastDataColumn = 0
		for col in range(self.tableForMTTRDashboard.columnCount() - 1, -1, -1):
			if not self.tableForMTTRDashboard.isColumnHidden(col):
				count_unhidden += 1

				if count_unhidden == 2:
					lastDataColumn = col
					break

		for i in range(self.tableForMTTRDashboard.rowCount()):
			if self.tableForMTTRDashboard.item(i, 1):
				if self.tableForMTTRDashboard.item(i, lastDataColumn).text() != 'No Failure':
					if float(self.tableForMTTRDashboard.item(i, lastDataColumn).text()) <= float(self.tableForMTTRDashboard.item(i, 1).text()):
						result = 'Pass'
						mttrResultItem = QTableWidgetItem(result)
						mttrResultItem.setTextAlignment(Qt.AlignCenter)
						mttrResultItem.setBackground(greenBg)
					else:
						result = 'Fail'
						mttrResultItem = QTableWidgetItem(result)
						mttrResultItem.setTextAlignment(Qt.AlignCenter)
						mttrResultItem.setBackground(redBg)

				else:
					result = 'Pass'
					mttrResultItem = QTableWidgetItem(result)
					mttrResultItem.setTextAlignment(Qt.AlignCenter)
					mttrResultItem.setBackground(greenBg)

			
				self.tableForMTTRDashboard.setItem(i, self.tableForMTTRDashboard.columnCount()-1, mttrResultItem)


	dataRangeMTTRDashInTable = range(2, 2+len(yearMonthStringsForCalculations))
	
	def onChangingToCombobox_MTTR():
		fromIndex = self.fromCombobox_MTTR.currentIndex()
		toIndex = self.toCombobox_MTTR.currentIndex()

		for indx in dataRangeMTTRDashInTable[fromIndex+toIndex+1:]:
			self.tableForMTTRDashboard.setColumnHidden(indx, True)

		for indx in dataRangeMTTRDashInTable[fromIndex:fromIndex+toIndex+1]:
			self.tableForMTTRDashboard.setColumnHidden(indx, False)

		findingResult()

		headingLabel_MTTR.setText(f'MTTR Result for {self.toCombobox_MTTR.currentText()} (6M)')

	def onChangingFromCombobox_MTTR():
		self.toCombobox_MTTR.clear()
		fromIndex = self.fromCombobox_MTTR.currentIndex()
		self.toCombobox_MTTR.addItems(yearMonthStringsForCalculations[fromIndex:])

		for indx in dataRangeMTTRDashInTable[:fromIndex]:
			self.tableForMTTRDashboard.setColumnHidden(indx, True)


		for indx in dataRangeMTTRDashInTable[fromIndex:]:
			self.tableForMTTRDashboard.setColumnHidden(indx, False)

		self.toCombobox_MTTR.setCurrentIndex(len(yearMonthStringsForCalculations[fromIndex:])-1)

	self.fromCombobox_MTTR.currentIndexChanged.connect(onChangingFromCombobox_MTTR)
	self.toCombobox_MTTR.currentIndexChanged.connect(onChangingToCombobox_MTTR)


	def settingToLastSixMonthsFilters():
		if len(yearMonthStringsForCalculations)<=6:
			self.fromCombobox_MTTR.setCurrentIndex(0)
		else:
			self.fromCombobox_MTTR.setCurrentIndex((len(yearMonthStringsForCalculations))-6)

		self.toCombobox_MTTR.setCurrentIndex(self.toCombobox_MTTR.count()-1)

	self.clearAllFiltersButton_MTTRDash.clicked.connect(settingToLastSixMonthsFilters)

	settingToLastSixMonthsFilters()


def deleteItems_MTTR(layout):
	if layout:
		while layout.count():
			item = layout.takeAt(0)
			widget = item.widget()
			if widget:
				widget.setParent(None)
			else:
				deleteItems_MTTR(item.layout())

def onClickingRefresh_MTTR(self, layout):
	deleteItems_MTTR(layout)
	self.mttrDashboardUi()