from PySide6.QtWidgets import (QLabel, QTableWidgetItem, QHBoxLayout, QFormLayout, QSpacerItem, QSizePolicy, QAbstractItemView, QTableWidget)
from functions import TableWidget, createComboBox, createPushButton
from datetime import datetime, timedelta, date
import calendar
from PySide6.QtCore import Qt
from dateutil.relativedelta import relativedelta
from PySide6.QtGui import QColor


def mdbfUi(self):
	from PySide6.QtWidgets import QApplication
	self.layoutForFilters_MDBFDash = QHBoxLayout()
	self.fromFormLayout_MDBFDash = QFormLayout()
	self.toFormLayout_MDBFDash = QFormLayout()

	currentYear = datetime.now().year
	currentMonth = datetime.now().month

	firstDayOfNextMonth = (datetime(currentYear, currentMonth, 1) + relativedelta(months=1)).date()
	lastDayOfCurrentMonth = (firstDayOfNextMonth - relativedelta(days=1))
	
	start_date = datetime(self.startingYear, self.startingMonth, 1).date()
	end_date = lastDayOfCurrentMonth

	current_date = start_date
	yearMonthStringsForCalculations = []
	yearMonthValuesForCalculations = []

	while current_date <= end_date:
		if (current_date.month != currentMonth) or (current_date.year != currentYear):
			yearMonthValuesForCalculations.append((current_date.year, current_date.month))
			formatted_month = current_date.strftime('%b - %Y')
			yearMonthStringsForCalculations.append(formatted_month)

		# Move to the next month
		current_date += relativedelta(months=1)

	# self.layoutForFilters_MDBFDash = QHBoxLayout()
	self.createComboBox(yearMonthStringsForCalculations, 'fromCombobox_MDBFDash')
	self.createComboBox(yearMonthStringsForCalculations, 'toCombobox_MDBFDash')

	self.fromFormLayout_MDBFDash.addRow('From: ', self.fromCombobox_MDBFDash)
	self.toFormLayout_MDBFDash.addRow('To: ', self.toCombobox_MDBFDash)


	clearFilterIconPath = self.currentTheme.get('clearTableFilterIcon')
	refreshTableIconPath = self.currentTheme.get('refreshIcon')

	self.createPushButton('clearAllFiltersButton_MDBFDash', '', clearFilterIconPath, 35, 'Clear filters')
	self.createPushButton('refreshButton_MDBFDash', '', refreshTableIconPath, 35, 'Refresh')


	self.layoutForFilters_MDBFDash.addItem(QSpacerItem(1, 0, QSizePolicy.Expanding, QSizePolicy.Minimum))
	self.layoutForFilters_MDBFDash.addLayout(self.fromFormLayout_MDBFDash)
	self.layoutForFilters_MDBFDash.addLayout(self.toFormLayout_MDBFDash)
	self.layoutForFilters_MDBFDash.addWidget(self.clearAllFiltersButton_MDBFDash)
	self.layoutForFilters_MDBFDash.addWidget(self.refreshButton_MDBFDash)

	self.mainVerticalLayout_MDBFDash.addLayout(self.layoutForFilters_MDBFDash)


		
	self.refreshButton_MDBFDash.clicked.connect(lambda: self.onClickingRefresh_MDBF(self.mainVerticalLayout_MDBFDash))



	self.monthlyFailuresTable_mdbf = TableWidget()
	headers = ['Depot', 'Trainset'] + yearMonthStringsForCalculations
	self.monthlyFailuresTable_mdbf.setColumnCount(len(headers))
	self.monthlyFailuresTable_mdbf.setHorizontalHeaderLabels(headers)
	self.monthlyFailuresTable_mdbf.setStyleSheet(self.tableWidgetQSS)
	self.monthlyFailuresTable_mdbf.horizontalHeader().setStyleSheet(self.headerHorizontalQSS)
	self.monthlyFailuresTable_mdbf.setAlternatingRowColors(True)
	self.monthlyFailuresTable_mdbf.setFixedHeight(int(0.55 * QApplication.primaryScreen().availableGeometry().height()))
	self.monthlyFailuresTable_mdbf.setShowGrid(False)

	headingLabel_MDBF = QLabel('Monthly Failures')
	headingLabel_MDBF.setStyleSheet("font-size: 14pt;")
	self.mainVerticalLayout_MDBFDash.addWidget(headingLabel_MDBF)

	self.mainVerticalLayout_MDBFDash.addWidget(self.monthlyFailuresTable_mdbf)
	self.monthlyFailuresTable_mdbf.setEditTriggers(QAbstractItemView.NoEditTriggers)

	self.monthlyFailuresTable_mdbf.setColumnWidth(0, int(0.11 * QApplication.primaryScreen().availableGeometry().width()))
	for i in range(1, self.monthlyFailuresTable_mdbf.columnCount()):
		self.monthlyFailuresTable_mdbf.setColumnWidth(i, int(0.07 * QApplication.primaryScreen().availableGeometry().width()))


	


	query = 'SELECT depot, trainset FROM trainsets'
	self.cursor.execute(query)
	res = self.cursor.fetchall()

	self.monthlyFailuresTable_mdbf.setRowCount(len(res)+1)
	for i, (depot, train) in enumerate(res):
		self.monthlyFailuresTable_mdbf.setItem(i, 0, QTableWidgetItem(depot))
		self.monthlyFailuresTable_mdbf.setItem(i, 1, QTableWidgetItem(train))


	self.monthlyFailuresTable_mdbf.setItem(self.monthlyFailuresTable_mdbf.rowCount()-1, 0, QTableWidgetItem('Total'))

	allMonthsFails = []
	for i, YM in enumerate(yearMonthValuesForCalculations):
		year, month = YM[0], YM[1]
		# last_day = calendar.monthrange(year, month)[1]
		# last_date = date(year, month, last_day)


		sql_query = "SELECT id FROM trainsets"
		# sql_query = "SELECT id FROM trainsets WHERE stabilization <"
		self.cursor.execute(sql_query)
		trainIds_ = self.cursor.fetchall()
		trainIds = [idd[0] for idd in trainIds_]
		curentMonthFails = 0
		for j, trainID in enumerate(trainIds):
			query = f"""SELECT COUNT(cm.cm_id)
						FROM corrective_maintenance cm
						JOIN trainsets t ON cm.trainset_id = t.id
						WHERE
							cm.trainset_id = {trainID}
							AND YEAR(cm.work_start_at) = {year}
							AND MONTH(cm.work_start_at) = {month}
							AND cm.failure_type = 'Service Failure'
							AND cm.verification = 'Yes'
							AND cm.failure_responsibility = 'BEML'
							AND t.stabilization < cm.work_start_at;
						"""
			self.cursor.execute(query)
			resu = self.cursor.fetchone()
			# print(f'No of failures for year {year} and month {month} for train {trainID} is: ', resu[0])
			self.monthlyFailuresTable_mdbf.setItem(j, i+2, QTableWidgetItem(str(resu[0])))
			curentMonthFails += resu[0]
		allMonthsFails.append(curentMonthFails)


	for j in range(2, self.monthlyFailuresTable_mdbf.columnCount()):
		totalMonthwiseFailures = 0
		for i in range(self.monthlyFailuresTable_mdbf.rowCount()-1):
			item = self.monthlyFailuresTable_mdbf.item(i,j)
			if item:
				val = int(item.text())
				totalMonthwiseFailures += val

		totalMWFItem = QTableWidgetItem(str(totalMonthwiseFailures))
		totalMWFItem.setTextAlignment(Qt.AlignCenter)
		self.monthlyFailuresTable_mdbf.setItem(self.monthlyFailuresTable_mdbf.rowCount()-1, j, totalMWFItem)


	self.mdbfDashboardTable = TableWidget()
	headers = [''] + yearMonthStringsForCalculations
	self.mdbfDashboardTable.setColumnCount(len(headers))
	self.mdbfDashboardTable.setHorizontalHeaderLabels(headers)
	self.mdbfDashboardTable.setStyleSheet(self.tableWidgetQSS)
	self.mdbfDashboardTable.horizontalHeader().setStyleSheet(self.headerHorizontalQSS)
	self.mdbfDashboardTable.setAlternatingRowColors(True)
	self.mdbfDashboardTable.setFixedHeight(int(0.38 * QApplication.primaryScreen().availableGeometry().height()))
	self.mdbfDashboardTable.setShowGrid(False)

	headingLabel2_MDBF = QLabel('Monthly MDBF Based on Last 6 Months')
	headingLabel2_MDBF.setStyleSheet("font-size: 14pt;")
	self.mainVerticalLayout_MDBFDash.addWidget(headingLabel2_MDBF)

	self.mainVerticalLayout_MDBFDash.addWidget(self.mdbfDashboardTable)
	self.mdbfDashboardTable.setEditTriggers(QAbstractItemView.NoEditTriggers)


	self.mdbfDashboardTable.setColumnWidth(0, int(0.18 * QApplication.primaryScreen().availableGeometry().width()))
	for i in range(1, self.mdbfDashboardTable.columnCount()):
		self.mdbfDashboardTable.setColumnWidth(i, int(0.07 * QApplication.primaryScreen().availableGeometry().width()))

	


	firstColumn = ['Monthly Service Failures', 'Service Failures (6M)', 'Accumulated Failures', 'Trains In Reliability Performance', 'No of Short Fall Trains', 'Monthly Running Mileage', '6 Months Running Mileage', 'Target MDBF(6M)', 'Achieved MDBF (6M)', 'Achieved MDBF With Short Fall Trains (6M)', 'Result']
	self.mdbfDashboardTable.setRowCount(len(firstColumn))
	for i, heading in enumerate(firstColumn):
		self.mdbfDashboardTable.setItem(i, 0, QTableWidgetItem(heading))

	for i, YM in enumerate(yearMonthValuesForCalculations):
		self.mdbfDashboardTable.setItem(0, i+1, QTableWidgetItem(str(allMonthsFails[i])))

	sixMonthsFailsForAllMonths = []
	for i in range(len(yearMonthValuesForCalculations)):
		if i < 6:
			sixMonthsFails = sum(allMonthsFails[:i+1])
		else:
			sixMonthsFails = sum(allMonthsFails[i:i-6:-1])

		sixMonthsFailsForAllMonths.append(sixMonthsFails)
		self.mdbfDashboardTable.setItem(1, i+1, QTableWidgetItem(str(sixMonthsFails)))

	for i in range(len(yearMonthValuesForCalculations)):
		accumulatedFails = sum(allMonthsFails[:i+1])
			
		self.mdbfDashboardTable.setItem(2, i+1, QTableWidgetItem(str(accumulatedFails)))


	for i, YeMo in enumerate(yearMonthValuesForCalculations):

		firstDayOfNextMonth = (datetime(YeMo[0], YeMo[1], 1) + relativedelta(months=1)).date()
		lastDayOfCurrentMonth = (firstDayOfNextMonth - relativedelta(days=1))

		query = "SELECT COUNT(*) FROM trainsets WHERE stabilization < %s"
		self.cursor.execute(query, (lastDayOfCurrentMonth,))
		resu = self.cursor.fetchone()
		self.mdbfDashboardTable.setItem(3, i+1, QTableWidgetItem(str(resu[0])))

	shortFallTrains = []
	for i, YeMo in enumerate(yearMonthValuesForCalculations):
		if self.MonthlyShortFallTrains:
			if self.MonthlyShortFallTrains[i][0]:
				if YeMo == self.MonthlyShortFallTrains[i][0]:
					shortFallTrains.append(self.MonthlyShortFallTrains[i][1])
					self.mdbfDashboardTable.setItem(4, i+1, QTableWidgetItem(str(self.MonthlyShortFallTrains[i][1])))
	

	monthlySumOfMonthMileagesForAllTrains = []
	for i, YM in enumerate(yearMonthValuesForCalculations):
		year, month = YM[0], YM[1]
		last_day = calendar.monthrange(year, month)[1]
		last_date = date(year, month, last_day)
		query = """
				SELECT tm.monthly_mileage
				FROM trainsets_mileage tm
				JOIN trainsets t ON tm.trainset_id = t.id
				WHERE
					tm.year = %s
					AND tm.month = %s
					AND t.stabilization < %s;
			"""

		self.cursor.execute(query, (year, month, last_date))
		resu = self.cursor.fetchall()
		monthMileagesForAllTrains = [mileage[0] for mileage in resu]
		sumOfMonthMileagesForAllTrains = sum(monthMileagesForAllTrains)
		monthlySumOfMonthMileagesForAllTrains.append(sumOfMonthMileagesForAllTrains)
		self.mdbfDashboardTable.setItem(5, i+1, QTableWidgetItem(str(sumOfMonthMileagesForAllTrains)))


	sixMonthsRunningMileagesForAllMonths = []
	for i in range(len(yearMonthValuesForCalculations)):
		if i < 6:
			sixMonthsRunningMileage = sum(monthlySumOfMonthMileagesForAllTrains[:i+1])
		else:
			sixMonthsRunningMileage = sum(monthlySumOfMonthMileagesForAllTrains[i:i-6:-1])

		sixMonthsRunningMileagesForAllMonths.append(sixMonthsRunningMileage)

		self.mdbfDashboardTable.setItem(6, i+1, QTableWidgetItem(str(sixMonthsRunningMileage)))

	for i in range(len(yearMonthValuesForCalculations)):
		self.mdbfDashboardTable.setItem(7, i+1, QTableWidgetItem(str(self.mdbfTarget)))


	for i in range(len(yearMonthValuesForCalculations)):
		if sixMonthsFailsForAllMonths[i] != 0:
			mdbf = round(sixMonthsRunningMileagesForAllMonths[i]/sixMonthsFailsForAllMonths[i], 2)
		else:
			mdbf = 'No Fails'
		
		self.mdbfDashboardTable.setItem(8, i+1, QTableWidgetItem(str(mdbf)))

	if shortFallTrains:
		achievedMDBFWithShortFallTrains = []
		for i in range(len(yearMonthValuesForCalculations)):
			if (shortFallTrains[i] + sixMonthsFailsForAllMonths[i]) != 0:
				mdbfWithShortFallTrain = sixMonthsRunningMileagesForAllMonths[i]/(shortFallTrains[i] + sixMonthsFailsForAllMonths[i])
				roundValueOfMDBFWithShortFallTrains = round(mdbfWithShortFallTrain, 2)
			else:
				roundValueOfMDBFWithShortFallTrains = 'No Fails'

			achievedMDBFWithShortFallTrains.append(roundValueOfMDBFWithShortFallTrains)
			self.mdbfDashboardTable.setItem(9, i+1, QTableWidgetItem(str(roundValueOfMDBFWithShortFallTrains)))		


		for i in range(len(yearMonthValuesForCalculations)):
			if achievedMDBFWithShortFallTrains[i] != 'No Fails':
				if achievedMDBFWithShortFallTrains[i] > self.mdbfTarget:
					resultItem = QTableWidgetItem('Achieved')
					resultItem.setBackground(QColor("#109F10"))
				else:
					resultItem = QTableWidgetItem('Not Achieved')
					resultItem.setBackground(QColor("#D40E0E"))
			else:
				resultItem = QTableWidgetItem('Achieved')
				resultItem.setBackground(QColor("#109F10"))

			self.mdbfDashboardTable.setItem(10, i+1, resultItem)		

	


	monthsRangeForMonthlyFailuresTable_mdbf = range(2, 2+len(yearMonthStringsForCalculations))
	monthsRangeForMdbfDashboardTable = range(1, 1+len(yearMonthStringsForCalculations))

	for row in range(self.monthlyFailuresTable_mdbf.rowCount()):
		for col in range(1,self.monthlyFailuresTable_mdbf.columnCount()):
			item = self.monthlyFailuresTable_mdbf.item(row, col)
			if item:
				item.setTextAlignment(Qt.AlignCenter)

	for row in range(self.mdbfDashboardTable.rowCount()):
		for col in range(1,self.mdbfDashboardTable.columnCount()):
			item = self.mdbfDashboardTable.item(row, col)
			if item:
				item.setTextAlignment(Qt.AlignCenter)
















	def find_totalDuration(datetime_pairs):
		totalDuration = timedelta()

		# Sort datetime pairs by start datetime
		if datetime_pairs:
			sorted_datetime_pairs = sorted(datetime_pairs, key=lambda x: x[0])
			# #print(sorted_datetime_pairs)
			# Initialize variables to keep track of the current start and end datetime
			current_start = sorted_datetime_pairs[0][0]
			current_end = sorted_datetime_pairs[0][1]

			# Iterate through the sorted datetime pairs
			for start, end in sorted_datetime_pairs[1:]:
				# Check for overlap
				if start < current_end:
					# Update the current end datetime if there is an overlap
					current_end = max(current_end, end)
				else:
					# Add the overlapping duration to the total
					totalDuration += current_end - current_start

					# Update the current start and end datetimes
					current_start = start
					current_end = end

			# Add the final overlapping duration (if any)
			totalDuration += current_end - current_start

			return totalDuration




	def calculateDowntimeForMonth(trainId, yearMonthValues):
		year, month = yearMonthValues

		query1 = f"""
				SELECT cm.work_start_at, cm.work_end_at
				FROM corrective_maintenance cm
				JOIN trainsets t ON cm.trainset_id = t.id
				WHERE
					cm.trainset_id = {trainId}
					AND YEAR(cm.work_start_at) = {year}
					AND MONTH(cm.work_start_at) = {month}
					AND (cm.failure_type = 'Service Failure' OR cm.failure_type = 'Relevant Failure')
					AND cm.verification = 'Yes'
					AND cm.failure_responsibility = 'BEML'
					AND t.stabilization < cm.work_start_at;
				"""
		self.cursor.execute(query1)
		result1 = self.cursor.fetchall()
		# print(f'CM data for  trainId {trainId} for month {month} and year {year}', result1)


		query2 = f"""
			SELECT opm.work_start_at, opm.work_end_at
			FROM other_preventive_maintenance opm
			JOIN trainsets t ON opm.trainset_id = t.id
			WHERE
				opm.trainset_id = {trainId}
				AND YEAR(opm.work_start_at) = {year}
				AND MONTH(opm.work_start_at) = {month}
				AND t.stabilization < opm.work_start_at;
			"""

		self.cursor.execute(query2)
		result2 = self.cursor.fetchall()
		# print(f'OPM data for  trainId {trainId} for month {month} and year {year}', result2)
		


		query3 = f"""
			SELECT sc.A_1, sc.A_2, sc.A_3, sc.B1_1, sc.B1_2, sc.B4, sc.B8, sc.C1, sc.C2
			FROM service_checks sc
			JOIN trainsets t ON sc.trainset_id = t.id
			WHERE
				sc.trainset_id = {trainId}
				AND sc.year = {year}
				AND sc.month = {month}
			"""
		self.cursor.execute(query3)
		result3 = self.cursor.fetchall()
		# print(f'SC data for  trainId {trainId} for month {month} and year {year}', result3)


		query = f'SELECT stabilization FROM trainsets WHERE id = {trainId}'
		self.cursor.execute(query)
		stabilization = self.cursor.fetchone()



		scDates = []
		if result3:
			for i, startDate in enumerate(result3[0]):
				if startDate:
					if startDate.date() > stabilization[0]:
						if i in [0, 1, 2]:
							endDate = startDate + timedelta(hours=2.5)

						if i in [3, 4]:
							endDate = startDate + timedelta(hours=10)

						if i == 5:
							endDate = startDate + timedelta(hours=20.5)

						if i == 6:
							endDate = startDate + timedelta(hours=47.5)

						if i == 7:
							endDate = startDate + timedelta(hours=132)

						if i == 8:
							endDate = startDate + timedelta(hours=276)

						scDates.append((startDate, endDate))

		# #print('sc data is-->', scDates)
		allDatePairsOfCurrentTrain = result1 + result2 + scDates
		# #print('all data-->', allDatePairsOfCurrentTrain)

		return find_totalDuration(allDatePairsOfCurrentTrain)













	self.lineTablesList_mdbfDash = []
	for h, line_name in enumerate(self.uniqueLines):
		label = QLabel(f'MDBF for {line_name}')
		label.setStyleSheet("font-size: 14pt;")
		self.mainVerticalLayout_MDBFDash.addWidget(label)

		table_widget = TableWidget()
		self.lineTablesList_mdbfDash.append(table_widget)
		headers = [''] + yearMonthStringsForCalculations
		table_widget.setColumnCount(len(headers))
		table_widget.setHorizontalHeaderLabels(headers)
		table_widget.setStyleSheet(self.tableWidgetQSS)
		table_widget.horizontalHeader().setStyleSheet(self.headerHorizontalQSS)
		# table_widget.verticalHeader().setStyleSheet(self.headerVerticalQSS)
		table_widget.setAlternatingRowColors(True)
		table_widget.setShowGrid(False)
		table_widget.setFixedHeight(int(0.38 * QApplication.primaryScreen().availableGeometry().height()))
		table_widget.setEditTriggers(QAbstractItemView.NoEditTriggers)
		self.mainVerticalLayout_MDBFDash.addWidget(table_widget)
		# table_widget.setRowCount(len(trainNames))


		table_widget.setColumnWidth(0, int(0.18 * QApplication.primaryScreen().availableGeometry().width()))
		for i in range(1, table_widget.columnCount()):
			table_widget.setColumnWidth(i, int(0.07 * QApplication.primaryScreen().availableGeometry().width()))
		

		firstColumn = ['Monthly Service Failures', 'Service Failures (6M)', 'Accumulated Failures', 'Trains In Reliability Performance', 'No of Short Fall Trains', 'Monthly Running Mileage', '6 Months Running Mileage', 'Target MDBF(6M)', 'Achieved MDBF (6M)', 'Achieved MDBF With Short Fall Trains (6M)', 'Result']


		table_widget.setRowCount(len(firstColumn))
		for i, heading in enumerate(firstColumn):
			table_widget.setItem(i, 0, QTableWidgetItem(heading))


		allMonthsFails = []
		for i, YM in enumerate(yearMonthValuesForCalculations):
			year, month = YM[0], YM[1]
			last_day = calendar.monthrange(year, month)[1]
			last_date = date(year, month, last_day)


			# sql_query = "SELECT id FROM trainsets WHERE stabilization < %s AND line = %s"
			sql_query = "SELECT id FROM trainsets WHERE line = %s"
			self.cursor.execute(sql_query, (line_name,))
			trainIds_ = self.cursor.fetchall()
			trainIds = [idd[0] for idd in trainIds_]
			curentMonthFails = 0
			for j, trainID in enumerate(trainIds):
				query = f"""SELECT COUNT(cm.cm_id)
							FROM corrective_maintenance cm
							JOIN trainsets t ON cm.trainset_id = t.id
							WHERE
								cm.trainset_id = {trainID}
								AND YEAR(cm.work_start_at) = {year}
								AND MONTH(cm.work_start_at) = {month}
								AND cm.failure_type = 'Service Failure'
								AND cm.verification = 'Yes'
								AND cm.failure_responsibility = 'BEML'
								AND t.stabilization < cm.work_start_at;
							"""
				self.cursor.execute(query)
				resu = self.cursor.fetchone()
				# print(f'No of failures for year {year} and month {month} for train {trainID} is: ', resu[0])
				# table_widget.setItem(j, i+2, QTableWidgetItem(str(resu[0])))
				curentMonthFails += resu[0]
			allMonthsFails.append(curentMonthFails)



		for i, YM in enumerate(yearMonthValuesForCalculations):
			table_widget.setItem(0, i+1, QTableWidgetItem(str(allMonthsFails[i])))


		sixMonthsFailsForAllMonths = []
		for i in range(len(yearMonthValuesForCalculations)):
			if i < 6:
				sixMonthsFails = sum(allMonthsFails[:i+1])
			else:
				sixMonthsFails = sum(allMonthsFails[i:i-6:-1])

			sixMonthsFailsForAllMonths.append(sixMonthsFails)
			table_widget.setItem(1, i+1, QTableWidgetItem(str(sixMonthsFails)))


		for i in range(len(yearMonthValuesForCalculations)):
			accumulatedFails = sum(allMonthsFails[:i+1])
				
			table_widget.setItem(2, i+1, QTableWidgetItem(str(accumulatedFails)))


		trainsUnderReliabilityPerformanceForCurrentLine = []
		for i, YeMo in enumerate(yearMonthValuesForCalculations):

			firstDayOfNextMonth = (datetime(YeMo[0], YeMo[1], 1) + relativedelta(months=1)).date()
			lastDayOfCurrentMonth = (firstDayOfNextMonth - relativedelta(days=1))

			query = "SELECT COUNT(*) FROM trainsets WHERE stabilization < %s AND line = %s"
			self.cursor.execute(query, (lastDayOfCurrentMonth,line_name))
			resu = self.cursor.fetchone()
			trainsUnderReliabilityPerformanceForCurrentLine.append(resu[0])
			table_widget.setItem(3, i+1, QTableWidgetItem(str(resu[0])))










		allActualMonthlyDowntimesForCurrentLine = []
		for i,YM in enumerate(yearMonthValuesForCalculations):
			year, month = YM[0], YM[1]
			last_day = calendar.monthrange(year, month)[1]
			last_date = date(year, month, last_day)

			sql_query = "SELECT id FROM trainsets WHERE line = %s"
			self.cursor.execute(sql_query, (line_name,))
			trainIds_ = self.cursor.fetchall()
			trainIds = [idd[0] for idd in trainIds_]
			# print(trainIds)

			currentMonthDownTime = timedelta()
			for trainID in trainIds:
				monthDownTime = calculateDowntimeForMonth(trainID, YM)
				# print('monthDownTime', monthDownTime)
				if monthDownTime:
					currentMonthDownTime += monthDownTime
					# print(currentMonthDownTime)

			totalDownTimeForThisMonth = currentMonthDownTime.days*24*60 + currentMonthDownTime.seconds//60
			allActualMonthlyDowntimesForCurrentLine.append(totalDownTimeForThisMonth)
			# print(f'Downtime for {YM} is', totalDownTimeForThisMonth)

			# self.availabilitySummaryTable.setItem(5, i+1, QTableWidgetItem(str(totalDownTimeForThisMonth)))
			# item = QTableWidgetItem(str(totalDownTimeForThisMonth))
			# self.availabilitySummaryTable.setItem(rowCount - 2, i+1, item)
		# print(allActualMonthlyDowntimesForCurrentLine)
		allActual6MonthsDowntimes = []
		for i in range(len(yearMonthValuesForCalculations)):
			if i < 6:
				sixMonthsActualDowntime = sum(allActualMonthlyDowntimesForCurrentLine[:i+1])
			else:
				sixMonthsActualDowntime = sum(allActualMonthlyDowntimesForCurrentLine[i:i-6:-1])

			allActual6MonthsDowntimes.append(sixMonthsActualDowntime)
		# print(allActual6MonthsDowntimes)


		totalMinutesInMonthForAllTrainsForCurrentLine = []
		for i,YM in enumerate(yearMonthValuesForCalculations):
			year, month = YM[0], YM[1]
			last_day = calendar.monthrange(year, month)[1]
			last_date = date(year, month, last_day)

			sql_query = "SELECT id FROM trainsets WHERE stabilization < %s AND line = %s"
			self.cursor.execute(sql_query, (last_date, line_name))
			trainIds_ = self.cursor.fetchall()

			_, last_day = calendar.monthrange(YM[0], YM[1])
			minutes_in_day = 24 * 60
			totalMinutesInMonth = last_day * minutes_in_day * len(trainIds_)
			totalMinutesInMonthForAllTrainsForCurrentLine.append(totalMinutesInMonth)
		# print(totalMinutesInMonthForAllTrainsForCurrentLine)


		totalTimeIn6MonthsForAllTrainsForCurrentLine = []
		for i in range(len(yearMonthValuesForCalculations)):
			if i < 6:
				sixMonthsTotalTime = sum(totalMinutesInMonthForAllTrainsForCurrentLine[:i+1])
			else:
				sixMonthsTotalTime = sum(totalMinutesInMonthForAllTrainsForCurrentLine[i:i-6:-1])

			totalTimeIn6MonthsForAllTrainsForCurrentLine.append(sixMonthsTotalTime)
		


		self.MonthlyShortFallTrainsForCurrentLine = []
		for i, YM in enumerate(yearMonthValuesForCalculations):
			year, month = YM[0], YM[1]
			last_day = calendar.monthrange(year, month)[1]
			last_date = date(year, month, last_day)

			sql_query = "SELECT id FROM trainsets WHERE stabilization < %s"
			self.cursor.execute(sql_query, (last_date,))
			trainIds_ = self.cursor.fetchall()
			# print(trainIds_)


			if totalTimeIn6MonthsForAllTrainsForCurrentLine[i]:
				availabiltyVal = 1-(allActual6MonthsDowntimes[i]/totalTimeIn6MonthsForAllTrainsForCurrentLine[i])
				# availabiltyPercentage = round(availabiltyVal*100, 2)
				# item = QTableWidgetItem(str(availabiltyPercentage))
				# item.setTextAlignment(Qt.AlignCenter)
				
				# self.availabilitySummaryTable.setItem(rowCount - 3, i+1, item)


				# redBg = QColor(self.currentTheme.get('redBGColor'))
				# greenBg = QColor(self.currentTheme.get('greenBGColor'))

				# if self.availabilityTarget < availabiltyPercentage:
				# 	resultItem = QTableWidgetItem('Achieved')
				# 	resultItem.setTextAlignment(Qt.AlignCenter)
				# 	resultItem.setBackground(greenBg)

				# else:
				# 	resultItem = QTableWidgetItem('Not Achieved')
				# 	resultItem.setTextAlignment(Qt.AlignCenter)
				# 	resultItem.setBackground(redBg)

				# self.availabilitySummaryTable.setItem(rowCount - 2, i+1, resultItem)


				if ((self.availabilityTarget/100) - availabiltyVal)*len(trainIds_) < 0:
					shortFallTrains = 0
				else:
					shortFallTrains = int(((self.availabilityTarget/100) - availabiltyVal)*len(trainIds_))+1

				self.MonthlyShortFallTrainsForCurrentLine.append((YM, shortFallTrains))
				# item = QTableWidgetItem(str(shortFallTrains))
				# item.setTextAlignment(Qt.AlignCenter)
				# table_widget.setItem(4, i+1, item)
			else:
				self.MonthlyShortFallTrainsForCurrentLine.append((YM, 0))







		shortFallTrains = []
		for i, YeMo in enumerate(yearMonthValuesForCalculations):
			if self.MonthlyShortFallTrainsForCurrentLine:
				if self.MonthlyShortFallTrainsForCurrentLine[i][0]:
					if YeMo == self.MonthlyShortFallTrainsForCurrentLine[i][0]:
						shortFallTrains.append(self.MonthlyShortFallTrainsForCurrentLine[i][1])
						table_widget.setItem(4, i+1, QTableWidgetItem(str(self.MonthlyShortFallTrainsForCurrentLine[i][1])))
		# print(self.MonthlyShortFallTrainsForCurrentLine)

		monthlySumOfMonthMileagesForAllTrains = []


		


		for i, YM in enumerate(yearMonthValuesForCalculations):
			year, month = YM[0], YM[1]
			last_day = calendar.monthrange(year, month)[1]
			last_date = date(year, month, last_day)


			sql_query = "SELECT id FROM trainsets WHERE stabilization < %s AND line = %s"
			self.cursor.execute(sql_query, (last_date,line_name))
			trainIds_ = self.cursor.fetchall()
			trainIds = [idd[0] for idd in trainIds_]
			trainIdsTuple = tuple(trainIds)

			if trainIdsTuple:
				if len(trainIdsTuple) > 1:
					query = f"""
							SELECT tm.monthly_mileage
							FROM trainsets_mileage tm
							JOIN trainsets t ON tm.trainset_id = t.id
							WHERE
								tm.trainset_id IN {trainIdsTuple}
								AND tm.year = {year}
								AND tm.month =  {month}
								AND t.stabilization < '{last_date}';
						"""
				
				elif len(trainIdsTuple) == 1:
					query = f"""
							SELECT tm.monthly_mileage
							FROM trainsets_mileage tm
							JOIN trainsets t ON tm.trainset_id = t.id
							WHERE
								tm.trainset_id = {trainIdsTuple[0]}
								AND tm.year = {year}
								AND tm.month =  {month}
								AND t.stabilization < '{last_date}';
						"""


				# self.cursor.execute(query, (trainIdsTuple, year, month, last_date))
				self.cursor.execute(query)
				resu = self.cursor.fetchall()
				monthMileagesForAllTrains = [mileage[0] for mileage in resu]
				sumOfMonthMileagesForAllTrains = sum(monthMileagesForAllTrains)
				monthlySumOfMonthMileagesForAllTrains.append(sumOfMonthMileagesForAllTrains)
				table_widget.setItem(5, i+1, QTableWidgetItem(str(sumOfMonthMileagesForAllTrains)))
			else:
				monthlySumOfMonthMileagesForAllTrains.append(0)
				table_widget.setItem(5, i+1, QTableWidgetItem(str(0)))


		sixMonthsRunningMileagesForAllMonths = []
		for i in range(len(yearMonthValuesForCalculations)):
			if i < 6:
				sixMonthsRunningMileage = sum(monthlySumOfMonthMileagesForAllTrains[:i+1])
			else:
				sixMonthsRunningMileage = sum(monthlySumOfMonthMileagesForAllTrains[i:i-6:-1])

			sixMonthsRunningMileagesForAllMonths.append(sixMonthsRunningMileage)

			table_widget.setItem(6, i+1, QTableWidgetItem(str(sixMonthsRunningMileage)))

		for i in range(len(yearMonthValuesForCalculations)):
			table_widget.setItem(7, i+1, QTableWidgetItem(str(self.mdbfTarget)))


		for i in range(len(yearMonthValuesForCalculations)):
			if sixMonthsFailsForAllMonths[i] != 0:
				mdbf = round(sixMonthsRunningMileagesForAllMonths[i]/sixMonthsFailsForAllMonths[i], 2)
			else:
				mdbf = 'No Fails'
			
			table_widget.setItem(8, i+1, QTableWidgetItem(str(mdbf)))

		if shortFallTrains:
			achievedMDBFWithShortFallTrains = []
			for i in range(len(yearMonthValuesForCalculations)):
				if (shortFallTrains[i] + sixMonthsFailsForAllMonths[i]) != 0:
					mdbfWithShortFallTrain = sixMonthsRunningMileagesForAllMonths[i]/(shortFallTrains[i] + sixMonthsFailsForAllMonths[i])
					roundValueOfMDBFWithShortFallTrains = round(mdbfWithShortFallTrain, 2)
				else:
					roundValueOfMDBFWithShortFallTrains = 'No Fails'

				achievedMDBFWithShortFallTrains.append(roundValueOfMDBFWithShortFallTrains)
				table_widget.setItem(9, i+1, QTableWidgetItem(str(roundValueOfMDBFWithShortFallTrains)))		


			for i in range(len(yearMonthValuesForCalculations)):
				if achievedMDBFWithShortFallTrains[i] != 'No Fails':
					if achievedMDBFWithShortFallTrains[i] > self.mdbfTarget:
						resultItem = QTableWidgetItem('Achieved')
						resultItem.setBackground(QColor("#109F10"))
					else:
						resultItem = QTableWidgetItem('Not Achieved')
						resultItem.setBackground(QColor("#D40E0E"))
				else:
					resultItem = QTableWidgetItem('Achieved')
					resultItem.setBackground(QColor("#109F10"))

				table_widget.setItem(10, i+1, resultItem)		

	


	# monthsRangeForMonthlyFailuresTable_mdbf = range(2, 2+len(yearMonthStringsForCalculations))

		for row in range(table_widget.rowCount()):
			for col in range(1,table_widget.columnCount()):
				item = table_widget.item(row, col)
				if item:
					item.setTextAlignment(Qt.AlignCenter)

	# for row in range(self.mdbfDashboardTable.rowCount()):
	# 	for col in range(1,self.mdbfDashboardTable.columnCount()):
	# 		item = self.mdbfDashboardTable.item(row, col)
	# 		if item:
	# 			item.setTextAlignment(Qt.AlignCenter)












	monthsRangeForMdbfLineTable = range(1, 1+len(yearMonthStringsForCalculations))


	def onChangingToCombobox_MDBFDash():
		fromIndex = self.fromCombobox_MDBFDash.currentIndex()
		toIndex = self.toCombobox_MDBFDash.currentIndex()

		for indx in monthsRangeForMonthlyFailuresTable_mdbf[fromIndex+toIndex+1:]:
			self.monthlyFailuresTable_mdbf.setColumnHidden(indx, True)
		for indx in monthsRangeForMdbfDashboardTable[fromIndex+toIndex+1:]:
			self.mdbfDashboardTable.setColumnHidden(indx, True)
		for tab in self.lineTablesList_mdbfDash:
			for indx in monthsRangeForMdbfLineTable[fromIndex+toIndex+1:]:
				tab.setColumnHidden(indx, True)


		for indx in monthsRangeForMonthlyFailuresTable_mdbf[fromIndex:fromIndex+toIndex+1]:
			self.monthlyFailuresTable_mdbf.setColumnHidden(indx, False)
		for indx in monthsRangeForMdbfDashboardTable[fromIndex:fromIndex+toIndex+1]:
			self.mdbfDashboardTable.setColumnHidden(indx, False)
		for tab in self.lineTablesList_mdbfDash:
			for indx in monthsRangeForMdbfLineTable[fromIndex:fromIndex+toIndex+1]:
				tab.setColumnHidden(indx, False)


		# headingLabel_MDBF.setText(f'MDBF for {self.toCombobox_MDBFDash.currentText()}')



	def onChangingFromCombobox_MDBFDash():
		self.toCombobox_MDBFDash.clear()
		fromIndex = self.fromCombobox_MDBFDash.currentIndex()
		self.toCombobox_MDBFDash.addItems(yearMonthStringsForCalculations[fromIndex:])

		for indx in monthsRangeForMonthlyFailuresTable_mdbf[:fromIndex]:
			self.monthlyFailuresTable_mdbf.setColumnHidden(indx, True)
		for indx in monthsRangeForMdbfDashboardTable[:fromIndex]:
			self.mdbfDashboardTable.setColumnHidden(indx, True)
		for tab in self.lineTablesList_mdbfDash:
			for indx in monthsRangeForMdbfLineTable[:fromIndex]:
				tab.setColumnHidden(indx, True)



		for indx in monthsRangeForMonthlyFailuresTable_mdbf[fromIndex:]:
			self.monthlyFailuresTable_mdbf.setColumnHidden(indx, False)
		for indx in monthsRangeForMdbfDashboardTable[fromIndex:]:
			self.mdbfDashboardTable.setColumnHidden(indx, False)
		for tab in self.lineTablesList_mdbfDash:
			for indx in monthsRangeForMdbfLineTable[fromIndex:]:
				tab.setColumnHidden(indx, False)
			
		self.toCombobox_MDBFDash.setCurrentIndex(len(yearMonthStringsForCalculations[fromIndex:])-1)

	self.fromCombobox_MDBFDash.currentIndexChanged.connect(onChangingFromCombobox_MDBFDash)
	self.toCombobox_MDBFDash.currentIndexChanged.connect(onChangingToCombobox_MDBFDash)

	


	def settingToLastSixMonthsFilters():
		
		if len(yearMonthStringsForCalculations)<=6:
			self.fromCombobox_MDBFDash.setCurrentIndex(0)
		else:
			self.fromCombobox_MDBFDash.setCurrentIndex((len(yearMonthStringsForCalculations))-6)

		self.toCombobox_MDBFDash.setCurrentIndex(self.toCombobox_MDBFDash.count()-1)

	self.clearAllFiltersButton_MDBFDash.clicked.connect(settingToLastSixMonthsFilters)

	settingToLastSixMonthsFilters()


def deleteItems_MDBF(layout):
	if layout:
		while layout.count():
			item = layout.takeAt(0)
			widget = item.widget()
			if widget:
				widget.setParent(None)
			else:
				deleteItems_MDBF(item.layout())

def onClickingRefresh_MDBF(self, layout):
	deleteItems_MDBF(layout)
	self.mdbfUi()