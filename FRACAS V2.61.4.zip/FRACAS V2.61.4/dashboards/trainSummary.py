from PySide6.QtWidgets import (QLabel, QTableWidgetItem, QAbstractItemView, QHBoxLayout, QFormLayout, QSpacerItem, QSizePolicy)
from functions import TableWidget
from datetime import datetime, timedelta, date
import calendar
from PySide6.QtCore import Qt
from dateutil.relativedelta import relativedelta
from PySide6.QtGui import QColor


def trainSummaryUi(self):
	from PySide6.QtWidgets import QApplication
	self.layoutForFilters_trainSummaryDash = QHBoxLayout()
	self.monthFormLayout_trainSummaryDash = QFormLayout()

	self.layoutForFilters_trainSummaryDash.addItem(QSpacerItem(1, 0, QSizePolicy.Expanding, QSizePolicy.Minimum))
	self.layoutForFilters_trainSummaryDash.addLayout(self.monthFormLayout_trainSummaryDash)

	# Get the current year and month
	currentYear = datetime.now().year
	currentMonth = datetime.now().month

	firstDayOfNextMonth = (datetime(currentYear, currentMonth, 1) + relativedelta(months=1)).date()
	lastDayOfCurrentMonth = (firstDayOfNextMonth - relativedelta(days=1))
	
	start_date = datetime(self.startingYear, self.startingMonth, 1).date()
	end_date = lastDayOfCurrentMonth

	current_date = start_date
	yearMonthStringsForCalculations = []
	yearMonthValuesForCalculations = []

	while current_date <= end_date:
		if (current_date.month != currentMonth) or (current_date.year != currentYear):
			yearMonthValuesForCalculations.append((current_date.year, current_date.month))
			formatted_month = current_date.strftime('%b - %Y')
			yearMonthStringsForCalculations.append(formatted_month)

		# Move to the next month
		current_date += relativedelta(months=1)


	self.createComboBox(yearMonthStringsForCalculations[:], 'monthCombobox_trainSummaryDash')
	self.monthFormLayout_trainSummaryDash.addRow('Month: ', self.monthCombobox_trainSummaryDash)


	self.trainSummaryTable = TableWidget()
	# headers = ['Depot', 'No of Trains \n Under Commissioning', 'No of Trains Under Stabilization', 'No of Trains Under \n Reliability Verification', 'Total No of Trains']
	headers = ['Depot', 'No of Trains Under Commissioning', 'No of Trains Under Stabilization', 'No of Trains Under Reliability Verification', 'Total No of Trains']
	self.trainSummaryTable.setColumnCount(len(headers))
	self.trainSummaryTable.setHorizontalHeaderLabels(headers)
	self.trainSummaryTable.setStyleSheet(self.tableWidgetQSS)
	self.trainSummaryTable.horizontalHeader().setStyleSheet(self.headerHorizontalQSS)
	# self.trainSummaryTable.verticalHeader().setStyleSheet(self.headerVerticalQSS)
	self.trainSummaryTable.setAlternatingRowColors(True)
	self.trainSummaryTable.setShowGrid(False)

	trainSummaryHeadngLabel = QLabel('')
	trainSummaryHeadngLabel.setStyleSheet("font-size: 14pt;")

	self.mainVerticalLayout_TrainSummaryDash.addLayout(self.layoutForFilters_trainSummaryDash)
	self.mainVerticalLayout_TrainSummaryDash.addWidget(trainSummaryHeadngLabel)
	self.mainVerticalLayout_TrainSummaryDash.addWidget(self.trainSummaryTable)
	self.trainSummaryTable.setEditTriggers(QAbstractItemView.NoEditTriggers)

	self.trainSummaryTable.setColumnWidth(0, int(0.08 * QApplication.primaryScreen().availableGeometry().width()))
	self.trainSummaryTable.setColumnWidth(1, int(0.15 * QApplication.primaryScreen().availableGeometry().width()))
	self.trainSummaryTable.setColumnWidth(2, int(0.15 * QApplication.primaryScreen().availableGeometry().width()))
	self.trainSummaryTable.setColumnWidth(3, int(0.19 * QApplication.primaryScreen().availableGeometry().width()))
	self.trainSummaryTable.setColumnWidth(4, int(0.1 * QApplication.primaryScreen().availableGeometry().width()))



	firstColumn = self.depotsList + ['Total Fleet']
	self.trainSummaryTable.setRowCount(len(firstColumn))
	for i, val in enumerate(firstColumn):
		self.trainSummaryTable.setItem(i, 0, QTableWidgetItem(val))

	def calculationsOfTrainSummary():
		MonthCBIndex = self.monthCombobox_trainSummaryDash.currentIndex()
		YMValues = yearMonthValuesForCalculations[MonthCBIndex]
		trainSummaryHeadngLabel.setText(f'Train Summary for {self.monthCombobox_trainSummaryDash.currentText()}')


		# currentYear = YMValues[0]
		# currentMonth = YMValues[1]
		# current_date = datetime(currentYear, currentMonth, 1)
		# previous_month_last_day = current_date - timedelta(days=1)
		_, last_day = calendar.monthrange(YMValues[0], YMValues[1])
		previous_month_last_day = datetime(YMValues[0], YMValues[1], last_day)


		sumOfTrainsUnderRevenue = 0
		sumOfTrainsUnderStabilization = 0
		sumOfTrainsAfterStabilization = 0
		for i, depot in enumerate(self.depotsList):
			query = f"SELECT COUNT(*) FROM trainsets WHERE depot = '{depot}' AND revenue_date > '{previous_month_last_day.date()}'"
			self.cursor.execute(query)
			noOftrainsUnderRevenue = self.cursor.fetchone()
			item = QTableWidgetItem(str(noOftrainsUnderRevenue[0]))
			item.setTextAlignment(Qt.AlignCenter)
			self.trainSummaryTable.setItem(i, 1, item)
			sumOfTrainsUnderRevenue += noOftrainsUnderRevenue[0]

			query = f"SELECT COUNT(*) FROM trainsets WHERE depot = '{depot}' AND revenue_date <= '{previous_month_last_day.date()}' AND stabilization > '{previous_month_last_day.date()}'"
			self.cursor.execute(query)
			noOftrainsUnderStabilization = self.cursor.fetchone()
			item = QTableWidgetItem(str(noOftrainsUnderStabilization[0]))
			item.setTextAlignment(Qt.AlignCenter)
			self.trainSummaryTable.setItem(i, 2, item)
			sumOfTrainsUnderStabilization += noOftrainsUnderStabilization[0]

			query = f"SELECT COUNT(*) FROM trainsets WHERE depot = '{depot}' AND '{previous_month_last_day.date()}' >= stabilization"
			self.cursor.execute(query)
			noOftrainsAfterStabilization = self.cursor.fetchone()
			item = QTableWidgetItem(str(noOftrainsAfterStabilization[0]))
			item.setTextAlignment(Qt.AlignCenter)
			self.trainSummaryTable.setItem(i, 3, item)
			sumOfTrainsAfterStabilization += noOftrainsAfterStabilization[0]

			totalTrains = noOftrainsUnderRevenue[0] + noOftrainsUnderStabilization[0] + noOftrainsAfterStabilization[0]
			item = QTableWidgetItem(str(totalTrains))
			item.setTextAlignment(Qt.AlignCenter)
			self.trainSummaryTable.setItem(i, 4, item)

		item = QTableWidgetItem(str(sumOfTrainsUnderRevenue))
		item.setTextAlignment(Qt.AlignCenter)
		self.trainSummaryTable.setItem(len(self.depotsList), 1, item)

		item = QTableWidgetItem(str(sumOfTrainsUnderStabilization))
		item.setTextAlignment(Qt.AlignCenter)
		self.trainSummaryTable.setItem(len(self.depotsList), 2, item)

		item = QTableWidgetItem(str(sumOfTrainsAfterStabilization))
		item.setTextAlignment(Qt.AlignCenter)
		self.trainSummaryTable.setItem(len(self.depotsList), 3, item)

		totalFleetTrains = sumOfTrainsUnderRevenue + sumOfTrainsUnderStabilization + sumOfTrainsAfterStabilization
		item = QTableWidgetItem(str(totalFleetTrains))
		item.setTextAlignment(Qt.AlignCenter)
		self.trainSummaryTable.setItem(len(self.depotsList), 4, item)
	self.monthCombobox_trainSummaryDash.currentIndexChanged.connect(calculationsOfTrainSummary)
	self.monthCombobox_trainSummaryDash.setCurrentIndex(self.monthCombobox_trainSummaryDash.count()-1)