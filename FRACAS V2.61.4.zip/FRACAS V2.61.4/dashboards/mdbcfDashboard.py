from PySide6.QtWidgets import (QTableWidgetItem, QPushButton, QWidget, QHBoxLayout, QVBoxLayout, QFormLayout, QLabel, QComboBox, QDateEdit, QTimeEdit, QSizePolicy, 
		QSpacerItem, QLineEdit, QDialog, QDialogButtonBox, QMessageBox, QAbstractItemView, QApplication)
from PySide6.QtGui import QIcon, QFont, QColor, QBrush
from functions import TableWidget

from datetime import datetime
from dateutil.relativedelta import relativedelta
import calendar
from PySide6.QtCore import Qt, QDateTime, QDate, QTime
import time


##Function to display the MDBCF dashboard:
def mdbcfDashboardUi(self):
	self.layoutForFilters_MDBCFDash = QHBoxLayout()
	self.fromFormLayout_MDBCFDash = QFormLayout()
	self.toFormLayout_MDBCFDash = QFormLayout()

	currentYear = datetime.now().year
	currentMonth = datetime.now().month

	firstDayOfNextMonth = (datetime(currentYear, currentMonth, 1) + relativedelta(months=1)).date()
	lastDayOfCurrentMonth = (firstDayOfNextMonth - relativedelta(days=1))
	
	start_date = datetime(self.startingYear, self.startingMonth, 1).date()
	end_date = lastDayOfCurrentMonth

	current_date = start_date
	yearMonthStringsForCalculations = []
	yearMonthValuesForCalculations = []

	while current_date <= end_date:
		if (current_date.month != currentMonth) or (current_date.year != currentYear):
			yearMonthValuesForCalculations.append((current_date.year, current_date.month))
			formatted_month = current_date.strftime('%b - %Y')
			yearMonthStringsForCalculations.append(formatted_month)
		current_date += relativedelta(months=1)

	self.createComboBox(yearMonthStringsForCalculations, 'fromCombobox_MDBCF') 
	self.createComboBox(yearMonthStringsForCalculations, 'toCombobox_MDBCF')

	self.fromFormLayout_MDBCFDash.addRow(QLabel('From: '), self.fromCombobox_MDBCF)
	self.toFormLayout_MDBCFDash.addRow(QLabel('To: '), self.toCombobox_MDBCF)


	clearFilterIconPath = self.currentTheme.get('clearTableFilterIcon')
	refreshTableIconPath = self.currentTheme.get('refreshIcon')

	self.createPushButton('clearAllFiltersButton_MDBCF', '', clearFilterIconPath, 35, 'Clear Filters')
	self.createPushButton('refreshBtn_MDBCFDash','', refreshTableIconPath, 35, 'Refresh')
	
	self.refreshBtn_MDBCFDash.clicked.connect(lambda: self.onClickingRefresh_MDBCF(self.mainVerticalLayout_MDBCFDash))
	
	self.layoutForFilters_MDBCFDash.addItem(QSpacerItem(1, 0, QSizePolicy.Expanding, QSizePolicy.Minimum))
	self.layoutForFilters_MDBCFDash.addLayout(self.fromFormLayout_MDBCFDash)
	self.layoutForFilters_MDBCFDash.addLayout(self.toFormLayout_MDBCFDash)
	self.layoutForFilters_MDBCFDash.addWidget(self.clearAllFiltersButton_MDBCF)
	self.layoutForFilters_MDBCFDash.addWidget(self.refreshBtn_MDBCFDash)

	self.mainVerticalLayout_MDBCFDash.addLayout(self.layoutForFilters_MDBCFDash)

	mdbcfTableHeadersLable = ['System / Subsystem'] + yearMonthStringsForCalculations +['6M Failure', '6M Running Mileage', 'Quantity', 'Target', 'MDBCF', 'Result']
	

	equipmentSqlQuery = 'SELECT id, parent_id, equipment, quantity, mdbcf_target FROM bom'
	self.cursor.execute(equipmentSqlQuery)
	bomEquipments_MDBCF = self.cursor.fetchall()


	## Create a tablewidget to display MDBCF data:
	self.tableForMDBCFDashboard = TableWidget(len(bomEquipments_MDBCF), len(mdbcfTableHeadersLable))
	self.tableForMDBCFDashboard.setStyleSheet(self.tableWidgetQSS)
	self.tableForMDBCFDashboard.horizontalHeader().setStyleSheet(self.headerVerticalQSS)
	self.tableForMDBCFDashboard.setAlternatingRowColors(True)
	self.tableForMDBCFDashboard.setShowGrid(False)
	self.tableForMDBCFDashboard.setFixedHeight(800)
	self.tableForMDBCFDashboard.setCornerButtonEnabled(False)
	self.tableForMDBCFDashboard.setEditTriggers(QAbstractItemView.NoEditTriggers)
	self.tableForMDBCFDashboard.setHorizontalHeaderLabels(mdbcfTableHeadersLable)


	headingLabel_MDBCF = QLabel('')
	headingLabel_MDBCF.setStyleSheet("font-size: 14pt;")
	self.mainVerticalLayout_MDBCFDash.addWidget(headingLabel_MDBCF)
	self.mainVerticalLayout_MDBCFDash.addWidget(self.tableForMDBCFDashboard)


	self.tableForMDBCFDashboard.setColumnWidth(0, int(0.16 * QApplication.primaryScreen().availableGeometry().width()))
	for col in range(1, self.tableForMDBCFDashboard.columnCount()):
		self.tableForMDBCFDashboard.setColumnWidth(col, int(0.06 * QApplication.primaryScreen().availableGeometry().width()))

	self.tableForMDBCFDashboard.setColumnWidth(self.tableForMDBCFDashboard.columnCount()-5, int(0.09 * QApplication.primaryScreen().availableGeometry().width()))




	systemEquipmentBg = QColor(self.currentTheme.get('parentComponentTextColor'))

	self.systemsInMDBCFDashboard = []
	for i, equipmentDetails in enumerate(bomEquipments_MDBCF):
	
		if equipmentDetails[1] == 0:
			self.systemsInMDBCFDashboard.append(i)
			systemNameItem = QTableWidgetItem(str(equipmentDetails[2]))
			systemNameItem.setForeground(systemEquipmentBg)
		else:
			systemNameItem = QTableWidgetItem(str(equipmentDetails[2]))

		self.tableForMDBCFDashboard.setItem(i, 0, systemNameItem)
		
		if equipmentDetails[4]:
			mdbcfTargeItem = QTableWidgetItem(str(equipmentDetails[4]))
			mdbcfTargeItem.setTextAlignment(Qt.AlignCenter)
			self.tableForMDBCFDashboard.setItem(i, self.tableForMDBCFDashboard.columnCount()-3, mdbcfTargeItem )

	

	dataRangeMDBCFDashInTable = range(1, 1+len(yearMonthStringsForCalculations))




	for i, YM in enumerate(yearMonthValuesForCalculations):
		from datetime import date

		year, month = YM[0], YM[1]

		for j, equipmentDetails in enumerate(bomEquipments_MDBCF):
			query = f'''SELECT COUNT(*)
						FROM corrective_maintenance cm
						JOIN trainsets t ON cm.trainset_id = t.id
						WHERE
							(cm.failure_type = 'Service Failure' OR cm.failure_type = 'Relevant Failure')
							AND YEAR(cm.work_start_at) = {year}
							AND MONTH(cm.work_start_at) = {month}
							AND cm.verification = 'Yes'
							AND cm.failure_responsibility = 'BEML'
							AND t.stabilization < cm.work_start_at
							AND (cm.system_id = {equipmentDetails[0]} OR cm.subsystem_id = {equipmentDetails[0]})
						'''
			self.cursor.execute(query)
			noOfFails = self.cursor.fetchone()

			noOfFailsItem = QTableWidgetItem(str(noOfFails[0]))
			noOfFailsItem.setTextAlignment(Qt.AlignCenter)
			self.tableForMDBCFDashboard.setItem(j, i+1, noOfFailsItem)


	self.tableForMDBCFDashboard.insertRow(self.tableForMDBCFDashboard.rowCount())
	self.tableForMDBCFDashboard.setItem(self.tableForMDBCFDashboard.rowCount()-1, 0, QTableWidgetItem('Total'))
	for i, YM in enumerate(yearMonthValuesForCalculations):
		failsCount = 0
		for j in range(self.tableForMDBCFDashboard.rowCount()-1):
			color_brush = self.tableForMDBCFDashboard.item(j, 0).foreground().color().name()
			if color_brush == '#ff6600':
				failsCount += int(self.tableForMDBCFDashboard.item(j, i+1).text())

		TotalFailsItem = QTableWidgetItem(str(failsCount))
		TotalFailsItem.setTextAlignment(Qt.AlignCenter)
		self.tableForMDBCFDashboard.setItem(self.tableForMDBCFDashboard.rowCount()-1, i+1, TotalFailsItem)






	self.tableForMDBCFDashboard.setRowHidden(96, True)
	self.tableForMDBCFDashboard.setRowHidden(97, True)
	self.tableForMDBCFDashboard.setRowHidden(98, True)
	self.tableForMDBCFDashboard.setRowHidden(100, True)
	self.tableForMDBCFDashboard.setRowHidden(101, True)
	self.tableForMDBCFDashboard.setRowHidden(103, True)
	self.tableForMDBCFDashboard.setRowHidden(104, True)
	self.tableForMDBCFDashboard.setRowHidden(106, True)
	self.tableForMDBCFDashboard.setRowHidden(107, True)


	def findingResult():

		redBg = QColor(self.currentTheme.get('redBGColor'))
		greenBg = QColor(self.currentTheme.get('greenBGColor'))


		count_unhidden = 0
		lastDataColumn = 0
		for col in range(self.tableForMDBCFDashboard.columnCount() - 1, -1, -1):
			if not self.tableForMDBCFDashboard.isColumnHidden(col):
				count_unhidden += 1

				if count_unhidden == 7:
					lastDataColumn = col
					break
		# print(lastDataColumn)

		if lastDataColumn in dataRangeMDBCFDashInTable:
			monthYearString = self.tableForMDBCFDashboard.horizontalHeaderItem(lastDataColumn).text()
			date_obj = datetime.strptime(monthYearString, '%b - %Y')

			# Calculate the previous 3 months using relativedelta
			last6Months = [(date_obj.year, date_obj.month)]
			for i in range(1, 6):
				previous_month = date_obj - relativedelta(months=i)
				last6Months.append((previous_month.year, previous_month.month))

		







		# visible_columns = [col for col in dataRangeMDBCFDashInTable if not self.tableForMDBCFDashboard.isColumnHidden(col)]
		# if visible_columns:
		# 	lastmonth = self.tableForMDBCFDashboard.horizontalHeaderItem(visible_columns[-1]).text()

		# 	inde = yearMonthStringsForCalculations.index(lastmonth)
		# 	allMonthsFromSelectedMonth = yearMonthValuesForCalculations[inde::-1]
		# 	last6Months = allMonthsFromSelectedMonth[:6]
			
			totalSixMonthsRunningMileageForAlltrains = 0
			for i, YM in enumerate(last6Months):
				from datetime import date

				year, month = YM[0], YM[1]
				last_day = calendar.monthrange(year, month)[1]
				last_date = date(year, month, last_day)

				sql_query = f"SELECT id FROM trainsets WHERE stabilization < '{last_date}'"
				self.cursor.execute(sql_query)
				trainIds_ = self.cursor.fetchall()
				trainIds = [idd[0] for idd in trainIds_]
				trainIdsTuple = tuple(trainIds)

				currentMonthRunningMileage = []
				if trainIdsTuple:
					if len(trainIdsTuple) > 1:
						query = f'SELECT SUM(monthly_mileage) FROM trainsets_mileage WHERE trainset_id IN {trainIdsTuple} AND month = {month} AND year = {year}'
					elif len(trainIdsTuple) == 1:
						query = f'SELECT SUM(monthly_mileage) FROM trainsets_mileage WHERE trainset_id = {trainIdsTuple[0]} AND month = {month} AND year = {year}'
					self.cursor.execute(query)
					currentMonthRunningMileage = self.cursor.fetchone()

				if currentMonthRunningMileage:
					if currentMonthRunningMileage[0]:
						totalSixMonthsRunningMileageForAlltrains += int(currentMonthRunningMileage[0])

			for j, equipmentDetails in enumerate(bomEquipments_MDBCF):

				sixMonthsRMItem = QTableWidgetItem(str(totalSixMonthsRunningMileageForAlltrains))
				sixMonthsRMItem.setTextAlignment(Qt.AlignCenter)
				self.tableForMDBCFDashboard.setItem(j, self.tableForMDBCFDashboard.columnCount()-5, sixMonthsRMItem)
				
				equipmentQuantityItem = QTableWidgetItem(str(equipmentDetails[3]))
				equipmentQuantityItem.setTextAlignment(Qt.AlignCenter)
				self.tableForMDBCFDashboard.setItem(j, self.tableForMDBCFDashboard.columnCount()-4, equipmentQuantityItem)

				# print(dataRangeMDBCFDashInTable)
				# print(lastDataColumn)

				dataRangeMDBCFDashInTableList = list(dataRangeMDBCFDashInTable)
				if lastDataColumn in dataRangeMDBCFDashInTableList:
					length_of_sublist = dataRangeMDBCFDashInTableList.index(lastDataColumn) + 1
				else:
					length_of_sublist = 0

				# print('length_of_sublist', length_of_sublist)	
				if length_of_sublist >= 6:
					sixMonthsFails = 0
					for ind in range(lastDataColumn-5, lastDataColumn+1):
						val = int(self.tableForMDBCFDashboard.item(j, ind).text())
						sixMonthsFails += val

					sixMonthsFailsItem = QTableWidgetItem(str(sixMonthsFails))
					sixMonthsFailsItem.setTextAlignment(Qt.AlignCenter)
					
					self.tableForMDBCFDashboard.setItem(j, self.tableForMDBCFDashboard.columnCount()-6, sixMonthsFailsItem)
				else:
					sixMonthsFails = 0
					for ind in range(1, lastDataColumn+1):
						val = int(self.tableForMDBCFDashboard.item(j, ind).text())
						sixMonthsFails += val

					sixMonthsFailsItem = QTableWidgetItem(str(sixMonthsFails))
					sixMonthsFailsItem.setTextAlignment(Qt.AlignCenter)
					
					self.tableForMDBCFDashboard.setItem(j, self.tableForMDBCFDashboard.columnCount()-6, sixMonthsFailsItem)



					# sixMonthsFails = 0
					# for ind in visible_columns[-6:]:
					# 	val = int(self.tableForMDBCFDashboard.item(j, ind).text())
					# 	sixMonthsFails += val

					# 	sixMonthsFailsItem = QTableWidgetItem(str(sixMonthsFails))
					# 	sixMonthsFailsItem.setTextAlignment(Qt.AlignCenter)
					
					# self.tableForMDBCFDashboard.setItem(j, self.tableForMDBCFDashboard.columnCount()-6, sixMonthsFailsItem)
				

				if self.tableForMDBCFDashboard.item(j, self.tableForMDBCFDashboard.columnCount()-3):
					# print(totalSixMonthsRunningMileageForAlltrains, equipmentDetails[3], sixMonthsFails)
					if sixMonthsFails:
						mdbcf = int((totalSixMonthsRunningMileageForAlltrains*equipmentDetails[3])/sixMonthsFails)
					else:
						mdbcf = 'No Failure'

					mdbcfValueItem = QTableWidgetItem(str(mdbcf))
					mdbcfValueItem.setTextAlignment(Qt.AlignCenter)
					self.tableForMDBCFDashboard.setItem(j, self.tableForMDBCFDashboard.columnCount()-2, mdbcfValueItem)


				if self.tableForMDBCFDashboard.item(j, self.tableForMDBCFDashboard.columnCount()-3):
					if isinstance(mdbcf, int):
						if mdbcf >= int(self.tableForMDBCFDashboard.item(j, self.tableForMDBCFDashboard.columnCount()-3).text()):
							result = 'Pass'
							mdbcfResultItem = QTableWidgetItem(result)
							mdbcfResultItem.setTextAlignment(Qt.AlignCenter)
							mdbcfResultItem.setBackground(greenBg)
						else:
							result = 'Fail'
							mdbcfResultItem = QTableWidgetItem(result)
							mdbcfResultItem.setTextAlignment(Qt.AlignCenter)
							mdbcfResultItem.setBackground(redBg)
					else:
						result = 'Pass'
						mdbcfResultItem = QTableWidgetItem(result)
						mdbcfResultItem.setTextAlignment(Qt.AlignCenter)
						mdbcfResultItem.setBackground(greenBg)
				


					self.tableForMDBCFDashboard.setItem(j, self.tableForMDBCFDashboard.columnCount()-1, QTableWidgetItem(mdbcfResultItem))


			sixMonthsFailsTotal = 0
			for j in range(self.tableForMDBCFDashboard.rowCount()-1):
				color_brush = self.tableForMDBCFDashboard.item(j, 0).foreground().color().name()
				if color_brush == '#ff6600':
					sixMonthsFailsTotal += int(self.tableForMDBCFDashboard.item(j, len(yearMonthValuesForCalculations)+1).text())

			TotalFailsItem = QTableWidgetItem(str(sixMonthsFailsTotal))
			TotalFailsItem.setTextAlignment(Qt.AlignCenter)
			self.tableForMDBCFDashboard.setItem(self.tableForMDBCFDashboard.rowCount()-1, len(yearMonthValuesForCalculations)+1, TotalFailsItem)



	def onChangingToCombobox_MDBCF():
		fromIndex = self.fromCombobox_MDBCF.currentIndex()
		toIndex = self.toCombobox_MDBCF.currentIndex()

		for indx in dataRangeMDBCFDashInTable[fromIndex+toIndex+1:]:
			self.tableForMDBCFDashboard.setColumnHidden(indx, True)

		for indx in dataRangeMDBCFDashInTable[fromIndex:fromIndex+toIndex+1]:
			self.tableForMDBCFDashboard.setColumnHidden(indx, False)


		headingLabel_MDBCF.setText(f'MDBCF for {self.toCombobox_MDBCF.currentText()}')
		findingResult()

	def onChangingfromCombobox_MDBCF():
		self.toCombobox_MDBCF.clear()
		fromIndex = self.fromCombobox_MDBCF.currentIndex()
		self.toCombobox_MDBCF.addItems(yearMonthStringsForCalculations[fromIndex:])

		for indx in dataRangeMDBCFDashInTable[:fromIndex]:
			self.tableForMDBCFDashboard.setColumnHidden(indx, True)


		for indx in dataRangeMDBCFDashInTable[fromIndex:]:
			self.tableForMDBCFDashboard.setColumnHidden(indx, False)

		self.toCombobox_MDBCF.setCurrentIndex(len(yearMonthStringsForCalculations[fromIndex:])-1)
		
	self.fromCombobox_MDBCF.currentIndexChanged.connect(onChangingfromCombobox_MDBCF)
	self.toCombobox_MDBCF.currentIndexChanged.connect(onChangingToCombobox_MDBCF)

	def settingToLastSixMonthsFilters():
		if len(yearMonthStringsForCalculations)<=6:
			self.fromCombobox_MDBCF.setCurrentIndex(0)
		else:
			self.fromCombobox_MDBCF.setCurrentIndex((len(yearMonthStringsForCalculations))-6)

		self.toCombobox_MDBCF.setCurrentIndex(self.toCombobox_MDBCF.count()-1)

	self.clearAllFiltersButton_MDBCF.clicked.connect(settingToLastSixMonthsFilters)

	settingToLastSixMonthsFilters()



def deleteItems_MDBCF(layout):
	if layout:
		while layout.count():
			item = layout.takeAt(0)
			widget = item.widget()
			if widget:
				widget.setParent(None)
			else:
				deleteItems_MDBCF(item.layout())

def onClickingRefresh_MDBCF(self, layout):
	deleteItems_MDBCF(layout)
	self.mdbcfDashboardUi()
