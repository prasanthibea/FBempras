from PySide6.QtWidgets import QVBoxLayout, QLabel, QComboBox, QMessageBox, QSpinBox, QScrollArea, QProgressBar, QAbstractItemView, QGridLayout, QToolBox, QWidget, QFormLayout, QDateEdit, QTimeEdit, QTextEdit, QPushButton, QSizePolicy, QHBoxLayout, QSpacerItem, QLineEdit, QFileDialog, QDialog, QDialogButtonBox, QTableWidgetItem
from PySide6.QtCore import Qt, QDate, QTime, QDateTime
from datetime import datetime, timedelta, time
from dateutil.relativedelta import relativedelta
from PySide6.QtGui import QIcon, QFont, QBrush, QColor
from functions import logErrors, TableWidget, FileAttachmentWidget
# import time
import pandas as pd
import shutil
import os

from cmData import onButtonClicked_cmData

def CMUI(self,tab):
	from PySide6.QtWidgets import QApplication
	from functions import timeLineEdit, CustomComboBox

	self.CMMainLayout = QVBoxLayout()

	# labelll = QLabel('corrective maintenance', tab)
	# self.CMMainLayout.addWidget(labelll, alignment = Qt.AlignCenter)


	## To open OPM table:
	self.createPushButton('openCMtableButton', 'Import',  width=int(0.075 * QApplication.primaryScreen().availableGeometry().width()))
	self.CMMainLayout.addWidget(self.openCMtableButton, alignment = Qt.AlignRight)

	self.createPushButton('submit_CM', 'SUBMIT', '', int(0.075 * QApplication.primaryScreen().availableGeometry().width()))

	# Create cancel OPM submission form button
	self.createPushButton('cancel_CM', 'CANCEL', '', int(0.075 * QApplication.primaryScreen().availableGeometry().width()))

	CMTabwidget = QWidget(tab)
	self.CMMainLayout.addWidget(CMTabwidget)

	CMTabVLayout = QVBoxLayout(CMTabwidget)
	CMTabHLayout = QHBoxLayout()

	CMTabVLayout.addLayout(CMTabHLayout)

	# Create form layout
	CMTabFormLayout1 = QFormLayout()
	CMTabFormLayout2 = QFormLayout()

	CMTabHLayout.addLayout(CMTabFormLayout1)
	spacer_item = QSpacerItem(int(0.01 * QApplication.primaryScreen().availableGeometry().width()), 5, QSizePolicy.Fixed, QSizePolicy.Minimum)
	CMTabHLayout.addItem(spacer_item)
	CMTabHLayout.addLayout(CMTabFormLayout2)

	# Add form elements
	self.createDateEditBox('eventDate_CMTab')
	current_date_ = datetime.now()
	currentYear = datetime.now().year
	currentMonth = datetime.now().month

	firstDayOfCurrentMonth = datetime(currentYear, currentMonth, 1).date()
	lastDateOfPreviousMonth = (firstDayOfCurrentMonth - relativedelta(days=1))

	firstDateOfPreviousMonth = QDate(lastDateOfPreviousMonth.year, lastDateOfPreviousMonth.month, 1)

	six_months_ago = current_date_ - relativedelta(months=6)
	firstDateOfSixMonthsAgo_ = six_months_ago.replace(day=1)
	firstDateOfSixMonthsAgo = QDate(firstDateOfSixMonthsAgo_.year, firstDateOfSixMonthsAgo_.month, 1)
	
	if firstDateOfPreviousMonth < QDate(self.startingYear, self.startingMonth, 1):
		firstDateOfPreviousMonth = QDate(self.startingYear, self.startingMonth, 1)



	# if self.userRole == 1:
	# 	self.eventDate_CMTab.setMinimumDate(firstDateOfSixMonthsAgo)

	# if self.userRole in [2, 3]:
	# 	self.eventDate_CMTab.setMinimumDate(firstDateOfPreviousMonth)
	

	# if ((self.userName == 'Ravikumar') and (self.editableOptionMaxDate > datetime.now().date())):
	# 	self.eventDate_CMTab.setMinimumDate(QDate(self.startingYear, self.startingMonth, 1))


	self.createTimeEditBox('eventTime_CMTab')
	self.createComboBox2(self.depotsList, 'depotComboBox_CMTab')
	self.createCheckableComboBox(self.trainsetsList, 'trainComboBox_CMTab')
	self.createCheckableComboBox(self.carsList, 'carComboBox_CMTab')
	self.createLineEditBox('jobcardNo_CMTab')
	self.createLineEditBox('issuedTo_CMTab')
	self.createComboBox2(['M/L', 'Depot'], 'reapairAt_CMTab')
	self.createLineEditBox('locationLineEdit_CMTab')
	self.createComboBox2(self.BOMSystemDictionary.keys(), 'systemComboBox_CMTab')
	self.systemComboBox_CMTab.setFixedWidth(int(0.15 * QApplication.primaryScreen().availableGeometry().width()))
	self.createComboBox2([], 'subSystemComboBox_CMTab')
	self.subSystemComboBox_CMTab.setFixedWidth(int(0.15 * QApplication.primaryScreen().availableGeometry().width()))
	self.createNumberLineEditBox('quantity_CMTab')
	self.createLineEditBox('otherSubSystemLineEdit_CMTab')
	self.createTextEditBox('faultDetails_CMTab')
	self.createComboBox2(['Relevant Failure', 'Service Failure', 'Non Relevant Failure'], 'failureType__CMTab')
	self.createComboBox2([], 'serviceFailureEffect__CMTab')
	self.createComboBox2(['Yes', 'No'], 'considerForRelavantFails__CMTab')
	# self.mianAttachment_CM = FileAttachmentWidget()
	self.createAttachmentWidget('mianAttachment_CM')
	self.mianAttachment_CM.fileListWidget.setMinimumHeight(140)
	self.createTextEditBox('actionTakenAtMainline_CM')
	self.createTextEditBox('actionTakenAtDepot_CM')
	self.createComboBox2(['External', 'Maintenance', 'Material', 'NFF', 'Operation', 'Software', 'Workmanship', 'Others'], 'failureCategory__CMTab')
	self.failureCategory__CMTab.setFixedWidth(int(0.15 * QApplication.primaryScreen().availableGeometry().width()))
	self.createComboBox2(['BEML', 'MMMOCL', 'Others'], 'failureResponsibility__CMTab')
	self.failureResponsibility__CMTab.setFixedWidth(int(0.15 * QApplication.primaryScreen().availableGeometry().width()))
	self.createLineEditBox('equipmentLineEdit_CMTab')
	self.createLineEditBox('componentLineEdit_CMTab')
	self.createLineEditBox('lowestLevelLineEdit_CMTab')
	self.createLineEditBox('NCR_CM')
	self.createComboBox2(['Yes', 'No'], 'componentReplaced_CM')
	self.createLineEditBox('replacedComponentLineEdit_CM')
	self.replacedComponentLineEdit_CM.setEnabled(False)
	self.createComboBox2(['Yes', 'No'], 'verification__CMTab')
	self.createDateEditBox('workStartDate_CMTab')
	# if self.userRole != 0:
	# 	self.workStartDate_CMTab.setMinimumDate(firstDateOfPreviousMonth)

	# if (self.userName == 'Ravikumar') and (self.editableOptionMaxDate > datetime.now().date()):
	# 	self.workStartDate_CMTab.setMinimumDate(QDate(self.startingYear, self.startingMonth, 1))

	self.createTimeEditBox('workStartTime_CMTab')
	self.createDateEditBox('workEndDate_CMTab')
	# if self.userRole != 0:
	# 	self.workEndDate_CMTab.setMinimumDate(firstDateOfPreviousMonth)

	# if (self.userName == 'Ravikumar') and (self.editableOptionMaxDate > datetime.now().date()):
	# 	self.workEndDate_CMTab.setMinimumDate(QDate(self.startingYear, self.startingMonth, 1))

	self.createTimeEditBox('workEndTime_CMTab')
	self.downTimeLabel_CMTab = QLabel('Down Time(Minutes):')
	self.downTime_CMTab = QLabel('0')


	self.listOfWidgets_CM = [self.eventDate_CMTab, self.eventTime_CMTab, self.depotComboBox_CMTab, self.trainComboBox_CMTab, self.carComboBox_CMTab, self.jobcardNo_CMTab,
							self.issuedTo_CMTab, self.reapairAt_CMTab, self.locationLineEdit_CMTab, self.systemComboBox_CMTab, self.subSystemComboBox_CMTab, self.faultDetails_CMTab,
							self.failureType__CMTab, self.serviceFailureEffect__CMTab, self.actionTakenAtMainline_CM, self.actionTakenAtDepot_CM, self.failureCategory__CMTab,
							self.failureResponsibility__CMTab, self.equipmentLineEdit_CMTab, self.componentLineEdit_CMTab, self.lowestLevelLineEdit_CMTab, self.NCR_CM, self.componentReplaced_CM,
							self.verification__CMTab, self.workStartDate_CMTab, self.workStartTime_CMTab, self.workEndDate_CMTab, self.workEndTime_CMTab, self.downTime_CMTab,
							self.otherSubSystemLineEdit_CMTab, self.considerForRelavantFails__CMTab, self.replacedComponentLineEdit_CM, self.quantity_CMTab]

	self.trainComboBox_CMTab.setEnabled(False)
	self.subSystemComboBox_CMTab.setEnabled(False)
	self.serviceFailureEffect__CMTab.setEnabled(False)

	@logErrors
	def onChangingDepotCombobox():
		if self.depotComboBox_CMTab.currentText() != '':
			self.trainComboBox_CMTab.setEnabled(True)
			self.trainComboBox_CMTab.clear()
			self.trainComboBox_CMTab.addItems(self.depotTrainDictionary[self.depotComboBox_CMTab.currentText()])

	self.depotComboBox_CMTab.currentIndexChanged.connect(lambda: onChangingDepotCombobox())

	def onSystemComboboxChanged():
		if self.systemComboBox_CMTab.currentText() != '':
			self.subSystemComboBox_CMTab.setEnabled(True)
			self.subSystemComboBox_CMTab.clear()
			self.subSystemComboBox_CMTab.addItems(self.BOMSystemDictionary[self.systemComboBox_CMTab.currentText()])
			
	self.systemComboBox_CMTab.currentIndexChanged.connect(lambda: onSystemComboboxChanged())

	def onSubSystemComboboxChanged():
		if self.subSystemComboBox_CMTab.isEnabled():
			if self.subSystemComboBox_CMTab.currentText() == 'Others':
				self.otherSubSystemLineEdit_CMTab.setEnabled(True)
			else:
				self.otherSubSystemLineEdit_CMTab.clear()
				self.otherSubSystemLineEdit_CMTab.setEnabled(False)
			
	self.subSystemComboBox_CMTab.currentIndexChanged.connect(lambda: onSubSystemComboboxChanged())


	def onComponentReplacedComboboxChanged():
		if self.componentReplaced_CM.currentText() == 'Yes':
			self.replacedComponentLineEdit_CM.setEnabled(True)
		else:
			self.replacedComponentLineEdit_CM.clear()
			self.replacedComponentLineEdit_CM.setEnabled(False)
			
	self.componentReplaced_CM.currentIndexChanged.connect(lambda: onComponentReplacedComboboxChanged())

	def onFailureTypeComboboxChanged():
		if self.failureType__CMTab.currentIndex() == 1:
			self.serviceFailureEffect__CMTab.setEnabled(True)
			self.serviceFailureEffect__CMTab.addItems(['Pre-departure Withdrawal', 'Withdrawal', '3 min delay', 'Deboarding'])
		else:
			self.serviceFailureEffect__CMTab.setEnabled(False)
			self.serviceFailureEffect__CMTab.clear()
				

	self.failureType__CMTab.currentIndexChanged.connect(lambda: onFailureTypeComboboxChanged())

	def onWorkDateTimeChanged():
		workStartDate = self.workStartDate_CMTab.date().toPython()
		workStartTime = self.workStartTime_CMTab.time().toPython().replace(second=0, microsecond=0)
		workEndDate = self.workEndDate_CMTab.date().toPython()
		workEndTime = self.workEndTime_CMTab.time().toPython().replace(second=0, microsecond=0)

		startDateTime = datetime.combine(workStartDate, workStartTime)
		endDateTime = datetime.combine(workEndDate, workEndTime)

		timeDifference = endDateTime - startDateTime
		minutesDifference = timeDifference.total_seconds() / 60

		if endDateTime < startDateTime:
			self.workEndDate_CMTab.setDate(self.workStartDate_CMTab.date())
			self.workEndTime_CMTab.setTime(self.workStartTime_CMTab.time())

			endDateTime = datetime.combine(workStartDate, workStartTime)
			timeDifference = endDateTime - startDateTime
			minutesDifference = timeDifference.total_seconds() / 60

		self.downTime_CMTab.setText(str(int(minutesDifference)))

	self.workStartDate_CMTab.dateChanged.connect(onWorkDateTimeChanged)
	self.workStartTime_CMTab.timeChanged.connect(onWorkDateTimeChanged)
	self.workEndDate_CMTab.dateChanged.connect(onWorkDateTimeChanged)
	self.workEndTime_CMTab.timeChanged.connect(onWorkDateTimeChanged)

	hLayoutForEventDateTime_CMTab = QHBoxLayout()
	hLayoutForEventDateTime_CMTab.addWidget(self.eventDate_CMTab)
	hLayoutForEventDateTime_CMTab.addWidget(self.eventTime_CMTab)

	hLayoutForWorkStartAt_CMTab = QHBoxLayout()
	hLayoutForWorkStartAt_CMTab.addWidget(self.workStartDate_CMTab)
	hLayoutForWorkStartAt_CMTab.addWidget(self.workStartTime_CMTab)

	hLayoutForWorkEndAt_CMTab = QHBoxLayout()
	hLayoutForWorkEndAt_CMTab.addWidget(self.workEndDate_CMTab)
	hLayoutForWorkEndAt_CMTab.addWidget(self.workEndTime_CMTab)

	CMTabFormLayout1.addRow('Event Date & Time:<font color="red">*</font>', hLayoutForEventDateTime_CMTab)
	CMTabFormLayout1.addRow('Depot:<font color="red">*</font>', self.depotComboBox_CMTab)
	CMTabFormLayout1.addRow('Trainset:<font color="red">*</font>', self.trainComboBox_CMTab)
	CMTabFormLayout1.addRow('Car No:', self.carComboBox_CMTab)
	CMTabFormLayout1.addRow('Jobcard No:', self.jobcardNo_CMTab)
	CMTabFormLayout1.addRow('Issued To:', self.issuedTo_CMTab)
	CMTabFormLayout1.addRow('ML/Depot:', self.reapairAt_CMTab)
	CMTabFormLayout1.addRow('Location:', self.locationLineEdit_CMTab)
	CMTabFormLayout1.addRow('System:<font color="red">*</font>', self.systemComboBox_CMTab)
	hLayoutForSubSystem_CM = QHBoxLayout()
	hLayoutForSubSystem_CM.addWidget(self.subSystemComboBox_CMTab)
	hLayoutForSubSystem_CM.addWidget(self.otherSubSystemLineEdit_CMTab)
	self.otherSubSystemLineEdit_CMTab.setEnabled(False)
	CMTabFormLayout1.addRow('Sub-System:<font color="red">*</font>', hLayoutForSubSystem_CM)
	CMTabFormLayout1.addRow('Quantity:<font color="red">*</font>', self.quantity_CMTab)
	CMTabFormLayout1.addRow('Fault Details:<font color="red">*</font>', self.faultDetails_CMTab)
	CMTabFormLayout1.addRow('Failure Type:<font color="red">*</font>', self.failureType__CMTab)
	CMTabFormLayout1.addRow('Service Failure Effect:', self.serviceFailureEffect__CMTab)
	CMTabFormLayout1.addRow('Consider for Relevant Fails?:<font color="red">*</font>', self.considerForRelavantFails__CMTab)
	CMTabFormLayout1.addRow('Attachments:', self.mianAttachment_CM)
	CMTabFormLayout2.addRow('Action Taken At Mainline:', self.actionTakenAtMainline_CM)
	CMTabFormLayout2.addRow('Action Taken At Depot:<font color="red">*</font>', self.actionTakenAtDepot_CM)
	CMTabFormLayout2.addRow('Failure Category:', self.failureCategory__CMTab)
	CMTabFormLayout2.addRow('Failure Responsibility:<font color="red">*</font>', self.failureResponsibility__CMTab)
	CMTabFormLayout2.addRow('Equipment:', self.equipmentLineEdit_CMTab)
	CMTabFormLayout2.addRow('Component:', self.componentLineEdit_CMTab)
	CMTabFormLayout2.addRow('Lowest Level Component:', self.lowestLevelLineEdit_CMTab)

	CMTabFormLayout2.addRow('NCR no:', self.NCR_CM)
	hLayoutForReplacedComponent = QHBoxLayout()
	hLayoutForReplacedComponent.addWidget(self.componentReplaced_CM)
	hLayoutForReplacedComponent.addWidget(self.replacedComponentLineEdit_CM)
	CMTabFormLayout2.addRow('Is Component Replaced?:', hLayoutForReplacedComponent)

	CMTabFormLayout2.addRow('Verification:<font color="red">*</font>', self.verification__CMTab)
	CMTabFormLayout2.addRow('Work Start At:<font color="red">*</font>', hLayoutForWorkStartAt_CMTab)
	CMTabFormLayout2.addRow('Work End At:<font color="red">*</font>', hLayoutForWorkEndAt_CMTab)

	CMTabFormLayout2.addRow(self.downTimeLabel_CMTab, self.downTime_CMTab)
	CMTabFormLayout2.setAlignment(self.downTime_CMTab, Qt.AlignTop)
	CMTabFormLayout2.setAlignment(self.downTimeLabel_CMTab, Qt.AlignTop)

	def openCMTableWindow():

		CMImportWindowWidth = int(0.8* QApplication.primaryScreen().availableGeometry().width())
		CMImportWindowHeight = int(0.6 * QApplication.primaryScreen().availableGeometry().height())

		self.CMImportWindow = QWidget()
		self.CMImportWindow.setWindowIcon(QIcon('Media/ramsify.png'))
		self.CMImportWindow.setWindowTitle('CM Data Input')
		self.CMImportWindow.setStyleSheet(self.widgetQSS)
		self.CMImportWindow.resize(CMImportWindowWidth, CMImportWindowHeight )
		self.CMImportWindowLayout = QVBoxLayout()


		# Create a label for the page:
		self.headingLabelOfCMDataImport = QLabel('Corrective Maintenance Data Input Table')
		self.headingLabelOfCMDataImport.setStyleSheet("font-size: 18pt;")
		self.headingLabelOfCMDataImport.setContentsMargins(20, 0, 0, 0)

		# Add the label to the vertical layout:
		self.CMImportWindowLayout.addWidget(self.headingLabelOfCMDataImport, alignment=Qt.AlignCenter)


		layoutForButtons_CMImport = QHBoxLayout()
		self.CMImportWindowLayout.addLayout(layoutForButtons_CMImport)


		headersOfCMImportTableReal = ['Event Date', 'Event Time', 'Depot', 'Trainset', 'Car Number', 'Jobcard No' ,'Issued To', 'ML/Depot', 'Location',
		 'System', 'Sub-System', 'Other Sub-System', 'Fault Details', 'Failure Type', 'Service Failure Effect', 'Consider for Relevant Fails?', 'Action Taken At Mainline', 'Action Taken At Depot', 'Failure Category',
		'Failure Responsibility', 'Equipment', 'Component', 'Lowest Level Component', 'NCR No', 'Is Component Replaced?', 'Replaced Component', 'Verification', 'Attachments',
		'Workstart Date', 'Workstart Time', 'Workend Date', 'Workend Time', 'Downtime(Mins)', '']
			
		HLayoutForTableAndMissingFileds = QHBoxLayout()
		self.CMImportWindowLayout.addLayout(HLayoutForTableAndMissingFileds)

		self.CMImportTable = TableWidget()
		self.CMImportTable.setColumnCount(len(headersOfCMImportTableReal))
		self.CMImportTable.setHorizontalHeaderLabels(headersOfCMImportTableReal)
		self.CMImportTable.setStyleSheet(self.tableWidgetQSS)
		self.CMImportTable.horizontalHeader().setStyleSheet(self.headerHorizontalQSS)
		# self.CMImportTable.verticalHeader().setStyleSheet(self.headerVerticalQSS)
		self.CMImportTable.setAlternatingRowColors(True)
		self.CMImportTable.setShowGrid(False)
		HLayoutForTableAndMissingFileds.addWidget(self.CMImportTable)
		self.CMImportTable.setEditTriggers(QAbstractItemView.NoEditTriggers)


		self.CMImportWindow.setLayout(self.CMImportWindowLayout)


		self.CMImportTable.setColumnWidth(0, int(0.07 * QApplication.primaryScreen().availableGeometry().width()))
		self.CMImportTable.setColumnWidth(1, int(0.06 * QApplication.primaryScreen().availableGeometry().width()))
		self.CMImportTable.setColumnWidth(2, int(0.07 * QApplication.primaryScreen().availableGeometry().width()))
		self.CMImportTable.setColumnWidth(3, int(0.07 * QApplication.primaryScreen().availableGeometry().width()))
		self.CMImportTable.setColumnWidth(4, int(0.1 * QApplication.primaryScreen().availableGeometry().width()))
		self.CMImportTable.setColumnWidth(5, int(0.08 * QApplication.primaryScreen().availableGeometry().width()))
		self.CMImportTable.setColumnWidth(6, int(0.08 * QApplication.primaryScreen().availableGeometry().width()))
		self.CMImportTable.setColumnWidth(7, int(0.07 * QApplication.primaryScreen().availableGeometry().width()))
		self.CMImportTable.setColumnWidth(8, int(0.07 * QApplication.primaryScreen().availableGeometry().width()))
		self.CMImportTable.setColumnWidth(9, int(0.15 * QApplication.primaryScreen().availableGeometry().width()))
		self.CMImportTable.setColumnWidth(10, int(0.15 * QApplication.primaryScreen().availableGeometry().width()))
		self.CMImportTable.setColumnWidth(11, int(0.1 * QApplication.primaryScreen().availableGeometry().width()))
		self.CMImportTable.setColumnWidth(12, int(0.12 * QApplication.primaryScreen().availableGeometry().width()))
		self.CMImportTable.setColumnWidth(13, int(0.12 * QApplication.primaryScreen().availableGeometry().width()))
		self.CMImportTable.setColumnWidth(14, int(0.1 * QApplication.primaryScreen().availableGeometry().width()))
		self.CMImportTable.setColumnWidth(15, int(0.14 * QApplication.primaryScreen().availableGeometry().width()))
		self.CMImportTable.setColumnWidth(16, int(0.12 * QApplication.primaryScreen().availableGeometry().width()))
		self.CMImportTable.setColumnWidth(17, int(0.12 * QApplication.primaryScreen().availableGeometry().width()))
		self.CMImportTable.setColumnWidth(18, int(0.09 * QApplication.primaryScreen().availableGeometry().width()))
		self.CMImportTable.setColumnWidth(19, int(0.11 * QApplication.primaryScreen().availableGeometry().width()))
		self.CMImportTable.setColumnWidth(20, int(0.1 * QApplication.primaryScreen().availableGeometry().width()))
		self.CMImportTable.setColumnWidth(21, int(0.1 * QApplication.primaryScreen().availableGeometry().width()))
		self.CMImportTable.setColumnWidth(22, int(0.1 * QApplication.primaryScreen().availableGeometry().width()))
		self.CMImportTable.setColumnWidth(23, int(0.14 * QApplication.primaryScreen().availableGeometry().width()))
		self.CMImportTable.setColumnWidth(24, int(0.15 * QApplication.primaryScreen().availableGeometry().width()))
		self.CMImportTable.setColumnWidth(25, int(0.12 * QApplication.primaryScreen().availableGeometry().width()))
		self.CMImportTable.setColumnWidth(26, int(0.07 * QApplication.primaryScreen().availableGeometry().width()))
		self.CMImportTable.setColumnWidth(27, int(0.08 * QApplication.primaryScreen().availableGeometry().width()))
		self.CMImportTable.setColumnWidth(28, int(0.08 * QApplication.primaryScreen().availableGeometry().width()))
		self.CMImportTable.setColumnWidth(29, int(0.08 * QApplication.primaryScreen().availableGeometry().width()))
		self.CMImportTable.setColumnWidth(30, int(0.08 * QApplication.primaryScreen().availableGeometry().width()))
		self.CMImportTable.setColumnWidth(31, int(0.08 * QApplication.primaryScreen().availableGeometry().width()))
		self.CMImportTable.setColumnWidth(32, int(0.08 * QApplication.primaryScreen().availableGeometry().width()))
		self.CMImportTable.setColumnWidth(33, int(0.08 * QApplication.primaryScreen().availableGeometry().width()))
		self.CMImportTable.setColumnWidth(34, int(0.1 * QApplication.primaryScreen().availableGeometry().width()))
		





		scrollForMissingFields = QScrollArea()
		scrollForMissingFields.setWidgetResizable(True)
		scrollForMissingFields.setStyleSheet(self.scrollAreaQSS)

		scrollForMissingFields.setMaximumWidth(250)


		self.missingFieldsWidget_CM = QWidget(self)
		missingFieldsMainLayout_CM = QVBoxLayout()
		missingFieldsGridLayout_CM = QGridLayout()
		self.missingFieldsWidget_CM.setLayout(missingFieldsMainLayout_CM)
		missingFieldsMainLayout_CM.addLayout(missingFieldsGridLayout_CM)
		
		HLayoutForTableAndMissingFileds.addWidget(scrollForMissingFields)

		scrollForMissingFields.setWidget(self.missingFieldsWidget_CM)
		scrollForMissingFields.hide()





		# self.CMImportTable.setColumnWidth(0, int(0.1 * QApplication.primaryScreen().availableGeometry().width()))
		# self.CMImportTable.setColumnWidth(1, int(0.07 * QApplication.primaryScreen().availableGeometry().width()))
		# self.CMImportTable.setColumnWidth(2, int(0.035 * QApplication.primaryScreen().availableGeometry().width()))



		
		# self.plusBtnOfCMImport = QPushButton()
		# self.plusBtnOfCMImport.setIcon(QIcon('Media/plus.png'))
		# self.plusBtnOfCMImport.setToolTip('Add new row')
		# self.plusBtnOfCMImport.setStyleSheet(self.pushbuttonQSS)
		# self.plusBtnOfCMImport.setFixedWidth(29)
		# self.plusBtnOfCMImport.setFixedHeight(25)
		# self.plusBtnOfCMImport.clicked.connect(lambda: addCMRow(self.CMImportGridLayout.rowCount() - 1))

		self.createLineEditBox('selectFolderForAttachmentsLineEdit_CMImport')
		self.createPushButton('selectFolderButton_CMImport', 'Select Folder')
		self.createPushButton('attachButton_CMImport', 'Attach')

		self.createPushButton('templateButton_CMImport', '', self.currentTheme.get('exportTemplateIcon'))
		self.templateButton_CMImport.setToolTip('Export template')
		self.templateButton_CMImport.setFixedWidth(29)
		self.templateButton_CMImport.setFixedHeight(25)

		self.createPushButton('importIconButton_CMImport', '', self.currentTheme.get('importDataIcon'))
		self.importIconButton_CMImport.setToolTip('Import CM data')
		self.importIconButton_CMImport.setFixedWidth(29)
		self.importIconButton_CMImport.setFixedHeight(25)

		layoutForButtons_CMImport.addWidget(self.selectFolderForAttachmentsLineEdit_CMImport)
		self.selectFolderForAttachmentsLineEdit_CMImport.setEnabled(False)
		layoutForButtons_CMImport.addWidget(self.selectFolderButton_CMImport)
		layoutForButtons_CMImport.addWidget(self.attachButton_CMImport)
		layoutForButtons_CMImport.addItem(QSpacerItem(1, 1, QSizePolicy.Expanding, QSizePolicy.Fixed))


		def onClickingSelectFolder_CMImport():
			folder_path = QFileDialog.getExistingDirectory(self, "Select Folder")
			if folder_path:
				self.selectFolderForAttachmentsLineEdit_CMImport.setText(str(folder_path))
				
		
				

		self.selectFolderButton_CMImport.clicked.connect(onClickingSelectFolder_CMImport)


		def onClickingAttachButton_CMImport():
			for r in range(self.CMImportTable.rowCount()):
				item = self.CMImportTable.item(r, 12)
				if item is not None:
					# self.CMImportTable.removeItemWidget(item)
					self.CMImportTable.setItem(r, 12, None)
					del item

			path = self.selectFolderForAttachmentsLineEdit_CMImport.text()
		
			if os.path.exists(path):
				files = [f for f in os.listdir(path) if os.path.isfile(os.path.join(path, f))]

				for r in range(self.CMImportTable.rowCount()):
					JCItem = self.CMImportTable.item(r, 5)
					if JCItem:
						allFiles = []
						for file in files:
							file_name, file_ext = os.path.splitext(file)
							if file_name == JCItem.text():
								allFiles.append(file)

						if len(allFiles) > 0:
							self.CMImportTable.setItem(r, self.CMImportTable.columnCount()-7, QTableWidgetItem(str(allFiles)))
						else:
							pass

				
			else:
				QMessageBox.warning(self, "Path Check", f"The path {path} does not exist.")



		self.attachButton_CMImport.clicked.connect(onClickingAttachButton_CMImport)


		# layoutForButtons_CMImport.addWidget(self.plusBtnOfCMImport)
		layoutForButtons_CMImport.addWidget(self.templateButton_CMImport)
		layoutForButtons_CMImport.addWidget(self.importIconButton_CMImport)



		# Create submit form push button
		self.createPushButton('submitBtnOfImportCM', 'SUBMIT', width=int(0.050 * QApplication.primaryScreen().availableGeometry().width()) )
		self.submitBtnOfImportCM.setFixedHeight(30)

		# Create import excel file push button
		self.createPushButton('cancelBtnOfImportCM', 'CANCEL', width=int(0.050 * QApplication.primaryScreen().availableGeometry().width()))
		self.cancelBtnOfImportCM.setFixedHeight(30)


		# #Create a horizontal layout to keep the add and import button:
		self.layoutForSubmitAndCancelBtnsOfCMImport = QHBoxLayout()
		self.layoutForSubmitAndCancelBtnsOfCMImport.addWidget(self.submitBtnOfImportCM, alignment = Qt.AlignRight)
		self.layoutForSubmitAndCancelBtnsOfCMImport.addWidget(self.cancelBtnOfImportCM, alignment = Qt.AlignLeft)

		
		self.CMImportWindowLayout.addLayout(self.layoutForSubmitAndCancelBtnsOfCMImport)


		#########################################################################################################################


		def onClickingSubmitCMImportWindow():

			# self.listOfImportedCMRows = []
			currentDateTimeValue = datetime.now()
			self.missingFields_CM = []
			for i in reversed(range(missingFieldsGridLayout_CM.rowCount())):
				for j in range(missingFieldsGridLayout_CM.columnCount()):
					item = missingFieldsGridLayout_CM.itemAtPosition(i, j)
					if item:
						widget = item.widget()
						if widget:
							missingFieldsGridLayout_CM.removeWidget(widget)
							widget.deleteLater()
						else:
							missingFieldsGridLayout_CM.removeItem(item)




			mandatorySuccess_CM = True
			# mandatoryFieldsOfImportedExcelRows_CM = [0, 1, 2, 3, 9, 10, 11, 12, 15, 17, 23, 24, 25, 26, 27]
			mandatoryFieldsOfImportedExcelRows_CM = [0, 1, 2, 3, 9, 10, 12, 13, 15, 17, 19, 26, 28, 29, 30, 31]
			self.allSysSubSysListInImport_CM = []

			if self.CMImportTable.rowCount() > 0:
				for row_index in range(self.CMImportTable.rowCount()):
					cm_id_string = 'CM' + '_' + currentDateTimeValue.strftime("%Y%m%d%H%M%S%f")[:-4]
					currentDateTimeValue += timedelta(milliseconds=10)
					singleRowData_CM = [cm_id_string]
					
					sysSubsys_CM = []


					for col_index in range(self.CMImportTable.columnCount()-1):

						if col_index in [0, 28, 30]:
							if self.CMImportTable.cellWidget(row_index, col_index):
								widget = self.CMImportTable.cellWidget(row_index, col_index).layout().itemAt(0).widget()
								if isinstance(widget, QLineEdit):
									if widget.text() != '':
										date = widget.text()
										widget = self.CMImportTable.cellWidget(row_index, col_index)
										self.CMImportTable.removeCellWidget(row_index, col_index)
										del widget
										self.CMImportTable.setItem(row_index, col_index, QTableWidgetItem(str(date)))

									else:
										mandatorySuccess_CM = False
										self.missingFields_CM.append((row_index+1, headersOfCMImportTableReal[col_index]))


						if col_index in [1, 29, 31]:
							widget = self.CMImportTable.cellWidget(row_index, col_index)
							if widget:
								if isinstance(widget, QLineEdit):
									if len(widget.text()) == 5:
										time = widget.text()
										self.CMImportTable.removeCellWidget(row_index, col_index)
										del widget
										self.CMImportTable.setItem(row_index, col_index, QTableWidgetItem(str(time)))
									else:
										mandatorySuccess_CM = False
										self.missingFields_CM.append((row_index+1, headersOfCMImportTableReal[col_index]))


						if col_index in [2, 3, 9, 10, 13, 15, 19, 26]:
							widget = self.CMImportTable.cellWidget(row_index, col_index)
							if widget:
								if widget.isEnabled():
									if isinstance(widget, QComboBox):
										if widget.currentText() != '':
											comboboxText = widget.currentText()
											self.CMImportTable.removeCellWidget(row_index, col_index)
											del widget
											self.CMImportTable.setItem(row_index, col_index, QTableWidgetItem(str(comboboxText)))
										else:
											mandatorySuccess_CM = False
											self.missingFields_CM.append((row_index+1, headersOfCMImportTableReal[col_index]))
								else:
									mandatorySuccess_CM = False
									self.missingFields_CM.append((row_index+1, headersOfCMImportTableReal[col_index]))



						if col_index in [12, 17]:
							widget = self.CMImportTable.cellWidget(row_index, col_index)
							if widget:
								if isinstance(widget, QLineEdit):
									if widget.text() == '':
										mandatorySuccess_CM = False
										self.missingFields_CM.append((row_index+1, headersOfCMImportTableReal[col_index]))
									else:
										lineEditText = widget.text()
										self.CMImportTable.removeCellWidget(row_index, col_index)
										del widget
										self.CMImportTable.setItem(row_index, col_index, QTableWidgetItem(str(lineEditText)))
				
					startDate = None
					startTime = None
					endDate = None
					endTime = None

					# Start Date
					if self.CMImportTable.item(row_index, self.CMImportTable.columnCount()-6):
						date_string = self.CMImportTable.item(row_index, self.CMImportTable.columnCount()-6).text()
						date_object = datetime.strptime(date_string, "%d-%m-%Y")
						startDate = QDate(date_object.year, date_object.month, date_object.day)

					elif isinstance(self.CMImportTable.cellWidget(row_index, self.CMImportTable.columnCount()-6).layout().itemAt(0).widget(), QLineEdit):
						lineEdit = self.CMImportTable.cellWidget(row_index, self.CMImportTable.columnCount()-6).layout().itemAt(0).widget()
						startDate_ = lineEdit.text()
						if startDate_ != '':
							startDate = QDate.fromString(startDate_, "dd-MM-yyyy")


					# Start Time
					if self.CMImportTable.item(row_index, self.CMImportTable.columnCount()-5):
						time_string = self.CMImportTable.item(row_index, self.CMImportTable.columnCount()-5).text()
						time_object = datetime.strptime(time_string, "%H:%M")
						startTime = QTime(time_object.hour, time_object.minute)

					elif isinstance(self.CMImportTable.cellWidget(row_index, self.CMImportTable.columnCount()-5), QLineEdit):
						lineEdit = self.CMImportTable.cellWidget(row_index, self.CMImportTable.columnCount()-5)
						startTime_ = lineEdit.text()
						if len(startTime_) == 5:
							startTime = QTime.fromString(time_string, "HH:mm")






					# End Date
					if self.CMImportTable.item(row_index, self.CMImportTable.columnCount()-4):
						date_string = self.CMImportTable.item(row_index, self.CMImportTable.columnCount()-4).text()
						date_object = datetime.strptime(date_string, "%d-%m-%Y")
						endDate = QDate(date_object.year, date_object.month, date_object.day)

					elif isinstance(self.CMImportTable.cellWidget(row_index, self.CMImportTable.columnCount()-4).layout().itemAt(0).widget(), QLineEdit):
						lineEdit = self.CMImportTable.cellWidget(row_index, self.CMImportTable.columnCount()-4).layout().itemAt(0).widget()
						endDate_ = lineEdit.text()
						if endDate_ != '':
							endDate = QDate.fromString(endDate_, "dd-MM-yyyy")
					

					# End Time
					if self.CMImportTable.item(row_index, self.CMImportTable.columnCount()-3):
						time_string = self.CMImportTable.item(row_index, self.CMImportTable.columnCount()-3).text()
						time_object = datetime.strptime(time_string, "%H:%M")
						endTime = QTime(time_object.hour, time_object.minute)

					elif isinstance(self.CMImportTable.cellWidget(row_index, self.CMImportTable.columnCount()-3), QLineEdit):
						lineEdit = self.CMImportTable.cellWidget(row_index, self.CMImportTable.columnCount()-3)
						startTime_ = lineEdit.text()
						if len(startTime_) == 5:
							endTime = QTime.fromString(time_string, "HH:mm")


					if startDate and startTime and endDate and endTime:
						startDateTime = QDateTime(startDate, startTime)
						endDateTime = QDateTime(endDate, endTime)

						difference_seconds = startDateTime.secsTo(endDateTime)
						minutes = int(difference_seconds/60)
						if minutes >= 0:
							self.CMImportTable.setItem(row_index, self.CMImportTable.columnCount()-2, QTableWidgetItem(str(minutes)))
						else:
							mandatorySuccess_CM = False
							for colInd in [self.CMImportTable.columnCount()-4, self.CMImportTable.columnCount()-6]:
								calenderWidget = QWidget()
								calenderWidget.setStyleSheet('')
								layout = QHBoxLayout()
								calenderWidget.setLayout(layout)
								calenderWidget.setFixedWidth(140)
								layout.setSpacing(0)
								layout.setContentsMargins(0, 0, 0, 0)
								# self.dateBox = QDateEdit()
								# self.dateBox.setCalendarPopup(True)

								self.createDateEditBox('dateBox')
								self.dateBox.setFixedHeight(24)
								self.dateBox.setFixedWidth(19)
								self.dateBox.setButtonSymbols(QDateEdit.NoButtons)
								
								# if self.userRole != 0:
								# 	self.dateBox.setMinimumDate(firstDateOfPreviousMonth)

								# if (self.userName == 'Ravikumar') and (self.editableOptionMaxDate > datetime.now().date()):
								# 	self.dateBox.setMinimumDate(QDate(self.startingYear, self.startingMonth, 1))


								self.dateBox.setStyleSheet("""
									QDateEdit {
									color: transparent;
									border: 1px solid transparent;
									border-radius: 0px;
									}
									QDateEdit:hover {
									border: 1px solid transparent;
									}
									QDateEdit::drop-down{
									border-bottom-right-radius: 1px;
									}
									QDateEdit::down-arrow{
									width: 24px;
									height: 24px;
									image: url('Media/calendar.png');
									}
									""")

								self.createLineEditBox('lineBoxInCalenderWidget')
								self.lineBoxInCalenderWidget.setReadOnly(True)
								self.lineBoxInCalenderWidget.setFixedHeight(24)
								self.lineBoxInCalenderWidget.setFixedWidth(110)
								self.lineBoxInCalenderWidget.setProperty("error", True)
								self.lineBoxInCalenderWidget.setStyleSheet(self.lineEditBoxQSS)
								layout.addWidget(self.lineBoxInCalenderWidget)
								layout.addWidget(self.dateBox)


								def dateChangedd(dateEdit, lineEdit):
									lineEdit.setText(str(dateEdit.date().toString("dd-MM-yyyy")))

								def dateEditFunctionInCell(dateEdit, lineEdit):

									dateEdit.dateChanged.connect(lambda: dateChangedd(dateEdit, lineEdit))

								dateEditFunctionInCell(self.dateBox, self.lineBoxInCalenderWidget)
								


								item = self.CMImportTable.takeItem(row_index, colInd)
								del item
								self.CMImportTable.setCellWidget(row_index, colInd, calenderWidget)
								self.missingFields_CM.append((row_index+1, headersOfCMImportTableReal[colInd]))



							for colInd in [self.CMImportTable.columnCount()-3, self.CMImportTable.columnCount()-5]:
								TimeLineEdit = timeLineEdit()
								TimeLineEdit.setFixedHeight(28)
								TimeLineEdit.setFixedWidth(120)
								TimeLineEdit.setProperty("error", True)
								TimeLineEdit.setStyleSheet(self.lineEditBoxQSS)
								TimeLineEdit.setStyleSheet(self.lineEditBoxQSS)

								item = self.CMImportTable.takeItem(row_index, colInd)
								del item
								self.CMImportTable.setCellWidget(row_index, colInd, TimeLineEdit)
								self.missingFields_CM.append((row_index+1, headersOfCMImportTableReal[col_index]))
				
				if len(self.missingFields_CM) > 0:
					for index, field in enumerate(self.missingFields_CM):
						missingFieldsGridLayout_CM.addWidget(QLabel(str(field[0])), index, 0)
						missingFieldsGridLayout_CM.addWidget(QLabel(str(field[1])), index, 1)
					missingFieldsGridLayout_CM.addItem(QSpacerItem(1, 1, QSizePolicy.Fixed, QSizePolicy.Expanding), len(self.missingFields_CM), 0)
					scrollForMissingFields.show()
				else:
					scrollForMissingFields.hide()


				for row in range(self.CMImportTable.rowCount()):
					for col in range(self.CMImportTable.columnCount()):
						item = self.CMImportTable.item(row, col)
						if item:
							item.setToolTip(item.text())


				if mandatorySuccess_CM:
					for r in range(self.CMImportTable.rowCount()):
						cm_id_string = 'CM' + '_' + currentDateTimeValue.strftime("%Y%m%d%H%M%S%f")[:-4]
						currentDateTimeValue += timedelta(milliseconds=10)
						singleRowData_CM = [cm_id_string]
						
						sysSubsys_CM = []

						for c in range(self.CMImportTable.columnCount()-1):
							if c in [0, 28, 30]:
								item = self.CMImportTable.item(r, c)
								if item:
									dateString = item.text()
									timeItem = self.CMImportTable.item(r, c+1)
									if timeItem:
										timeString = timeItem.text()
										datetimeObject = datetime.strptime(dateString + " " + timeString, "%d-%m-%Y %H:%M")
										singleRowData_CM.append(datetimeObject)

							elif c in [1, 29, 31]:
								pass

							# elif c == 3:
							# 	item = self.CMImportTable.item(r, c)
							# 	if item:
							# 		trainString = item.text()
							# 		query = "SELECT id FROM trainsets WHERE trainset = %s"
							# 		self.cursor.execute(query, (trainString,))
							# 		result = self.cursor.fetchone()
							# 		singleRowData_CM.append(result[0])


							elif c == 9:
								item = self.CMImportTable.item(r, c)
								if item:
									systemString = item.text()
									query = "SELECT id FROM bom WHERE equipment = %s AND parent_id = 0"
									self.cursor.execute(query, (systemString,))
									result = self.cursor.fetchone()
									singleRowData_CM.append(result[0])

							elif c == 10:
								item = self.CMImportTable.item(r, c)
								if item:
									subSystemString = item.text()
									query = "SELECT id FROM bom WHERE parent_id = (SELECT id FROM bom WHERE equipment = %s AND parent_id = 0) AND equipment = %s"
									self.cursor.execute(query, (self.CMImportTable.item(r, c-1).text(), subSystemString))
									result = self.cursor.fetchone()
									singleRowData_CM.append(result[0])

							elif c == 27:
								item = self.CMImportTable.item(r, c)
								attachedFilesList = []
								vall = 0
								if item:
									folder_path = self.selectFolderForAttachmentsLineEdit_CMImport.text()
									dest_folder = "C:\\ProgramData\\RAMSify\\Attachments"

									if not os.path.exists(dest_folder):
										os.makedirs(dest_folder)

									if os.path.exists(folder_path):
										for filename in os.listdir(folder_path):
											base_name, extension = os.path.splitext(filename)
											if base_name == self.CMImportTable.item(r, 5).text():
												src_file = os.path.join(folder_path, filename)

												fVal = str(vall)
												if len(str(vall)) == 1:
													fVal = '00'+str(vall)
												elif len(str(vall)) == 2:
													fVal = '0'+str(vall)
												else:
													fVal = str(vall)


												new_filename = f"{base_name}_{datetime.now().strftime('%Y%m%d%H%M%S')}{fVal}{extension}"
												attachedFilesList.append(new_filename)
												dest_file = os.path.join(dest_folder, new_filename)

												shutil.copy(src_file, dest_file)
												vall += 1

									singleRowData_CM.append(str(attachedFilesList))
								else:
									singleRowData_CM.append(None)


							else:
								item = self.CMImportTable.item(r, c)
								if item:
									itemText = item.text()
									singleRowData_CM.append(itemText)
								else:
									singleRowData_CM.append(None)

						insert_query = """
							INSERT INTO corrective_maintenance (
							cm_id, event_datetime, depot, trainset_id, car_no, jobcard_no, issued_to, ml_depot, location,
							system_id, subsystem_id, other_subsystem, fault_details, failure_type, service_failure_effect, consider_for_relevant_fails,
							action_taken_at_mainline, action_taken_at_depot, failure_category, failure_responsibility,
							equipment, component, lowest_level_component, ncr_no, component_replaced, replaced_component, verification, attachments, work_start_at, work_end_at, down_time, user_id
							) SELECT
								%s, %s, %s, trainsets.id, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s
							FROM
								trainsets
							WHERE
								trainsets.trainset = %s
						"""

						singleRowData_CM.append(self.user_id)
						trainset = singleRowData_CM.pop(3)
						singleRowData_CM.append(trainset)
						self.cursor.execute(insert_query, tuple(singleRowData_CM))
						self.mydb.commit()



					msg = QMessageBox()
					msg.setIcon(QMessageBox.Information)
					msg.setText(f"{self.CMImportTable.rowCount()} CM's added Successfully")
					msg.setWindowTitle("Message")
					msg.setWindowIcon(QIcon('Media/ramsify.png'))
					msg.exec_()

					self.CMImportWindow.close()
					self.apply_CMDT.click()

					# self.refreshButton_availDash.click()
					# self.refreshBtn_MDBCFDash.click()
					# self.refreshButton_MDBFDash.click()
					# self.refreshBtn_MTTRDash.click()
					# self.refreshBtn_PF.click()
					# self.refreshBtn_SRF.click()

				else:
					msg = QMessageBox()
					msg.setIcon(QMessageBox.Information)
					msg.setText("Please Enter All the Mandatory Fields")
					msg.setWindowTitle("Message")
					msg.setWindowIcon(QIcon('Media/ramsify.png'))
					msg.exec_()





				# if mandatorySuccess_CM:
				# 	pass
					# for singleRowData_CM in self.listOfImportedCMRows:

					# 	insert_query = """
					# 		INSERT INTO corrective_maintenance (
					# 		cm_id, event_datetime, depot, trainset_id, car_no, jobcard_no, issued_to, ml_depot, location,
					# 		system_id, subsystem_id, fault_details, failure_type, service_failure_effect,
					# 		action_taken_at_mainline, action_taken_at_depot, failure_category, failure_responsibility,
					# 		equipment, component, lowest_level_component, ncr_no, component_replaced, verification, work_start_at, work_end_at, down_time, user_id
					# 		) SELECT
					# 			%s, %s, %s, trainsets.id, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s
					# 		FROM
					# 			trainsets
					# 		WHERE
					# 			trainsets.trainset = %s
					# 	"""
						
					# 	singleRowData_CM.append(self.user_id)
					# 	trainset = singleRowData_CM.pop(3)
					# 	singleRowData_CM.append(trainset)
					# 	self.cursor.execute(insert_query, tuple(singleRowData_CM))
					# 	self.mydb.commit()


					# cmMsgBox = QMessageBox()
					# cmMsgBox.setIcon(QMessageBox.Information) 
					# cmMsgBox.setText('Data Submitted Successfully')
					# cmMsgBox.setWindowTitle("Message")
					# cmMsgBox.setWindowIcon(QIcon('Media/ramsify.png'))
					# cmMsgBox.setStandardButtons(QMessageBox.Ok)
					# cmMsgBox.exec_()


					# self.CMImportWindow.close()
					# del self.CMImportWindow

					# self.refreshButton_availDash.click()
					# self.refreshBtn_MDBCFDash.click()
					# self.refreshButton_MDBFDash.click()
					# self.refreshBtn_MTTRDash.click()
					# self.refreshBtn_PF.click()
					# self.refreshBtn_SRF.click()


					# ### Function to reflect the newly added CM data into CM Data table:

					# for row, singleRowData_CM in enumerate(self.listOfImportedCMRows):
					# 	self.cmDataTable.setRowCount(self.cmDataTable.rowCount()+1)

					# 	relevant_data_CM = [singleRowData_CM[1], singleRowData_CM[2], singleRowData_CM[-1], self.allSysSubSysListInImport_CM[row][0], self.allSysSubSysListInImport_CM[row][1], 
					# 	singleRowData_CM[11], singleRowData_CM[12], singleRowData_CM[16], singleRowData_CM[4], singleRowData_CM[20], singleRowData_CM[5], singleRowData_CM[-5], singleRowData_CM[-4], singleRowData_CM[-3]]

					# 	button = QPushButton(str(singleRowData_CM[0]))
					# 	button.setStyleSheet("QPushButton { text-decoration: none; }"
					# 		"QPushButton:hover { text-decoration: underline; }")
					# 	button.setCursor(Qt.PointingHandCursor)
					# 	self.cmDataTable.setCellWidget(self.cmDataTable.rowCount()-1, 0, button)
					# 	button.clicked.connect(lambda : onButtonClicked_cmData(self, button.text()))

						
						
					# 	for col, value in enumerate(relevant_data_CM):
					# 		if value is not None:
					# 			if isinstance(value, datetime):
					# 				formatted_datetime = value.strftime('%Y-%m-%d %H:%M')
					# 				item = QTableWidgetItem(formatted_datetime)
					# 				item.setTextAlignment(Qt.AlignCenter)
					# 			else:
					# 				item = QTableWidgetItem(str(value))
					# 				item.setTextAlignment(Qt.AlignCenter)
					# 		else:
					# 			item = QTableWidgetItem('')
					# 			item.setTextAlignment(Qt.AlignCenter)
					# 		self.cmDataTable.setItem(self.cmDataTable.rowCount()-1, col+1, item)
			else:
				msg = QMessageBox()
				msg.setIcon(QMessageBox.Information)
				msg.setText("Please Import the Data")
				msg.setWindowTitle("Message")
				msg.setWindowIcon(QIcon('Media/ramsify.png'))
				msg.exec_()



		self.cancelBtnOfImportCM.clicked.connect(lambda: self.CMImportWindow.close())
		self.submitBtnOfImportCM.clicked.connect(onClickingSubmitCMImportWindow)




		#########################################################################################################################


		### Export the table into excel file:

		def exportCMInputTemplate():
			# Get the file path for saving the Excel file
			file_path, _ = QFileDialog.getSaveFileName(None, "Save Excel File", "", "Excel Files (*.xlsx)")

			if file_path:

				headersOfCMImportTableTemplate = ['Event Date', 'Event Time', 'Depot', 'Trainset', 'Car Number', 'Jobcard No' ,'Issued To', 'ML/Depot', 'Location',
											 'System', 'Sub-System', 'Other Sub-System', 'Quantity', 'Fault Details', 'Failure Type', 'Service Failure Effect', 'Consider for Relevant Fails?', 'Action Taken At Mainline', 'Action Taken At Depot', 'Failure Category',
											'Failure Responsibility', 'Equipment', 'Component', 'Lowest Level Component', 'NCR No', 'Is Component Replaced?', 'Replaced Component', 'Verification',
											'Workstart Date', 'Workstart Time', 'Workend Date', 'Workend Time']

				# Create a Pandas DataFrame from the table data excluding downtime label
				df = pd.DataFrame([headersOfCMImportTableTemplate])

				# Save the DataFrame to an Excel file
				df.to_excel(file_path, index=False, header=False)

				# Show success message
				msg = QMessageBox()
				msg.setIcon(QMessageBox.Information)
				msg.setText("Exported Successfully")
				msg.setWindowTitle("Message")
				msg.setWindowIcon(QIcon('Media/ramsify.png'))
				msg.exec_()

		self.templateButton_CMImport.clicked.connect(exportCMInputTemplate)

		#########################################################################################################################
		#########################################################################################################################
		#########################################################################################################################
		#########################################################################################################################

		## Import multiple data from the excel:
		def importCMDataFromExceltoTable():

			file_path, _ = QFileDialog.getOpenFileName(None, "Select Excel File", "", "Excel Files (*.xlsx)")

			if file_path:
				# Read the excel file into pandas dataframe
				dataf = pd.read_excel(file_path)
				dataf = dataf.map(lambda x: x.strip() if isinstance(x, str) else x)

				# Get the headers as a list
				excelHeaders = dataf.columns.tolist()

				excelDataMappingWindowWidth = int(0.3* QApplication.primaryScreen().availableGeometry().width())
				excelDataMappingWindowHeight = int(0.6 * QApplication.primaryScreen().availableGeometry().height())

				self.excelAndTableColumnsMappingWindow = QWidget()
				self.excelAndTableColumnsMappingWindow.setWindowIcon(QIcon('Media/ramsify.png'))
				self.excelAndTableColumnsMappingWindow.setWindowTitle('Map Columns')
				self.excelAndTableColumnsMappingWindow.setStyleSheet(self.widgetQSS)
				self.excelAndTableColumnsMappingWindow.setFixedHeight(excelDataMappingWindowHeight)
				self.excelAndTableColumnsMappingWindow.setFixedWidth(excelDataMappingWindowWidth)
				# self.excelAndTableColumnsMappingWindow.resize(excelDataMappingWindowWidth,excelDataMappingWindowHeight)

				VLayoutForColumnsMappingWindow = QVBoxLayout()

				columnsMappingHeaderLabel = QLabel('Map Columns')
				columnsMappingHeaderLabel.setAlignment(Qt.AlignHCenter)
				columnsMappingHeaderLabel.setContentsMargins(20, 0, 0, 0)


				scrollArea_ExcelImportWindow = QScrollArea()
				scrollArea_ExcelImportWindow.setStyleSheet(self.scrollAreaQSS)
				scrollArea_ExcelImportWindow.setWidgetResizable(True)
				

				VLayoutForColumnsMappingWindow.addWidget(columnsMappingHeaderLabel)


				excelColumnsWithTableColumnsWidget = QWidget()
				# excelColumnsWithTableColumnsWidget.setAlignment(Qt.AlignTop)

				scrollArea_ExcelImportWindow.setWidget(excelColumnsWithTableColumnsWidget)


				excelAndTableColumnsGridLayout = QGridLayout()

				widgetHeadersLabel = QLabel('Fields')
				widgetHeadersLabel.setStyleSheet("font-size: 13pt;")

				excelHeadersLabel = QLabel('Imported Excel Columns')
				excelHeadersLabel.setStyleSheet("font-size: 13pt;")

				

				excelAndTableColumnsGridLayout.addWidget(widgetHeadersLabel, 0, 0)
				excelAndTableColumnsGridLayout.addWidget(excelHeadersLabel, 0, 1)

				headersOfCMImportTable = ['Event Date', 'Event Time', 'Depot', 'Trainset', 'Car Number', 'Jobcard No' ,'Issued To', 'ML/Depot', 'Location',
										 'System', 'Sub-System', 'Other Sub-System', 'Quantity', 'Fault Details', 'Failure Type', 'Service Failure Effect', 'Consider for Relevant Fails?', 'Action Taken At Mainline', 'Action Taken At Depot', 'Failure Category',
										'Failure Responsibility', 'Equipment', 'Component', 'Lowest Level Component', 'NCR No', 'Is Component Replaced?', 'Replaced Component', 'Verification',
										'Workstart Date', 'Workstart Time', 'Workend Date', 'Workend Time']

				for i in range(len(headersOfCMImportTable)):
					fieldLabel_mappingWindow = QLabel(headersOfCMImportTable[i])
					excelAndTableColumnsGridLayout.addWidget(fieldLabel_mappingWindow, i + 1, 0)

					self.createComboBox(excelHeaders, 'excelColumnNames')

					if (headersOfCMImportTable[i]).lower() in [s.lower() for s in excelHeaders]:
						for d, header in enumerate(excelHeaders):
							if headersOfCMImportTable[i].lower() == header.lower():
								self.excelColumnNames.setCurrentText(excelHeaders[d])
					else:
						self.excelColumnNames.setProperty('error', True)
						self.excelColumnNames.setStyleSheet(self.comboBoxQSS)

					excelAndTableColumnsGridLayout.addWidget(self.excelColumnNames, i + 1, 1)


				excelColumnsWithTableColumnsWidget.setLayout(excelAndTableColumnsGridLayout)

				VLayoutForColumnsMappingWindow.addWidget(scrollArea_ExcelImportWindow)



				self.createPushButton('submitImportedExcelData', 'SUBMIT', width=int(0.050 * QApplication.primaryScreen().availableGeometry().width()))
				self.submitImportedExcelData.setFixedHeight(30)

				def mapData():
					allSelected = True
					for c in range(excelAndTableColumnsGridLayout.rowCount()):
						if isinstance(excelAndTableColumnsGridLayout.itemAtPosition(c, 1).widget(), QComboBox):

							if excelAndTableColumnsGridLayout.itemAtPosition(c, 1).widget().currentText() != '':
								excelAndTableColumnsGridLayout.itemAtPosition(c, 1).widget().setProperty('error', False)
								excelAndTableColumnsGridLayout.itemAtPosition(c, 1).widget().setStyleSheet(self.comboBoxQSS)
							else:
								allSelected = False


					if allSelected:
						self.excelAndTableColumnsMappingWindow.close()
						excelIndices = []
						for i in range(excelAndTableColumnsGridLayout.rowCount()):
							if excelAndTableColumnsGridLayout.itemAtPosition(i, 1):
								if excelAndTableColumnsGridLayout.itemAtPosition(i, 1).widget():
									if isinstance(excelAndTableColumnsGridLayout.itemAtPosition(i, 1).widget(), CustomComboBox):
										excelIndices.append(excelAndTableColumnsGridLayout.itemAtPosition(i, 1).widget().currentIndex())

						dataf_ = dataf.iloc[:, excelIndices]

						# self.CMImportTable.setRowCount(dataf_.shape[0])


						current_date_ = datetime.now()

						currentYear = current_date_.year
						currentMonth = current_date_.month
						firstDayOfCurrentMonth = datetime(currentYear, currentMonth, 1).date()
						lastDateOfPreviousMonth = (firstDayOfCurrentMonth - relativedelta(days=1))
						firstDateOfPreviousMonth = datetime(lastDateOfPreviousMonth.year, lastDateOfPreviousMonth.month, 1).date()

						six_months_ago = current_date_ - relativedelta(months=6)
						firstDateOfSixMonthsAgo_ = six_months_ago.replace(day=1)
						firstDateOfSixMonthsAgo = datetime(firstDateOfSixMonthsAgo_.year, firstDateOfSixMonthsAgo_.month, 1).date()

						if self.userRole == 0:
							minDateToEnter = datetime(self.startingYear, self.startingMonth, 1).date()

						if self.userRole == 1:
							minDateToEnter = firstDateOfSixMonthsAgo

						if self.userRole in [2, 3]:
							minDateToEnter = firstDateOfPreviousMonth
						

						if ((self.userName == 'Ravikumar') and (self.editableOptionMaxDate > datetime.now().date())):
							minDateToEnter = datetime(self.startingYear, self.startingMonth, 1).date()


						def addCMRow(rowData, color= None):
							for col_index, value in enumerate(rowData):
								# QApplication.processEvents()



								if col_index in [0, 28, 30]:

									try:
										if isinstance(value, datetime) and (minDateToEnter < value.date()):
											date_value = value.date()
											formatted_date = date_value.strftime('%d-%m-%Y')
											item = QTableWidgetItem(str(formatted_date))
											if col_index == 0:
												self.CMImportTable.setItem(self.CMImportTable.rowCount()-1, col_index, item)
											else:
												self.CMImportTable.setItem(self.CMImportTable.rowCount()-1, col_index, item)

										else:

											calenderWidget = QWidget()
											layout = QHBoxLayout()
											calenderWidget.setLayout(layout)
											calenderWidget.setFixedWidth(140)
											layout.setSpacing(0)
											layout.setContentsMargins(0, 0, 0, 0)
											# self.dateBox = QDateEdit()
											# self.dateBox.setCalendarPopup(True)

											self.createDateEditBox('dateBox')
											self.dateBox.setButtonSymbols(QDateEdit.NoButtons)
											self.dateBox.setFixedHeight(24)
											self.dateBox.setFixedWidth(19)


											self.dateBox.setStyleSheet("""
												QDateEdit {
												color: transparent;
												border: 1px solid transparent;
												border-radius: 0px;
												}
												QDateEdit:hover {
												border: 1px solid transparent;
												}
												QDateEdit::drop-down{
												border-bottom-right-radius: 1px;
												}
												QDateEdit::down-arrow{
												width: 24px;
												height: 24px;
												image: url('Media/calendar.png');
												}
												""")

											self.createLineEditBox('lineBoxInCalenderWidget')
											self.lineBoxInCalenderWidget.setReadOnly(True)
											self.lineBoxInCalenderWidget.setFixedHeight(24)
											self.lineBoxInCalenderWidget.setFixedWidth(110)
											self.lineBoxInCalenderWidget.setProperty("error", True)
											self.lineBoxInCalenderWidget.setStyleSheet(self.lineEditBoxQSS)

											# if self.userRole != 0:
											# 	self.dateBox.setMinimumDate(firstDateOfPreviousMonth)

											# if (self.userName == 'Ravikumar') and (self.editableOptionMaxDate > datetime.now().date()):
											# 	self.dateBox.setMinimumDate(QDate(self.startingYear, self.startingMonth, 1))

											layout.addWidget(self.lineBoxInCalenderWidget)
											layout.addWidget(self.dateBox)


											def dateChangedd(dateEdit, lineEdit):
												lineEdit.setText(str(dateEdit.date().toString("dd-MM-yyyy")))

											def dateEditFunctionInCell(dateEdit, lineEdit):

												dateEdit.dateChanged.connect(lambda: dateChangedd(dateEdit, lineEdit))

											dateEditFunctionInCell(self.dateBox, self.lineBoxInCalenderWidget)
											
											if col_index == 0:
												self.CMImportTable.setCellWidget(self.CMImportTable.rowCount()-1, col_index, calenderWidget)
												self.missingFields_CM.append((self.CMImportTable.rowCount(), headersOfCMImportTableReal[col_index]))
											else:
												self.CMImportTable.setCellWidget(self.CMImportTable.rowCount()-1, col_index, calenderWidget)
												self.missingFields_CM.append((self.CMImportTable.rowCount(), headersOfCMImportTableReal[col_index]))

									except ValueError:
										self.createDateEditBox('dateBox')
										# if self.userRole != 0:
										# 	self.dateBox.setMinimumDate(firstDateOfPreviousMonth)

										# if (self.userName == 'Ravikumar') and (self.editableOptionMaxDate > datetime.now().date()):
										# 	self.dateBox.setMinimumDate(QDate(self.startingYear, self.startingMonth, 1))
										if col_index == 0:
											self.CMImportTable.setCellWidget(self.CMImportTable.rowCount()-1, col_index, self.dateBox)
											self.missingFields_CM.append((self.CMImportTable.rowCount(), headersOfCMImportTableReal[col_index]))
										else:
											self.CMImportTable.setCellWidget(self.CMImportTable.rowCount()-1, col_index, self.dateBox)
											self.missingFields_CM.append((self.CMImportTable.rowCount(), headersOfCMImportTableReal[col_index]))


								if col_index in [1, 29, 31]:
									try:
										if str(type(value)) == "<class 'datetime.time'>":
											formatted_time = value.strftime('%H:%M')
											item = QTableWidgetItem(str(formatted_time))
											if col_index == 1:
												self.CMImportTable.setItem(self.CMImportTable.rowCount()-1, col_index, item)
											else:
												self.CMImportTable.setItem(self.CMImportTable.rowCount()-1, col_index, item)

										else:
											# self.createTimeEditBox('timeBox')
											TimeLineEdit = timeLineEdit()
											TimeLineEdit.setFixedHeight(28)
											TimeLineEdit.setFixedWidth(120)
											TimeLineEdit.setProperty("error", True)
											TimeLineEdit.setStyleSheet(self.lineEditBoxQSS)
											TimeLineEdit.setStyleSheet(self.lineEditBoxQSS)
											if col_index == 1:
												self.CMImportTable.setCellWidget(self.CMImportTable.rowCount()-1, col_index, TimeLineEdit)
												self.missingFields_CM.append((self.CMImportTable.rowCount(), headersOfCMImportTableReal[col_index]))
											else:
												self.CMImportTable.setCellWidget(self.CMImportTable.rowCount()-1, col_index, TimeLineEdit)
												self.missingFields_CM.append((self.CMImportTable.rowCount(), headersOfCMImportTableReal[col_index]))

									except ValueError:
										TimeLineEdit = timeLineEdit()
										TimeLineEdit.setFixedHeight(28)
										TimeLineEdit.setFixedWidth(120)
										TimeLineEdit.setStyleSheet(self.lineEditBoxQSS)
										if col_index == 1:
											self.CMImportTable.setCellWidget(self.CMImportTable.rowCount()-1, col_index, TimeLineEdit)
											self.missingFields_CM.append((self.CMImportTable.rowCount(), headersOfCMImportTableReal[col_index]))
										else:
											self.CMImportTable.setCellWidget(self.CMImportTable.rowCount()-1, col_index, TimeLineEdit)
											self.missingFields_CM.append((self.CMImportTable.rowCount(), headersOfCMImportTableReal[col_index]))

								if col_index == 2:
									invalidVal = True
									for depo in self.depotsList:
										if str(value).lower() == depo.lower():
											item = QTableWidgetItem(depo)
											self.CMImportTable.setItem(self.CMImportTable.rowCount()-1, col_index, item)
											invalidVal = False
											break
									if invalidVal:
										self.createComboBox(self.depotsList, 'depoComboBox')
										self.depoComboBox.setProperty("error", True)
										self.depoComboBox.setStyleSheet(self.comboBoxQSS)
										self.CMImportTable.setCellWidget(self.CMImportTable.rowCount()-1, col_index, self.depoComboBox)
										self.missingFields_CM.append((self.CMImportTable.rowCount(), headersOfCMImportTableReal[col_index]))

								if col_index == 3:
									invalidVal = True
									for train in self.trainsetsList:
										if str(value).lower() == train.lower():
											item = QTableWidgetItem(train)
											self.CMImportTable.setItem(self.CMImportTable.rowCount()-1, col_index, item)
											invalidVal = False
											break
									if invalidVal:
										self.createComboBox(self.trainsetsList, 'trainComboBox')
										self.trainComboBox.setProperty("error", True)
										self.trainComboBox.setStyleSheet(self.comboBoxQSS)
										self.CMImportTable.setCellWidget(self.CMImportTable.rowCount()-1, col_index, self.trainComboBox)
										self.missingFields_CM.append((self.CMImportTable.rowCount(), headersOfCMImportTableReal[col_index]))

								if col_index == 4:
									for car in self.carsList:
										if str(value).lower() == car.lower():
											item = QTableWidgetItem(car)
											self.CMImportTable.setItem(self.CMImportTable.rowCount()-1, col_index, item)
											break

								if col_index == 5:
									if not pd.isna(value):
										item = QTableWidgetItem(str(value).split('.')[0])
										self.CMImportTable.setItem(self.CMImportTable.rowCount()-1, col_index, item)


								# if col_index in [5, 6, 8, 11, 14, 15, 18, 19, 20, 21]:
								if col_index in [6, 8, 11, 13, 17, 18, 21, 22, 23, 24, 26]:
									if not pd.isna(value):
										item = QTableWidgetItem(str(value))
										if col_index in [6, 8, 11]:
											self.CMImportTable.setItem(self.CMImportTable.rowCount()-1, col_index, item)
										else:
											self.CMImportTable.setItem(self.CMImportTable.rowCount()-1, col_index-1, item)

								




								# if col_index == 12:
								# 	if not pd.isna(value):
								# 		if not str(value) == '':
								# 			try:
								# 				int_value = int(value)
								# 				# print(f"The value {value} can be converted to an integer: {int_value}")
								# 				item = QTableWidgetItem(str(int_value))
								# 				self.CMImportTable.setItem(self.CMImportTable.rowCount()-1, col_index, item)
								# 			except ValueError:
								# 				self.createNumberLineEditBox('lineBox')
								# 				self.lineBox.setProperty("error", True)
								# 				self.lineBox.setStyleSheet(self.lineEditBoxQSS)
								# 				self.CMImportTable.setCellWidget(self.CMImportTable.rowCount()-1, col_index, self.lineBox)

								# 		else:
								# 			self.createNumberLineEditBox('lineBox')
								# 			self.lineBox.setProperty("error", True)
								# 			self.lineBox.setStyleSheet(self.lineEditBoxQSS)
								# 			self.CMImportTable.setCellWidget(self.CMImportTable.rowCount()-1, col_index, self.lineBox)
								# 	else:
								# 		self.createNumberLineEditBox('lineBox')
								# 		self.lineBox.setProperty("error", True)
								# 		self.lineBox.setStyleSheet(self.lineEditBoxQSS)
								# 		self.CMImportTable.setCellWidget(self.CMImportTable.rowCount()-1, col_index, self.lineBox)



								if col_index in [13, 18]:
									if not pd.isna(value):
										if not str(value) == '':
											item = QTableWidgetItem(str(value))
											self.CMImportTable.setItem(self.CMImportTable.rowCount()-1, col_index-1, item)
										else:
											self.createLineEditBox('lineBox')
											self.lineBox.setProperty("error", True)
											self.lineBox.setStyleSheet(self.lineEditBoxQSS)
											self.CMImportTable.setCellWidget(self.CMImportTable.rowCount()-1, col_index-1, self.lineBox)
											self.missingFields_CM.append((self.CMImportTable.rowCount(), headersOfCMImportTableReal[col_index-1]))
									else:
										self.createLineEditBox('lineBox')
										self.lineBox.setProperty("error", True)
										self.lineBox.setStyleSheet(self.lineEditBoxQSS)
										self.CMImportTable.setCellWidget(self.CMImportTable.rowCount()-1, col_index-1, self.lineBox)
										self.missingFields_CM.append((self.CMImportTable.rowCount(), headersOfCMImportTableReal[col_index-1]))


								if col_index == 16:
									invalidVal = True
									for optio in ['Yes', 'No']:
										if str(value).lower() == optio.lower():
											item = QTableWidgetItem(optio)
											self.CMImportTable.setItem(self.CMImportTable.rowCount()-1, col_index-1, item)
											invalidVal = False
											break
									if invalidVal:
										self.createComboBox(['Yes', 'No'], 'considerForRelevantFails_a')
										self.considerForRelevantFails_a.setProperty("error", True)
										self.considerForRelevantFails_a.setStyleSheet(self.comboBoxQSS)
										self.CMImportTable.setCellWidget(self.CMImportTable.rowCount()-1, col_index-1, self.considerForRelevantFails_a)
										self.missingFields_CM.append((self.CMImportTable.rowCount(), headersOfCMImportTableReal[col_index-1]))


								if col_index == 7:
									# invalidVal = True
									for option in ['M/L', 'Depot']:
										if str(value).lower() == option.lower():
											item = QTableWidgetItem(option)
											self.CMImportTable.setItem(self.CMImportTable.rowCount()-1, col_index, item)
											invalidVal = False
											break
									# if invalidVal:
									# 	self.createComboBox(['M/L', 'Depot'], 'mlDepotComboBox')
									# 	self.mlDepotComboBox.setProperty("error", True)
									# 	self.mlDepotComboBox.setStyleSheet(self.comboBoxQSS)
									# 	self.CMImportTable.setCellWidget(self.CMImportTable.rowCount()-1, col_index, self.mlDepotComboBox)

								failCategoryOptions = ['External', 'Maintenance', 'Material', 'NFF', 'Operation', 'Software', 'Workmanship', 'Others']
								if col_index == 19:
									for option in failCategoryOptions:
										if str(value).lower() == option.lower():
											item = QTableWidgetItem(option)
											self.CMImportTable.setItem(self.CMImportTable.rowCount()-1, col_index-1, item)
											break


								if col_index == 20:
									invalidVal = True
									for responsibilityOption in ['BEML', 'MMMOCL', 'Others']:
										if str(value).lower() == responsibilityOption.lower():
											item = QTableWidgetItem(responsibilityOption)
											self.CMImportTable.setItem(self.CMImportTable.rowCount()-1, col_index-1, item)
											invalidVal = False
											break
									if invalidVal:
										self.createComboBox(['BEML', 'MMMOCL', 'Others'], 'responsibilComboBox')
										self.responsibilComboBox.setProperty("error", True)
										self.responsibilComboBox.setStyleSheet(self.comboBoxQSS)
										self.CMImportTable.setCellWidget(self.CMImportTable.rowCount()-1, col_index-1, self.responsibilComboBox)
										self.missingFields_CM.append((self.CMImportTable.rowCount(), headersOfCMImportTableReal[col_index-1]))

								if col_index == 25:
									for componentReplaced in ['Yes', 'No']:
										if str(value).lower() == componentReplaced.lower():
											item = QTableWidgetItem(componentReplaced)
											self.CMImportTable.setItem(self.CMImportTable.rowCount()-1, col_index-1, item)
											break

								if col_index == 27:
									invalidVal = True
									for verificationOption in ['Yes', 'No']:
										if str(value).lower() == verificationOption.lower():
											item = QTableWidgetItem(verificationOption)
											self.CMImportTable.setItem(self.CMImportTable.rowCount()-1, col_index-1, item)
											invalidVal = False
											break
									if invalidVal:
										self.createComboBox(['Yes', 'No'], 'varificaComboBox')
										self.varificaComboBox.setProperty("error", True)
										self.varificaComboBox.setStyleSheet(self.comboBoxQSS)
										self.CMImportTable.setCellWidget(self.CMImportTable.rowCount()-1, col_index-1, self.varificaComboBox)
										self.missingFields_CM.append((self.CMImportTable.rowCount(), headersOfCMImportTableReal[col_index-1]))


								if col_index == 9:
									invalidVal = True
									for systemOption in list(self.BOMSystemDictionary.keys()):
										if str(value).lower() == systemOption.lower():
											item = QTableWidgetItem(systemOption)
											self.CMImportTable.setItem(self.CMImportTable.rowCount()-1, col_index, item)
											invalidVal = False


											invalidVal2 = True
											subSysOptions = self.BOMSystemDictionary[systemOption]
											for subSystemOption in subSysOptions:
												subSys = rowData.iloc[col_index + 1]
												if str(subSys).lower() == subSystemOption.lower():
													item2 = QTableWidgetItem(subSystemOption)
													self.CMImportTable.setItem(self.CMImportTable.rowCount()-1, col_index + 1, item2)
													invalidVal2 = False
													break
											if invalidVal2:
												self.createComboBox(subSysOptions, 'subsystComboBox')
												self.subsystComboBox.setProperty("error", True)
												self.subsystComboBox.setStyleSheet(self.comboBoxQSS)
												self.CMImportTable.setCellWidget(self.CMImportTable.rowCount()-1, col_index + 1, self.subsystComboBox)
												self.missingFields_CM.append((self.CMImportTable.rowCount(), headersOfCMImportTableReal[col_index+1]))

											break
									if invalidVal:
										self.createComboBox(list(self.BOMSystemDictionary.keys()), 'systComboBox')
										self.systComboBox.setProperty("error", True)
										self.systComboBox.setStyleSheet(self.comboBoxQSS)
										self.CMImportTable.setCellWidget(self.CMImportTable.rowCount()-1, col_index, self.systComboBox)
										self.missingFields_CM.append((self.CMImportTable.rowCount(), headersOfCMImportTableReal[col_index]))

										self.createComboBox([], 'subsystComboBox')
										self.subsystComboBox.setProperty("error", True)
										self.subsystComboBox.setStyleSheet(self.comboBoxQSS)
										self.subsystComboBox.setEnabled(False)
										self.CMImportTable.setCellWidget(self.CMImportTable.rowCount()-1, col_index + 1, self.subsystComboBox)
										self.missingFields_CM.append((self.CMImportTable.rowCount(), headersOfCMImportTableReal[col_index+1]))

										def onChangingSysCombobox_CMImport2(sysCMCB, subSysCMCB):
											subSysCMCB.setEnabled(True)
											subSysCMCB.clear()
											if sysCMCB.currentText() != '':
												subSysCMCB.addItems(self.BOMSystemDictionary[sysCMCB.currentText()])
											else:
												subSysCMCB.setEnabled(False)

										def functionalityOfSystemSubsysCB_CMI2(sysCMCB, subSysCMCB):
											sysCMCB.currentTextChanged.connect(lambda:onChangingSysCombobox_CMImport2(sysCMCB, subSysCMCB))

										functionalityOfSystemSubsysCB_CMI2(self.systComboBox, self.subsystComboBox)

								if col_index == 10:
									if not pd.isna(value):
										if not pd.isna(rowData.iloc[col_index - 1]):
											if rowData.iloc[col_index - 1].lower() == 'others':
												
												item = QTableWidgetItem(str(value))
												self.CMImportTable.setItem(self.CMImportTable.rowCount()-1, col_index, item)
												

								if col_index == 14:
									invalidVal3 = True
									failureTypeOptions = ['Relevant Failure', 'Service Failure', 'Non Relevant Failure']
									for opti in failureTypeOptions:
										if str(value).lower() == opti.lower():
											item = QTableWidgetItem(opti)
											self.CMImportTable.setItem(self.CMImportTable.rowCount()-1, col_index-1, item)
											invalidVal3 = False

											if opti == 'Service Failure':
												invalidVal4 = True
												serviceFailureEffectOptions = ['Pre-departure Withdrawal', 'Withdrawal', '3 min delay', 'Deboarding']

												serviceFialureValue = rowData.iloc[col_index + 1]
												# print(col_index + 1, serviceFialureValue)
												if not pd.isna(serviceFialureValue):
													for serviceFailEffectValue in serviceFailureEffectOptions:
														if serviceFialureValue.lower() == serviceFailEffectValue.lower():
															item2 = QTableWidgetItem(serviceFailEffectValue)
															self.CMImportTable.setItem(self.CMImportTable.rowCount()-1, col_index-1 + 1, item2)
															invalidVal4 = False
															break

													if invalidVal4:
														self.createComboBox(serviceFailureEffectOptions, 'serviceFailEffectComboBox')
														self.serviceFailEffectComboBox.setProperty("error", True)
														self.serviceFailEffectComboBox.setStyleSheet(self.comboBoxQSS)
														self.CMImportTable.setCellWidget(self.CMImportTable.rowCount()-1, col_index-1 + 1, self.serviceFailEffectComboBox)
														self.missingFields_CM.append((self.CMImportTable.rowCount(), headersOfCMImportTableReal[col_index-1+1]))

											break


									if invalidVal3:
										self.createComboBox(failureTypeOptions, 'failureTypeCB2')
										self.failureTypeCB2.setProperty("error", True)
										self.failureTypeCB2.setStyleSheet(self.comboBoxQSS)
										self.CMImportTable.setCellWidget(self.CMImportTable.rowCount()-1, col_index-1, self.failureTypeCB2)
										self.missingFields_CM.append((self.CMImportTable.rowCount(), headersOfCMImportTableReal[col_index-1]))

										self.createComboBox([], 'serviceFailureEffectCombobox_ICM2')
										# self.serviceFailureEffectCombobox_ICM2.setProperty("error", True)
										# self.serviceFailureEffectCombobox_ICM2.setStyleSheet(self.comboBoxQSS)
										self.serviceFailureEffectCombobox_ICM2.setEnabled(False)
										self.CMImportTable.setCellWidget(self.CMImportTable.rowCount()-1, col_index-1 + 1, self.serviceFailureEffectCombobox_ICM2)
										self.missingFields_CM.append((self.CMImportTable.rowCount(), headersOfCMImportTableReal[col_index-1+1]))


										def onChangingFailureTypeCombobox_CMImport(failureTypeCB, serviceFailureCB):

											if failureTypeCB.currentIndex() == 1:
												serviceFailureCB.setEnabled(True)
												serviceFailureCB.clear()
												serviceFailureCB.addItems(['Pre-departure Withdrawal', 'Withdrawal', '3 min delay', 'Deboarding'])
											else:
												serviceFailureCB.setEnabled(False)
												serviceFailureCB.clear()

										def functionalityOfServiceFailureTypeCB2(failureTypeCB, serviceFailureCB):
											failureTypeCB.currentTextChanged.connect(lambda:onChangingFailureTypeCombobox_CMImport(failureTypeCB, serviceFailureCB))

										functionalityOfServiceFailureTypeCB2(self.failureTypeCB2, self.serviceFailureEffectCombobox_ICM2)


							startDate = None
							startTime = None
							endDate = None
							endTime = None

							# Start Date
							if self.CMImportTable.item(self.CMImportTable.rowCount()-1, self.CMImportTable.columnCount()-6):
								date_string = self.CMImportTable.item(self.CMImportTable.rowCount()-1, self.CMImportTable.columnCount()-6).text()
								date_object = datetime.strptime(date_string, "%d-%m-%Y")
								startDate = QDate(date_object.year, date_object.month, date_object.day)

							elif isinstance(self.CMImportTable.cellWidget(self.CMImportTable.rowCount()-1, self.CMImportTable.columnCount()-6).layout().itemAt(0).widget(), QLineEdit):
								lineEdit = self.CMImportTable.cellWidget(self.CMImportTable.rowCount()-1, self.CMImportTable.columnCount()-6).layout().itemAt(0).widget()
								startDate_ = lineEdit.text()
								if startDate_ != '':
									startDate = QDate.fromString(startDate_, "dd-MM-yyyy")


							# Start Time
							if self.CMImportTable.item(self.CMImportTable.rowCount()-1, self.CMImportTable.columnCount()-5):
								time_string = self.CMImportTable.item(self.CMImportTable.rowCount()-1, self.CMImportTable.columnCount()-5).text()
								time_object = datetime.strptime(time_string, "%H:%M")
								startTime = QTime(time_object.hour, time_object.minute)

							elif isinstance(self.CMImportTable.cellWidget(self.CMImportTable.rowCount()-1, self.CMImportTable.columnCount()-5), QLineEdit):
								lineEdit = self.CMImportTable.cellWidget(self.CMImportTable.rowCount()-1, self.CMImportTable.columnCount()-5)
								startTime_ = lineEdit.text()
								if len(startTime_) == 5:
									startTime = QTime.fromString(time_string, "HH:mm")




							# End Date
							if self.CMImportTable.item(self.CMImportTable.rowCount()-1, self.CMImportTable.columnCount()-4):
								date_string = self.CMImportTable.item(self.CMImportTable.rowCount()-1, self.CMImportTable.columnCount()-4).text()
								date_object = datetime.strptime(date_string, "%d-%m-%Y")
								endDate = QDate(date_object.year, date_object.month, date_object.day)

							elif isinstance(self.CMImportTable.cellWidget(self.CMImportTable.rowCount()-1, self.CMImportTable.columnCount()-4).layout().itemAt(0).widget(), QLineEdit):
								lineEdit = self.CMImportTable.cellWidget(self.CMImportTable.rowCount()-1, self.CMImportTable.columnCount()-4).layout().itemAt(0).widget()
								endDate_ = lineEdit.text()
								if endDate_ != '':
									endDate = QDate.fromString(endDate_, "dd-MM-yyyy")
							

							# End Time
							if self.CMImportTable.item(self.CMImportTable.rowCount()-1, self.CMImportTable.columnCount()-3):
								time_string = self.CMImportTable.item(self.CMImportTable.rowCount()-1, self.CMImportTable.columnCount()-3).text()
								time_object = datetime.strptime(time_string, "%H:%M")
								endTime = QTime(time_object.hour, time_object.minute)

							elif isinstance(self.CMImportTable.cellWidget(self.CMImportTable.rowCount()-1, self.CMImportTable.columnCount()-3), QLineEdit):
								lineEdit = self.CMImportTable.cellWidget(self.CMImportTable.rowCount()-1, self.CMImportTable.columnCount()-3)
								startTime_ = lineEdit.text()
								if len(startTime_) == 5:
									endTime = QTime.fromString(time_string, "HH:mm")


							if startDate and startTime and endDate and endTime:
								startDateTime = QDateTime(startDate, startTime)
								endDateTime = QDateTime(endDate, endTime)

								difference_seconds = startDateTime.secsTo(endDateTime)
								minutes = int(difference_seconds/60)
								if minutes >= 0:
									self.CMImportTable.setItem(self.CMImportTable.rowCount()-1, self.CMImportTable.columnCount()-2, QTableWidgetItem(str(minutes)))
								else:
									for colInd in [self.CMImportTable.columnCount()-4, self.CMImportTable.columnCount()-6]:
										calenderWidget = QWidget()
										calenderWidget.setStyleSheet('')
										layout = QHBoxLayout()
										calenderWidget.setLayout(layout)
										calenderWidget.setFixedWidth(140)
										layout.setSpacing(0)
										layout.setContentsMargins(0, 0, 0, 0)
										# self.dateBox = QDateEdit()
										# self.dateBox.setCalendarPopup(True)
										self.createDateEditBox('dateBox')
										self.dateBox.setFixedHeight(24)
										self.dateBox.setFixedWidth(19)
										self.dateBox.setButtonSymbols(QDateEdit.NoButtons)
										
										# if self.userRole != 0:
										# 	self.dateBox.setMinimumDate(firstDateOfPreviousMonth)

										# if (self.userName == 'Ravikumar') and (self.editableOptionMaxDate > datetime.now().date()):
										# 	self.dateBox.setMinimumDate(QDate(self.startingYear, self.startingMonth, 1))


										self.dateBox.setStyleSheet("""
											QDateEdit {
											color: transparent;
											border: 1px solid transparent;
											border-radius: 0px;
											}
											QDateEdit:hover {
											border: 1px solid transparent;
											}
											QDateEdit::drop-down{
											border-bottom-right-radius: 1px;
											}
											QDateEdit::down-arrow{
											width: 24px;
											height: 24px;
											image: url('Media/calendar.png');
											}
											""")

										self.createLineEditBox('lineBoxInCalenderWidget')
										self.lineBoxInCalenderWidget.setReadOnly(True)
										self.lineBoxInCalenderWidget.setFixedHeight(24)
										self.lineBoxInCalenderWidget.setFixedWidth(110)
										self.lineBoxInCalenderWidget.setProperty("error", True)
										self.lineBoxInCalenderWidget.setStyleSheet(self.lineEditBoxQSS)
										layout.addWidget(self.lineBoxInCalenderWidget)
										layout.addWidget(self.dateBox)


										def dateChangedd(dateEdit, lineEdit):
											lineEdit.setText(str(dateEdit.date().toString("dd-MM-yyyy")))

										def dateEditFunctionInCell(dateEdit, lineEdit):

											dateEdit.dateChanged.connect(lambda: dateChangedd(dateEdit, lineEdit))

										dateEditFunctionInCell(self.dateBox, self.lineBoxInCalenderWidget)
										


										item = self.CMImportTable.takeItem(self.CMImportTable.rowCount()-1, colInd)
										del item
										self.CMImportTable.setCellWidget(self.CMImportTable.rowCount()-1, colInd, calenderWidget)
										self.missingFields_CM.append((self.CMImportTable.rowCount(), headersOfCMImportTableReal[colInd]))



									for colInd in [self.CMImportTable.columnCount()-3, self.CMImportTable.columnCount()-5]:
										TimeLineEdit = timeLineEdit()
										TimeLineEdit.setFixedHeight(28)
										TimeLineEdit.setFixedWidth(120)
										TimeLineEdit.setProperty("error", True)
										TimeLineEdit.setStyleSheet(self.lineEditBoxQSS)
										TimeLineEdit.setStyleSheet(self.lineEditBoxQSS)

										item = self.CMImportTable.takeItem(self.CMImportTable.rowCount()-1, colInd)
										del item
										self.CMImportTable.setCellWidget(self.CMImportTable.rowCount()-1, colInd, TimeLineEdit)
										self.missingFields_CM.append((self.CMImportTable.rowCount(), headersOfCMImportTableReal[colInd]))


							for row in range(self.CMImportTable.rowCount()):
								for col in range(self.CMImportTable.columnCount()):
									item = self.CMImportTable.item(row, col)
									if item:
										item.setToolTip(item.text())

							

							self.createPushButton('minusButn', '', 'Media/delete.png', 35, 'Remove')
							self.minusButn.setStyleSheet(f'''{self.pushbuttonQSS} QPushButton {{ background: transparent; }}
																	QPushButton:hover {{background: transparent;
																		}}
																		QPushButton:pressed {{
																			background: transparent;
																		}}''')
							self.minusButn.clicked.connect(self.onClickingRemoveButn)
							self.CMImportTable.setCellWidget(self.CMImportTable.rowCount()-1, self.CMImportTable.columnCount()-1, self.minusButn)
						

							if color:
								for col in range(self.CMImportTable.columnCount()):
									item = self.CMImportTable.item(self.CMImportTable.rowCount()-1, col)
									if item:
										item.setForeground(QColor(color))
						

						def onSelectingMultipleTrainsAndCars(rowData, multiTrainsSelected, multiCarsSelected):

							# print('multiTrainsSelected', rowData, multiTrainsSelected)
							if multiTrainsSelected and multiCarsSelected:
								listOfTrains = rowData.iloc[3].split(',')
								cleanedListOfTrains = [s.strip() for s in listOfTrains]
								allTrainsListLower = [item.lower() for item in self.trainsetsList]
								validListOfTrains = [item for item in cleanedListOfTrains if item.lower() in allTrainsListLower]



								listOfCars = rowData.iloc[4].split(',')
								cleanedListOfCars = [s.strip() for s in listOfCars]
								allCarsListLower = [item.lower() for item in self.carsList]
								validListOfCars = [item for item in cleanedListOfCars if item.lower() in allCarsListLower]

								numberOfTrainsSelected = len(validListOfTrains)
								numberOfCarsSelected = len(validListOfCars)

								quantity = rowData.iloc[12]
								quantityInt = 1
								try:
									quantityInt = int(quantity)
								except ValueError:
									quantityInt = 1

								if numberOfCarsSelected == 0:
									numberOfCarsSelected = 1

								totalRows = numberOfTrainsSelected * numberOfCarsSelected * quantityInt

								repeated_rows = []


								date_valid = (pd.to_datetime(rowData.iloc[28], errors='coerce') is not pd.NaT and 
												pd.to_datetime(rowData.iloc[30], errors='coerce') is not pd.NaT)

								# Check for time values separately if needed
								time_valid = isinstance(rowData.iloc[29], time) and isinstance(rowData.iloc[31], time)


								if date_valid and time_valid:
									workStartDateTime = pd.to_datetime(rowData.iloc[28].strftime('%Y-%m-%d') + ' ' + str(rowData.iloc[29]))
									workEndDateTime = pd.to_datetime(rowData.iloc[30].strftime('%Y-%m-%d') + ' ' + str(rowData.iloc[31]))

									# Calculate duration
									duration = workEndDateTime - workStartDateTime
								

									# Split duration into totalRows parts
									duration_parts = pd.to_timedelta([(duration.total_seconds() / (totalRows))*1000000000])

								# else:
								# 	workStartDateTime = ''
								# 	workEndDateTime = ''


								relFailVal = 2
								if not pd.isna(rowData.iloc[16]):
									considerForRelavantValue_ = rowData.iloc[16]
									considerForRelavantValue = considerForRelavantValue_.strip()
									if considerForRelavantValue.lower() == 'yes':
										relFailVal = 0
									elif considerForRelavantValue.lower() == 'no':
										relFailVal = 1
									else:
										relFailVal = 2


								for p in range(totalRows):
									new_row = rowData.copy()
									# new_row.iloc[3] = validListOfTrains[p]
									if date_valid and time_valid:
										new_row.iloc[28] = (workStartDateTime + p * duration_parts[0])
										new_row.iloc[29] = (workStartDateTime + p * duration_parts[0]).time()
										new_row.iloc[30] = (workStartDateTime + (p + 1) * duration_parts[0])
										new_row.iloc[31] = (workStartDateTime + (p + 1) * duration_parts[0]).time()
									else:
										new_row.iloc[28] = ''
										new_row.iloc[29] = ''
										new_row.iloc[30] = ''
										new_row.iloc[31] = ''
									

									if relFailVal == 0:
										if p == 0:
											new_row.iloc[16] = 'Yes'
										else:
											new_row.iloc[16] = 'No'

									elif relFailVal == 1:
										new_row.iloc[16] = 'No'

									else:
										pass




									repeated_rows.append(new_row.to_frame().T)

								# Concatenate the list of rows into a new DataFrame
								repeatedDF = pd.concat(repeated_rows, ignore_index=True)


								val = 0
								for j in range(numberOfCarsSelected):
									for q in range(numberOfTrainsSelected):
										for k in range(quantityInt):
											repeatedDF.iloc[val, 4] = cleanedListOfCars[j]
											val += 1


								val = 0
								for j in range(numberOfCarsSelected):
									for i in range(numberOfTrainsSelected):
										for k in range(quantityInt):
											if cleanedListOfTrains != []:
												repeatedDF.iloc[val, 3] = cleanedListOfTrains[i]
												val += 1



								for row_index, repeatedRowData in repeatedDF.iterrows():
									self.CMImportTable.insertRow(self.CMImportTable.rowCount())
									addCMRow(repeatedRowData, 'green')





							elif multiTrainsSelected:
								listOfTrains = rowData.iloc[3].split(',')
								cleanedListOfTrains = [s.strip() for s in listOfTrains]

								allTrainsListLower = [item.lower() for item in self.trainsetsList]
								validListOfTrains = [item for item in cleanedListOfTrains if item.lower() in allTrainsListLower]
								numberOfTrainsSelected = len(validListOfTrains)


								quantity = rowData.iloc[12]
								quantityInt = 1
								try:
									quantityInt = int(quantity)
								except ValueError:
									quantityInt = 1

								totalRows = numberOfTrainsSelected * quantityInt


								repeated_rows = []

								date_valid = (pd.to_datetime(rowData.iloc[28], errors='coerce') is not pd.NaT and 
												pd.to_datetime(rowData.iloc[30], errors='coerce') is not pd.NaT)

								# Check for time values separately if needed
								time_valid = isinstance(rowData.iloc[29], time) and isinstance(rowData.iloc[31], time)
								
								if date_valid and time_valid:
									workStartDateTime = pd.to_datetime(rowData.iloc[28].strftime('%Y-%m-%d') + ' ' + str(rowData.iloc[29]))
									workEndDateTime = pd.to_datetime(rowData.iloc[30].strftime('%Y-%m-%d') + ' ' + str(rowData.iloc[31]))

									# Calculate duration
									duration = workEndDateTime - workStartDateTime
									duration_parts = pd.to_timedelta([(duration.total_seconds() / (totalRows))*1000000000])

								
								

								# Split duration into len(validListOfTrains) parts
								# Create new rows for each duration part

								relFailVal = 2
								if not pd.isna(rowData.iloc[16]):
									considerForRelavantValue_ = rowData.iloc[16]
									considerForRelavantValue = considerForRelavantValue_.strip()
									if considerForRelavantValue.lower() == 'yes':
										relFailVal = 0
									elif considerForRelavantValue.lower() == 'no':
										relFailVal = 1
									else:
										relFailVal = 2

								for p in range(totalRows):
									new_row = rowData.copy()
									# new_row.iloc[3] = validListOfTrains[p]
									# print(workStartDateTime)
									if date_valid and time_valid:
										new_row.iloc[28] = (workStartDateTime + p * duration_parts[0])
										new_row.iloc[29] = (workStartDateTime + p * duration_parts[0]).time()
										new_row.iloc[30] = (workStartDateTime + (p + 1) * duration_parts[0])
										new_row.iloc[31] = (workStartDateTime + (p + 1) * duration_parts[0]).time()

									else:
										new_row.iloc[28] = ''
										new_row.iloc[29] = ''
										new_row.iloc[30] = ''
										new_row.iloc[31] = ''

									if relFailVal == 0:
										if p == 0:
											new_row.iloc[16] = 'Yes'
										else:
											new_row.iloc[16] = 'No'

									elif relFailVal == 1:
										new_row.iloc[16] = 'No'

									else:
										pass

									repeated_rows.append(new_row.to_frame().T)


								# Concatenate the list of rows into a new DataFrame
								repeatedDF = pd.concat(repeated_rows, ignore_index=True)


								val = 0
								for i in range(numberOfTrainsSelected):
									for j in range(quantityInt):
										if cleanedListOfTrains != []:
											repeatedDF.iloc[val, 3] = cleanedListOfTrains[i]
											val += 1

								for row_index, repeatedRowData in repeatedDF.iterrows():
									self.CMImportTable.insertRow(self.CMImportTable.rowCount())
									addCMRow(repeatedRowData, 'green')




							elif multiCarsSelected:
								listOfCars = rowData.iloc[4].split(',')
								cleanedListOfCars = [s.strip() for s in listOfCars]


								allCarsListLower = [item.lower() for item in self.carsList]
								validListOfCars = [item for item in cleanedListOfCars if item.lower() in allCarsListLower]

								numberOfCarsSelected = len(validListOfCars)


								quantity = rowData.iloc[12]
								quantityInt = 1
								try:
									quantityInt = int(quantity)
								except ValueError:
									quantityInt = 1

								totalRows = numberOfCarsSelected * quantityInt


								repeated_rows = []

								date_valid = (pd.to_datetime(rowData.iloc[28], errors='coerce') is not pd.NaT and 
												pd.to_datetime(rowData.iloc[30], errors='coerce') is not pd.NaT)

								# Check for time values separately if needed
								time_valid = isinstance(rowData.iloc[29], time) and isinstance(rowData.iloc[31], time)

								
								if date_valid and time_valid:
									workStartDateTime = pd.to_datetime(rowData.iloc[28].strftime('%Y-%m-%d') + ' ' + str(rowData.iloc[29]))
									workEndDateTime = pd.to_datetime(rowData.iloc[30].strftime('%Y-%m-%d') + ' ' + str(rowData.iloc[31]))

									# Calculate duration
									duration = workEndDateTime - workStartDateTime
								
									# Split duration into len(validListOfCars) parts
									duration_parts = pd.to_timedelta([(duration.total_seconds() / (totalRows))*1000000000])
								


								# Create new rows for each duration part
								relFailVal = 2
								if not pd.isna(rowData.iloc[16]):
									considerForRelavantValue_ = rowData.iloc[16]
									considerForRelavantValue = considerForRelavantValue_.strip()
									if considerForRelavantValue.lower() == 'yes':
										relFailVal = 0
									elif considerForRelavantValue.lower() == 'no':
										relFailVal = 1
									else:
										relFailVal = 2

								for p in range(totalRows):
									new_row = rowData.copy()
									# new_row.iloc[4] = validListOfCars[p]
									if date_valid and time_valid:
										new_row.iloc[28] = (workStartDateTime + p * duration_parts[0])
										new_row.iloc[29] = (workStartDateTime + p * duration_parts[0]).time()
										new_row.iloc[30] = (workStartDateTime + (p + 1) * duration_parts[0])
										new_row.iloc[31] = (workStartDateTime + (p + 1) * duration_parts[0]).time()

									else:
										new_row.iloc[28] = ''
										new_row.iloc[29] = ''
										new_row.iloc[30] = ''
										new_row.iloc[31] = ''

									if relFailVal == 0:
										if p == 0:
											new_row.iloc[16] = 'Yes'
										else:
											new_row.iloc[16] = 'No'

									elif relFailVal == 1:
										new_row.iloc[16] = 'No'

									else:
										pass

									repeated_rows.append(new_row.to_frame().T)

								# Concatenate the list of rows into a new DataFrame
								repeatedDF = pd.concat(repeated_rows, ignore_index=True)


								val = 0
								for i in range(quantityInt):
									for j in range(numberOfCarsSelected):
										if cleanedListOfCars != []:
											repeatedDF.iloc[val, 4] = cleanedListOfCars[j]
											val += 1


								for row_index, repeatedRowData in repeatedDF.iterrows():
									self.CMImportTable.insertRow(self.CMImportTable.rowCount())
									addCMRow(repeatedRowData, 'green')




						
							# self.CMImportTable.insertRow(self.CMImportTable.rowCount())


						self.missingFields_CM = []
						for row_index, rowData in dataf_.iterrows():

							multiTrainsSelected = False
							multiCarsSelected = False
							if not pd.isna(rowData.iloc[3]):
								if ',' in rowData.iloc[3]:
									multiTrainsSelected = True
							if not pd.isna(rowData.iloc[4]):
								if ',' in rowData.iloc[4]:
									multiCarsSelected = True


							if multiTrainsSelected or multiCarsSelected:
								onSelectingMultipleTrainsAndCars(rowData, multiTrainsSelected, multiCarsSelected)
								continue

							else:
								repeated_rows = []

								# if (pd.to_datetime(rowData.iloc[28], errors='coerce') is not pd.NaT) and (pd.to_datetime(rowData.iloc[29], errors='coerce') is not pd.NaT) and (pd.to_datetime(rowData.iloc[30], errors='coerce') is not pd.NaT) and (pd.to_datetime(rowData.iloc[31], errors='coerce') is not pd.NaT):
								# 	print('hello')
								# if rowData.iloc[28] and rowData.iloc[29] and rowData.iloc[30] and rowData.iloc[31]:

								date_valid = (pd.to_datetime(rowData.iloc[28], errors='coerce') is not pd.NaT and 
												pd.to_datetime(rowData.iloc[30], errors='coerce') is not pd.NaT)

								# Check for time values separately if needed
								time_valid = isinstance(rowData.iloc[29], time) and isinstance(rowData.iloc[31], time)


								if date_valid and time_valid:
									workStartDateTime = pd.to_datetime(rowData.iloc[28].strftime('%Y-%m-%d') + ' ' + str(rowData.iloc[29]))
									workEndDateTime = pd.to_datetime(rowData.iloc[30].strftime('%Y-%m-%d') + ' ' + str(rowData.iloc[31]))

									# Calculate duration
									duration = workEndDateTime - workStartDateTime
									
									quantity = rowData.iloc[12]
									quantityInt = 1
									try:
										quantityInt = int(quantity)
									except ValueError:
										quantityInt = 1

									totalRows = quantityInt


									# Split duration into len(validListOfCars) parts
									duration_parts = pd.to_timedelta([(duration.total_seconds() / (totalRows))*1000000000])
									# Create new rows for each duration part
									for i in range(totalRows):
										new_row = rowData.copy()
										# new_row.iloc[4] = validListOfCars[i]
										new_row.iloc[28] = (workStartDateTime + i * duration_parts[0])
										new_row.iloc[29] = (workStartDateTime + i * duration_parts[0]).time()
										new_row.iloc[30] = (workStartDateTime + (i + 1) * duration_parts[0])
										new_row.iloc[31] = (workStartDateTime + (i + 1) * duration_parts[0]).time()
										repeated_rows.append(new_row.to_frame().T)

									# Concatenate the list of rows into a new DataFrame
									repeatedDF = pd.concat(repeated_rows, ignore_index=True)
									# addCMRow(rowData)


									for row_index, repeatedRowData in repeatedDF.iterrows():
										self.CMImportTable.insertRow(self.CMImportTable.rowCount())
										if totalRows == 1:
											addCMRow(repeatedRowData)

										if totalRows > 1:
											addCMRow(repeatedRowData, 'green')
								else:
									repeated_rows = []
									workStartDateTime = ''
									workEndDateTime = ''

									# Calculate duration
									# duration = workEndDateTime - workStartDateTime
									
									quantity = rowData.iloc[12]
									quantityInt = 1
									try:
										quantityInt = int(quantity)
									except ValueError:
										quantityInt = 1

									totalRows = quantityInt


									# Split duration into len(validListOfCars) parts
									# duration_parts = pd.to_timedelta([(duration.total_seconds() / (totalRows))*1000000000])
									# Create new rows for each duration part
									for i in range(totalRows):
										new_row = rowData.copy()
										# new_row.iloc[4] = validListOfCars[i]
										new_row.iloc[28] = workStartDateTime
										new_row.iloc[29] = workStartDateTime
										new_row.iloc[30] = workStartDateTime
										new_row.iloc[31] = workStartDateTime
										repeated_rows.append(new_row.to_frame().T)

									# Concatenate the list of rows into a new DataFrame
									repeatedDF = pd.concat(repeated_rows, ignore_index=True)
									# addCMRow(rowData)


									for row_index, repeatedRowData in repeatedDF.iterrows():
										self.CMImportTable.insertRow(self.CMImportTable.rowCount())
										if totalRows == 1:
											addCMRow(repeatedRowData)

										if totalRows > 1:
											addCMRow(repeatedRowData, 'green')
										




						for ro in range(self.CMImportTable.rowCount()):
							for co in range(self.CMImportTable.columnCount()):
								item = self.CMImportTable.item(ro, co)
								if item is not None:
									item.setTextAlignment(Qt.AlignCenter)



						if len(self.missingFields_CM) > 0:

							for index, field in enumerate(self.missingFields_CM):
								missingFieldsGridLayout_CM.addWidget(QLabel(str(field[0])), index, 0)
								missingFieldsGridLayout_CM.addWidget(QLabel(str(field[1])), index, 1)
							missingFieldsGridLayout_CM.addItem(QSpacerItem(1, 1, QSizePolicy.Fixed, QSizePolicy.Expanding), len(self.missingFields_CM), 0)
							
							scrollForMissingFields.show()
						else:
							scrollForMissingFields.hide()
							


				self.submitImportedExcelData.clicked.connect(mapData)


				self.createPushButton('cancelImportedExcelData', 'CANCEL', width=int(0.050 * QApplication.primaryScreen().availableGeometry().width()))
				self.cancelImportedExcelData.setFixedHeight(30)
				self.cancelImportedExcelData.clicked.connect(lambda: self.excelAndTableColumnsMappingWindow.close())


				submitAndCancelBtnOfExcelImportWindow = QHBoxLayout()
				submitAndCancelBtnOfExcelImportWindow.addWidget(self.submitImportedExcelData, alignment=Qt.AlignRight)
				submitAndCancelBtnOfExcelImportWindow.addWidget(self.cancelImportedExcelData, alignment=Qt.AlignLeft)


				VLayoutForColumnsMappingWindow.addLayout(submitAndCancelBtnOfExcelImportWindow)


				self.excelAndTableColumnsMappingWindow.setLayout(VLayoutForColumnsMappingWindow)

				
				self.excelAndTableColumnsMappingWindow.show()

			else:
				pass


			# self.mapImportedDataToWidgets(self.CMImportGridLayout, self.plusBtnOfCMImport, headersOfCMImportTable[:-2])


		self.importIconButton_CMImport.clicked.connect(importCMDataFromExceltoTable)

		

		self.CMImportWindow.show()


	# Create a QPushButton for toggling the form visibility
	self.openCMtableButton.clicked.connect(openCMTableWindow)




	def onClickingSubmit_CM():
		
		mandatoryVerification_CM = True
		mandatoryIndexes = [0, 1, 2, 3, 9, 10, 11, 12, 15, 17, 23, 24, 25, 26, 27, 30, 32]
		# mandatoryIndexes = [0, 1, 2, 3, 9, 10, 12, 13, 15, 17, 19, 26, 27, 28, 29, 30]

		trainMultiSelected = False
		carMultiSelected = False

		row = []
		CM_id = 'CM' + '_' + datetime.now().strftime("%Y%m%d%H%M%S%f")[:-4]
		row.append(CM_id)

		for i, wid in enumerate(self.listOfWidgets_CM):
			if isinstance(wid, QDateEdit):
				if isinstance(self.listOfWidgets_CM[i+1], QTimeEdit):
					datetime_ = QDateTime(wid.date(), self.listOfWidgets_CM[i+1].time())
					row.append(datetime_.toPython())

			elif isinstance(wid, QComboBox):
				if wid.isEnabled():
					if wid.currentText() == '':
						row.append(None)

						if i in mandatoryIndexes:
							mandatoryVerification_CM = False
							wid.setProperty("error", True)
							wid.setStyleSheet(self.comboBoxQSS)

					else:
						if i == 3:
							row.append(wid.currentText())
							wid.setProperty("error", False)
							wid.setStyleSheet(self.comboBoxQSS)

							if ', ' in wid.currentText():
								trainMultiSelected = True

						elif i == 4:
							row.append(wid.currentText())
							wid.setProperty("error", False)
							wid.setStyleSheet(self.comboBoxQSS)

							if ', ' in wid.currentText():
								carMultiSelected = True


						elif i == 9:
							query = "SELECT id FROM bom WHERE equipment = %s AND parent_id = 0"
							self.cursor.execute(query, (wid.currentText(),))
							result = self.cursor.fetchone()
							row.append(result[0])
							wid.setProperty("error", False)
							wid.setStyleSheet(self.comboBoxQSS)
							
						elif i == 10:
							query = "SELECT id FROM bom WHERE parent_id = (SELECT id FROM bom WHERE equipment = %s AND parent_id = 0) AND equipment = %s"
							self.cursor.execute(query, (self.listOfWidgets_CM[9].currentText(), wid.currentText()))
							result = self.cursor.fetchone()
							row.append(result[0])
							wid.setProperty("error", False)
							wid.setStyleSheet(self.comboBoxQSS)

						else:
							row.append(wid.currentText())
							wid.setProperty("error", False)
							wid.setStyleSheet(self.comboBoxQSS)
				else:
					row.append(None)

			elif isinstance(wid, QLineEdit):
				if wid.isEnabled():
					if wid.text() == '':
						row.append(None)
						if i in mandatoryIndexes:
							mandatoryVerification_CM = False
							wid.setProperty("error", True)
							wid.setStyleSheet(self.lineEditBoxQSS)

					else:
						if i == 32:
							if int(wid.text()) == 0:
								mandatoryVerification_CM = False
								wid.setProperty("error", True)
								wid.setStyleSheet(self.lineEditBoxQSS)
							else:
								wid.setProperty("error", False)
								wid.setStyleSheet(self.lineEditBoxQSS)
								row.append(int(wid.text()))

						else:
							row.append(wid.text())

			elif isinstance(wid, QTextEdit):
				if wid.toPlainText() == '':
					row.append(None)
					if i in mandatoryIndexes:
						mandatoryVerification_CM = False
						wid.setProperty("error", True)
						wid.setStyleSheet(self.textEditBoxQSS)
				else:
					row.append(wid.toPlainText())
					wid.setProperty("error", False)
					wid.setStyleSheet(self.textEditBoxQSS)

			elif isinstance(wid, QLabel):
				row.append(int(wid.text()))

		# mandatoryVerification_CM = False

		if not mandatoryVerification_CM:
			pass

		else:
			# insert_query = """
			# 	INSERT INTO corrective_maintenance (
			# 	cm_id, event_datetime, depot, trainset_id, car_no, jobcard_no, issued_to, ml_depot, location,
			# 	system_id, subsystem_id, fault_details, failure_type, service_failure_effect,
			# 	action_taken_at_mainline, action_taken_at_depot, failure_category, failure_responsibility,
			# 	equipment, component, lowest_level_component, ncr_no, component_replaced, verification, work_start_at, work_end_at, down_time, user_id
			# 	) SELECT
			# 		%s, %s, %s, trainsets.id, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s
			# 	FROM
			# 		trainsets
			# 	WHERE
			# 		trainsets.trainset = %s
			# """


			# row.append(self.user_id)
			# trainset = row.pop(3)
			# row.append(trainset)
			# self.cursor.execute(insert_query, tuple(row))
			# self.mydb.commit()

			# self.cmDataTable.setRowCount(self.cmDataTable.rowCount()+1)

			# new_data = [row[1], row[2], self.trainComboBox_CMTab.currentText(), self.systemComboBox_CMTab.currentText(), self.subSystemComboBox_CMTab.currentText(), self.failureType__CMTab.currentText(), self.serviceFailureEffect__CMTab.currentText(), self.failureResponsibility__CMTab.currentText(), self.jobcardNo_CMTab.text(), self.NCR_CM.text(), self.issuedTo_CMTab.text(), row[-5], row[-4], self.downTime_CMTab.text()]
			# button = QPushButton(str(row[0]))
			# button.setStyleSheet("QPushButton { text-decoration: none; }"
			# 	"QPushButton:hover { text-decoration: underline; }")
			# button.setCursor(Qt.PointingHandCursor)
			# self.cmDataTable.setCellWidget(self.cmDataTable.rowCount()-1, 0, button)
			# button.clicked.connect(lambda : onButtonClicked_cmData(self, button.text()))


			# for col, value in enumerate(new_data):
			# 	if value != None:
			# 		if isinstance(value, datetime):
			# 			formatted_datetime = value.strftime('%Y-%m-%d %H:%M')
			# 			item = QTableWidgetItem(formatted_datetime)
			# 			item.setTextAlignment(Qt.AlignCenter)
			# 		else:
			# 			item = QTableWidgetItem(str(value))
			# 			item.setTextAlignment(Qt.AlignCenter)
			# 	else:
			# 		item = QTableWidgetItem('')
			# 		item.setTextAlignment(Qt.AlignCenter)
			# 	self.cmDataTable.setItem(self.cmDataTable.rowCount()-1, col+1, item)

			# cmMsgBox = QMessageBox()
			# cmMsgBox.setIcon(QMessageBox.Information) 
			# cmMsgBox.setText(f'Data submitted successfully.\nID:{CM_id}')
			# cmMsgBox.setWindowTitle("Message")
			# cmMsgBox.setWindowIcon(QIcon('Media/ramsify.png'))
			# cmMsgBox.setStandardButtons(QMessageBox.Ok)
			# cmMsgBox.exec_()

			# ## To clear the fields once after the submission:
			# onClickingCancel_CM()


			from PySide6.QtWidgets import QApplication

			self.CorrectiveMaintenanceConfirmationWindow = QWidget()
			self.CorrectiveMaintenanceConfirmationWindow.move(150, 150)
			self.CorrectiveMaintenanceConfirmationWindow.resize(1700, 600)
			self.CorrectiveMaintenanceConfirmationWindow.setWindowTitle("Confirm CM Data")
			self.CorrectiveMaintenanceConfirmationWindow.setWindowIcon(QIcon('Media/ramsify.png'))

			CmConfirmationWindowLayout = QVBoxLayout()

			self.CorrectiveMaintenanceDataTable = TableWidget()
			headers = ['Event Date', 'Event Time', 'Depot', 'Trainset', 'Car Number', 'Jobcard No' ,'Issued To', 'ML/Depot', 'Location',
					'System', 'Sub-System', 'Other Sub-System', 'Fault Details', 'Failure Type', 'Service Failure Effect', 'Consider for Relevant Fails?', 'Action Taken At Mainline', 'Action Taken At Depot', 'Failure Category',
					'Failure Responsibility', 'Equipment', 'Component', 'Lowest Level Component', 'NCR No', 'Is Component Replaced?', 'Replaced Component', 'Verification', 'Attachments',
					'Workstart Date', 'Workstart Time', 'Workend Date', 'Workend Time', 'Downtime(Mins)']
			self.CorrectiveMaintenanceDataTable.setColumnCount(len(headers))
			# self.CorrectiveMaintenanceDataTable.setRowCount(1)
			self.CorrectiveMaintenanceDataTable.setHorizontalHeaderLabels(headers)
			self.CorrectiveMaintenanceDataTable.setStyleSheet(self.tableWidgetQSS)
			self.CorrectiveMaintenanceDataTable.horizontalHeader().setStyleSheet(self.headerHorizontalQSS)
			# # self.cmDataTable.verticalHeader().setStyleSheet(self.headerVerticalQSS)
			self.CorrectiveMaintenanceDataTable.setAlternatingRowColors(True)
			self.CorrectiveMaintenanceDataTable.setShowGrid(False)
			CmConfirmationWindowLayout.addWidget(self.CorrectiveMaintenanceDataTable)
			
			self.CorrectiveMaintenanceConfirmationWindow.setLayout(CmConfirmationWindowLayout)

			self.CorrectiveMaintenanceDataTable.setColumnWidth(0, int(0.07 * QApplication.primaryScreen().availableGeometry().width()))
			self.CorrectiveMaintenanceDataTable.setColumnWidth(1, int(0.06 * QApplication.primaryScreen().availableGeometry().width()))
			self.CorrectiveMaintenanceDataTable.setColumnWidth(2, int(0.07 * QApplication.primaryScreen().availableGeometry().width()))
			self.CorrectiveMaintenanceDataTable.setColumnWidth(3, int(0.07 * QApplication.primaryScreen().availableGeometry().width()))
			self.CorrectiveMaintenanceDataTable.setColumnWidth(4, int(0.1 * QApplication.primaryScreen().availableGeometry().width()))
			self.CorrectiveMaintenanceDataTable.setColumnWidth(5, int(0.08 * QApplication.primaryScreen().availableGeometry().width()))
			self.CorrectiveMaintenanceDataTable.setColumnWidth(6, int(0.08 * QApplication.primaryScreen().availableGeometry().width()))
			self.CorrectiveMaintenanceDataTable.setColumnWidth(7, int(0.07 * QApplication.primaryScreen().availableGeometry().width()))
			self.CorrectiveMaintenanceDataTable.setColumnWidth(8, int(0.07 * QApplication.primaryScreen().availableGeometry().width()))
			self.CorrectiveMaintenanceDataTable.setColumnWidth(9, int(0.15 * QApplication.primaryScreen().availableGeometry().width()))
			self.CorrectiveMaintenanceDataTable.setColumnWidth(10, int(0.15 * QApplication.primaryScreen().availableGeometry().width()))
			self.CorrectiveMaintenanceDataTable.setColumnWidth(11, int(0.1 * QApplication.primaryScreen().availableGeometry().width()))
			self.CorrectiveMaintenanceDataTable.setColumnWidth(12, int(0.12 * QApplication.primaryScreen().availableGeometry().width()))
			self.CorrectiveMaintenanceDataTable.setColumnWidth(13, int(0.12 * QApplication.primaryScreen().availableGeometry().width()))
			self.CorrectiveMaintenanceDataTable.setColumnWidth(14, int(0.1 * QApplication.primaryScreen().availableGeometry().width()))
			self.CorrectiveMaintenanceDataTable.setColumnWidth(15, int(0.14 * QApplication.primaryScreen().availableGeometry().width()))
			self.CorrectiveMaintenanceDataTable.setColumnWidth(16, int(0.12 * QApplication.primaryScreen().availableGeometry().width()))
			self.CorrectiveMaintenanceDataTable.setColumnWidth(17, int(0.12 * QApplication.primaryScreen().availableGeometry().width()))
			self.CorrectiveMaintenanceDataTable.setColumnWidth(18, int(0.15 * QApplication.primaryScreen().availableGeometry().width()))
			self.CorrectiveMaintenanceDataTable.setColumnWidth(19, int(0.11 * QApplication.primaryScreen().availableGeometry().width()))
			self.CorrectiveMaintenanceDataTable.setColumnWidth(20, int(0.1 * QApplication.primaryScreen().availableGeometry().width()))
			self.CorrectiveMaintenanceDataTable.setColumnWidth(21, int(0.1 * QApplication.primaryScreen().availableGeometry().width()))
			self.CorrectiveMaintenanceDataTable.setColumnWidth(22, int(0.12 * QApplication.primaryScreen().availableGeometry().width()))
			self.CorrectiveMaintenanceDataTable.setColumnWidth(23, int(0.14 * QApplication.primaryScreen().availableGeometry().width()))
			self.CorrectiveMaintenanceDataTable.setColumnWidth(24, int(0.15 * QApplication.primaryScreen().availableGeometry().width()))
			self.CorrectiveMaintenanceDataTable.setColumnWidth(25, int(0.12 * QApplication.primaryScreen().availableGeometry().width()))
			self.CorrectiveMaintenanceDataTable.setColumnWidth(26, int(0.07 * QApplication.primaryScreen().availableGeometry().width()))
			self.CorrectiveMaintenanceDataTable.setColumnWidth(27, int(0.08 * QApplication.primaryScreen().availableGeometry().width()))

			self.CorrectiveMaintenanceDataTable.setColumnWidth(28, int(0.08 * QApplication.primaryScreen().availableGeometry().width()))
			self.CorrectiveMaintenanceDataTable.setColumnWidth(29, int(0.08 * QApplication.primaryScreen().availableGeometry().width()))
			self.CorrectiveMaintenanceDataTable.setColumnWidth(30, int(0.08 * QApplication.primaryScreen().availableGeometry().width()))
			self.CorrectiveMaintenanceDataTable.setColumnWidth(31, int(0.08 * QApplication.primaryScreen().availableGeometry().width()))
			self.CorrectiveMaintenanceDataTable.setColumnWidth(32, int(0.1 * QApplication.primaryScreen().availableGeometry().width()))

			numberOfTrainsSelected = 1
			numberOfCarsSelected = 1
			quantity = int(self.quantity_CMTab.text())

			if ',' in row[3]:
				selectedListOfTrains = row[3].split(',')
				cleanedListOfSelectedTrains = [s.strip() for s in selectedListOfTrains]
				numberOfTrainsSelected = len(cleanedListOfSelectedTrains)
			else:
				cleanedListOfSelectedTrains = [row[3]]
				numberOfTrainsSelected = len(cleanedListOfSelectedTrains)


			if row[4]:
				if ',' in row[4]:
					selectedListOfCars = row[4].split(',')
					cleanedListOfSelectedCars = [s.strip() for s in selectedListOfCars]
					numberOfCarsSelected = len(cleanedListOfSelectedCars)
				else:
					cleanedListOfSelectedCars = [row[4]]
					numberOfCarsSelected = len(cleanedListOfSelectedCars)


			else:
				cleanedListOfSelectedCars = []
				numberOfCarsSelected = 1



			

			totalRows = numberOfTrainsSelected * numberOfCarsSelected * quantity
			self.CorrectiveMaintenanceDataTable.setRowCount(totalRows)



			workStartDateValue = self.workStartDate_CMTab.date()
			workStartTimeValue = self.workStartTime_CMTab.time()
			workStartDateTimeObject = QDateTime(workStartDateValue, workStartTimeValue)

			workEndDateValue = self.workEndDate_CMTab.date()
			workEndTimeValue = self.workEndTime_CMTab.time()
			workEndDateTimeObject = QDateTime(workEndDateValue, workEndTimeValue)


			workDuration = workStartDateTimeObject.secsTo(workEndDateTimeObject)

			eachRowWorkDuration = int(workDuration/totalRows)



			# def addCMRow_():
			for f in range(totalRows):
				self.createDateEditBox('eventDateEdit_ICM_')
				currentYear = datetime.now().year
				currentMonth = datetime.now().month

				firstDayOfCurrentMonth_ = datetime(currentYear, currentMonth, 1).date()
				lastDateOfPreviousMonth_ = (firstDayOfCurrentMonth_ - relativedelta(days=1))

				firstDateOfPreviousMonth_ = QDate(lastDateOfPreviousMonth_.year, lastDateOfPreviousMonth_.month, 1)
				
				if firstDateOfPreviousMonth_ < QDate(self.startingYear, self.startingMonth, 1):
					firstDateOfPreviousMonth_ = QDate(self.startingYear, self.startingMonth, 1)

				# if self.userRole != 0:
				# 	self.eventDateEdit_ICM_.setMinimumDate(firstDateOfPreviousMonth_)

				# if (self.userName == 'Ravikumar') and (self.editableOptionMaxDate_ > datetime.now().date()):
				# 	self.eventDateEdit_ICM_.setMinimumDate(QDate(self.startingYear, self.startingMonth, 1))

				self.CorrectiveMaintenanceDataTable.setCellWidget(f, 0 ,self.eventDateEdit_ICM_)
				self.eventDateEdit_ICM_.setFixedWidth(int(0.07 * QApplication.primaryScreen().availableGeometry().width()))

				date_edit_widget = hLayoutForEventDateTime_CMTab.itemAt(0).widget()
				# event_date = date_edit_widget.date().toString(Qt.ISODate)
				self.eventDateEdit_ICM_.setDate(date_edit_widget.date())


				## event time label and timeedit widget:
				self.createTimeEditBox('eventTimeEdit_ICM_')
				self.CorrectiveMaintenanceDataTable.setCellWidget(f, 1, self.eventTimeEdit_ICM_)
				
				time_edit_widget = hLayoutForEventDateTime_CMTab.itemAt(1).widget()
				# event_time = time_edit_widget.time().toString(Qt.ISODate)
				self.eventTimeEdit_ICM_.setTime(time_edit_widget.time())

				self.eventTimeEdit_ICM_.setFixedWidth(int(0.05 * QApplication.primaryScreen().availableGeometry().width()))
				

				## Depot name and label combobox:
				self.createComboBox(self.depotsList, 'depotNameCombobox_ICM_')
				self.CorrectiveMaintenanceDataTable.setCellWidget(f, 2, self.depotNameCombobox_ICM_ )
				self.depotNameCombobox_ICM_.setFixedWidth(int(0.07 * QApplication.primaryScreen().availableGeometry().width()))			
			

				## trainset name label and combobox widget:
				self.createComboBox([], 'trainsetCombobox_ICM_')
				self.CorrectiveMaintenanceDataTable.setCellWidget(f, 3, self.trainsetCombobox_ICM_)


				self.trainsetCombobox_ICM_.setEnabled(False)
				self.trainsetCombobox_ICM_.setFixedWidth(int(0.07 * QApplication.primaryScreen().availableGeometry().width()))

				## Function to dynamically update the trainset combobox based on the depo selection:
				def onChangingDepotCombobox_CMImport_(depotCB_, trainsetCB_):
					trainsetCB_.setEnabled(True)
					trainsetCB_.clear()
					if depotCB_.currentText() != '':
						trainsetCB_.addItems(self.depotTrainDictionary[depotCB_.currentText()])
					else:
						trainsetCB_.setEnabled(False)

				def functionalityOfDepoTrainCB_ICM_(depotCB_, trainsetCB_):
					depotCB_.currentTextChanged.connect(lambda:onChangingDepotCombobox_CMImport_(depotCB_, trainsetCB_))

				functionalityOfDepoTrainCB_ICM_(self.depotNameCombobox_ICM_, self.trainsetCombobox_ICM_)

				depot_data = self.depotComboBox_CMTab.currentText()  
				self.depotNameCombobox_ICM_.setCurrentText(depot_data)

				# trainset_data = self.trainComboBox_CMTab.currentText()
				# totalRows/numberOfTrainsSelected
				# self.trainsetCombobox_ICM_.setCurrentText(trainset_data)


				## car number label and combobox widget:
				self.createComboBox(self.carsList, 'carNumberCombobox_ICM_')
				self.CorrectiveMaintenanceDataTable.setCellWidget(f, 4, self.carNumberCombobox_ICM_)			
				car_data = self.carComboBox_CMTab.currentText()  
				self.carNumberCombobox_ICM_.setCurrentText(car_data)			
				# self.carNumberCombobox_ICM_.setFixedWidth(int(0.07 * QApplication.primaryScreen().availableGeometry().width()))
			
			
				## JC number line edit:
				self.createLineEditBox('jobCardNumberLineEdit_ICM_')
				self.CorrectiveMaintenanceDataTable.setCellWidget(f, 5, self.jobCardNumberLineEdit_ICM_)

				def onJCNumberTextChanged_ICM_(JCNumberLineEdit_):
					JCNumberLineEdit_.setToolTip(JCNumberLineEdit_.text())

				def setToolTipsOfJCN_ICM_(JCNumberLineEdit_):
					JCNumberLineEdit_.textChanged.connect(lambda:onJCNumberTextChanged_ICM_(JCNumberLineEdit_))

				setToolTipsOfJCN_ICM_(self.jobCardNumberLineEdit_ICM_)

				jobcard_data = self.jobcardNo_CMTab.text()
				self.jobCardNumberLineEdit_ICM_.setText(jobcard_data)
				# self.jobCardNumberLineEdit_ICM_.setFixedWidth(int(0.07 * QApplication.primaryScreen().availableGeometry().width()))

				## Issued to line edit:
				self.createLineEditBox('issuedToLineEdit_ICM_')
				self.CorrectiveMaintenanceDataTable.setCellWidget(f, 6, self.issuedToLineEdit_ICM_)

				def onIssuedToTextChanged_ICM_(IssuedToLineEdit_):
					IssuedToLineEdit_.setToolTip(IssuedToLineEdit_.text())

				def setToolTipsOfIssuedTo_ICM_(IssuedToLineEdit_):
					IssuedToLineEdit_.textChanged.connect(lambda:onIssuedToTextChanged_ICM_(IssuedToLineEdit_))

				setToolTipsOfIssuedTo_ICM_(self.issuedToLineEdit_ICM_)

				issued_data = self.issuedTo_CMTab.text()
				self.issuedToLineEdit_ICM_.setText(issued_data)
				# self.issuedToLineEdit_ICM_.setFixedWidth(int(0.07 * QApplication.primaryScreen().availableGeometry().width()))


				## main line/depot combobox widget:
				self.createComboBox(['M/L', 'Depot'], 'mainLineDepot_ICM_')
				self.CorrectiveMaintenanceDataTable.setCellWidget(f, 7, self.mainLineDepot_ICM_)
				mainlinedepot_data = self.reapairAt_CMTab.currentText()  
				self.mainLineDepot_ICM_.setCurrentText(mainlinedepot_data)	

				self.mainLineDepot_ICM_.setFixedWidth(int(0.07 * QApplication.primaryScreen().availableGeometry().width()))



				## location to line edit:
				self.createLineEditBox('locationLineEdit_ICM_')
				self.CorrectiveMaintenanceDataTable.setCellWidget(f, 8, self.locationLineEdit_ICM_)

				def onFDTextChanged_ICM_(LocationLineEdit_):
					LocationLineEdit_.setToolTip(LocationLineEdit_.text())

				def setToolTipsOfLocation_ICM_(LocationLineEdit_):
					LocationLineEdit_.textChanged.connect(lambda:onFDTextChanged_ICM_(LocationLineEdit_))

				setToolTipsOfLocation_ICM_(self.locationLineEdit_ICM_)

				location_data = self.locationLineEdit_CMTab.text()
				self.locationLineEdit_ICM_.setText(location_data)
				# self.locationLineEdit_ICM_.setFixedWidth(int(0.07 * QApplication.primaryScreen().availableGeometry().width()))


				## system type label and combobox widget:
				self.createComboBox(self.BOMSystemDictionary.keys(),'systemCombobox_ICM_')
				self.CorrectiveMaintenanceDataTable.setCellWidget(f, 9, self.systemCombobox_ICM_)			
				self.systemCombobox_ICM_.setFixedWidth(int(0.15 * QApplication.primaryScreen().availableGeometry().width()))


				## sub-system type label and combobox widget:
				self.createComboBox([],'subSystemCombobox_ICM_')
				self.CorrectiveMaintenanceDataTable.setCellWidget(f, 10, self.subSystemCombobox_ICM_)
				self.subSystemCombobox_ICM_.setEnabled(False)
				self.subSystemCombobox_ICM_.setFixedWidth(int(0.15 * QApplication.primaryScreen().availableGeometry().width()))

				def onChangingSysCombobox_CMImport_(sysCMCB_, subSysCMCB_):
					subSysCMCB_.setEnabled(True)
					subSysCMCB_.clear()
					if sysCMCB_.currentText() != '':
						subSysCMCB_.addItems(self.BOMSystemDictionary[sysCMCB_.currentText()])
					else:
						subSysCMCB_.setEnabled(False)

				def functionalityOfSystemSubsysCB_CMI_(sysCMCB_, subSysCMCB_):
					sysCMCB_.currentTextChanged.connect(lambda:onChangingSysCombobox_CMImport_(sysCMCB_, subSysCMCB_))

				functionalityOfSystemSubsysCB_CMI_(self.systemCombobox_ICM_, self.subSystemCombobox_ICM_)







				system_data = self.systemComboBox_CMTab.currentText()  
				self.systemCombobox_ICM_.setCurrentText(system_data)

				subsystem_data = self.subSystemComboBox_CMTab.currentText()
				self.subSystemCombobox_ICM_.setCurrentText(subsystem_data)


				self.createLineEditBox('otherSubSystem_ICM_')
				self.CorrectiveMaintenanceDataTable.setCellWidget(f, 11, self.otherSubSystem_ICM_)
				otherSubsystemValue = self.otherSubSystemLineEdit_CMTab.text()

				def onFaultDetailDTextChanged_ICM_(otherSubSystemLineEdit_):
					otherSubSystemLineEdit_.setToolTip(otherSubSystemLineEdit_.text())

				def setToolTipsOfFDetails_ICM_(otherSubSystemLineEdit_):
					otherSubSystemLineEdit_.textChanged.connect(lambda:onFaultDetailDTextChanged_ICM_(otherSubSystemLineEdit_))

				setToolTipsOfFDetails_ICM_(self.otherSubSystem_ICM_)

				self.otherSubSystem_ICM_.setText(otherSubsystemValue)
				# self.otherSubSystem_ICM_.setFixedWidth(int(0.07 * QApplication.primaryScreen().availableGeometry().width()))



				def onChangingSubSysCombobox_CMImport_(subSysCMCB_, otherSubsystemBox):
					if subSysCMCB_.currentText() == 'Others':
						otherSubsystemBox.setEnabled(True)
					else:
						otherSubsystemBox.clear()
						otherSubsystemBox.setEnabled(False)



				def functionalityOfOtherSubsysCB_CMI_(subSysCMCB_, otherSubsystemBox):
					subSysCMCB_.currentTextChanged.connect(lambda:onChangingSubSysCombobox_CMImport_(subSysCMCB_, otherSubsystemBox))

				functionalityOfOtherSubsysCB_CMI_(self.subSystemCombobox_ICM_, self.otherSubSystem_ICM_)






				## fault details line edit:
				self.createLineEditBox('faultDetailsLineEdit_ICM_')
				self.CorrectiveMaintenanceDataTable.setCellWidget(f, 12, self.faultDetailsLineEdit_ICM_)
				faultdetails_data = self.faultDetails_CMTab.toPlainText()
				# self.faultDetailsLineEdit_ICM_.setFixedWidth(int(0.07 * QApplication.primaryScreen().availableGeometry().width()))

				def onFaultDetailDTextChanged_ICM_(FaultDetailLineEdit_):
					FaultDetailLineEdit_.setToolTip(FaultDetailLineEdit_.text())

				def setToolTipsOfFDetails_ICM_(FaultDetailLineEdit_):
					FaultDetailLineEdit_.textChanged.connect(lambda:onFaultDetailDTextChanged_ICM_(FaultDetailLineEdit_))

				setToolTipsOfFDetails_ICM_(self.faultDetailsLineEdit_ICM_)

				self.faultDetailsLineEdit_ICM_.setText(faultdetails_data)


				## failure type combobox widget:
				self.createComboBox(['Relevant Failure', 'Service Failure', 'Non Relevant Failure'],'failureTypeCombobox_ICM_')
				self.CorrectiveMaintenanceDataTable.setCellWidget(f, 13, self.failureTypeCombobox_ICM_)
				self.failureTypeCombobox_ICM_.setFixedWidth(int(0.12 * QApplication.primaryScreen().availableGeometry().width()))

				## sub-system type label and combobox widget:
				self.createComboBox([],'serviceFailureEffectCombobox_ICM_')
				self.CorrectiveMaintenanceDataTable.setCellWidget(f, 14, self.serviceFailureEffectCombobox_ICM_)
				self.serviceFailureEffectCombobox_ICM_.setEnabled(False)
				self.serviceFailureEffectCombobox_ICM_.setFixedWidth(int(0.1 * QApplication.primaryScreen().availableGeometry().width()))

				def onChangingFailureTypeCombobox_CMImport_(failureTypeCB_, serviceFailureCB_):

					if failureTypeCB_.currentIndex() == 1:
						serviceFailureCB_.setEnabled(True)
						serviceFailureCB_.clear()
						serviceFailureCB_.addItems(['Pre-departure Withdrawal', 'Withdrawal', '3 min delay', 'Deboarding'])
					else:
						serviceFailureCB_.setEnabled(False)
						serviceFailureCB_.clear()

				def functionalityOfServiceFailureTypeCB_(failureTypeCB_, serviceFailureCB_):
					failureTypeCB_.currentTextChanged.connect(lambda:onChangingFailureTypeCombobox_CMImport_(failureTypeCB_, serviceFailureCB_))

				functionalityOfServiceFailureTypeCB_(self.failureTypeCombobox_ICM_, self.serviceFailureEffectCombobox_ICM_)

				failuretype_data = self.failureType__CMTab.currentText()  
				self.failureTypeCombobox_ICM_.setCurrentText(failuretype_data)

				servicefailure_data = self.serviceFailureEffect__CMTab.currentText()
				self.serviceFailureEffectCombobox_ICM_.setCurrentText(servicefailure_data)

				

				## consider For Relevant Fails combobox widget:
				self.createComboBox(['Yes', 'No'], 'considerForRelevantFails_ICM_')
				self.CorrectiveMaintenanceDataTable.setCellWidget(f, 15, self.considerForRelevantFails_ICM_)
				self.considerForRelevantFails_ICM_.setFixedWidth(int(0.14 * QApplication.primaryScreen().availableGeometry().width()))

				
				if totalRows > 1:
					if f == 0:
						self.considerForRelevantFails_ICM_.setCurrentIndex(0)
					else:
						self.considerForRelevantFails_ICM_.setCurrentIndex(1)

				if totalRows == 1:
					self.considerForRelevantFails_ICM_.setCurrentText(self.considerForRelavantFails__CMTab.currentText())






				## Action taken at mainline line edit:
				self.createLineEditBox('actionTakenAtMainLineEdit_ICM_')
				self.CorrectiveMaintenanceDataTable.setCellWidget(f, 16, self.actionTakenAtMainLineEdit_ICM_)


				def onActionTakenTextChanged_ICM_(ActionTakenLineEdit_):
					ActionTakenLineEdit_.setToolTip(ActionTakenLineEdit_.text())

				def setToolTipsOfActionTakenMainLine_ICM_(ActionTakenLineEdit_):
					ActionTakenLineEdit_.textChanged.connect(lambda:onActionTakenTextChanged_ICM_(ActionTakenLineEdit_))

				setToolTipsOfActionTakenMainLine_ICM_(self.actionTakenAtMainLineEdit_ICM_)
		
				actionmainline_data = self.actionTakenAtMainline_CM.toPlainText()
				self.actionTakenAtMainLineEdit_ICM_.setText(actionmainline_data)
				# self.actionTakenAtMainLineEdit_ICM_.setFixedWidth(int(0.07 * QApplication.primaryScreen().availableGeometry().width()))

				## Action taken at depot line edit:
				self.createLineEditBox('actionTakenAtDepotLineEdit_ICM_')
				self.CorrectiveMaintenanceDataTable.setCellWidget(f, 17, self.actionTakenAtDepotLineEdit_ICM_ )
				


				def onActionTakenAtDepotTextChanged_ICM_(ActionTakenAtDepotLineEdit_):
					ActionTakenAtDepotLineEdit_.setToolTip(ActionTakenAtDepotLineEdit_.text())

				def setToolTipsOfActionTakenAtDepotLine_ICM_(ActionTakenAtDepotLineEdit_):
					ActionTakenAtDepotLineEdit_.textChanged.connect(lambda:onActionTakenAtDepotTextChanged_ICM_(ActionTakenAtDepotLineEdit_))

				setToolTipsOfActionTakenAtDepotLine_ICM_(self.actionTakenAtDepotLineEdit_ICM_)

				actiondepot_data = self.actionTakenAtDepot_CM.toPlainText()
				self.actionTakenAtDepotLineEdit_ICM_.setText(actiondepot_data)
				# self.actionTakenAtDepotLineEdit_ICM_.setFixedWidth(int(0.07 * QApplication.primaryScreen().availableGeometry().width()))


				## Failure category combobox widget:
				self.createComboBox(['External', 'Maintenance', 'Material', 'NFF', 'Operation', 'Software', 'Workmanship', 'Others'],'failureCategory_ICM')
				self.CorrectiveMaintenanceDataTable.setCellWidget(f, 18, self.failureCategory_ICM)
				
				failurecategory_data = self.failureCategory__CMTab.currentText()
				self.failureCategory_ICM.setCurrentText(failurecategory_data)
				
				self.failureCategory_ICM.setFixedWidth(int(0.15 * QApplication.primaryScreen().availableGeometry().width()))


				## Failure responsibility combobox widget:
				self.createComboBox(['BEML', 'MMMOCL', 'Others'],'failureResponsibilityCombobox_ICM_')
				self.CorrectiveMaintenanceDataTable.setCellWidget(f, 19, self.failureResponsibilityCombobox_ICM_,)
				
				failureresponsibility_data = self.failureResponsibility__CMTab.currentText()
				self.failureResponsibilityCombobox_ICM_.setCurrentText(failureresponsibility_data)
				
				self.failureResponsibilityCombobox_ICM_.setFixedWidth(int(0.11 * QApplication.primaryScreen().availableGeometry().width()))



				## equipment line edit:
				self.createLineEditBox('equipmentLineEdit_ICM_')
				self.CorrectiveMaintenanceDataTable.setCellWidget(f, 20, self.equipmentLineEdit_ICM_)
				


				def onEquipmentTextChanged_ICM_(equipmentLineEdit_):
					equipmentLineEdit_.setToolTip(equipmentLineEdit_.text())

				def setToolTipsOfEquipment_ICM_(equipmentLineEdit_):
					equipmentLineEdit_.textChanged.connect(lambda:onEquipmentTextChanged_ICM_(equipmentLineEdit_))

				setToolTipsOfEquipment_ICM_(self.equipmentLineEdit_ICM_)

				equipment_data = self.equipmentLineEdit_CMTab.text()
				self.equipmentLineEdit_ICM_.setText(equipment_data)
				# self.equipmentLineEdit_ICM_.setFixedWidth(int(0.07 * QApplication.primaryScreen().availableGeometry().width()))


				## component line edit:
				self.createLineEditBox('componentLineEdit_ICM_')
				self.CorrectiveMaintenanceDataTable.setCellWidget(f, 21, self.componentLineEdit_ICM_)
				

				def onComponentTextChanged_ICM_(componentLineEdit_):
					componentLineEdit_.setToolTip(componentLineEdit_.text())

				def setToolTipsOfComponent_ICM_(componentLineEdit_):
					componentLineEdit_.textChanged.connect(lambda:onComponentTextChanged_ICM_(componentLineEdit_))

				setToolTipsOfComponent_ICM_(self.componentLineEdit_ICM_)

				component_data = self.componentLineEdit_CMTab.text()
				self.componentLineEdit_ICM_.setText(component_data)
				# self.componentLineEdit_ICM_.setFixedWidth(int(0.07 * QApplication.primaryScreen().availableGeometry().width()))


				## Lowest level component line edit:
				self.createLineEditBox('lowLevelComponentLineEdit_ICM_')
				self.CorrectiveMaintenanceDataTable.setCellWidget(f, 22, self.lowLevelComponentLineEdit_ICM_, )			

				def onLLComponentTextChanged_ICM_(LLcomponentLineEdit_):
					LLcomponentLineEdit_.setToolTip(LLcomponentLineEdit_.text())

				def setToolTipsOfLLComponent_ICM_(LLcomponentLineEdit_):
					LLcomponentLineEdit_.textChanged.connect(lambda:onLLComponentTextChanged_ICM_(LLcomponentLineEdit_))
				setToolTipsOfLLComponent_ICM_(self.lowLevelComponentLineEdit_ICM_)

				lowestlevel_data = self.lowestLevelLineEdit_CMTab.text()
				self.lowLevelComponentLineEdit_ICM_.setText(lowestlevel_data)
				# self.lowLevelComponentLineEdit_ICM_.setFixedWidth(int(0.07 * QApplication.primaryScreen().availableGeometry().width()))

				

				## NCR Number line edit:
				self.createLineEditBox('ncrNumberLineEdit_ICM_')
				self.CorrectiveMaintenanceDataTable.setCellWidget(f, 23, self.ncrNumberLineEdit_ICM_)			
				ncrnumber_data = self.NCR_CM.text()

				def onNCNumberTextChanged_ICM_(NCNumberLineEdit_):
					NCNumberLineEdit_.setToolTip(NCNumberLineEdit_.text())

				def setToolTipsOfNCN_ICM_(NCNumberLineEdit_):
					NCNumberLineEdit_.textChanged.connect(lambda:onNCNumberTextChanged_ICM_(NCNumberLineEdit_))

				setToolTipsOfNCN_ICM_(self.ncrNumberLineEdit_ICM_)
				self.ncrNumberLineEdit_ICM_.setText(ncrnumber_data)
				# self.ncrNumberLineEdit_ICM_.setFixedWidth(int(0.07 * QApplication.primaryScreen().availableGeometry().width()))



				## Is component replaced combobox widget:
				self.createComboBox(['Yes', 'No'], 'isComponentReplaced_ICM_')
				self.CorrectiveMaintenanceDataTable.setCellWidget(f, 24, self.isComponentReplaced_ICM_)			
				componentreplace_data = self.componentReplaced_CM.currentText()
				self.isComponentReplaced_ICM_.setCurrentText(componentreplace_data)
				self.isComponentReplaced_ICM_.setFixedWidth(int(0.15 * QApplication.primaryScreen().availableGeometry().width()))

				## replaced component line edit:
				self.createLineEditBox('replacedComponentLineEdit_ICM_')
				self.CorrectiveMaintenanceDataTable.setCellWidget(f, 25, self.replacedComponentLineEdit_ICM_)			
				replacedComponent_data = self.replacedComponentLineEdit_CM.text()

				def onReplacedComponentTextChanged_ICM_(replacedComponentLineEdit_):
					replacedComponentLineEdit_.setToolTip(replacedComponentLineEdit_.text())

				def setToolTipsOfNCN_ICM_(replacedComponentLineEdit_):
					replacedComponentLineEdit_.textChanged.connect(lambda:onReplacedComponentTextChanged_ICM_(replacedComponentLineEdit_))

				setToolTipsOfNCN_ICM_(self.replacedComponentLineEdit_ICM_)
				self.replacedComponentLineEdit_ICM_.setText(replacedComponent_data)
				# self.replacedComponentLineEdit_ICM_.setFixedWidth(int(0.07 * QApplication.primaryScreen().availableGeometry().width()))



				def onChangingIsComponentReplacedCombobox_CM_(isComponentReplcedCB_, replacedComponentLineEdit_):

					if isComponentReplcedCB_.currentText() == 'Yes':
						replacedComponentLineEdit_.setEnabled(True)
						replacedComponentLineEdit_.clear()
					else:
						replacedComponentLineEdit_.clear()
						replacedComponentLineEdit_.setEnabled(False)

				def functionalityOfIsComponentReplacedCB_(isComponentReplcedCB_, replacedComponentLineEdit_):
					isComponentReplcedCB_.currentTextChanged.connect(lambda:onChangingIsComponentReplacedCombobox_CM_(isComponentReplcedCB_, replacedComponentLineEdit_))

				functionalityOfIsComponentReplacedCB_(self.isComponentReplaced_ICM_, self.replacedComponentLineEdit_ICM_)



				## Verification combobox widget:
				self.createComboBox(['Yes', 'No'],'verificationCombobox_ICM_')
				self.CorrectiveMaintenanceDataTable.setCellWidget(f, 26, self.verificationCombobox_ICM_)
				
				verification_data = self.verification__CMTab.currentText()
				self.verificationCombobox_ICM_.setCurrentText(verification_data)
				self.verificationCombobox_ICM_.setFixedWidth(int(0.07 * QApplication.primaryScreen().availableGeometry().width()))




				# dest_folder = "C:\\ProgramData\\RAMSify\\Attachments"
				selected_files = [self.mianAttachment_CM.fileListWidget.item(i).text() for i in range(self.mianAttachment_CM.fileListWidget.count())]
				# listOfAttachmentsNames = []
				# for f, file_path in enumerate(selected_files):
				# 	if os.path.exists(file_path):
				# 		file_name = os.path.basename(file_path)
				# 		file_extension = os.path.splitext(file_name)[1]
				# 		current_datetime = datetime.now().strftime("%Y%m%d%H%M%S")
						
				# 		fVal = str(f)
				# 		if len(str(f)) == 1:
				# 			fVal = '00'+str(f)
				# 		elif len(str(f)) == 2:
				# 			fVal = '0'+str(f)
				# 		else:
				# 			fVal = str(f)

				# 		new_file_name = f"{os.path.splitext(file_name)[0]}_{current_datetime}{fVal}{file_extension}"
				# 		listOfAttachmentsNames.append(new_file_name)

				# 		dest_path = os.path.join(dest_folder, new_file_name)
				# 		shutil.copy(file_path, dest_path)
				# 	else:
				# 		QMessageBox.warning(self, "Warning", f"File {file_path} does not exist.", QMessageBox.Ok)





				# attachmentsItem = QTableWidgetItem(str(listOfAttachmentsNames))
				# attachmentsItem.setFlags(attachmentsItem.flags() & ~Qt.ItemIsEditable)
				if len(selected_files)>0:
					self.CorrectiveMaintenanceDataTable.setCellWidget(f, 27, QLabel(str(selected_files)))
					self.CorrectiveMaintenanceDataTable.cellWidget(f, 27).setToolTip(str(selected_files))
					# attachmentsItem.setToolTip(str(listOfAttachmentsNames))
				else:
					self.CorrectiveMaintenanceDataTable.setCellWidget(f, 27, QLabel(''))







				
				
				startDatee = self.workStartDate_CMTab.date()
				startTimee = self.workStartTime_CMTab.time()

				startDateTimee = QDateTime(startDatee, startTimee)
				
				startDateTimeOfCurrentRow = startDateTimee.addSecs(eachRowWorkDuration*f)

				if startDateTimeOfCurrentRow.time().second() >= 30:
					startDateTimeOfCurrentRow = startDateTimeOfCurrentRow.addSecs(60 - startDateTimeOfCurrentRow.time().second())
				else:
					startDateTimeOfCurrentRow = startDateTimeOfCurrentRow.addSecs(-startDateTimeOfCurrentRow.time().second())


				startDateOfCurrentRow = startDateTimeOfCurrentRow.date()
				startTimeOfCurrentRow = startDateTimeOfCurrentRow.time()

				endDateTimeOfCurrentRow = startDateTimee.addSecs(eachRowWorkDuration*(f+1))


				if endDateTimeOfCurrentRow.time().second() >= 30:
					endDateTimeOfCurrentRow = endDateTimeOfCurrentRow.addSecs(60 - endDateTimeOfCurrentRow.time().second())
				else:
					endDateTimeOfCurrentRow = endDateTimeOfCurrentRow.addSecs(-endDateTimeOfCurrentRow.time().second())


				endDateOfCurrentRow = endDateTimeOfCurrentRow.date()
				endTimeOfCurrentRow = endDateTimeOfCurrentRow.time()





				## work start date label and dateedit widget:
				self.createDateEditBox('workStartDate_ICM_')
				# if self.userRole != 0:
				# 	self.workStartDate_ICM_.setMinimumDate(firstDateOfPreviousMonth)

				# if (self.userName == 'Ravikumar') and (self.editableOptionMaxDate > datetime.now().date()):
				# 	self.workStartDate_ICM_.setMinimumDate(QDate(self.startingYear, self.startingMonth, 1))

				self.CorrectiveMaintenanceDataTable.setCellWidget(f, 28, self.workStartDate_ICM_)		
				# work_start_date = self.workStartDate_CMTab.date().toString(Qt.ISODate)			
				self.workStartDate_ICM_.setFixedWidth(int(0.07 * QApplication.primaryScreen().availableGeometry().width()))
				

				## work start time label and timeedit widget:
				self.createTimeEditBox('workStartTime_ICM_')
				self.CorrectiveMaintenanceDataTable.setCellWidget(f, 29, self.workStartTime_ICM_)			
				# work_start_time = self.workStartTime_CMTab.time().toString(Qt.ISODate)
				self.workStartTime_ICM_.setFixedWidth(int(0.05 * QApplication.primaryScreen().availableGeometry().width()))


				## work end date label and dateedit widget:
				self.createDateEditBox('workEndDate_ICM_')
				# if self.userRole != 0:
				# 	self.workEndDate_ICM_.setMinimumDate(firstDateOfPreviousMonth)

				# if (self.userName == 'Ravikumar') and (self.editableOptionMaxDate > datetime.now().date()):
				# 	self.workEndDate_ICM_.setMinimumDate(QDate(self.startingYear, self.startingMonth, 1))

				self.CorrectiveMaintenanceDataTable.setCellWidget(f, 30, self.workEndDate_ICM_)
				self.workEndDate_ICM_.setFixedWidth(int(0.07 * QApplication.primaryScreen().availableGeometry().width()))

				## work end time label and timeedit widget:
				self.createTimeEditBox('workEndTime_ICM_')
				self.CorrectiveMaintenanceDataTable.setCellWidget(f, 31, self.workEndTime_ICM_)			
				self.workEndTime_ICM_.setFixedWidth(int(0.05 * QApplication.primaryScreen().availableGeometry().width()))


				## Actual down time value label and lineedit widget:
				self.downtimeInMinutes_ICM_ = QLabel('0')
				self.CorrectiveMaintenanceDataTable.setCellWidget(f, 32, self.downtimeInMinutes_ICM_)
				label_text = self.downTime_CMTab.text()
				self.downtimeInMinutes_ICM_.setText(label_text)
				self.downtimeInMinutes_ICM_.setAlignment(Qt.AlignCenter)



				def onChangingDateTimeWidgets_CMImport_(workStartDate, workStartTime, workEndDate, workEndTime, downTimeLabel):

					workStartDatetime_ICM_ = QDateTime(workStartDate.date(), workStartTime.time())
					workEndDatetime_ICM_ = QDateTime(workEndDate.date(), workEndTime.time())

					if workEndDatetime_ICM_ < workStartDatetime_ICM_:
						workEndDate.setDate(workStartDate.date())
						workEndTime.setTime(workStartTime.time())

					# Calculate the time difference in minutes
					time_difference_ICM_ = workStartDatetime_ICM_.secsTo(workEndDatetime_ICM_) / 60

					# Convert the time difference to an integer
					time_difference_ICM_ = int(time_difference_ICM_)

					# Update the actual downtime value if it's not negative
					if time_difference_ICM_ >= 0:
						downTimeLabel.setText(str(time_difference_ICM_))
					else:
						downTimeLabel.setText("0")  # or any default value
					

				def functionalityOfCMDowntime_(workStartDate, workStartTime, workEndDate, workEndTime, downTimeLabel):
					workStartDate.dateChanged.connect(lambda:onChangingDateTimeWidgets_CMImport_(workStartDate, workStartTime, workEndDate, workEndTime, downTimeLabel ))
					workStartTime.timeChanged.connect(lambda:onChangingDateTimeWidgets_CMImport_(workStartDate, workStartTime, workEndDate, workEndTime, downTimeLabel))
					workEndDate.dateChanged.connect(lambda:onChangingDateTimeWidgets_CMImport_(workStartDate, workStartTime, workEndDate, workEndTime, downTimeLabel))
					workEndTime.timeChanged.connect(lambda:onChangingDateTimeWidgets_CMImport_(workStartDate, workStartTime, workEndDate, workEndTime, downTimeLabel))

				functionalityOfCMDowntime_(self.workStartDate_ICM_, self.workStartTime_ICM_, self.workEndDate_ICM_, self.workEndTime_ICM_, self.downtimeInMinutes_ICM_)

				self.workStartDate_ICM_.setDate(startDateOfCurrentRow)
				self.workStartTime_ICM_.setTime(startTimeOfCurrentRow)
				self.workEndDate_ICM_.setDate(endDateOfCurrentRow)
				self.workEndTime_ICM_.setTime(endTimeOfCurrentRow)


			val = 0
			for i in range(numberOfTrainsSelected):
				for j in range(numberOfCarsSelected):
					for k in range(quantity):
						self.CorrectiveMaintenanceDataTable.cellWidget(val, 3).setCurrentText(cleanedListOfSelectedTrains[i])
						val += 1


			val = 0
			for i in range(numberOfTrainsSelected):
				for j in range(numberOfCarsSelected):
					if cleanedListOfSelectedCars != []:
						for k in range(quantity):
							self.CorrectiveMaintenanceDataTable.cellWidget(val, 4).setCurrentText(cleanedListOfSelectedCars[j])
							val += 1

			# addCMRow_()

			

			self.createPushButton('submit_CM_', 'SUBMIT', '',  width=int(0.050 * QApplication.primaryScreen().availableGeometry().width()))
			self.submit_CM_.setFixedHeight(30)

			# Create cancel OPM submission form button
			self.createPushButton('cancel_CM_', 'CANCEL', '',  width=int(0.050 * QApplication.primaryScreen().availableGeometry().width()))
			self.cancel_CM_.setFixedHeight(30)

			CmHboxlayout = QHBoxLayout()

			CmHboxlayout.addWidget(self.submit_CM_, alignment = Qt.AlignRight)
			CmHboxlayout.addWidget(self.cancel_CM_, alignment = Qt.AlignLeft)

			CmConfirmationWindowLayout.addLayout(CmHboxlayout)


			self.CorrectiveMaintenanceConfirmationWindow.show()


			def submitcmdata():

				mandatorySuccess_CM = True
				# mandatoryFieldsOfImportedExcelRows_CM = [0, 1, 2, 3, 9, 10, 11, 12, 15, 17, 23, 24, 25, 26, 27]
				mandatoryFieldsOfImportedExcelRows_CM = [0, 1, 2, 3, 9, 10, 12, 13, 15, 17, 19, 26, 28, 29, 30, 31]
				currentDateTimeValue = datetime.now()

				# self.missingFields_CM = []

				self.listOfImportedCMRows_CMTable = []
				# self.allSysSubSysListInImport_CMTable = []

				for r in range(self.CorrectiveMaintenanceDataTable.rowCount()):
					cm_id_string = 'CM' + '_' + currentDateTimeValue.strftime("%Y%m%d%H%M%S%f")[:-4]
					currentDateTimeValue += timedelta(milliseconds=10)
					singleRowData_CM_ = [cm_id_string]

					# sysSubsys_CMTable = []

					for c in range(self.CorrectiveMaintenanceDataTable.columnCount()):
						widget = self.CorrectiveMaintenanceDataTable.cellWidget(r, c)
						

						if c in [0, 28, 30]:
							datetime_ = QDateTime(widget.date(), self.CorrectiveMaintenanceDataTable.cellWidget(r, c+1).time())
							singleRowData_CM_.append(datetime_.toPython())
						
						if c in [1, 29, 31]:
							pass

						if widget.isEnabled():
							if isinstance(widget, QComboBox):
								if widget.currentText() == '':
									singleRowData_CM_.append(None)
									if c in mandatoryFieldsOfImportedExcelRows_CM:
										widget.setProperty("error", True)
										widget.setStyleSheet(self.comboBoxQSS)
										mandatorySuccess_CM = False
								else:
									if c == 9:
										query = "SELECT id FROM bom WHERE equipment = %s AND parent_id = 0"
										self.cursor.execute(query, (widget.currentText(),))
										result = self.cursor.fetchone()
										singleRowData_CM_.append(result[0])
										widget.setProperty("error", False)
										widget.setStyleSheet(self.comboBoxQSS)
										# sysSubsys_CMTable.append(widget.currentText())
									
									elif c == 10:
										query = "SELECT id FROM bom WHERE parent_id = (SELECT id FROM bom WHERE equipment = %s AND parent_id = 0) AND equipment = %s"
										self.cursor.execute(query, (self.CorrectiveMaintenanceDataTable.cellWidget(r, c-1).currentText(), widget.currentText()))
										result = self.cursor.fetchone()
										singleRowData_CM_.append(result[0])
										widget.setProperty("error", False)
										widget.setStyleSheet(self.comboBoxQSS)
										# sysSubsys_CMTable.append(widget.currentText())

									else:
										singleRowData_CM_.append(widget.currentText())
										widget.setProperty("error", False)
										widget.setStyleSheet(self.comboBoxQSS)

							elif isinstance(widget, QLineEdit):
								if c in mandatoryFieldsOfImportedExcelRows_CM and not widget.text():
									mandatorySuccess_CM = False
									widget.setProperty("error", True)
									widget.setStyleSheet(self.lineEditBoxQSS)
									singleRowData_CM_.append(None)
								else:
									singleRowData_CM_.append(widget.text())

							elif isinstance(widget, QLabel):
								if widget.text() == '':
									singleRowData_CM_.append(None)
								else:
									singleRowData_CM_.append(widget.text())

						else:
							singleRowData_CM_.append(None)
					

					self.listOfImportedCMRows_CMTable.append(singleRowData_CM_)	
					# self.allSysSubSysListInImport_CMTable.append(sysSubsys_CMTable)



				if mandatorySuccess_CM:

					dest_folder = "C:\\ProgramData\\RAMSify\\Attachments"
					selected_files = [self.mianAttachment_CM.fileListWidget.item(i).text() for i in range(self.mianAttachment_CM.fileListWidget.count())]
					listOfAttachmentsNames = []
					for f, file_path in enumerate(selected_files):
						if os.path.exists(file_path):
							file_name = os.path.basename(file_path)
							file_extension = os.path.splitext(file_name)[1]
							current_datetime = datetime.now().strftime("%Y%m%d%H%M%S")
							
							fVal = str(f)
							if len(str(f)) == 1:
								fVal = '00'+str(f)
							elif len(str(f)) == 2:
								fVal = '0'+str(f)
							else:
								fVal = str(f)

							new_file_name = f"{os.path.splitext(file_name)[0]}_{current_datetime}{fVal}{file_extension}"
							listOfAttachmentsNames.append(new_file_name)

							dest_path = os.path.join(dest_folder, new_file_name)
							shutil.copy(file_path, dest_path)
						else:
							QMessageBox.warning(self, "Warning", f"File {file_path} does not exist.", QMessageBox.Ok)




				
					for singleRowData_CM_ in self.listOfImportedCMRows_CMTable:

						insert_query = """
							INSERT INTO corrective_maintenance (
							cm_id, event_datetime, depot, trainset_id, car_no, jobcard_no, issued_to, ml_depot, location,
							system_id, subsystem_id, other_subsystem, fault_details, failure_type, service_failure_effect, consider_for_relevant_fails,
							action_taken_at_mainline, action_taken_at_depot, failure_category, failure_responsibility,
							equipment, component, lowest_level_component, ncr_no, component_replaced, replaced_component, verification, attachments, work_start_at, work_end_at, down_time, user_id
							) SELECT
								%s, %s, %s, trainsets.id, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s
							FROM
								trainsets
							WHERE
								trainsets.trainset = %s
						"""
						singleRowData_CM_[27] = str(listOfAttachmentsNames)
						singleRowData_CM_.append(self.user_id)
						trainset = singleRowData_CM_.pop(3)
						singleRowData_CM_.append(trainset)
						self.cursor.execute(insert_query, tuple(singleRowData_CM_))
						self.mydb.commit()
				

					cmMsgBox = QMessageBox()
					cmMsgBox.setIcon(QMessageBox.Information) 
					cmMsgBox.setText(f"{self.CorrectiveMaintenanceDataTable.rowCount()} CM's added successfully.")
					cmMsgBox.setWindowTitle("Message")
					cmMsgBox.setWindowIcon(QIcon('Media/ramsify.png'))
					cmMsgBox.setStandardButtons(QMessageBox.Ok)
					cmMsgBox.exec_()

					self.apply_CMDT.click()

					self.CorrectiveMaintenanceConfirmationWindow.close()
					self.cancel_CM.click()
			

			self.submit_CM_.clicked.connect(submitcmdata)
			self.cancel_CM_.clicked.connect(lambda: self.CorrectiveMaintenanceConfirmationWindow.close())

	self.submit_CM.clicked.connect(onClickingSubmit_CM)


	def onClickingCancel_CM():

		currentDateTime = datetime.now()

		self.eventDate_CMTab.setDate(self.eventDate_CMTab.minimumDate())
		self.eventTime_CMTab.setTime(QTime(0, 0))
		self.trainComboBox_CMTab.setCurrentIndex(-1)
		self.depotComboBox_CMTab.setCurrentIndex(-1)
		for i in range(self.trainComboBox_CMTab.model().rowCount()):
			item = self.trainComboBox_CMTab.model().item(i)

			inactive_brush = QBrush(QColor('#f6f8fc'))
			item.setBackground(inactive_brush)
			item.setForeground(QColor("black"))
		self.trainComboBox_CMTab.lineEdit().setToolTip(None)

		self.carComboBox_CMTab.setCurrentIndex(-1)
		for i in range(self.carComboBox_CMTab.model().rowCount()):
			item = self.carComboBox_CMTab.model().item(i)
			inactive_brush = QBrush(QColor('#f6f8fc'))
			item.setBackground(inactive_brush)
			item.setForeground(QColor("black"))
		self.carComboBox_CMTab.lineEdit().setToolTip(None)



		self.jobcardNo_CMTab.clear()
		self.issuedTo_CMTab.clear()
		self.reapairAt_CMTab.setCurrentIndex(-1) 
		self.locationLineEdit_CMTab.clear() 
		self.systemComboBox_CMTab.setCurrentIndex(-1)
		self.subSystemComboBox_CMTab.setCurrentIndex(-1)
		self.quantity_CMTab.clear()
		self.faultDetails_CMTab.clear()
		self.failureType__CMTab.setCurrentIndex(-1) 
		self.serviceFailureEffect__CMTab.setCurrentIndex(-1)
		self.considerForRelavantFails__CMTab.setCurrentIndex(-1)

		self.mianAttachment_CM.fileListWidget.clear()
		self.mianAttachment_CM.fileListWidget.hide()
		self.mianAttachment_CM.removeButton.setEnabled(False)
		self.actionTakenAtMainline_CM.clear()
		self.actionTakenAtDepot_CM.clear() 
		self.failureCategory__CMTab.setCurrentIndex(-1)
		self.failureResponsibility__CMTab.setCurrentIndex(-1) 
		self.equipmentLineEdit_CMTab.clear()
		self.componentLineEdit_CMTab.clear() 
		self.lowestLevelLineEdit_CMTab.clear() 
		self.NCR_CM.clear() 
		self.componentReplaced_CM.setCurrentIndex(-1)
		self.verification__CMTab.setCurrentIndex(-1) 
		self.workStartDate_CMTab.setDate(self.eventDate_CMTab.minimumDate()) 
		self.workStartTime_CMTab.setTime(QTime(0, 0)) 
		self.workEndDate_CMTab.setDate(self.eventDate_CMTab.minimumDate()) 
		self.workEndTime_CMTab.setTime(QTime(0, 0))
		self.downTime_CMTab.setText('0')


		self.trainComboBox_CMTab.setEnabled(False)
		self.subSystemComboBox_CMTab.setEnabled(False)
		self.serviceFailureEffect__CMTab.setEnabled(False)
		


	self.cancel_CM.clicked.connect(onClickingCancel_CM)


	# #Create a horizontal layout to keep the submit and cancel button:
	self.layoutForSubmitAndCancelBtnsOfCM = QHBoxLayout()
	self.layoutForSubmitAndCancelBtnsOfCM.addWidget(self.submit_CM, alignment = Qt.AlignRight)
	self.layoutForSubmitAndCancelBtnsOfCM.addWidget(self.cancel_CM, alignment = Qt.AlignLeft)

	
	self.CMMainLayout.addLayout(self.layoutForSubmitAndCancelBtnsOfCM)

	tab.setLayout(self.CMMainLayout)