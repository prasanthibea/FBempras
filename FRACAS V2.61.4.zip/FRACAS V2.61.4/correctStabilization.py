import mysql.connector

# Connect to the MySQL database
connection = mysql.connector.connect(
    host="localhost",
    user="root",
    password="FRACAS@22",
    database="ramsify"
)

# Create a cursor object to execute SQL queries
cursor = connection.cursor()

try:
    # Update the stabilization date for all rows
    update_query = "UPDATE trainsets SET stabilization = stabilization - INTERVAL 1 DAY"
    cursor.execute(update_query)

    # Commit the changes to the database
    connection.commit()

    print("Stabilization dates updated successfully.")

except mysql.connector.Error as error:
    print("Error updating stabilization dates:", error)

finally:
    # Close the cursor and connection
    cursor.close()
    connection.close()
