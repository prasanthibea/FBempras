from datetime import date
def databaseData(self):

	self.startingYear = int(self.config.get('startingYearMonth', 'startingYear'))
	self.startingMonth = int(self.config.get('startingYearMonth', 'startingMonth'))
	self.availabilityTarget = float(self.config.get('availability', 'availabilityTarget'))
	self.mdbfTarget = int(self.config.get('MDBF', 'MDBFTarget'))
	failureCounts = self.config.get('failures', 'systemIds')
	failureCountList = list(failureCounts.split(','))
	self.systemIdsList = sorted([int(ids) for ids in failureCountList])

	userRoles = self.config.get('userRoles', 'roles')
	self.userRolesList = list(userRoles.split(','))

	self.ASCHours = float(self.config.get('SCHours', 'a'))
	self.B1SCHours = float(self.config.get('SCHours', 'b1'))
	self.B4SCHours = float(self.config.get('SCHours', 'b4'))
	self.B8SCHours = float(self.config.get('SCHours', 'b8'))
	self.C1SCHours = float(self.config.get('SCHours', 'c1'))
	self.C2SCHours = float(self.config.get('SCHours', 'c2'))

	# print(self.ASCHours, self.B1SCHours, self.B4SCHours, self.B8SCHours, self.C1SCHours, self.C2SCHours)





	equipmentIds = self.config.get('MTTR', 'equipmentIdsForMTTR')
	equipmentIdsList = list(equipmentIds.split(',')) 
	self.equipmentsListforMTTR = sorted([int(ids) for ids in equipmentIdsList])
	# print(self.equipmentsListforMTTR)


	# List of all trains
	self.trainsetsList = []
	self.cursor.execute('SELECT trainset FROM trainsets WHERE deleted_at IS NULL')
	trainsets = self.cursor.fetchall()
	for train in trainsets:
		self.trainsetsList.append(train[0])

	# List of trainsets ids
	self.cursor.execute('SELECT id FROM trainsets WHERE deleted_at IS NULL')
	trainsetIds = self.cursor.fetchall()
	self.trainsetsIdsList = [id_[0] for id_ in trainsetIds]

	# List of all depots
	self.depotsList = []
	self.cursor.execute('SELECT DISTINCT depot FROM trainsets')
	depots = self.cursor.fetchall()
	for depot in depots:
		self.depotsList.append(depot[0])


	# List of cars
	self.carsList = ['DM1', 'T2', 'M3', 'M4', 'T5', 'DM6']


	# # Dictionary of depot and train
	self.depotTrainDictionary = {}

	# Fetch data from the 'trainsets' table
	self.cursor.execute("SELECT depot, trainset FROM trainsets")
	rows = self.cursor.fetchall()

	# Organize data into a dictionary
	for depot, trainset in rows:
		if depot not in self.depotTrainDictionary:
			self.depotTrainDictionary[depot] = []
		self.depotTrainDictionary[depot].append(trainset)


	# Dictionary of systems and subsystems
	self.BOMSystemDictionary = {}
	self.cursor.execute('SELECT id, parent_id, equipment FROM bom')

	bomData = self.cursor.fetchall()
	equipment_info = {row[0]: {'parent_id': row[1], 'equipment': row[2]} for row in bomData}
	for equipment_id, info in equipment_info.items():
		parent_id = info['parent_id']
		equipment_name = info['equipment']

		# If it's a parent, create an empty list for its children
		if parent_id == 0:
			self.BOMSystemDictionary[equipment_name] = []
		else:
			# If it's a child, append it to the parent's list
			parent_name = equipment_info[parent_id]['equipment']
			self.BOMSystemDictionary[parent_name].append(equipment_name)


	uniqueLinesQuery = 'SELECT DISTINCT `line` from trainsets'
	self.cursor.execute(uniqueLinesQuery)
	uniqueLines_ = self.cursor.fetchall()
	self.uniqueLines = [line[0] for line in uniqueLines_]


	self.editableOptionMaxDate = date(2024, 9, 30)