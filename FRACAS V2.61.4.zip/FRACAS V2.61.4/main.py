from PySide6.QtWidgets import QVBoxLayout, QSpacerItem, QSizePolicy, QLabel
from PySide6.QtCore import Qt, QSettings
from PySide6.QtGui import QIcon, QFont, QFontDatabase
from PySide6.QtWidgets import QApplication, QMainWindow, QPushButton
from PySide6.QtUiTools import loadUiType

import sys
import time

from loginForm import *

Ui_MainWindow, QMainWindowBase = loadUiType("uifile.ui")
class MainWindow(QMainWindow, Ui_MainWindow):

	from functions import (logErrors, readIniFile, connectDB, createCheckBoxes, createComboBox, createComboBox2, createDateTimeEditBox, createTextEditBox, createRadioButtons, createPushButton, browseFiles,
					createLayout, removeAttachment, openAttachment, createLineEditBox, createTableView, createListView, createDateEditBox, createTimeEditBox,
					create_folder_if_not_exists, logout, topItems, childrenOf, createSpinBox, mapImportedDataToWidgets, CustomSpinBox,
					generate_pdf_report, onClickingRemoveButn, createCheckableComboBox, FileAttachmentWidget, createAttachmentWidget, onClickingRemoveButn_OPM,
					createStackedBarChart, CustomValueAxis, showContextMenu, createPieChart, createLineChart, createBarChart, NumberLineEdit, createNumberLineEditBox)
	from sideMenu import (on_menu_button_clicked, onSideMenuTreeItemClicked, on_home_btn_clicked, on_settings_btn_clicked, sideTreeMenu, buttonsOnSideMenu, 
							onClickingConfigurationBtn)

	from configurationPage import configurationUI, onClickingRefresh_users
	from hideAndUnhide import hideOrUnhideFunction
	from menuBar import menuBarActions
	from tables import createTables
	from toolBar import toolBarFunction, onTriggeringSettingsAction, onTriggeringHelpAction
	from settings import settingsUI, onChangingFontCombobox, onChangingThemeCombobox

	from settingTheme import settingThemeFunction
	from QSSS import QSSValues

	from databaseData import databaseData
	from runningMileage import runningMileageUI
	from maintenance import maintenanceUI

	from maintenanceData import maintenanceDataUI
	from cmData import onButtonClicked_cmData
	from opmData import onButtonClicked_opmData
	# from scData import onButtonClicked_scData
	from home import homeUi, onClickingRefresh_home

	from dashboards.availabilityDashboard import availabilityUi, onClickingRefresh_availDash
	from dashboards.mdbfDashboard import mdbfUi, onClickingRefresh_MDBF
	from dashboards.trainSummary import trainSummaryUi
	from dashboards.patternFailure import patternFailureUi, onClickingRefresh_PF
	from dashboards.dashboardRunningMielage import dashboardRunningmileageUI, onClickingRefresh_RM
	from dashboards.systemsFailures import systemsFailuresUi, onClickingRefresh_SRF
	from dashboards.mttrDashboard import mttrDashboardUi, onClickingRefresh_MTTR
	from dashboards.mdbcfDashboard import mdbcfDashboardUi, onClickingRefresh_MDBCF


	from more.ncr import ncrUI
	from more.ncrform import ncrformUI

	from generateReports import generateReportFunction
	# from monthlyReport import generateMonthlyReport
	



	@logErrors
	def __init__(self):
		super(MainWindow,self).__init__()

		# pixmap = QPixmap("Media/Splashscreen11.png")
		# splashScreen = QSplashScreen(pixmap)
		# splashScreen.show()
		# start_time = time.time()
		font_id = QFontDatabase.addApplicationFont("Roboto-Regular.ttf")
		font_family = QFontDatabase.applicationFontFamilies(font_id)[0]
		custom_font = QFont(font_family)
		custom_font.setPointSize(int(0.006 * QApplication.primaryScreen().availableGeometry().width()))
		QApplication.setFont(custom_font)

		self.setupUi(self)
		screen = QApplication.primaryScreen()

		self.readIniFile()
		self.connectDB()
		self.databaseData()

		self.settings = QSettings("RAMSify", "BeAnalytic")
		self.QSSValues()
		
		self.setWindowTitle('RAMSify')
		self.setWindowIcon(QIcon('Media/ramsify.png'))
		
		self.crossButtons = {}
		self.checkedItemsOfBOMWindow = {}
		self.logoutButton.clicked.connect(self.logout)
		self.settings = QSettings("RAMSify", "BeAnalytic")


		self.toolBarFunction()
		self.createTables()
		self.sideTreeMenu()
		self.buttonsOnSideMenu()
		self.configurationUI()
		self.settingsUI()
		
		self.settingThemeFunction()

		# print("Total time taken:", time.time() - start_time)

		# start_time = time.time()
		self.runningMileageUI()
		# print("Total time taken for runningMileageUI:", time.time() - start_time)

		# start_time = time.time()
		self.maintenanceUI()
		# print("Total time taken for maintenanceUI:", time.time() - start_time)

		# start_time = time.time()
		self.maintenanceDataUI()
		# print("Total time taken for maintenanceDataUI:", time.time() - start_time)

		# start_time = time.time()
		# self.availabilityUi()
		# print("Total time taken for availabilityUi:", time.time() - start_time)

		# start_time = time.time()
		# self.mdbfUi()
		# print("Total time taken for mdbfUi:", time.time() - start_time)
		
		# start_time = time.time()
		# self.trainSummaryUi()
		# print("Total time taken for trainSummaryUi:", time.time() - start_time)

		# start_time = time.time()
		# self.patternFailureUi()
		# print("Total time taken for patternFailureUi:", time.time() - start_time)

		# start_time = time.time()
		# self.systemsFailuresUi()
		# print("Total time taken for systemsFailuresUi:", time.time() - start_time)

		
		# start_time = time.time()
		# self.dashboardRunningmileageUI()
		# print("Total time taken for dashboardRunningmileageUI:", time.time() - start_time)

		# start_time = time.time()
		# self.mttrDashboardUi()
		# print("Total time taken for mttrDashboardUi:", time.time() - start_time)
		
		# start_time = time.time()
		# self.mdbcfDashboardUi()
		# print("Total time taken for mdbcfDashboardUi:", time.time() - start_time)


		self.menuBarActions()
		# start_time = time.time()
		# self.homeUi()
		# print("Total time taken for homeUi:", time.time() - start_time)



		self.ncrUI()
		self.ncrformUI()

		self.sideMenuSize = 0
		self.stackedWidget.setCurrentIndex(0)
		self.userNameButton.setText(self.userName)
		self.hideOrUnhideFunction()
		# splashScreen.close()
		self.showMaximized()

	def closeEvent(self, event):
		self.mydb.commit()
		self.cursor.close()
		self.mydb.close()
		event.accept()