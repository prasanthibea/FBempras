import requests
from concurrent.futures import ThreadPoolExecutor

# Define the URL of your deployed React app
url = 'http://13.234.32.91:3000/'  # Replace with your actual EC2 URL

# Function to send a single request
def send_request():
    try:
        response = requests.get(url)
        print(f"Status Code: {response.status_code}, Response: {response.text[:100]}")  # Print the status code and first 100 characters of the response
    except requests.exceptions.RequestException as e:
        print(f"Request failed: {e}")

# Number of requests to send
num_requests = 20

# Create a ThreadPoolExecutor to send requests concurrently
with ThreadPoolExecutor(max_workers=num_requests) as executor:
    futures = [executor.submit(send_request) for _ in range(num_requests)]

    # Wait for all futures to complete
    for future in futures:
        future.result()
