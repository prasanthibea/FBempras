def QSSValues(self):
	from PySide6.QtWidgets import QApplication
	self.allThemes = {

					'Light': {	

								'kpiLabelsAndValuesColor' : '#000000',


								'scrollHandleColor': '#d0d0d9',
								'scrollHandleHoverColor': '#638094',
								'scrollHandlePressedColor': '#506c80',


								'background': '#ffffff',
								'scrollAreaBackground' : '#FFFFFF',
								'textColor' : '#26282C',
								'centralWidgetBckgroundColor' : '#F6F8FC',
								'leftMenuBGColor' : '#F6F8FC',
								'highlightColor' : '#6C7AE0',
								'oppositeTextColor' : '#ffffff',
								'activeTreeItemBGColor' : '#D3E3FD',
								'treeItemHoverBGColor' :'#eaebef',
								'selectedItemColor' : '#202124',
								'tableBorderColor' : 'transparent',
								'tableHeaderBGColor' : '#6C7AE0',
								'tableAlternateRowColor' : '#E3E3EF',

								'chartBackGroundColor' : '#FBFCFF',


								'greenTextColor' : '#23C823',
								'redTextColor' : '#C82323',
								'greenBGColor' : '#1FB01F',
								'redBGColor' : '#D40E0E',
								'textColor' : '#000000',
								'oppositeTextColor' : '#ffffff',
								
								'parentComponentTextColor' : '#ff6600',

								'toolWidgetBodyBackgroundColor': '#F6FBFC',

								'helpQuestionMarkIcon': 'Media/darkQuestion.png',

								'menuIcon': 'Media/darkMenu.png',
								'downArrow': 'Media/darkDownArrow.png',
								'upArrow': 'Media/darkUpArrow.png',

								'exportTemplateIcon': 'Media/whiteExport.png',
								'importDataIcon': 'Media/whiteImport.png',

								'clearTableFilterIcon': 'Media/whiteClearFilters.png',
								'ExportTableIcon': 'Media/whiteExport.png',
								'refreshIcon' : 'Media/whiteRefresh.png',


		
								'checkBoxIcon': 'Media/darkCheckbox.png',
								'unCheckBoxIcon': 'Media/darkUncheckbox.png',
								'partiallyCheckedBoxIcon': 'Media/darkPartialCheckbox.png',

								'manageUserIcon': 'Media/whiteManageUsers.png',
								'addUserIcon': 'Media/whiteAddUser.png',
								'deleteUserIcon': 'Media/whiteDeleteUser.png',
								'enableUserIcon': 'Media/whiteEnableUser.png',
								'disableUserIcon': 'Media/whiteDisableUser.png',
								'downloadIcon': 'Media/download.png',
								'deleteIcon' : 'Media/delete.png',
								'whiteDeleteIcon' : 'Media/whiteDelete.png',


								'oppositeColorCheckBoxIcon' : 'Media/whiteCheckbox.png',
								'oppositeColorUnCheckBoxIcon': 'Media/whiteUncheckbox.png',
								'oppositeColorPartiallyCheckedBoxIcon': 'Media/whitePartialCheckbox.png',
								'customFilterIcon' : 'Media/customFilter.png'

								},


					'Dark': {	

								'kpiLabelsAndValuesColor' : '#000000',


								'scrollHandleColor': '#50507A',
								'scrollHandleHoverColor': '#D63A88',
								'scrollHandlePressedColor': '#FF007F',
						
								'background': '#2D2D44',
								'scrollAreaBackground' : '#303841',
								'textColor' : '#ffffff',
								'centralWidgetBckgroundColor' : '#27263c',
								'leftMenuBGColor' : '#27263c',
								'highlightColor' : '#AEB9DD',
								'oppositeTextColor' : '#26282C',
								'activeTreeItemBGColor' : 'transparent',
								'treeItemHoverBGColor' :'#27263c',
								'selectedItemColor' : '#ffffff',
								'tableBorderColor' : '#397696',
								'tableHeaderBGColor' : '#AEB9DD',
								'tableAlternateRowColor' : '#33314F',


								'chartBackGroundColor' : '#FBFCFF',

								
								'greenTextColor' : '#00DF00',
								'redTextColor' : '#DF0000',
								'greenBGColor' : '#20A720',
								'redBGColor' : '#bb0000',
								'textColor' : '#ffffff',
								'oppositeTextColor' : '#000000',

								'parentComponentTextColor' : '#ff6600',

								'toolWidgetBodyBackgroundColor': '#F6FBFC',


								'helpQuestionMarkIcon': 'Media/whiteQuestion.png',

								'menuIcon': 'Media/whiteMenu.png',
								'downArrow': 'Media/whiteDownArrow.png',
								'upArrow': 'Media/whiteUpArrow.png',

								'exportTemplateIcon': 'Media/whiteExport.png',
								'importDataIcon': 'Media/whiteImport.png',

								'clearTableFilterIcon': 'Media/whiteClearFilters.png',
								'ExportTableIcon': 'Media/whiteExport.png',
								'refreshIcon' : 'Media/whiteRefresh.png',

								

								'checkBoxIcon': 'Media/whiteCheckbox.png',
								'unCheckBoxIcon': 'Media/whiteUncheckbox.png',
								'partiallyCheckedBoxIcon': 'Media/whitePartialCheckbox.png',

								'manageUserIcon': 'Media/whiteManageUsers.png',
								'addUserIcon': 'Media/whiteAddUser.png',
								'deleteUserIcon': 'Media/whiteDeleteUser.png',
								'enableUserIcon': 'Media/whiteEnableUser.png',
								'disableUserIcon': 'Media/whiteDisableUser.png',
								'downloadIcon': 'Media/download.png',
								'deleteIcon' : 'Media/delete.png',
								'whiteDeleteIcon' : 'Media/whiteDelete.png',


								'oppositeColorCheckBoxIcon' : 'Media/whiteCheckbox.png',
								'oppositeColorUnCheckBoxIcon': 'Media/whiteUncheckbox.png',
								'oppositeColorPartiallyCheckedBoxIcon': 'Media/whitePartialCheckbox.png',
								'customFilterIcon' : 'Media/customFilter.png',

								}


					}
	if self.allThemes.get(self.settings.value('theme')) == None:
		self.settings.setValue('theme', 'Light')


	self.currentTheme = self.allThemes.get(self.settings.value('theme'))



	self.scrollAreaQSS = f'''QAbstractScrollArea
	{{
		background-color: {self.currentTheme.get('scrollAreaBackground')};
	}}

	QScrollBar:vertical {{
					border: none;
					background: {self.currentTheme.get('background')};
					width: 10px;
					margin: 15px 0 15px 0;
					border-radius: 0px;
				}}


				/*  HANDLE BAR VERTICAL */
				QScrollBar::handle:vertical 
				{{
				background-color: {self.currentTheme.get('scrollHandleColor')};
				min-height: 30px;
				border-radius: 5px;
				}}


				QScrollBar::handle:vertical:hover {{
					background-color: {self.currentTheme.get('scrollHandleHoverColor')};
				}}

				QScrollBar::handle:vertical:pressed {{
					background-color: {self.currentTheme.get('scrollHandlePressedColor')};
				}}


				/* BTN TOP - SCROLLBAR */
				QScrollBar::sub-line:vertical {{
								border: none;
								background-color: {self.currentTheme.get('scrollHandlePressedColor')};
								height: 15px;
								border-top-left-radius: 5px;
								border-top-right-radius: 5px;
								subcontrol-position: top;
								subcontrol-origin: margin;
							}}


				QScrollBar::sub-line:vertical:hover {{
								background-color: {self.currentTheme.get('scrollHandleHoverColor')};
							}}


				QScrollBar::sub-line:vertical:pressed {{
								background-color: {self.currentTheme.get('scrollHandlePressedColor')};
							}}

				/* BTN BOTTOM - SCROLLBAR */
				QScrollBar::add-line:vertical {{
								border: none;
								background-color: {self.currentTheme.get('scrollHandlePressedColor')};
								height: 15px;
								border-bottom-left-radius: 5px;
								border-bottom-right-radius: 5px;
								subcontrol-position: bottom;
								subcontrol-origin: margin;
							}}


				QScrollBar::add-line:vertical:hover {{
								background-color: {self.currentTheme.get('scrollHandleHoverColor')};
							}}


				QScrollBar::add-line:vertical:pressed {{ 
								background-color: {self.currentTheme.get('scrollHandlePressedColor')};
							}}


	/* RESET ARROW  vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv	   */
				QScrollBar::up-arrow:vertical, QScrollBar::down-arrow:vertical {{
								background: none;
							}}
				QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical {{
								background: none;
							}}
	/* ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^	   */


		QScrollBar:horizontal {{
					border: none;
					background: {self.currentTheme.get('background')};
					height: 10px;
					margin: 0 15px 0 15px;
					border-radius: 0px;
				}}


				/*  HANDLE BAR VERTICAL */
				QScrollBar::handle:horizontal 
				{{
				background-color: {self.currentTheme.get('scrollHandleColor')};
				min-width: 30px;
				border-radius: 5px;
				}}


				QScrollBar::handle:horizontal:hover {{
					background-color: {self.currentTheme.get('scrollHandleHoverColor')};
				}}

				QScrollBar::handle:horizontal:pressed {{
					background-color: {self.currentTheme.get('scrollHandlePressedColor')};
				}}

				/* BTN RIGHT - SCROLLBAR */
				QScrollBar::sub-line:horizontal {{
								border: none;
								background-color: {self.currentTheme.get('scrollHandlePressedColor')};
								width: 15px;
								border-top-left-radius: 5px;
								border-bottom-left-radius: 5px;
								subcontrol-position: left;
								subcontrol-origin: margin;
							}}


				QScrollBar::sub-line:horizontal:hover {{
								background-color: {self.currentTheme.get('scrollHandleHoverColor')};
							}}


				QScrollBar::sub-line:horizontal:pressed {{
								background-color: {self.currentTheme.get('scrollHandlePressedColor')};
							}}

				/* BTN LEFT - SCROLLBAR */
				QScrollBar::add-line:horizontal {{
								border: none;
								background-color: {self.currentTheme.get('scrollHandlePressedColor')};
								width: 15px;
								border-top-right-radius: 5px;
								border-bottom-right-radius: 5px;
								subcontrol-position: right;
								subcontrol-origin: margin;
							}}


				QScrollBar::add-line:horizontal:hover {{
								background-color: {self.currentTheme.get('scrollHandleHoverColor')};
							}}


				QScrollBar::add-line:horizontal:pressed {{ 
								background-color: {self.currentTheme.get('scrollHandlePressedColor')};
							}}
				'''

	self.lineEditBoxQSS = f'''QLineEdit
						{{
							background-color: {self.currentTheme.get('centralWidgetBckgroundColor')};
							selection-background-color: #AECBFA;
							selection-color: black;
							border: 1px solid {self.currentTheme.get('highlightColor')};
							border-radius: 2px;
							color: {self.currentTheme.get('textColor')};
							padding: 3px;
						}}
						
					QLineEdit:hover
						{{
							border: 2px solid {self.currentTheme.get('highlightColor')};
						}}
					QLineEdit:disabled
						{{
							background-color: #E8E8E8;
							border: 1px solid #B0B0B0;
							color: #808080;
						}}

					QLineEdit[error="true"]
						{{
							border: 2px solid red;
						}}
						'''





	self.mainWindowQSS = f'''*{{
			border: none;
			color: {self.currentTheme.get('textColor')}
	}}
	#centralwidget,#homeBtn,  #mianBodyContent{{
		 background-color: {self.currentTheme.get('centralWidgetBckgroundColor')};
	}}
	#header, #mainBody {{
		 background-color: {self.currentTheme.get('centralWidgetBckgroundColor')};
	}}
	#userBtn{{
		 border: 1px solid #cc5bce;
		 border-radius:  21px;
		 text-align: center;
	}}
	QPushButton{{
		 text-align: left;
		 padding:5px 10px;
		 border-top-left-radius: 10px;
		 border-bottom-left-radius: 10px;
	}}
	QToolButton{{
		 text-align: left;
		 padding:5px 10px;
		 border-top-left-radius: 10px;
		 border-bottom-left-radius: 10px;
	}}
	#homeBtn{{
		 text-align: left;
	}}
	#FRBtn, #RCABtn, #reportsBtn_2, #tasksBtn
	{{
		 border: 2px solid #cc5bce;
		 border-radius:  8px;
		 text-align: center;
		 background-color: #27263c;
	}}

	#FRBtn:hover, #RCABtn:hover, #reportsBtn_2:hover, #tasksBtn:hover
	{{
		 border: 3px solid #cc5bce;
	}}

	QMenuBar
	{{
		 background-color: #fffefe;
		 color: black;
	}}

	QMenuBar::item
	{{
		 background-color: #fffefe;
		 color: black;
	}}

	QMenuBar::item:selected
	{{
		 background-color: #cce8ff;
		 color: black;
	}}

	QMenuBar::item:pressed
	{{
		 background-color: #cce8ff;
		 color: black;
	}}
	QMenu
	{{
		 background-color: #fffefe;
		 color: black;
	}}
	QMenu::item
	{{
		 background-color: #fffefe;
		 color: black;
	}}

	QMenu::item:selected
	{{
		 background-color: #A6D2F6;
		 color: black;
	}}
	QMenu::separator {{
		 height: 1px;
		 background: #D1DBCB;
		 margin-left: 10px;
		 margin-right: 5px;
	}}
	
	QCalendarWidget QAbstractItemView:enabled /* date of actual month */{{
		color: #d7e3e6;
		selection-background-color: #1899da;
		selection-color: #f8f8f8;
		border: 1px solid #658b94;
		padding-bottom:  5px;
	}}

	QCalendarWidget QAbstractItemView:disabled /* date previous/next month */ {{
		color: #6f6969;
	}}

	QCalendarWidget QWidget {{
		alternate-background-color: #0f1924;/*  week and day frame */
		background: #162635;
	}}

	QCalendarWidget #qt_calendar_navigationbar {{
		background: #0a121a;
		padding: 2px;
	}}

	/* year and month */
	QCalendarWidget QToolButton  {{
		color:#d7e3e6;
		padding:2px;
		margin: 2px;
		border-radius:3px;
	}}

	QCalendarWidget QToolButton:hover {{
		border: 1px solid #2a3539;
	}}
	/* oppress hook icon */
	QCalendarWidget QToolButton::menu-indicator {{
		image: none;
	}}

	QCalendarWidget #qt_calendar_nextmonth {{
		qproperty-icon: url(Media/right-arrow.png);
		qproperty-iconSize: 18px;
		background: #0a121a;
	}}

	QCalendarWidget #qt_calendar_prevmonth {{
		qproperty-icon: url(Media/left-arrow.png);
		qproperty-iconSize: 18px;
		background: #0a121a;
	}}

	QCalendarWidget QSpinBox {{
		color: #d7e3e6;
		background-color: #0a121a;
	}}

	''' + self.scrollAreaQSS 


	self.sideMenuTreeQSS = f'''

	QTreeWidget:item
	{{
		padding: 4px;
	}}
	QTreeWidget:item:has-children
	{{
		background: {self.currentTheme.get('highlightColor')};
		color: {self.currentTheme.get('oppositeTextColor')}
	}}
	QTreeWidget:item:selected:has-children
	{{
		background: {self.currentTheme.get('highlightColor')};
		color: {self.currentTheme.get('oppositeTextColor')};
	}}
	QTreeWidget:item:selected:!has-children
	{{
		background: {self.currentTheme.get('activeTreeItemBGColor')};
		color: {self.currentTheme.get('selectedItemColor')};
	}}

	QTreeWidget:item:selected:!has-children:hover
	{{
		background: {self.currentTheme.get('activeTreeItemBGColor')};
		color: {self.currentTheme.get('selectedItemColor')};
	}}
	QTreeWidget:item:!has-children:hover
	{{
		background: {self.currentTheme.get('treeItemHoverBGColor')};
	}}

	QTreeWidget::branch:open:has-children:!has-siblings, QTreeWidget::branch:open:has-children:has-siblings  {{
		image: url(Media/down-arrow.png);
	}}
	QTreeWidget::branch:has-children:!has-siblings:closed, QTreeWidget::branch:closed:has-children:has-siblings {{
			image: url(Media/right-arrow-tree.png);
	}}

	'''




	self.scrollBarQSS = '''QScrollBar:vertical {
					border: none;
					background: #2D2D44;
					width: 10px;
					margin: 15px 0 15px 0;
					border-radius: 0px;
				}
				/*  HANDLE BAR VERTICAL */
				QScrollBar::handle:vertical {
					background-color: #50507A;
					min-height: 30px;
					border-radius: 5px;
				}
				QScrollBar::handle:vertical:hover {
					background-color: #D63A88;
				}
				QScrollBar::handle:vertical:pressed {
					background-color: #FF007F;
				}
				/* BTN TOP - SCROLLBAR */
				QScrollBar::sub-line:vertical {
					border: none;
					background-color: #654A6D;
					height: 15px;
					border-top-left-radius: 5px;
					border-top-right-radius: 5px;
					subcontrol-position: top;
					subcontrol-origin: margin;
				}
				QScrollBar::sub-line:vertical:hover {
					background-color: #FF007F;
				}
				QScrollBar::sub-line:vertical:pressed {
					background-color: #B9005C;
				}

				/* BTN BOTTOM - SCROLLBAR */
				QScrollBar::add-line:vertical {
					border: none;
					background-color: #654A6D;
					height: 15px;
					border-bottom-left-radius: 5px;
					border-bottom-right-radius: 5px;
					subcontrol-position: bottom;
					subcontrol-origin: margin;
				}
				QScrollBar::add-line:vertical:hover {
					background-color: #FF007F;
				}
				QScrollBar::add-line:vertical:pressed { 
					background-color: #B9005C;
				}


	/* RESET ARROW  vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv	   */
				QScrollBar::up-arrow:vertical, QScrollBar::down-arrow:vertical {
					background: none;
				}
				QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical {
					background: none;
				}


	QScrollBar:horizontal {
					border: none;
					background: #2D2D44;
					height: 10px;
					margin: 0 15px 0 15px ;
					border-radius: 0px;
				}
				/*  HANDLE BAR horizontal */
				QScrollBar::handle:horizontal {
					background-color: #50507A;
					min-width: 10px;
					border-radius: 5px;
				}
				QScrollBar::handle:horizontal:hover {
					background-color: #D63A88;
				}
				QScrollBar::handle:horizontal:pressed {
					background-color: #FF007F;
				}
				/* BTN TOP - SCROLLBAR */
				QScrollBar::sub-line:horizontal {
					border: none;
					background-color: #654A6D;
					width: 15px;
					border-top-left-radius: 5px;
					border-bottom-left-radius: 5px;
					subcontrol-position: left;
					subcontrol-origin: margin;
				}
				QScrollBar::sub-line:horizontal:hover {
					background-color: #FF007F;
				}
				QScrollBar::sub-line:horizontal:pressed {
					background-color: #B9005C;
				}

				/* BTN BOTTOM - SCROLLBAR */
				QScrollBar::add-line:horizontal {
					border: none;
					background-color: #654A6D;
					width: 15px;
					border-top-right-radius: 5px;
					border-bottom-right-radius: 5px;
					subcontrol-position: right;
					subcontrol-origin: margin;
				}
				QScrollBar::add-line:horizontal:hover {
					background-color: #FF007F;
				}
				QScrollBar::add-line:horizontal:pressed { 
					background-color: #B9005C;
				}


	/* RESET ARROW  vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv	   */
				QScrollBar::up-arrow:horizontal, QScrollBar::down-arrow:horizontal {
					background: none;
				}
				QScrollBar::add-page:horizontal, QScrollBar::sub-page:horizontal {
					background: none;
				}'''


	self.calenderQSS = '''QCalendarWidget QAbstractItemView:enabled /* date of actual month */{
			color: #d7e3e6;
			selection-background-color: #1899da;
			selection-color: #f8f8f8;
			border: 1px solid #658b94;
			padding-bottom:  5px;
		}

		QCalendarWidget QAbstractItemView:disabled /* date previous/next month */ {
			color: #6f6969;
		}

		QCalendarWidget QWidget {
			alternate-background-color: #0f1924;/*  week and day frame */
			background: #162635;
		}

		QCalendarWidget #qt_calendar_navigationbar {
			background: #0a121a;
			padding: 2px;
		}

		/* year and month */
		QCalendarWidget QToolButton  {
			color:#d7e3e6;
			padding:2px;
			margin: 2px;
			border-radius:3px;
		}

		QCalendarWidget QToolButton:hover {
			border: 1px solid #2a3539;
		}
		/* oppress hook icon */
		QCalendarWidget QToolButton::menu-indicator {
			image: none;
		}

		QCalendarWidget #qt_calendar_nextmonth {
			qproperty-icon: url(Media/right-arrow.png);
			qproperty-iconSize: 18px;
			background: #0a121a;
		}

		QCalendarWidget #qt_calendar_prevmonth {
			qproperty-icon: url(Media/left-arrow.png);
			qproperty-iconSize: 18px;
			background: #0a121a;
		}

		QCalendarWidget QSpinBox {
			color: #d7e3e6;
			background-color: #0a121a;
		}'''

	self.leftMenuQSS = f'''background-color: {self.currentTheme.get('leftMenuBGColor')}

						'''


	self.pushbuttonQSS =  f'''
				QPushButton {{
					outline: none;
					border-radius: 8px;
					border: none;
					text-align: center;
					background: qlineargradient(x1: 0, y1: 0, x2: 1, y2: 0, stop: 0 #6C7AE0, stop: 1 #5A64FA);
					color: #fff;
				}}
				QPushButton:hover {{
					background: qlineargradient(x1: 0, y1: 0, x2: 1, y2: 0, stop: 0 #7387F5, stop: 1 #6D73FF);
				}}
				QPushButton:pressed {{
					background: qlineargradient(x1: 0, y1: 0, x2: 1, y2: 0, stop: 0 #3C3C82, stop: 1 #3C3C82);
				}}
			'''


	self.attachmentQSS = '''QPushButton
						{
							background-color: #27263c;
							border-radius: 0px;
						}

						QPushButton:hover
						{
							text-decoration: underline;
							color: #94E2E4;
						}
						'''


	self.attachmentCrossButtonQSS = '''QPushButton
								{
									background-color: #27263c;
									border-radius: 5px;
									text-align: center;
								}

								QPushButton:hover
								{
									border: 1px solid #cc5bce;
								}'''

	self.activeQSS = '''QToolButton
					{
						background-color: #1b1b27;
						border-left: 3px solid #cc5bce;
						font-weight: bold;
					}'''
					
	self.passiveQSS = '''QToolButton
					{
						background-color: #27263c;
						border-left: 0px ;
						font-weight: ;
					}'''


	self.treeWidgetQSS = '''QTreeView {
		show-decoration-selected: 1;
	}

	QTreeView::item {
		border: 1px solid #d9d9d9;
		border-top-color: transparent;
		border-bottom-color: transparent;
	}

	QTreeView::item:hover {
		background: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 #e7effd, stop: 1 #cbdaf1);
		border: 1px solid #bfcde4;
	}

	QTreeView::item:selected {
		border: 1px solid #567dbc;
	}

	QTreeView::item:selected:active{
		background: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 #6ea1f1, stop: 1 #567dbc);
	}

	QTreeView::item:selected:!active {
		background: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 #6b9be8, stop: 1 #577fbf);
	}

	''' + self.scrollBarQSS


	self.treeWidgetQSS2 = '''QTreeView {
		color:white;
		show-decoration-selected: False;
		background-color: #27263c;
		alternate-background-color: #342445;
	}

	QTreeView::item {
		border-radius: 2px;
		border-top-color: transparent;
		border-bottom-color: transparent;
	}

	QTreeView::item:hover {
		background: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 #e7effd, stop: 1 #cbdaf1);
		border: 1px solid #bfcde4;
		color: black;
	}

	QTreeView::item:selected:active{
		background: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 #6ea1f1, stop: 1 #567dbc);
	}

	QTreeView::item:selected:!active {
		background: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 #6b9be8, stop: 1 #577fbf);
	}

	QTreeWidget::branch:open:has-children:!has-siblings, QTreeWidget::branch:open:has-children:has-siblings  {
		border-image: none;
		image: url(Media/down-arrow2.png);
	}
	QTreeWidget::branch:has-children:!has-siblings:closed, QTreeWidget::branch:closed:has-children:has-siblings {
			border-image: none;
			image: url(Media/right-arrow2.png);
	}

	'''+ self.scrollBarQSS


	self.comboBoxQSS =f'''QComboBox
					{{
						background-color: {self.currentTheme.get('centralWidgetBckgroundColor')};
						border-style: solid;
						border: 1px solid {self.currentTheme.get('highlightColor')};
						border-radius: 4px;
						padding: 3px;
						color: {self.currentTheme.get('textColor')};
					}}
					QComboBox:hover
					{{
						border: 2px solid {self.currentTheme.get('highlightColor')};
					}}
					QComboBox:on
					{{
						selection-background-color: {self.currentTheme.get('highlightColor')};
					}}
					QComboBox QAbstractItemView
					{{
						background-color: {self.currentTheme.get('centralWidgetBckgroundColor')};
						border-radius: 2px;
						border: 1px solid {self.currentTheme.get('textColor')};
						selection-background-color: {self.currentTheme.get('centralWidgetBckgroundColor')};
						selection-color: {self.currentTheme.get('textColor')};
					}}
					QComboBox::drop-down
					{{

						width: 24px;
						border-left-width: 0px;
						border-left-color: darkgray;
						border-left-style: solid; /* just a single line */
						border-top-right-radius: 2px; /* same radius as the QComboBox */
						border-bottom-right-radius: 2px;
					 }}
					QComboBox::down-arrow
					{{
						image: url({self.currentTheme.get('downArrow')});
						width: 14px;
						height: 14px;
					}}
					QComboBox:disabled
						{{
							background-color: #E8E8E8;
							border: 1px solid #B0B0B0;
							color: #808080;
						}}
					QComboBox[error="true"]
						{{
							border: 2px solid red;
						}}
					'''

	self.timeEditBoxQSS =f"""
			QTimeEdit {{
				background-color: {self.currentTheme.get('centralWidgetBckgroundColor')};
				color: {self.currentTheme.get('textColor')};
				border: 1px solid {self.currentTheme.get('highlightColor')};
				border-radius: 4px;
				padding: 3px;
			}}

			QTimeEdit:hover
					{{
						border: 2px solid {self.currentTheme.get('highlightColor')};
					}}

			QTimeEdit::up-button, QTimeEdit::down-button {{
				width: 20px;
				height: 11px;
				background-color: {self.currentTheme.get('highlightColor')};
				border: 1px solid ;
				border-radius: 1px;
			}}

			QTimeEdit::up-button:pressed, QTimeEdit::down-button:pressed {{
				background-color: #777;
			}}

			QTimeEdit::down-arrow {{
				width: 12px;
				height: 12px;
				image: url({self.currentTheme.get('downArrow')});
			}}
			QTimeEdit::up-arrow {{
				width: 12px;
				height: 12px;
				image: url({self.currentTheme.get('upArrow')});
			}}

			QTimeEdit:disabled
			{{
				background-color: #E8E8E8;
				border: 1px solid #B0B0B0;
				color: #808080;
			}}
		"""


	self.dateEditBoxQSS = f"""

		QDateEdit {{
			background-color: {self.currentTheme.get('centralWidgetBckgroundColor')};
			color: {self.currentTheme.get('textColor')};
			border: 1px solid {self.currentTheme.get('highlightColor')};
			border-radius: 4px;
			padding: 3px;
		}}

		QDateEdit:hover
				{{
					border: 2px solid {self.currentTheme.get('highlightColor')};
				}}

		QDateEdit::up-button, QDateEdit::down-button {{
			width: 20px;
			height: 11px;
			background-color: {self.currentTheme.get('highlightColor')};
			border: 1px solid ;
			border-radius: 1px;
		}}

		QDateEdit::drop-down{{
			width: 24px;
			border-left-width: 0px;
			border-left-color: darkgray;
			border-left-style: solid; /* just a single line */
			border-top-right-radius: 2px; /* same radius as the QComboBox */
			border-bottom-right-radius: 2px;
		}}


		QDateEdit::up-button:pressed, QDateEdit::down-button:pressed {{
			background-color: #777;
		}}

		QDateEdit:disabled
			{{
				background-color: #E8E8E8;
				border: 1px solid #B0B0B0;
				color: #808080;
			}}

		QDateEdit::down-arrow, QDateEdit::up-arrow {{
			width: 14px;
			height: 14px;
			image: url({self.currentTheme.get('downArrow')});  /* replace with your arrow image */
		}}"""

	self.tableViewQSS = f'''QTableView
					{{
						border: 1px solid {self.currentTheme.get('tableBorderColor')};
						gridline-color: #505E65;
						background-color: {self.currentTheme.get('centralWidgetBckgroundColor')};
						border-radius: 0px;
						alternate-background-color: #342445;
					}}


					QTableView::item:selected:active{{
						background: #6CA1ED;
						color: {self.currentTheme.get('textColor')};
					}}

					QTableView QTableCornerButton::section {{
					background: #12366B;
					border-left: 1px outset #12366B;
					border-right: 2px outset black;
					border-bottom: 2px outset black;
					border-radius: 1px;
					}}
					''' + self.scrollAreaQSS



	self.tableWidgetQSS = f'''QTableWidget
					{{
						border: 3px solid {self.currentTheme.get('tableHeaderBGColor')};
						gridline-color: transparent;
						background-color: {self.currentTheme.get('centralWidgetBckgroundColor')};
						border-radius: 8px;
						alternate-background-color: {self.currentTheme.get('tableAlternateRowColor')};
					}}

					QTableWidget::item:selected:active{{
						background-color: transparent;
						border: 1px solid {self.currentTheme.get('textColor')};
						color: {self.currentTheme.get('textColor')};
					}}


					QTableWidget::item:selected:!active{{
						background-color: {self.currentTheme.get('centralWidgetBckgroundColor')};
						color: {self.currentTheme.get('textColor')};
					}}

					QTableWidget QTableCornerButton::section {{
					background: {self.currentTheme.get('tableHeaderBGColor')};
					border-radius: 0px;
					}}

					''' + self.scrollAreaQSS



	self.headerHorizontalQSS = f'''::section
					{{
					color: {self.currentTheme.get('oppositeTextColor')};
					font-weight: bold;
					background: {self.currentTheme.get('tableHeaderBGColor')};
					padding: 10px;
					border: 0px;
					}}
					QHeaderView::down-arrow {{
					image: url(Media//down-arrow-small.png);

					}}

					QHeaderView::up-arrow {{
					image: url(Media//up-arrow-small.png);
					}}

					'''


	self.headerVerticalQSS = f'''::section
					{{
					color: {self.currentTheme.get('oppositeTextColor')};
					font-weight: bold;
					background: {self.currentTheme.get('tableHeaderBGColor')};
					padding: 4px 2px 4px 2px;
					border: 0px;
					}}
					QHeaderView::down-arrow {{
					image: url(Media//down-arrow-small.png);

					}}

					QHeaderView::up-arrow {{
					image: url(Media//up-arrow-small.png);
					}}

					'''

					#Background-color: #BE0101;

					#QHeaderView
					#{
					#	font: Times;
					#	color: DodgerBlue;
					#	font-weight: bold;
					#	background: black;
	#
					#}

	self.toolBarQSS = '''QToolBar {
					spacing: 10px; /* spacing between items in the tool bar */
					}
					'''



	self.tabWidgetQSS = '''
	QTabWidget{
		border: 0px transparent black;
	}

	QTabWidget::pane {
		border: 1px solid #76797C;
		padding: 5px;
		margin: 0px;
	}

	QTabWidget::tab-bar {
		left: 20px; /* move to the right by 20px */
	}

	QTabBar
	{
		qproperty-drawBase: 0;
		border-radius: 3px;
	}

	QTabBar::focus
	{
		border: 0px transparent black;
		color: black;
	}

	QTabBar::hover
	{
		border: 0px transparent black;
		color: black;
	}



	/* TOP TABS */
	QTabBar::tab:top {
		color: #eff0f1;
		border: 1px solid #76797C;
		border-bottom: 1px transparent black;
		background-color: #323232;
		padding: 5px;
		min-width: 50px;
		border-top-left-radius: 2px;
		border-top-right-radius: 2px;
	}

	QTabBar::tab:top:!selected
	{
		color: #eff0f1;
		background-color: #54575B;
		border: 1px solid #76797C;
		border-bottom: 1px transparent black;
		border-top-left-radius: 2px;
		border-top-right-radius: 2px;
	}

	QTabBar::tab:top:!selected:hover {
		background-color: #D1DBCB;
		color: black;
	}

	'''



	


	self.checkBoxQSS = f"""
			QCheckBox {{
				padding: 3px;
			}}

			QCheckBox::indicator {{
				/* Style for the unchecked state */
				image: url({self.currentTheme.get('unCheckBoxIcon')})
			}}

			QCheckBox::indicator:checked {{
				/* Style for the checked state */

				image: url({self.currentTheme.get('checkBoxIcon')})
			}}

			"""

	####### styleSheet configuration for create report pages:

	self.listWidgetQSS = f""" QListWidget 
 						{{
 							background-color: {self.currentTheme.get('centralWidgetBckgroundColor')};
 							color: {self.currentTheme.get('textColor')};
 							border: 2px solid #a2a4a7;
 							border-radius: 10px;
 						}}
 						QListWidget::item {{
 							padding: 5px;
 						}}
 						QListWidget:item:selected, QListWidget:branch:hover
 						{{
 							background: transparent;
 							outline: none;  /* Remove the dotted outline */
 						}}
 						QListWidget::item:selected:active{{
 						border: 1px solid {self.currentTheme.get('highlightColor')};
 						color: {self.currentTheme.get('textColor')};
 						outline: none;
 						}}


 						QListWidget::item:selected:!active{{
 							background-color: {self.currentTheme.get('activeTreeItemBGColor')};
 							color: {self.currentTheme.get('textColor')};
 						}}

 						QListWidget::item:selected {{
 							border: 0px transparent black;
 							color: black;
 							background-color: {self.currentTheme.get('activeTreeItemBGColor')};
 							border-radius: 5px;

						}}

 						QListWidget:item:!has-children:hover
 						{{
 							background: {self.currentTheme.get('treeItemHoverBGColor')};
 							border-radius: 5px;
 						}}
 						QListWidget::focus {{
 						outline: none;  /* Remove the focus outline */					   
 						}}"""



	self.stackedWidgetQSS = f'''background-color: {self.currentTheme.get('centralWidgetBckgroundColor')};
								color: {self.currentTheme.get('textColor')};
								border-radius: 10px;
								border: 2px  #a2a4a7;

								'''




	self.widgetQSS = f'''background-color: {self.currentTheme.get('centralWidgetBckgroundColor')};
								color: {self.currentTheme.get('textColor')};
								border-radius: 10px;
								border: 2px  #a2a4a7;

								'''




	self.dateTimeEditBoxQSS = f'''QDateTimeEdit
					{{
						background-color:  {self.currentTheme.get('centralWidgetBckgroundColor')};
						selection-background-color: #AECBFA;
						selection-color: black;
						border: 1px solid {self.currentTheme.get('highlightColor')};
						border-radius: 2px;
						color: {self.currentTheme.get('textColor')};
					}}
					QDateTimeEdit::down-arrow
					{{
						image: url({self.currentTheme.get('downArrow')});
					}}
					QDateTimeEdit::drop-down
					{{
						width: 24px;
						color: {self.currentTheme.get('textColor')};
						border-left-width: 0px;
						padding-left: 1px;
						padding-right: 3px;

					 }}
					QDateTimeEdit:hover
					{{
						 border: 2px solid {self.currentTheme.get('highlightColor')};
					}}
					QDateTimeEdit:on
					{{
						 padding-top: 6px;
						 padding-left: 4px;
						 selection-background-color: #AECBFA;
					}}

					QDateTimeEdit:disabled
						{{
							background-color: #E8E8E8;
							border: 1px solid #B0B0B0;
							color: #808080;
						}}

					QDateTimeEdit QAbstractItemView
					{{
						 background-color: #1e1e1e;
						 border-radius: 2px;
						 border: 2px solid {self.currentTheme.get('highlightColor')};
						 selection-background-color: #AECBFA;
						 color :{self.currentTheme.get('textColor')};
					}}
				'''


	self.bigPushButtonQSS = '''QPushButton
						{
							border: 2px solid #cc5bce;
							border-radius:  8px;
							text-align: center;
							background-color: #27263c;
							font-weight: bold;
									color: white;
						}
					
						QPushButton:hover
						{
							border: 3px solid #cc5bce;
						}'''


	self.spinBoxQSS =f"""
			QSpinBox {{
				background-color: {self.currentTheme.get('centralWidgetBckgroundColor')};
				color: {self.currentTheme.get('textColor')};
				border: 1px solid {self.currentTheme.get('highlightColor')};
				border-radius: 4px;
				padding: 3px;
			}}

			QSpinBox:hover
					{{
						border: 2px solid {self.currentTheme.get('highlightColor')};
					}}

			QSpinBox::up-button, QSpinBox::down-button {{
				width: 20px;
				height: 11px;
				background-color: {self.currentTheme.get('highlightColor')};
				border: 1px solid ;
				border-radius: 1px;
			}}

			QSpinBox::up-button:pressed, QSpinBox::down-button:pressed {{
				background-color: #777;
			}}

			QSpinBox::down-arrow {{
				width: 12px;
				height: 12px;
				image: url({self.currentTheme.get('downArrow')});
			}}
			QSpinBox::up-arrow {{
				width: 12px;
				height: 12px;
				image: url({self.currentTheme.get('upArrow')});
			}}

			QSpinBox:disabled
			{{
				background-color: #E8E8E8;
				border: 1px solid #B0B0B0;
				color: #808080;
			}}
		"""


	self.textEditBoxQSS = f'''QTextEdit
						{{
							background-color: {self.currentTheme.get('centralWidgetBckgroundColor')};
							selection-background-color: #AECBFA;
							selection-color: black;
							border: 1px solid {self.currentTheme.get('highlightColor')};
							border-radius: 2px;
							color: {self.currentTheme.get('textColor')};
						}}
						
						QTextEdit:hover
						{{
							border: 2px solid {self.currentTheme.get('highlightColor')};
						}}
						QTextEdit:disabled
						{{
							background-color: #E8E8E8;
							border: 1px solid #B0B0B0;
							color: #808080;
						}}
						QTextEdit[error="true"]
						{{
							border: 2px solid red;
						}}'''

	self.toolTipQSS = """
					QToolTip {
						background-color: #ffffff;
						color: black;
						border: 1px solid #000;
						font-size: 12px;
					}
				"""


	# self.calenderQSS = f'''QCalendarWidget QAbstractItemView:enabled /* date of actual month */{{
	# 	color: {self.currentTheme.get('textColor')};
	# 	background-color:white;}}
	
	# QCalendarWidget QAbstractItemView:disabled /* date previous/next month */ {{
	# 	color: #6f6969;
	# }}

	# '''

	self.toolBoxQSS = """
			QToolBox::tab {
				background-color: #3498db; /* Header color */
				color: white;
				border-radius: 5px;
				padding: 5px;
			}

			QToolBox::tab:selected {
				background-color: #2980b9; /* Header color when selected */
			}

			QToolBox::tab:hover {
				background-color: #2980b9; /* Header color on hover */
			}

			QToolBox::tab:!selected {
				background-color: #2c3e50; /* Header color when not selected */
			}

			QToolBox::tab:disabled {
				color: #7f8c8d; /* Header color when disabled */
			}

			QToolBox::tab-page {
				background-color: #ecf0f1; /* Body color */
				border: 1px solid #bdc3c7; /* Border color */
				border-radius: 15px;
				padding: 10px;
			}
		"""

	self.removeTab_X_QSS =  '''QPushButton {
								border-radius: 8px;
								text-align: center;
								background: #D12C2C;
								color: #fff;}
							'''