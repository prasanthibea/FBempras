from PySide6.QtWidgets import QLabel, QWidget, QVBoxLayout, QSpacerItem, QDialog, QMessageBox, QSizePolicy, QFileDialog, QHBoxLayout, QScrollBar, QDateEdit, QScrollArea, QTabWidget, QTableWidget, QTableWidgetItem, QAbstractItemView, QFormLayout, QLineEdit, QTextEdit, QComboBox, QGridLayout, QPushButton, QSpinBox
from PySide6.QtCore import Qt, QDate, QDateTime
from PySide6.QtGui import QIcon, QBrush, QColor
from datetime import date, datetime
import shutil
import os
# from ncr import *

def ncrformUI(self):
	from PySide6.QtWidgets import QApplication, QDateEdit	
	from functions import logErrors
	# from PySide6.QtCore import QDate, QDateTime

	# self.mainVerticalLayout_NcrForm.addWidget(QLabel('NONCONFORMITY REPORT'), alignment = Qt.AlignCenter)	
	
	NCRHLayout = QHBoxLayout()
	self.mainVerticalLayout_NcrForm.addLayout(NCRHLayout)
	
	NCRFormLayout1 = QFormLayout()
	NCRFormLayout2 = QFormLayout()

	NCRHLayout.addLayout(NCRFormLayout1)
	spacer_item = QSpacerItem(int(0.01 * QApplication.primaryScreen().availableGeometry().width()), 5, QSizePolicy.Fixed, QSizePolicy.Minimum)
	NCRHLayout.addItem(spacer_item)
	NCRHLayout.addLayout(NCRFormLayout2)
	

	# self.createPushButton('ckdmndl_NCR', 'CKD','', int(0.045 * QApplication.primaryScreen().availableGeometry().width()))
	self.ckdmndl_NCR = QPushButton('CKD')
	self.ckdmndl_NCR.setFixedWidth(37)
	self.ckdmndl_NCR.setFixedHeight(25)
	self.ckdmndl_NCR.setStyleSheet('border-radius: 2px; background:white; border: 1px solid grey;padding: 2px;')

	self.current_ncr = QLabel()
	self.reportno = QLabel('NCR-BEML MRS1-T&C-')

	# self.updateReportNumber()


	self.cursor.execute("SELECT report_no FROM ncr ORDER BY id DESC LIMIT 1")
	reporesul = self.cursor.fetchone()
	# print(reporesul)

	if reporesul:
		report_no = reporesul[0]  # Extract the first item from the tuple
		# print(report_no)

		parts = report_no.split('-')  # Now split the string based on '-'
		cur_number = int(parts[-1].strip())  # Assuming the number is at the end
		newnumber = cur_number + 1
		# print(f"Newreportnumber: - {newnumber}")
		formatted_report_no = f"-{newnumber}"
		self.current_ncr.setText(formatted_report_no)
	else:
		self.current_ncr.setText("-1")
		print("No report number found.")



	self.createLineEditBox('projectLineEdit_NCR')
	self.createLineEditBox('productLineEdit_NCR')
	self.createNumberLineEditBox('quantityLineEdit_NCR')
	self.createLineEditBox('supplierLineEdit_NCR')
	self.createLineEditBox('detectionLineEdit_NCR')
	self.createComboBox2(['CKD', 'Mandala'], 'placeComboBox_NCR')
	self.createLineEditBox('storedLineEdit_NCR')
	self.createComboBox2(['Major', 'Minor'],'severityComboBox_NCR')
	self.createComboBox2(['Before Installation', 'Installed', 'Disassembled', 'Before receiving'], 'materialstatusComboBox_NCR')
	self.createLineEditBox('distributiontoLineEdit_NCR')
	self.createCheckableComboBox(self.trainsetsList, 'trainComboBox_NCR')
	self.createCheckableComboBox(self.carsList, 'carComboBox_NCR')
	self.createLineEditBox('assydwgnoLineEdit_NCR')
	self.createNumberLineEditBox('revLineEdit_NCR')
	self.createLineEditBox('partnoLineEdit_NCR')
	self.createLineEditBox('assysnoLineEdit_NCR')
	self.createLineEditBox('partserialnoLineEdit_NCR')
	self.createLineEditBox('blnoLineEdit_NCR')
	self.createLineEditBox('invoicenoLineEdit_NCR')
	self.createLineEditBox('responsiblepartyLineEdit_NCR')
	self.createComboBox2(['Before Installation', 'Installed', 'Disassembled', 'Before receiving'], 'materialstatusComboBox_NCR')
	self.createTextEditBox('descriptionofnonconform_NCR')
	self.createAttachmentWidget('attacheddocuments1_NCR')

	# self.createDateEditBox('date_NCR')

	current_date = QDate.currentDate()
	start_of_month = QDate(current_date.year(), current_date.month(), 1)
	self.date_NCR = QDateEdit()
	self.date_NCR.setDate(start_of_month)
	self.date_NCR.setStyleSheet(self.dateEditBoxQSS)
	self.date_NCR.setCalendarPopup(True)
	self.date_NCR.setDisplayFormat("dd-MM-yyyy")

	
	# self.createDateEditBox('date_NCR')
	# current_date = QDate.currentDate()
	# self.date_NCR.setMinimumDate(QDate(current_date.year(), current_date.month(), 1))

	self.createLineEditBox('teamLineEdit_NCR')
	self.createLineEditBox('issuedbyLineEdit_NCR')
	self.createLineEditBox('reviewedbyLineEdit_NCR')
	self.createLineEditBox('approvedbyLineEdit_NCR')
	self.createTextEditBox('causeofnonconformity_NCR')
	self.createAttachmentWidget('attacheddocuments2_NCR')
	self.createTextEditBox('correctionorcorrectiveactionLineEdit_NCR')
	self.createTextEditBox('actionplan_NCR')
	self.createAttachmentWidget('attacheddocuments3_NCR')
	# self.createDateEditBox('date1_NCR')
	self.date1_NCR = QDateEdit()
	self.date1_NCR.setDate(start_of_month)
	self.date1_NCR.setStyleSheet(self.dateEditBoxQSS)
	self.date1_NCR.setCalendarPopup(True)
	self.date1_NCR.setDisplayFormat("dd-MM-yyyy")

	self.createLineEditBox('actionbyLineEdit_NCR')
	self.createLineEditBox('issuedby1LineEdit_NCR')
	self.createLineEditBox('reviewedby1LineEdit_NCR')
	self.createLineEditBox('approvedby1LineEdit_NCR')
	self.createComboBox2(['Claim', 'Holding', 'Use as is', 'Rework', 'Waiver', 'Scrap', 'Repair'], 'decisionComboBox_NCR')
	self.createComboBox2(['Yes', 'No'], 'repairprocedureComboBox_NCR')	
	self.createLineEditBox('name1LineEdit_NCR')

	# self.createDateEditBox('date2_NCR')
	# self.date2_NCR.setMinimumDate(QDate(current_date.year(), current_date.month(), 1))
	self.date2_NCR = QDateEdit()
	self.date2_NCR.setDate(start_of_month)
	self.date2_NCR.setStyleSheet(self.dateEditBoxQSS)
	self.date2_NCR.setCalendarPopup(True)
	self.date2_NCR.setDisplayFormat("dd-MM-yyyy")
	
	self.createLineEditBox('sign1LineEdit_NCR')
	self.createLineEditBox('name2LineEdit_NCR')

	# self.createDateEditBox('date3_NCR')
	# self.date3_NCR.setMinimumDate(QDate(current_date.year(), current_date.month(), 1))
	self.date3_NCR = QDateEdit()
	self.date3_NCR.setDate(start_of_month)
	self.date3_NCR.setStyleSheet(self.dateEditBoxQSS)
	self.date3_NCR.setCalendarPopup(True)
	self.date3_NCR.setDisplayFormat("dd-MM-yyyy")

	self.createLineEditBox('sign2LineEdit_NCR')
	self.createComboBox2(['Internal', 'Customer'], 'approvalscopComboBox_NCR')     	
	self.createLineEditBox('entityLineEdit_NCR')
	self.createLineEditBox('positionLineEdit_NCR')
	self.createLineEditBox('name3LineEdit_NCR')

	# self.createDateEditBox('date4_NCR')
	# self.date4_NCR.setMinimumDate(QDate(current_date.year(), current_date.month(), 1))
	self.date4_NCR = QDateEdit()
	self.date4_NCR.setDate(start_of_month)
	self.date4_NCR.setStyleSheet(self.dateEditBoxQSS)
	self.date4_NCR.setCalendarPopup(True)
	self.date4_NCR.setDisplayFormat("dd-MM-yyyy")
	
	self.createLineEditBox('sign3LineEdit_NCR')
	self.createAttachmentWidget('attacheddocuments4_NCR')
	self.attacheddocuments4_NCR.fileListWidget.setMinimumHeight(140)


	ckmandlhboxlayout_NCR = QHBoxLayout()
	ckmandlhboxlayout_NCR.addWidget(self.reportno, alignment = Qt.AlignRight )
	ckmandlhboxlayout_NCR.addWidget(self.ckdmndl_NCR, alignment = Qt.AlignLeft )
	ckmandlhboxlayout_NCR.addWidget(self.current_ncr,alignment = Qt.AlignLeft)
	ckmandlhboxlayout_NCR.addItem(QSpacerItem(1, 0, QSizePolicy.Expanding, QSizePolicy.Minimum))

	NCRFormLayout1.addRow('Report No: <font color="red">*</font>', ckmandlhboxlayout_NCR)
	NCRFormLayout1.addRow('Project:', self.projectLineEdit_NCR)
	NCRFormLayout1.addRow('Product:', self.productLineEdit_NCR)
	NCRFormLayout1.addRow('Quantity: <font color="red">*</font>', self.quantityLineEdit_NCR)
	
	NCRFormLayout1.addRow('Supplier: <font color="red">*</font>', self.supplierLineEdit_NCR)
	NCRFormLayout1.addRow('Detection: <font color="red">*</font>', self.detectionLineEdit_NCR)
	NCRFormLayout1.addRow('Place:', self.placeComboBox_NCR)
	NCRFormLayout1.addRow('Stored at:', self.storedLineEdit_NCR)	
	NCRFormLayout1.addRow('Severity:', self.severityComboBox_NCR)
	# NCRFormLayout1.addRow('Material status:', self.materialstatusComboBox_NCR)
	NCRFormLayout1.addRow('Distribution to: <font color="red">*</font>', self.distributiontoLineEdit_NCR)
	NCRFormLayout1.addRow('Trainset: <font color="red">*</font>', self.trainComboBox_NCR)
	NCRFormLayout1.addRow('Car:', self.carComboBox_NCR)

	NCRFormLayout1.addRow('Assy dwg no:', self.assydwgnoLineEdit_NCR)
	NCRFormLayout1.addRow('Rev:', self.revLineEdit_NCR)
	NCRFormLayout1.addRow('Part No:', self.partnoLineEdit_NCR)

	NCRFormLayout1.addRow('Assy Serial No:', self.assysnoLineEdit_NCR)
	NCRFormLayout1.addRow('Part Serial No:', self.partserialnoLineEdit_NCR)


	NCRFormLayout1.addRow('B/L No:', self.blnoLineEdit_NCR)
	NCRFormLayout1.addRow('Invoice no:', self.invoicenoLineEdit_NCR)
	NCRFormLayout1.addRow('Responsible party: <font color="red">*</font>', self.responsiblepartyLineEdit_NCR)
	NCRFormLayout1.addRow('Material status:', self.materialstatusComboBox_NCR)

	NCRFormLayout1.addRow('Description of non-conform: <font color="red">*</font>', self.descriptionofnonconform_NCR)
	NCRFormLayout1.addRow('Attached documents (if any):', self.attacheddocuments1_NCR)

	NCRFormLayout1.addRow('Date: <font color="red">*</font>' , self.date_NCR)
	NCRFormLayout1.addRow('Team :', self.teamLineEdit_NCR)
	NCRFormLayout1.addRow('Issued by: <font color="red">*</font>', self.issuedbyLineEdit_NCR)
	NCRFormLayout1.addRow('Reviewed by: <font color="red">*</font>', self.reviewedbyLineEdit_NCR)
	NCRFormLayout1.addRow('Approved by: <font color="red">*</font>', self.approvedbyLineEdit_NCR)

	NCRFormLayout1.addRow('Cause of nonconformity: ', self.causeofnonconformity_NCR)
	NCRFormLayout2.addRow('Attached documents (if any):', self.attacheddocuments2_NCR)
	NCRFormLayout2.addRow('A. Correction/corrective action result: <font color="red">*</font>', self.correctionorcorrectiveactionLineEdit_NCR)
	NCRFormLayout2.addRow('B. Action Plan: ', self.actionplan_NCR)
	NCRFormLayout2.addRow('Attached documents (if any):', self.attacheddocuments3_NCR)
	NCRFormLayout2.addRow('Date: ' , self.date1_NCR)
	NCRFormLayout2.addRow('Action by:', self.actionbyLineEdit_NCR)
	NCRFormLayout2.addRow('Issued by:', self.issuedby1LineEdit_NCR)
	NCRFormLayout2.addRow('Reviewed by:', self.reviewedby1LineEdit_NCR)
	NCRFormLayout2.addRow('Approved by:', self.approvedby1LineEdit_NCR)
	NCRFormLayout2.addRow('Decision :', self.decisionComboBox_NCR)
	NCRFormLayout2.addRow('Repair procedure:', self.repairprocedureComboBox_NCR)
	NCRFormLayout2.addRow(QLabel('Verification on correction:	'))
	NCRFormLayout2.addRow('            Names:', self.name1LineEdit_NCR)
	NCRFormLayout2.addRow('            Date:' , self.date2_NCR)
	NCRFormLayout2.addRow('            Sign:', self.sign1LineEdit_NCR)
	NCRFormLayout2.addRow(QLabel('Verification on corrective action:	'))
	NCRFormLayout2.addRow('            Name:', self.name2LineEdit_NCR)
	NCRFormLayout2.addRow('            Date: ' , self.date3_NCR)
	NCRFormLayout2.addRow('            Sign:', self.sign2LineEdit_NCR)
	NCRFormLayout2.addRow('Approval Scope:', self.approvalscopComboBox_NCR)

	NCRFormLayout2.addRow('Entity:', self.entityLineEdit_NCR)
	NCRFormLayout2.addRow('Position:', self.positionLineEdit_NCR)
	NCRFormLayout2.addRow('Name:', self.name3LineEdit_NCR)
	NCRFormLayout2.addRow('Date:', self.date4_NCR)
	NCRFormLayout2.addRow('Sign:', self.sign3LineEdit_NCR)
	NCRFormLayout2.addRow('Signed NCR:', self.attacheddocuments4_NCR)


	def toggleLabelText():
		currentText = self.ckdmndl_NCR.text()
		if currentText == 'CKD':
			self.ckdmndl_NCR.setText('Mandala')		
			self.ckdmndl_NCR.setFixedWidth(65)	
		else:
			self.ckdmndl_NCR.setText('CKD')
			self.ckdmndl_NCR.setFixedWidth(37)	
	self.ckdmndl_NCR.clicked.connect(toggleLabelText)

	

	# def displaytext():
	# 	currentText = self.reportno.text()
	# 	if currentText == 'NCR-BEML MRS1-T&C-':
	# 		self.reportno.setText('NCR-BEML MRS1-T&C-Mandala')
	# 	else:
	# 		self.reportno.setText('NCR-BEML MRS1-T&C-')
	# self.ckdmndl_NCR.clicked.connect(displaytext)


	self.createPushButton('submit_NCR', 'SUBMIT', '', int(0.075 * QApplication.primaryScreen().availableGeometry().width()))
	self.createPushButton('cancel_NCR', 'CANCEL', '', int(0.075 * QApplication.primaryScreen().availableGeometry().width()))

	ncrHboxlayout = QHBoxLayout()
	ncrHboxlayout.addWidget(self.submit_NCR, alignment = Qt.AlignRight)
	ncrHboxlayout.addWidget(self.cancel_NCR, alignment = Qt.AlignLeft)

	self.mainVerticalLayout_NcrForm.addLayout(ncrHboxlayout)
	

	########################################################################

	self.allFields = [self.reportno, self.projectLineEdit_NCR, self.productLineEdit_NCR, self.quantityLineEdit_NCR, self.supplierLineEdit_NCR,
					self.detectionLineEdit_NCR,self.placeComboBox_NCR, self.storedLineEdit_NCR, self.severityComboBox_NCR,self.distributiontoLineEdit_NCR,
					self.trainComboBox_NCR, self.carComboBox_NCR, self.assydwgnoLineEdit_NCR, self.revLineEdit_NCR, self.partnoLineEdit_NCR,
					self.assysnoLineEdit_NCR, self.partserialnoLineEdit_NCR, self.blnoLineEdit_NCR, self.invoicenoLineEdit_NCR, self.responsiblepartyLineEdit_NCR,
					self.materialstatusComboBox_NCR, self.descriptionofnonconform_NCR,self.attacheddocuments1_NCR, self.date_NCR, self.teamLineEdit_NCR, 
					self.issuedbyLineEdit_NCR, self.reviewedbyLineEdit_NCR, self.approvedbyLineEdit_NCR, self.causeofnonconformity_NCR, 
					self.attacheddocuments2_NCR, self.correctionorcorrectiveactionLineEdit_NCR, self.actionplan_NCR, self.attacheddocuments3_NCR, 
					self.date1_NCR, self.actionbyLineEdit_NCR, self.issuedby1LineEdit_NCR, self.reviewedby1LineEdit_NCR, self.approvedby1LineEdit_NCR, 
					self.decisionComboBox_NCR, self.repairprocedureComboBox_NCR, self.name1LineEdit_NCR, self.date2_NCR, self.sign1LineEdit_NCR, 
					self.name2LineEdit_NCR, self.date3_NCR, self.sign2LineEdit_NCR, self.approvalscopComboBox_NCR, self.entityLineEdit_NCR, 
					self.positionLineEdit_NCR, self.name3LineEdit_NCR, self.date4_NCR, self.sign3LineEdit_NCR, self.attacheddocuments4_NCR]

	# self.submit_NCR.clicked.connect(self.onClickingsubmit_Ncr)				
	def onClickingsubmit_Ncr():
		print('Submitting form....................')
		mandatoryVerification_NCR = True
		mandatoryIndexesNcr = [0, 3, 4, 5, 9, 10, 19, 21, 23, 25, 26, 27, 30]
	
		ncrFormData =[]
		# ReportNo = f'{self.reportno.text()}{self.ckdmndl_NCR.text()}{self.current_ncr.text()}'
		
		# ncrFormData = [Attacheddocuments1, Attacheddocuments2, Attacheddocuments3, Signedncr, self.user_id]
		for i, wid in enumerate(self.allFields):
			if i ==0:
				ReportNo = f'{self.reportno.text()}{self.ckdmndl_NCR.text()}{self.current_ncr.text()}'
				ncrFormData.append(ReportNo)
				print(ncrFormData)
			else:	
				if isinstance(wid, QComboBox):
					if wid.isEnabled():
						if wid.currentText() == '':
							ncrFormData.append(None)
							if i in mandatoryIndexesNcr:
								mandatoryVerification_NCR = False
								wid.setProperty("error", True)
								wid.setStyleSheet(self.comboBoxQSS)

						else:
							ncrFormData.append(wid.currentText())
							wid.setProperty("error", False)
							wid.setStyleSheet(self.comboBoxQSS)


				elif isinstance(wid, QLineEdit):
					# if wid.isEnabled():
					# 	text_value = wid.text().strip()
					# 	if text_value == '':
					# 		ncrFormData.append(None)
					# 		if i in mandatoryIndexesNcr:
					# 			mandatoryVerification_NCR = False
					# 			wid.setProperty("error", True)
					# 			wid.setStyleSheet(self.lineEditBoxQSS)

					# 	else:
					# 		ncrFormData.append(text_value)
					# 		wid.setProperty("error", False)
					# 		wid.setStyleSheet(self.lineEditBoxQSS)

					if wid.text() == '':
						ncrFormData.append(None)
						if i in mandatoryIndexesNcr:
							mandatoryVerification_NCR = False
							wid.setProperty("error", True)
							wid.setStyleSheet(self.lineEditBoxQSS)
					else:
						if wid.text().isdigit():
							ncrFormData.append(int(wid.text()))
						else:
							ncrFormData.append(wid.text()) 	

						wid.setProperty("error", False)
						wid.setStyleSheet(self.lineEditBoxQSS)
	

				elif isinstance(wid, QTextEdit):
					if wid.isEnabled():
						text_value = wid.toPlainText().strip()
						if text_value == '':
							ncrFormData.append(None)
							if i in mandatoryIndexesNcr:
								mandatoryVerification_NCR = False
								wid.setProperty("error", True)
								wid.setStyleSheet(self.textEditBoxQSS)		

						else:
							ncrFormData.append(text_value)
							wid.setProperty("error", False)
							wid.setStyleSheet(self.textEditBoxQSS)

				# elif isinstance(wid, QLabel):
				# 	ReportNo = f'{self.reportno.text()}{self.ckdmndl_NCR.text()}{self.current_ncr.text()}'
				# 	ncrFormData.append(ReportNo)

				elif isinstance(wid, QDateEdit):
					qdate = wid.date()
					# ncrFormData.append(date_)
					py_date = date(qdate.year(), qdate.month(), qdate.day())  # Convert QDate to Python date
					ncrFormData.append(py_date)		

					# date_str = wid.date().toString("yyyy-MM-dd")
					# ncrFormData.append(date_str)


		dest_folder = "C:\\ProgramData\\RAMSify\\Attachments"
		# selected_files = [self.mianAttachment_CM.fileListWidget.item(i).text() for i in range(self.mianAttachment_CM.fileListWidget.count())]
		selected_files1 = [self.attacheddocuments1_NCR.fileListWidget.item(i).text() for i in range(self.attacheddocuments1_NCR.fileListWidget.count())]
		selected_files2 = [self.attacheddocuments2_NCR.fileListWidget.item(i).text() for i in range(self.attacheddocuments2_NCR.fileListWidget.count())]
		selected_files3	= [self.attacheddocuments3_NCR.fileListWidget.item(i).text() for i in range(self.attacheddocuments3_NCR.fileListWidget.count())]		
		selected_files4	= [self.attacheddocuments4_NCR.fileListWidget.item(i).text() for i in range(self.attacheddocuments4_NCR.fileListWidget.count())]		

		listOfAttachmentsNames1 = []
		for f, file_path in enumerate(selected_files1):
			if os.path.exists(file_path):
				file_name = os.path.basename(file_path)
				file_extension = os.path.splitext(file_name)[1]
				current_datetime = datetime.now().strftime("%Y%m%d%H%M%S")
				
				fVal = str(f)
				if len(str(f)) == 1:
					fVal = '00'+str(f)
				elif len(str(f)) == 2:
					fVal = '0'+str(f)
				else:
					fVal = str(f)

				new_file_name = f"{os.path.splitext(file_name)[0]}_{current_datetime}{fVal}{file_extension}"
				listOfAttachmentsNames1.append(new_file_name)

				dest_path = os.path.join(dest_folder, new_file_name)
				shutil.copy(file_path, dest_path)
			else:
				QMessageBox.warning(self, "Warning", f"File {file_path} does not exist.", QMessageBox.Ok)
			
		listOfAttachmentsNames2 = []
		for f, file_path in enumerate(selected_files2):
			if os.path.exists(file_path):
				file_name = os.path.basename(file_path)
				file_extension = os.path.splitext(file_name)[1]
				current_datetime = datetime.now().strftime("%Y%m%d%H%M%S")
				
				fVal = str(f)
				if len(str(f)) == 1:
					fVal = '00'+str(f)
				elif len(str(f)) == 2:
					fVal = '0'+str(f)
				else:
					fVal = str(f)

				new_file_name = f"{os.path.splitext(file_name)[0]}_{current_datetime}{fVal}{file_extension}"
				listOfAttachmentsNames2.append(new_file_name)

				dest_path = os.path.join(dest_folder, new_file_name)
				shutil.copy(file_path, dest_path)
			else:
				QMessageBox.warning(self, "Warning", f"File {file_path} does not exist.", QMessageBox.Ok)
		

		listOfAttachmentsNames3 = []
		for f, file_path in enumerate(selected_files3):
			if os.path.exists(file_path):
				file_name = os.path.basename(file_path)
				file_extension = os.path.splitext(file_name)[1]
				current_datetime = datetime.now().strftime("%Y%m%d%H%M%S")
				
				fVal = str(f)
				if len(str(f)) == 1:
					fVal = '00'+str(f)
				elif len(str(f)) == 2:
					fVal = '0'+str(f)
				else:
					fVal = str(f)

				new_file_name = f"{os.path.splitext(file_name)[0]}_{current_datetime}{fVal}{file_extension}"
				listOfAttachmentsNames3.append(new_file_name)

				dest_path = os.path.join(dest_folder, new_file_name)
				shutil.copy(file_path, dest_path)
			else:
				QMessageBox.warning(self, "Warning", f"File {file_path} does not exist.", QMessageBox.Ok)
		

		listOfAttachmentsNamesSigned = []
		for f, file_path in enumerate(selected_files4):
			if os.path.exists(file_path):
				file_name = os.path.basename(file_path)
				file_extension = os.path.splitext(file_name)[1]
				current_datetime = datetime.now().strftime("%Y%m%d%H%M%S")
				
				fVal = str(f)
				if len(str(f)) == 1:
					fVal = '00'+str(f)
				elif len(str(f)) == 2:
					fVal = '0'+str(f)
				else:
					fVal = str(f)

				new_file_name = f"{os.path.splitext(file_name)[0]}_{current_datetime}{fVal}{file_extension}"
				listOfAttachmentsNamesSigned.append(new_file_name)

				dest_path = os.path.join(dest_folder, new_file_name)
				shutil.copy(file_path, dest_path)
			else:
				QMessageBox.warning(self, "Warning", f"File {file_path} does not exist.", QMessageBox.Ok)
			

		# Attacheddocuments1 = ", ".join([self.attacheddocuments1_NCR.fileListWidget.item(i).text() for i in range(self.attacheddocuments1_NCR.fileListWidget.count())])	
		# Attacheddocuments2 = ", ".join([self.attacheddocuments2_NCR.fileListWidget.item(i).text() for i in range(self.attacheddocuments2_NCR.fileListWidget.count())])
		# Attacheddocuments3 = ", ".join([self.attacheddocuments3_NCR.fileListWidget.item(i).text() for i in range(self.attacheddocuments3_NCR.fileListWidget.count())])			
		# Signedncr = ", ".join([self.attacheddocuments4_NCR.fileListWidget.item(i).text() for i in range(self.attacheddocuments4_NCR.fileListWidget.count())])
		
		# ncrFormData.insert(22, str(listOfAttachmentsNames1))

		if listOfAttachmentsNames1:
			ncrFormData.insert(22, str(listOfAttachmentsNames1))
		else:
			ncrFormData.insert(22, None) 
		
		if listOfAttachmentsNames2:
			ncrFormData.insert(29, str(listOfAttachmentsNames2))
		else:
			ncrFormData.insert(29, None)

		if listOfAttachmentsNames3:
			ncrFormData.insert(32, str(listOfAttachmentsNames3))
		else:
			ncrFormData.insert(32, None)

		if listOfAttachmentsNamesSigned:
			ncrFormData.append(str(listOfAttachmentsNamesSigned))
		else:
			ncrFormData.append(None)

		# ncrFormData.insert(29, str(listOfAttachmentsNames2))
		# ncrFormData.insert(32, str(listOfAttachmentsNames3))	
		# ncrFormData.append(str(listOfAttachmentsNamesSigned))
		ncrFormData.append(self.user_id)

		if not mandatoryVerification_NCR:
			print('Mandatory fields missing.')

		else:
			# print('Form data:', ncrFormData)
		
			query = """
				INSERT INTO ncr
				
				(report_no, project, product, quantity, supplier, detection, place, stored_at, severity, distribution_to, trainset, car, 
				assy_dwg_no, rev, part_no, assy_serial_no, part_serial_no, bl_no, invoice_no, responsible_party, material_status, 
				description_of_nonconform, attachments_one, attachments_one_date, attachments_one_team, attachments_one_issued_by, 
				attachments_one_reviewed_by, attachments_one_approved_by, cause_of_nonconformity, attached_documents_two, 
				acorrection_corrective_action_result, baction_Plan, attachments_three, attachments_three_date, attachments_three_action_by,
				attachments_three_issued_by, attachments_three_reviewed_by, attachments_three_approved_by, decision, repair_procedure,
				correction_name, correction_date, correction_sign, correctiveaction_name, correctiveaction_date, correctiveaction_sign,
				approval_scope, approvedby_entity, approvedby_position, approvedby_name, approvedby_date, approvedby_sign, signed_ncr, user_id
				) 
				VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s,
						%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
			""" 


			# print("Query:", query)
			print("Data:", ncrFormData)

			# Print lengths for debugging
			print("Number of parameters:", len(ncrFormData))
			print("Number of placeholders in query:", query.count('%s'))
			
			try:
				self.cursor.execute(query, tuple(ncrFormData))
				self.mydb.commit()
				print("Data saved successfully.")
				print('Formdata:', ncrFormData)
				self.ncrDataTable_NCR.setRowCount(self.ncrDataTable_NCR.rowCount()+1)

				# for col, fieldData in enumerate(ncrFormData[1:]):
				# 	# print('headin',header_index)
				# 	# data = str(ncrFormData[header_index])
					
				# 	# item = QTableWidgetItem(fieldData)
				# 	# self.ncrDataTable_NCR.setItem(self.ncrDataTable_NCR.rowCount()-1, col+2, item)

				# 	if isinstance(fieldData, datetime.date):
				# 		# Create an empty QTableWidgetItem (instead of converting the date to string)
				# 		item = QTableWidgetItem()
				# 		# Store the date as a user-defined property, not converting it to string
				# 		item.setData(Qt.UserRole, fieldData)
				# 		# Optionally, you can set a placeholder text or mark the date visually
				# 		item.setText("Date")
				# 	else:
				# 		# For other types like integers or floats, set them without conversion to string
				# 		item = QTableWidgetItem()
				# 		item.setData(Qt.UserRole, fieldData)
				# 		item.setText(str(fieldData))


				# button = QPushButton(str(ncrFormData[0]))
				# button.setStyleSheet("QPushButton { text-decoration: none; }" "QPushButton:hover { text-decoration: underline; }")
				# button.setCursor(Qt.PointingHandCursor)

				# self.ncrDataTable_NCR.setCellWidget(self.ncrDataTable_NCR.rowCount()-1, 1, button)



				#############################################
				self.cancel_NCR.click()
				parts = self.current_ncr.text().split('-')
				cur_number = int(parts[-1].strip())
				newnumber = cur_number + 1
				formatted_report_no = f"- {newnumber}"
				self.current_ncr.setText(formatted_report_no)


			except Exception as e:
				print(f"Error: {e}")
				QMessageBox.critical(self, "Database Error", f"An error occurred: {e}")
			
	self.submit_NCR.clicked.connect(onClickingsubmit_Ncr)



	def onClickingcancel_Ncr():
		print('gggffg')
		self.projectLineEdit_NCR.clear()
		self.productLineEdit_NCR.clear()
		self.quantityLineEdit_NCR.clear()
		self.supplierLineEdit_NCR.clear()
		self.detectionLineEdit_NCR.clear()
		self.placeComboBox_NCR.setCurrentIndex(-1) 
		self.storedLineEdit_NCR.clear()
		self.severityComboBox_NCR.setCurrentIndex(-1)
		self.distributiontoLineEdit_NCR.clear()
		self.trainComboBox_NCR.setCurrentIndex(-1)

		for i in range(self.trainComboBox_NCR.model().rowCount()):
			item = self.trainComboBox_NCR.model().item(i)

			inactive_brush = QBrush(QColor('#f6f8fc'))
			item.setBackground(inactive_brush)
			item.setForeground(QColor("black"))
		self.trainComboBox_NCR.lineEdit().setToolTip(None)

		self.carComboBox_NCR.setCurrentIndex(-1)
		for i in range(self.carComboBox_NCR.model().rowCount()):
			item = self.carComboBox_NCR.model().item(i)
			inactive_brush = QBrush(QColor('#f6f8fc'))
			item.setBackground(inactive_brush)
			item.setForeground(QColor("black"))
		self.carComboBox_NCR.lineEdit().setToolTip(None)

		
		self.assydwgnoLineEdit_NCR.clear()
		self.revLineEdit_NCR.clear()
		self.partnoLineEdit_NCR.clear()

		self.assysnoLineEdit_NCR.clear()
		self.partserialnoLineEdit_NCR.clear()
		self.blnoLineEdit_NCR.clear()
		self.invoicenoLineEdit_NCR.clear()
		self.responsiblepartyLineEdit_NCR.clear()
		self.materialstatusComboBox_NCR.setCurrentIndex(-1)
		self.descriptionofnonconform_NCR.clear()
		self.attacheddocuments1_NCR.fileListWidget.clear()
		self.attacheddocuments1_NCR.fileListWidget.hide()
		
		current_date = QDate.currentDate()
		start_of_month = QDate(current_date.year(), current_date.month(), 1)
		self.date_NCR.setDate(start_of_month)	
		
		self.teamLineEdit_NCR.clear()
		self.issuedbyLineEdit_NCR.clear()
		self.reviewedbyLineEdit_NCR.clear()
		self.approvedbyLineEdit_NCR.clear()
		self.causeofnonconformity_NCR.clear()
		self.attacheddocuments2_NCR.fileListWidget.clear()
		self.attacheddocuments2_NCR.fileListWidget.hide()
		self.correctionorcorrectiveactionLineEdit_NCR.clear()
		self.actionplan_NCR.clear()
		self.attacheddocuments3_NCR.fileListWidget.clear()
		self.attacheddocuments3_NCR.fileListWidget.hide()

		# self.date1_NCR.setDate(self.date_NCR.minimumDate())
		self.date1_NCR.setDate(start_of_month)

		self.actionbyLineEdit_NCR.clear()
		self.issuedby1LineEdit_NCR.clear()
		self.reviewedby1LineEdit_NCR.clear()
		self.approvedby1LineEdit_NCR.clear()
		self.decisionComboBox_NCR.setCurrentIndex(-1)
		self.repairprocedureComboBox_NCR.setCurrentIndex(-1)
		self.name1LineEdit_NCR.clear()
		self.date2_NCR.setDate(start_of_month)
		# self.date2_NCR.setDate(self.date_NCR.minimumDate())
	
		self.sign1LineEdit_NCR.clear()
		self.name2LineEdit_NCR.clear()
		self.date3_NCR.setDate(start_of_month)
		# self.date3_NCR.setDate(self.date_NCR.minimumDate())
		self.sign2LineEdit_NCR.clear()
		self.approvalscopComboBox_NCR.setCurrentIndex(-1)
		self.entityLineEdit_NCR.clear()
		self.positionLineEdit_NCR.clear()
		self.name3LineEdit_NCR.clear()
		self.date4_NCR.setDate(start_of_month)
		# self.date4_NCR.setDate(self.date_NCR.minimumDate())
		self.sign3LineEdit_NCR.clear()
		self.attacheddocuments4_NCR.fileListWidget.clear()
		self.attacheddocuments4_NCR.fileListWidget.hide()
	
	self.cancel_NCR.clicked.connect(onClickingcancel_Ncr)

