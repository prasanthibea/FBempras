from PySide6.QtWidgets import QLabel, QWidget, QVBoxLayout, QSpacerItem, QDialog, QMessageBox, QSizePolicy, QFileDialog, QHBoxLayout,QScrollBar, QScrollArea, QTabWidget,QTableWidget, QTableWidgetItem, QAbstractItemView, QFormLayout, QLineEdit, QComboBox, QGridLayout, QPushButton, QSpinBox
from PySide6.QtCore import Qt
from PySide6.QtGui import QIcon
from datetime import datetime


def ncrformUI(self):
	from PySide6.QtWidgets import QApplication	

	self.mainVerticalLayout_NcrForm.addWidget(QLabel('NONCONFORMITY REPORT'), alignment = Qt.AlignCenter)	
	
	NCRHLayout = QHBoxLayout()
	self.mainVerticalLayout_NcrForm.addLayout(NCRHLayout)
	
	NCRFormLayout1 = QFormLayout()
	NCRFormLayout2 = QFormLayout()

	NCRHLayout.addLayout(NCRFormLayout1)
	NCRHLayout.addLayout(NCRFormLayout2)
	

	self.createPushButton('ckdmndl_NCR', 'CKD', '', int(0.045 * QApplication.primaryScreen().availableGeometry().width()))	
	self.ckdmndl_NCR.setStyleSheet('border: 1px solid #7387F5 ')
	self.counter = QLabel('-1')
	self.reportno = QLabel('NCR-BEML MRS1-T&C- ')
	# self.counter = 1
	# self.reportno = QLabel(f'NCR-BEML MRS1-T&C- {self.counter}')


	self.createLineEditBox('projectLineEdit_NCR')
	self.createLineEditBox('productLineEdit_NCR')
	self.createNumberLineEditBox('quantityLineEdit_NCR')
	self.createLineEditBox('supplierLineEdit_NCR')
	self.createLineEditBox('detectionLineEdit_NCR')
	self.createComboBox2(['CKD', 'Mandala'], 'placeComboBox_NCR')
	self.createLineEditBox('storedLineEdit_NCR')
	self.createComboBox2(['Major', 'Minor'],'severityComboBox_NCR')
	self.createComboBox2(['Before Installation', 'Installed', 'Disassembled', 'Before receiving'], 'materialstatusComboBox_NCR')
	self.createLineEditBox('distributiontoLineEdit_NCR')
	self.createCheckableComboBox(self.trainsetsList, 'trainComboBox_NCR')
	self.createCheckableComboBox(self.carsList, 'carComboBox_NCR')
	self.createLineEditBox('assydwgnoLineEdit_NCR')
	self.createNumberLineEditBox('revLineEdit_NCR')
	self.createLineEditBox('partnoLineEdit_NCR')
	self.createLineEditBox('assysnoLineEdit_NCR')
	self.createLineEditBox('partserialnoLineEdit_NCR')
	self.createLineEditBox('blnoLineEdit_NCR')
	self.createLineEditBox('invoicenoLineEdit_NCR')
	self.createLineEditBox('responsiblepartyLineEdit_NCR')
	self.createComboBox2(['Before Installation', 'Installed', 'Disassembled', 'Before receiving'], 'materialstatusComboBox_NCR')
	self.createTextEditBox('descriptionofnonconform_NCR')
	self.createAttachmentWidget('attacheddocuments1_NCR')
	self.createDateEditBox('date_NCR')
	self.createLineEditBox('teamLineEdit_NCR')
	self.createLineEditBox('issuedbyLineEdit_NCR')
	self.createLineEditBox('reviewedbyLineEdit_NCR')
	self.createLineEditBox('approvedbyLineEdit_NCR')
	self.createTextEditBox('causeofnonconformity_NCR')
	self.createAttachmentWidget('attacheddocuments2_NCR')
	self.createTextEditBox('correctionorcorrectiveactionLineEdit_NCR')
	self.createTextEditBox('actionplan_NCR')
	self.createAttachmentWidget('attacheddocuments3_NCR')
	self.createDateEditBox('date1_NCR')
	self.createLineEditBox('actionbyLineEdit_NCR')
	self.createLineEditBox('issuedby1LineEdit_NCR')
	self.createLineEditBox('reviewedby1LineEdit_NCR')
	self.createLineEditBox('approvedby1LineEdit_NCR')
	self.createComboBox2(['Claim', 'Holding', 'Use as is', 'Rework', 'Waiver', 'Scrap', 'Repair'], 'decisionComboBox_NCR')
	self.createComboBox2(['Yes', 'No'], 'repairprocedureComboBox_NCR')	
	self.createLineEditBox('name1LineEdit_NCR')
	self.createDateEditBox('date2_NCR')
	self.createLineEditBox('sign1LineEdit_NCR')
	self.createLineEditBox('name2LineEdit_NCR')
	self.createDateEditBox('date3_NCR')
	self.createLineEditBox('sign2LineEdit_NCR')
	self.createComboBox2(['Internal', 'Customer'], 'approvalscopComboBox_NCR')     	
	self.createLineEditBox('entityLineEdit_NCR')
	self.createLineEditBox('positionLineEdit_NCR')
	self.createLineEditBox('name3LineEdit_NCR')
	self.createDateEditBox('date4_NCR')
	self.createLineEditBox('sign3LineEdit_NCR')
	self.createAttachmentWidget('attacheddocuments4_NCR')
	self.attacheddocuments4_NCR.fileListWidget.setMinimumHeight(140)


	ckmandlhboxlayout_NCR = QHBoxLayout()
	ckmandlhboxlayout_NCR.addWidget(self.reportno, alignment = Qt.AlignRight )
	ckmandlhboxlayout_NCR.addWidget(self.ckdmndl_NCR, alignment = Qt.AlignLeft )
	ckmandlhboxlayout_NCR.addWidget(self.counter,alignment = Qt.AlignLeft)
	ckmandlhboxlayout_NCR.addItem(QSpacerItem(1, 0, QSizePolicy.Expanding, QSizePolicy.Minimum))

	NCRFormLayout1.addRow('Report No: <font color="red">*</font>', ckmandlhboxlayout_NCR)
	NCRFormLayout1.addRow('Project:', self.projectLineEdit_NCR)
	NCRFormLayout1.addRow('Product:', self.productLineEdit_NCR)
	NCRFormLayout1.addRow('Quantity: <font color="red">*</font>', self.quantityLineEdit_NCR)
	
	NCRFormLayout1.addRow('Supplier: <font color="red">*</font>', self.supplierLineEdit_NCR)
	NCRFormLayout1.addRow('Detection: <font color="red">*</font>', self.detectionLineEdit_NCR)
	NCRFormLayout1.addRow('Place:', self.placeComboBox_NCR)
	NCRFormLayout1.addRow('Stored at:', self.storedLineEdit_NCR)	
	NCRFormLayout1.addRow('Severity:', self.severityComboBox_NCR)
	# NCRFormLayout1.addRow('Material status:', self.materialstatusComboBox_NCR)
	NCRFormLayout1.addRow('Distribution to: <font color="red">*</font>', self.distributiontoLineEdit_NCR)
	NCRFormLayout1.addRow('Trainset: <font color="red">*</font>', self.trainComboBox_NCR)
	NCRFormLayout1.addRow('Car:', self.carComboBox_NCR)

	NCRFormLayout1.addRow('Assy dwg no:', self.assydwgnoLineEdit_NCR)
	NCRFormLayout1.addRow('Rev:', self.revLineEdit_NCR)
	NCRFormLayout1.addRow('Part No:', self.partnoLineEdit_NCR)

	NCRFormLayout1.addRow('Assy Serial No:', self.assysnoLineEdit_NCR)
	NCRFormLayout1.addRow('Part Serial No:', self.partserialnoLineEdit_NCR)


	NCRFormLayout1.addRow('B/L No:', self.blnoLineEdit_NCR)
	NCRFormLayout1.addRow('Invoice no:', self.invoicenoLineEdit_NCR)
	NCRFormLayout1.addRow('Responsible party: <font color="red">*</font>', self.responsiblepartyLineEdit_NCR)
	NCRFormLayout1.addRow('Material status:', self.materialstatusComboBox_NCR)

	NCRFormLayout1.addRow('Description of non-conform: <font color="red">*</font>', self.descriptionofnonconform_NCR)
	NCRFormLayout1.addRow('Attached documents (if any):', self.attacheddocuments1_NCR)

	NCRFormLayout1.addRow('Date: <font color="red">*</font>' , self.date_NCR)
	NCRFormLayout1.addRow('Team :', self.teamLineEdit_NCR)
	NCRFormLayout1.addRow('Issued by: <font color="red">*</font>', self.issuedbyLineEdit_NCR)
	NCRFormLayout1.addRow('Reviewed by: <font color="red">*</font>', self.reviewedbyLineEdit_NCR)
	NCRFormLayout1.addRow('Approved by: <font color="red">*</font>', self.approvedbyLineEdit_NCR)

	NCRFormLayout1.addRow('Cause of nonconformity: ', self.causeofnonconformity_NCR)
	NCRFormLayout2.addRow('Attached documents (if any):', self.attacheddocuments2_NCR)
	NCRFormLayout2.addRow('A. Correction/corrective action result: <font color="red">*</font>', self.correctionorcorrectiveactionLineEdit_NCR)
	NCRFormLayout2.addRow('B. Action Plan: ', self.actionplan_NCR)
	NCRFormLayout2.addRow('Attached documents (if any):', self.attacheddocuments3_NCR)
	NCRFormLayout2.addRow('Date: ' , self.date1_NCR)
	NCRFormLayout2.addRow('Action by:', self.actionbyLineEdit_NCR)
	NCRFormLayout2.addRow('Issued by:', self.issuedby1LineEdit_NCR)
	NCRFormLayout2.addRow('Reviewed by:', self.reviewedby1LineEdit_NCR)
	NCRFormLayout2.addRow('Approved by:', self.approvedby1LineEdit_NCR)
	NCRFormLayout2.addRow('Decision :', self.decisionComboBox_NCR)
	NCRFormLayout2.addRow('Repair procedure:', self.repairprocedureComboBox_NCR)
	NCRFormLayout2.addRow(QLabel('Verification on correction:	'))
	NCRFormLayout2.addRow('Name:', self.name1LineEdit_NCR)
	NCRFormLayout2.addRow('Date: ' , self.date2_NCR)
	NCRFormLayout2.addRow('Sign:', self.sign1LineEdit_NCR)
	NCRFormLayout2.addRow(QLabel('Verification on corrective action:	'))
	NCRFormLayout2.addRow('Name:', self.name2LineEdit_NCR)
	NCRFormLayout2.addRow('Date: ' , self.date3_NCR)
	NCRFormLayout2.addRow('Sign:', self.sign2LineEdit_NCR)
	NCRFormLayout2.addRow('Approval Scope:', self.approvalscopComboBox_NCR)

	NCRFormLayout2.addRow('Entity:', self.entityLineEdit_NCR)
	NCRFormLayout2.addRow('Position:', self.positionLineEdit_NCR)
	NCRFormLayout2.addRow('Name:', self.name3LineEdit_NCR)
	NCRFormLayout2.addRow('Date:', self.date4_NCR)
	NCRFormLayout2.addRow('Sign:', self.sign3LineEdit_NCR)
	NCRFormLayout2.addRow('Signed NCR:', self.attacheddocuments4_NCR)


	def toggleLabelText():
		currentText = self.ckdmndl_NCR.text()
		if currentText == 'CKD':
			self.ckdmndl_NCR.setText('Mandala')
		else:
			self.ckdmndl_NCR.setText('CKD')

	self.ckdmndl_NCR.clicked.connect(toggleLabelText)




	# def displaytext():
	# 	currentText = self.reportno.text()
	# 	if currentText == 'NCR-BEML MRS1-T&C-':
	# 		self.reportno.setText('NCR-BEML MRS1-T&C-Mandala')
	# 	else:
	# 		self.reportno.setText('NCR-BEML MRS1-T&C-')
	# self.ckdmndl_NCR.clicked.connect(displaytext)


	self.createPushButton('submit_NCR', 'SUBMIT', '', int(0.075 * QApplication.primaryScreen().availableGeometry().width()))
	self.createPushButton('cancel_NCR', 'CANCEL', '', int(0.075 * QApplication.primaryScreen().availableGeometry().width()))

	ncrHboxlayout = QHBoxLayout()
	ncrHboxlayout.addWidget(self.submit_NCR, alignment = Qt.AlignRight)
	ncrHboxlayout.addWidget(self.cancel_NCR, alignment = Qt.AlignLeft)

	self.mainVerticalLayout_NcrForm.addLayout(ncrHboxlayout)
	

	########################################################################

	self.allFields = [self.reportno, self.projectLineEdit_NCR, self.productLineEdit_NCR, self.quantityLineEdit_NCR, self.supplierLineEdit_NCR,
					self.detectionLineEdit_NCR,self.placeComboBox_NCR, self.storedLineEdit_NCR, self.severityComboBox_NCR,self.distributiontoLineEdit_NCR,
					self.trainComboBox_NCR, self.carComboBox_NCR, self.assydwgnoLineEdit_NCR, self.revLineEdit_NCR, self.partnoLineEdit_NCR,
					self.assysnoLineEdit_NCR, self.partserialnoLineEdit_NCR, self.blnoLineEdit_NCR, self.invoicenoLineEdit_NCR, self.responsiblepartyLineEdit_NCR,
					self.materialstatusComboBox_NCR, self.descriptionofnonconform_NCR,self.attacheddocuments1_NCR, self.date_NCR, self.teamLineEdit_NCR, 
					self.issuedbyLineEdit_NCR, self.reviewedbyLineEdit_NCR, self.approvedbyLineEdit_NCR, self.causeofnonconformity_NCR, 
					self.attacheddocuments2_NCR, self.correctionorcorrectiveactionLineEdit_NCR, self.actionplan_NCR, self.attacheddocuments3_NCR, 
					self.date1_NCR, self.actionbyLineEdit_NCR, self.issuedby1LineEdit_NCR, self.reviewedby1LineEdit_NCR, self.approvedby1LineEdit_NCR, 
					self.decisionComboBox_NCR, self.repairprocedureComboBox_NCR, self.name1LineEdit_NCR, self.date2_NCR, self.sign1LineEdit_NCR, 
					self.name2LineEdit_NCR, self.date3_NCR, self.sign2LineEdit_NCR, self.approvalscopComboBox_NCR, self.entityLineEdit_NCR, 
					self.positionLineEdit_NCR, self.name3LineEdit_NCR, self.date4_NCR, self.sign3LineEdit_NCR, self.attacheddocuments4_NCR]



	def onClickingsubmit_Ncr():
		print('dfdfsfsfs')
		
		# mandatoryVerification_NCR = True
		mandatoryIndexes = [0, 3, 4, 5, 9, 10, 19, 21, 22, 25, 26, 27]
		missingFields = []

	
		# Reportntext = self.reportno.text()
		ReportNo = self.reportno.text()		
		print(ReportNo)

		Project = self.projectLineEdit_NCR.text()
		Product = self.productLineEdit_NCR.text()
		Quantity = self.quantityLineEdit_NCR.text()
		Supplier = self.supplierLineEdit_NCR.text()
		Detection = self.detectionLineEdit_NCR.text()
		Place = self.placeComboBox_NCR.currentText() 
		Storedat =self.storedLineEdit_NCR.text()
		Severity = self.severityComboBox_NCR.currentText()
		Distribution = self.distributiontoLineEdit_NCR.text()
		Train = self.trainComboBox_NCR.currentText()
		Car = self.carComboBox_NCR.currentText()
		Assydwgno = self.assydwgnoLineEdit_NCR.text()
		Rev = self.revLineEdit_NCR.text()
		Partno = self.partnoLineEdit_NCR.text()
		Assysno = self.assysnoLineEdit_NCR.text()
		Partserialno =self.partserialnoLineEdit_NCR.text()
		Blno = self.blnoLineEdit_NCR.text()
		Invoiceno = self.invoicenoLineEdit_NCR.text()
		Responsibleparty = self.responsiblepartyLineEdit_NCR.text()
		Materialstatus = self.materialstatusComboBox_NCR.currentText()
		Descriptionnonconform = self.descriptionofnonconform_NCR.toPlainText()			
		# self.attacheddocuments1_NCR.fileListWidget.text()
		# Attacheddocuments1 = [self.attacheddocuments1_NCR.fileListWidget.item(i).text() for i in range(self.attacheddocuments1_NCR.fileListWidget.count())]
		# print(Attacheddocuments1)

		Attacheddocuments1 = ", ".join([self.attacheddocuments1_NCR.fileListWidget.item(i).text() for i in range(self.attacheddocuments1_NCR.fileListWidget.count())])
		# print(Attacheddocuments1)
	
		Date = self.date_NCR.date().toString("yyyy-MM-dd")
		print('1',Date)
		Team = self.teamLineEdit_NCR.text()
		Issuedby = self.issuedbyLineEdit_NCR.text()
		Reviewedby = self.reviewedbyLineEdit_NCR.text()
		Approvedby = self.approvedbyLineEdit_NCR.text()
		Causenonconformity = self.causeofnonconformity_NCR.toPlainText()
		# self.attacheddocuments2_NCR.getFilePath()
		# Attacheddocuments2 = [self.attacheddocuments2_NCR.fileListWidget.item(i).text() for i in range(self.attacheddocuments2_NCR.fileListWidget.count())]
		# print(Attacheddocuments2)
		Attacheddocuments2 = ", ".join([self.attacheddocuments2_NCR.fileListWidget.item(i).text() for i in range(self.attacheddocuments2_NCR.fileListWidget.count())])
		# print(Attacheddocuments2)
	
		Correctiocorrectiveaction = self.correctionorcorrectiveactionLineEdit_NCR.toPlainText()
		Actionplan = self.actionplan_NCR.toPlainText()
		# self.attacheddocuments3_NCR.getFilePath()
		# Attacheddocuments3 = [self.attacheddocuments3_NCR.fileListWidget.item(i).text() for i in range(self.attacheddocuments3_NCR.fileListWidget.count())]
		# print(Attacheddocuments3)
		Attacheddocuments3 = ", ".join([self.attacheddocuments3_NCR.fileListWidget.item(i).text() for i in range(self.attacheddocuments3_NCR.fileListWidget.count())])
		# print(Attacheddocuments3)
	
		Date1 = self.date1_NCR.date().toString("yyyy-MM-dd")

		Actionby = self.actionbyLineEdit_NCR.text()
		Issued1by = self.issuedby1LineEdit_NCR.text()
		Reviewed1by = self.reviewedby1LineEdit_NCR.text()
		Approved1by = self.approvedby1LineEdit_NCR.text()
		Decision = self.decisionComboBox_NCR.currentText()
		Repairprocedure = self.repairprocedureComboBox_NCR.currentText()
		Name1 = self.name1LineEdit_NCR.text()
		Date2 = self.date2_NCR.date().toString("yyyy-MM-dd")
		Sign1 = self.sign1LineEdit_NCR.text()
		Name2 = self.name2LineEdit_NCR.text()
		Date3 = self.date3_NCR.date().toString("yyyy-MM-dd")
		Sign2 = self.sign2LineEdit_NCR.text()
		Approvalscope = self.approvalscopComboBox_NCR.currentText()
		Entity = self.entityLineEdit_NCR.text()
		Position = self.positionLineEdit_NCR.text()
		Name3 = self.name3LineEdit_NCR.text()
		Date4 = self.date4_NCR.date().toString("yyyy-MM-dd")
		Sign3 = self.sign3LineEdit_NCR.text()
		# self.attacheddocuments4_NCR.fileListWidget.item().text()
		# Signedncr = [self.attacheddocuments4_NCR.fileListWidget.item(i).text() for i in range(self.attacheddocuments4_NCR.fileListWidget.count())]
		# print(Signedncr)

		Signedncr = ", ".join([self.attacheddocuments4_NCR.fileListWidget.item(i).text() for i in range(self.attacheddocuments4_NCR.fileListWidget.count())])
		# print(Signedncr)

		
		

		ncrFormData = [ReportNo, Project, Product, Quantity, Supplier, Detection, Place, Storedat, Severity, Distribution, Train, Car, Assydwgno, Rev, Partno, Assysno, Partserialno, Blno, Invoiceno, Responsibleparty, Materialstatus,
					  Descriptionnonconform, Attacheddocuments1, Date, Team, Issuedby, Reviewedby, Approvedby, Causenonconformity, Attacheddocuments2, Correctiocorrectiveaction,
					  Actionplan, Attacheddocuments3, Date1, Actionby, Issued1by, Reviewed1by, Approved1by, Decision, Repairprocedure, Name1, Date2, Sign1,
					  Name2, Date3, Sign2, Approvalscope, Entity, Position, Name3, Date4, Sign3, Signedncr,self.user_id ]

		# print('11',ncrFormData)		


		query = """
			INSERT INTO ncr
			(report_no, project, product, quantity, supplier, detection, place, stored_at, severity, distribution_to, trainset, car, 
			assy_dwg_no, rev, part_no, assy_serial_no, part_serial_no, bl_no, invoice_no, responsible_party, material_status, 
			description_of_nonconform, attachements_one, attachements_one_date, attachements_one_team, attachements_one_issued_by, 
			attachements_one_reviewed_by, attachements_one_approved_by, cause_of_nonconformity, attached_documents_two, 
			acorrection_corrective_action_result, baction_Plan, attachements_three, attachements_three_date, attachements_three_action_by,
			attachements_three_issued_by, attachements_three_reviewed_by, attachements_three_approved_by, decision, repair_procedure,
			correction_name, correction_date, correction_sign, correctiveaction_name, correctiveaction_date, correctiveaction_sign,
			approval_scope, approvedby_entity, approvedby_position, approvedby_name, approvedby_date, approvedby_sign, signed_ncr, user_id
			) 
			VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s,
					%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
		""" 
		print("Query:", query)
		print("Data:", ncrFormData)

		# Print lengths for debugging
		print("Number of parameters:", len(ncrFormData))
		print("Number of placeholders in query:", query.count('%s'))
		# ncrFormData.append(self.user_id)
		self.cursor.execute(query, tuple(ncrFormData))
		self.mydb.commit()
		print("Data saved successfully.")


		self.counter += 1
		self.reportno.setText(f'NCR-BEML MRS1-T&C- {self.ckdmndl_NCR.text()} - {self.counter}')



		# query = """
		# 	INSERT INTO ncr
		# 	(report_no, project, product, quantity, supplier, detection, place, stored_at, severity, distribution_to, trainset, car, 
		# 	assy_dwg_no, rev, part_no, assy_serial_no, part_serial_no, bl_no, invoice_no, responsible_party, material_status, 
		# 	description_of_nonconform, attachements_one, attachements_one_date, attachements_one_team, attachements_one_issued_by, 
		# 	attachements_one_reviewed_by, attachements_one_approved_by, cause_of_nonconformity, attached_documents_two, 
		# 	acorrection_corrective_action_result, baction_Plan, attachements_three, attachements_three_date, attachements_three_action_by,
		# 	attachements_three_issued_by, attachements_three_reviewed_by, attachements_three_approved_by, decision, repair_procedure,
		# 	correction_name, correction_date, correction_sign, correctiveaction_name, correctiveaction_date, correctiveaction_sign,
		# 	approval_scope, approvedby_entity, approvedby_position, approvedby_name, approvedby_date, approvedby_sign, signed_ncr
		# 	  ) SELECT
		# 	 	%s, %s, %s, %s, %s, %s, %s, %s, %s, %s,   trainsets.id, %s, %s, %s,  %s, %s, %s, %s, %s, %s,   %s, %s, %s, %s,  
		# 		%s, %s, %s, %s, %s, %s, %s, %s, %s, %s,   %s, %s, %s, %s, %s, %s, %s, %s, %s, %s,        %s, %s, %s, %s, %s, %s, %s, %s, %s

		# 		%s, %s, %s, %s, %s, %s, %s, %s, %s, %s,trainsets.id, %s, %s, %s,  %s, %s, %s, %s, %s, %s,%s, %s, %s, %s,  
		# 		%s, %s, %s, %s, %s, %s, %s, %s, %s, %s,%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s
  

		# 	FROM
		# 		trainsets
		# 	WHERE
		# 		trainsets.trainset = %s 
			
		# """

		# # Debugging: Print the length and values of ncrFormData
		# # print("ncrFormData length:", len(ncrFormData))
		# # print("ncrFormData:", ncrFormData)
		# self.cursor.execute(query, tuple(ncrFormData)) 
		# print('12',ncrFormData)
		# self.mydb.commit()




		# self.cursor.execute(query, (ReportNo, Project, Product, Quantity, Supplier, Dection, Place, Storedat, Severity, Distribution,
		# 				Train, Car, Assydwgno, Rev, Partno, Assysno, Partserialno, Blno, Invoiceno, Responsibleparty, Materialstatus,
		# 				Descriptionnonconform, Attacheddocuments1, Date, Team, Issuedby, Reviewedby, Approvedby, Causenonconformity, Attacheddocuments2, Correctiocorrectiveaction,
		# 				Actionplan, Attacheddocuments3, Date1, Actionby, Issued1by, Reviewed1by, Approved1by, Decision, Repairprocedure, Name1, Date2, Sign1,
		# 				Name2, Date3, Sign2, Approvalscope, Entity, Position, Name3, Date4, Sign3, Signedncr
		# 				))
		# self.mydb.commit()


	self.submit_NCR.clicked.connect(onClickingsubmit_Ncr)




	# def onClickingcancel_Ncr():
	# 	# print('gggffg')


	# self.cancel_NCR.clicked.connect(onClickingcancel_Ncr)


		# #############################################################################
