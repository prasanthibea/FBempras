


mandatoryVerification_NCR = True

ncrFormData = [1,2,3]
if not mandatoryVerification_NCR:
	print('Mandatory fields missing.')

else:
	print('Form data:', ncrFormData)









# from PySide6.QtWidgets import QLabel, QWidget, QVBoxLayout, QSpacerItem, QDialog, QMessageBox, QSizePolicy, QFileDialog, QHBoxLayout,QScrollBar, QScrollArea, QTabWidget, QTableWidget, QTableWidgetItem, QAbstractItemView, QFormLayout, QLineEdit, QTextEdit, QComboBox, QGridLayout, QPushButton, QSpinBox
# from PySide6.QtCore import Qt
# from PySide6.QtGui import QIcon
# from datetime import datetime


# def ncrformUI(self):
# 	from PySide6.QtWidgets import QApplication	

# 	self.mainVerticalLayout_NcrForm.addWidget(QLabel('NONCONFORMITY REPORT'), alignment = Qt.AlignCenter)	
	
# 	NCRHLayout = QHBoxLayout()
# 	self.mainVerticalLayout_NcrForm.addLayout(NCRHLayout)
	
# 	NCRFormLayout1 = QFormLayout()
# 	NCRFormLayout2 = QFormLayout()

# 	NCRHLayout.addLayout(NCRFormLayout1)
# 	NCRHLayout.addLayout(NCRFormLayout2)
	

# 	# self.createPushButton('ckdmndl_NCR', 'CKD','', int(0.045 * QApplication.primaryScreen().availableGeometry().width()))
# 	self.ckdmndl_NCR = QPushButton('CKD')
# 	self.ckdmndl_NCR.setFixedWidth(37)
# 	self.ckdmndl_NCR.setFixedHeight(25)
# 	self.ckdmndl_NCR.setStyleSheet('border-radius: 2px; background:white; border: 1px solid grey;padding: 2px;')

# 	self.current_ncr = QLabel()
# 	self.reportno = QLabel('NCR-BEML MRS1-T&C- ')


# 	# self.cursor.execute("SELECT report_no FROM ncr ORDER BY id DESC LIMIT 1")
# 	# reporesul = self.cursor.fetchone()
# 	# print(reporesul)



# 	self.cursor.execute("SELECT report_no FROM ncr")
# 	all_records = self.cursor.fetchall()
# 	print("All records in ncr table:", [record[0] for record in all_records])

# 	if all_records:
# 		# Sort records based on the numeric part of the report number
# 		all_records_sorted = sorted(all_records, key=lambda record: int(record[0].split('-')[-1].strip()))

# 		print('fdg',all_records_sorted)
# 		# Extract the last (highest) report number
# 		last_report_no = all_records_sorted[-1][0].strip()  # Get the last (highest) record
# 		print(f"Last report number: {last_report_no}")

# 		parts = last_report_no.split('-')
# 		current_number = int(parts[-1].strip())  # Assuming the number is at the end, strip extra spaces
# 		new_number = current_number + 1
		
# 		# Update the label with the new number
# 		self.current_ncr.setText(f" - {new_number}")
# 		print(f"New report number: - {new_number}")  # This should now print the correct incremented number
# 	else:
# 		# If there are no records, initialize with the starting number
# 		self.current_ncr.setText("- 1")
# 		print("Initialized with - 1")

	

# 	self.createLineEditBox('projectLineEdit_NCR')
# 	self.createLineEditBox('productLineEdit_NCR')
# 	self.createNumberLineEditBox('quantityLineEdit_NCR')
# 	self.createLineEditBox('supplierLineEdit_NCR')
# 	self.createLineEditBox('detectionLineEdit_NCR')
# 	self.createComboBox2(['CKD', 'Mandala'], 'placeComboBox_NCR')
# 	self.createLineEditBox('storedLineEdit_NCR')
# 	self.createComboBox2(['Major', 'Minor'],'severityComboBox_NCR')
# 	self.createComboBox2(['Before Installation', 'Installed', 'Disassembled', 'Before receiving'], 'materialstatusComboBox_NCR')
# 	self.createLineEditBox('distributiontoLineEdit_NCR')
# 	self.createCheckableComboBox(self.trainsetsList, 'trainComboBox_NCR')
# 	self.createCheckableComboBox(self.carsList, 'carComboBox_NCR')
# 	self.createLineEditBox('assydwgnoLineEdit_NCR')
# 	self.createNumberLineEditBox('revLineEdit_NCR')
# 	self.createLineEditBox('partnoLineEdit_NCR')
# 	self.createLineEditBox('assysnoLineEdit_NCR')
# 	self.createLineEditBox('partserialnoLineEdit_NCR')
# 	self.createLineEditBox('blnoLineEdit_NCR')
# 	self.createLineEditBox('invoicenoLineEdit_NCR')
# 	self.createLineEditBox('responsiblepartyLineEdit_NCR')
# 	self.createComboBox2(['Before Installation', 'Installed', 'Disassembled', 'Before receiving'], 'materialstatusComboBox_NCR')
# 	self.createTextEditBox('descriptionofnonconform_NCR')
# 	self.createAttachmentWidget('attacheddocuments1_NCR')
# 	self.createDateEditBox('date_NCR')
# 	self.createLineEditBox('teamLineEdit_NCR')
# 	self.createLineEditBox('issuedbyLineEdit_NCR')
# 	self.createLineEditBox('reviewedbyLineEdit_NCR')
# 	self.createLineEditBox('approvedbyLineEdit_NCR')
# 	self.createTextEditBox('causeofnonconformity_NCR')
# 	self.createAttachmentWidget('attacheddocuments2_NCR')
# 	self.createTextEditBox('correctionorcorrectiveactionLineEdit_NCR')
# 	self.createTextEditBox('actionplan_NCR')
# 	self.createAttachmentWidget('attacheddocuments3_NCR')
# 	self.createDateEditBox('date1_NCR')
# 	self.createLineEditBox('actionbyLineEdit_NCR')
# 	self.createLineEditBox('issuedby1LineEdit_NCR')
# 	self.createLineEditBox('reviewedby1LineEdit_NCR')
# 	self.createLineEditBox('approvedby1LineEdit_NCR')
# 	self.createComboBox2(['Claim', 'Holding', 'Use as is', 'Rework', 'Waiver', 'Scrap', 'Repair'], 'decisionComboBox_NCR')
# 	self.createComboBox2(['Yes', 'No'], 'repairprocedureComboBox_NCR')	
# 	self.createLineEditBox('name1LineEdit_NCR')
# 	self.createDateEditBox('date2_NCR')
# 	self.createLineEditBox('sign1LineEdit_NCR')
# 	self.createLineEditBox('name2LineEdit_NCR')
# 	self.createDateEditBox('date3_NCR')
# 	self.createLineEditBox('sign2LineEdit_NCR')
# 	self.createComboBox2(['Internal', 'Customer'], 'approvalscopComboBox_NCR')     	
# 	self.createLineEditBox('entityLineEdit_NCR')
# 	self.createLineEditBox('positionLineEdit_NCR')
# 	self.createLineEditBox('name3LineEdit_NCR')
# 	self.createDateEditBox('date4_NCR')
# 	self.createLineEditBox('sign3LineEdit_NCR')
# 	self.createAttachmentWidget('attacheddocuments4_NCR')
# 	self.attacheddocuments4_NCR.fileListWidget.setMinimumHeight(140)


# 	ckmandlhboxlayout_NCR = QHBoxLayout()
# 	ckmandlhboxlayout_NCR.addWidget(self.reportno, alignment = Qt.AlignRight )
# 	ckmandlhboxlayout_NCR.addWidget(self.ckdmndl_NCR, alignment = Qt.AlignLeft )
# 	ckmandlhboxlayout_NCR.addWidget(self.current_ncr,alignment = Qt.AlignLeft)
# 	ckmandlhboxlayout_NCR.addItem(QSpacerItem(1, 0, QSizePolicy.Expanding, QSizePolicy.Minimum))

# 	NCRFormLayout1.addRow('Report No: <font color="red">*</font>', ckmandlhboxlayout_NCR)
# 	NCRFormLayout1.addRow('Project:', self.projectLineEdit_NCR)
# 	NCRFormLayout1.addRow('Product:', self.productLineEdit_NCR)
# 	NCRFormLayout1.addRow('Quantity: <font color="red">*</font>', self.quantityLineEdit_NCR)
	
# 	NCRFormLayout1.addRow('Supplier: <font color="red">*</font>', self.supplierLineEdit_NCR)
# 	NCRFormLayout1.addRow('Detection: <font color="red">*</font>', self.detectionLineEdit_NCR)
# 	NCRFormLayout1.addRow('Place:', self.placeComboBox_NCR)
# 	NCRFormLayout1.addRow('Stored at:', self.storedLineEdit_NCR)	
# 	NCRFormLayout1.addRow('Severity:', self.severityComboBox_NCR)
# 	# NCRFormLayout1.addRow('Material status:', self.materialstatusComboBox_NCR)
# 	NCRFormLayout1.addRow('Distribution to: <font color="red">*</font>', self.distributiontoLineEdit_NCR)
# 	NCRFormLayout1.addRow('Trainset: <font color="red">*</font>', self.trainComboBox_NCR)
# 	NCRFormLayout1.addRow('Car:', self.carComboBox_NCR)

# 	NCRFormLayout1.addRow('Assy dwg no:', self.assydwgnoLineEdit_NCR)
# 	NCRFormLayout1.addRow('Rev:', self.revLineEdit_NCR)
# 	NCRFormLayout1.addRow('Part No:', self.partnoLineEdit_NCR)

# 	NCRFormLayout1.addRow('Assy Serial No:', self.assysnoLineEdit_NCR)
# 	NCRFormLayout1.addRow('Part Serial No:', self.partserialnoLineEdit_NCR)


# 	NCRFormLayout1.addRow('B/L No:', self.blnoLineEdit_NCR)
# 	NCRFormLayout1.addRow('Invoice no:', self.invoicenoLineEdit_NCR)
# 	NCRFormLayout1.addRow('Responsible party: <font color="red">*</font>', self.responsiblepartyLineEdit_NCR)
# 	NCRFormLayout1.addRow('Material status:', self.materialstatusComboBox_NCR)

# 	NCRFormLayout1.addRow('Description of non-conform: <font color="red">*</font>', self.descriptionofnonconform_NCR)
# 	NCRFormLayout1.addRow('Attached documents (if any):', self.attacheddocuments1_NCR)

# 	NCRFormLayout1.addRow('Date: <font color="red">*</font>' , self.date_NCR)
# 	NCRFormLayout1.addRow('Team :', self.teamLineEdit_NCR)
# 	NCRFormLayout1.addRow('Issued by: <font color="red">*</font>', self.issuedbyLineEdit_NCR)
# 	NCRFormLayout1.addRow('Reviewed by: <font color="red">*</font>', self.reviewedbyLineEdit_NCR)
# 	NCRFormLayout1.addRow('Approved by: <font color="red">*</font>', self.approvedbyLineEdit_NCR)

# 	NCRFormLayout1.addRow('Cause of nonconformity: ', self.causeofnonconformity_NCR)
# 	NCRFormLayout2.addRow('Attached documents (if any):', self.attacheddocuments2_NCR)
# 	NCRFormLayout2.addRow('A. Correction/corrective action result: <font color="red">*</font>', self.correctionorcorrectiveactionLineEdit_NCR)
# 	NCRFormLayout2.addRow('B. Action Plan: ', self.actionplan_NCR)
# 	NCRFormLayout2.addRow('Attached documents (if any):', self.attacheddocuments3_NCR)
# 	NCRFormLayout2.addRow('Date: ' , self.date1_NCR)
# 	NCRFormLayout2.addRow('Action by:', self.actionbyLineEdit_NCR)
# 	NCRFormLayout2.addRow('Issued by:', self.issuedby1LineEdit_NCR)
# 	NCRFormLayout2.addRow('Reviewed by:', self.reviewedby1LineEdit_NCR)
# 	NCRFormLayout2.addRow('Approved by:', self.approvedby1LineEdit_NCR)
# 	NCRFormLayout2.addRow('Decision :', self.decisionComboBox_NCR)
# 	NCRFormLayout2.addRow('Repair procedure:', self.repairprocedureComboBox_NCR)
# 	NCRFormLayout2.addRow(QLabel('Verification on correction:	'))
# 	NCRFormLayout2.addRow('Name:', self.name1LineEdit_NCR)
# 	NCRFormLayout2.addRow('Date: ' , self.date2_NCR)
# 	NCRFormLayout2.addRow('Sign:', self.sign1LineEdit_NCR)
# 	NCRFormLayout2.addRow(QLabel('Verification on corrective action:	'))
# 	NCRFormLayout2.addRow('Name:', self.name2LineEdit_NCR)
# 	NCRFormLayout2.addRow('Date: ' , self.date3_NCR)
# 	NCRFormLayout2.addRow('Sign:', self.sign2LineEdit_NCR)
# 	NCRFormLayout2.addRow('Approval Scope:', self.approvalscopComboBox_NCR)

# 	NCRFormLayout2.addRow('Entity:', self.entityLineEdit_NCR)
# 	NCRFormLayout2.addRow('Position:', self.positionLineEdit_NCR)
# 	NCRFormLayout2.addRow('Name:', self.name3LineEdit_NCR)
# 	NCRFormLayout2.addRow('Date:', self.date4_NCR)
# 	NCRFormLayout2.addRow('Sign:', self.sign3LineEdit_NCR)
# 	NCRFormLayout2.addRow('Signed NCR:', self.attacheddocuments4_NCR)


# 	def toggleLabelText():
# 		currentText = self.ckdmndl_NCR.text()
# 		if currentText == 'CKD':
# 			self.ckdmndl_NCR.setText('Mandala')		
# 			self.ckdmndl_NCR.setFixedWidth(65)	
# 		else:
# 			self.ckdmndl_NCR.setText('CKD')
# 			self.ckdmndl_NCR.setFixedWidth(37)	
# 	self.ckdmndl_NCR.clicked.connect(toggleLabelText)

	

# 	# def displaytext():
# 	# 	currentText = self.reportno.text()
# 	# 	if currentText == 'NCR-BEML MRS1-T&C-':
# 	# 		self.reportno.setText('NCR-BEML MRS1-T&C-Mandala')
# 	# 	else:
# 	# 		self.reportno.setText('NCR-BEML MRS1-T&C-')
# 	# self.ckdmndl_NCR.clicked.connect(displaytext)


# 	self.createPushButton('submit_NCR', 'SUBMIT', '', int(0.075 * QApplication.primaryScreen().availableGeometry().width()))
# 	self.createPushButton('cancel_NCR', 'CANCEL', '', int(0.075 * QApplication.primaryScreen().availableGeometry().width()))

# 	ncrHboxlayout = QHBoxLayout()
# 	ncrHboxlayout.addWidget(self.submit_NCR, alignment = Qt.AlignRight)
# 	ncrHboxlayout.addWidget(self.cancel_NCR, alignment = Qt.AlignLeft)

# 	self.mainVerticalLayout_NcrForm.addLayout(ncrHboxlayout)
	

# 	########################################################################

# 	self.allFields = [self.reportno, self.projectLineEdit_NCR, self.productLineEdit_NCR, self.quantityLineEdit_NCR, self.supplierLineEdit_NCR,
# 					self.detectionLineEdit_NCR,self.placeComboBox_NCR, self.storedLineEdit_NCR, self.severityComboBox_NCR,self.distributiontoLineEdit_NCR,
# 					self.trainComboBox_NCR, self.carComboBox_NCR, self.assydwgnoLineEdit_NCR, self.revLineEdit_NCR, self.partnoLineEdit_NCR,
# 					self.assysnoLineEdit_NCR, self.partserialnoLineEdit_NCR, self.blnoLineEdit_NCR, self.invoicenoLineEdit_NCR, self.responsiblepartyLineEdit_NCR,
# 					self.materialstatusComboBox_NCR, self.descriptionofnonconform_NCR,self.attacheddocuments1_NCR, self.date_NCR, self.teamLineEdit_NCR, 
# 					self.issuedbyLineEdit_NCR, self.reviewedbyLineEdit_NCR, self.approvedbyLineEdit_NCR, self.causeofnonconformity_NCR, 
# 					self.attacheddocuments2_NCR, self.correctionorcorrectiveactionLineEdit_NCR, self.actionplan_NCR, self.attacheddocuments3_NCR, 
# 					self.date1_NCR, self.actionbyLineEdit_NCR, self.issuedby1LineEdit_NCR, self.reviewedby1LineEdit_NCR, self.approvedby1LineEdit_NCR, 
# 					self.decisionComboBox_NCR, self.repairprocedureComboBox_NCR, self.name1LineEdit_NCR, self.date2_NCR, self.sign1LineEdit_NCR, 
# 					self.name2LineEdit_NCR, self.date3_NCR, self.sign2LineEdit_NCR, self.approvalscopComboBox_NCR, self.entityLineEdit_NCR, 
# 					self.positionLineEdit_NCR, self.name3LineEdit_NCR, self.date4_NCR, self.sign3LineEdit_NCR, self.attacheddocuments4_NCR]

# 	# self.submit_NCR.clicked.connect(self.onClickingsubmit_Ncr)				
# 	def onClickingsubmit_Ncr():
# 		print('Submitting form...')
# 		# mandatoryVerification_NCR = True
# 		mandatoryIndexes = [0, 3, 4, 5, 9, 10, 19, 21, 22, 25, 26, 27, 30]
# 		# missingFields = []

# 		# Reset field styles first
# 		for index in mandatoryIndexes:
# 			field = self.allFields[index]
# 			self.quantityLineEdit_NCR.setStyleSheet(self.lineEditBoxQSS)
# 			# self.lineEditBoxQSS.setProperty("error", True)

# 			self.distributiontoLineEdit_NCR.setStyleSheet(self.lineEditBoxQSS)
# 			self.detectionLineEdit_NCR.setStyleSheet(self.lineEditBoxQSS)
# 			self.supplierLineEdit_NCR.setStyleSheet(self.lineEditBoxQSS)
# 			self.trainComboBox_NCR.setStyleSheet(self.comboBoxQSS)
# 			self.responsiblepartyLineEdit_NCR.setStyleSheet(self.lineEditBoxQSS)
# 			self.descriptionofnonconform_NCR.setStyleSheet(self.textEditBoxQSS)
# 			self.correctionorcorrectiveactionLineEdit_NCR.setStyleSheet(self.textEditBoxQSS)
# 			self.issuedbyLineEdit_NCR.setStyleSheet(self.lineEditBoxQSS)
# 			self.reviewedbyLineEdit_NCR.setStyleSheet(self.lineEditBoxQSS)
# 			self.approvedbyLineEdit_NCR.setStyleSheet(self.lineEditBoxQSS)

			
# 		# Check if mandatory fields are filled
# 		for index in mandatoryIndexes:
# 			field = self.allFields[index]
# 			if isinstance(field, QLineEdit) and not field.text().strip():
# 				field.setStyleSheet("border: 2px solid red;") 
# 			elif isinstance(field, QComboBox) and not field.currentText().strip():
# 				field.setStyleSheet("border: 2px solid red;") 
# 			elif isinstance(field, QTextEdit) and not field.toPlainText().strip():
# 				field.setStyleSheet("border: 2px solid red;")

		

# 		# if missingFields:
# 		# QMessageBox.warning(self, "Mandatory Fields", f"Please fill in the following fields")
# 		# pass		

# 		# Create the new report number
# 		# ReportNo = f'{report_prefix} - {new_number}'
# 		# print('New ReportNo:', ReportNo)
# 		# self.current_ncr.setText(ReportNo)
		
# 		# self.current_ncr.text()
# 		# ReportNo = self.reportno.text()	
# 		ReportNo = f'{self.reportno.text()} {self.ckdmndl_NCR.text()} {self.current_ncr.text()}'
# 		print('jj',ReportNo)
# 		# self.current_ncr.setText(f'- {new_number}')
# 		Project = self.projectLineEdit_NCR.text()
# 		Product = self.productLineEdit_NCR.text()
# 		Quantity = self.quantityLineEdit_NCR.text()
# 		Supplier = self.supplierLineEdit_NCR.text()
# 		Detection = self.detectionLineEdit_NCR.text()
# 		Place = self.placeComboBox_NCR.currentText() 
# 		Storedat = self.storedLineEdit_NCR.text()
# 		Severity = self.severityComboBox_NCR.currentText()
# 		Distribution = self.distributiontoLineEdit_NCR.text()
# 		Train = self.trainComboBox_NCR.currentText()
# 		Car = self.carComboBox_NCR.currentText()
# 		Assydwgno = self.assydwgnoLineEdit_NCR.text()
# 		Rev = self.revLineEdit_NCR.text()
# 		Partno = self.partnoLineEdit_NCR.text()
# 		Assysno = self.assysnoLineEdit_NCR.text()
# 		Partserialno = self.partserialnoLineEdit_NCR.text()
# 		Blno = self.blnoLineEdit_NCR.text()
# 		Invoiceno = self.invoicenoLineEdit_NCR.text()
# 		Responsibleparty = self.responsiblepartyLineEdit_NCR.text()
# 		Materialstatus = self.materialstatusComboBox_NCR.currentText()
# 		Descriptionnonconform = self.descriptionofnonconform_NCR.toPlainText()			
# 		Attacheddocuments1 = ", ".join([self.attacheddocuments1_NCR.fileListWidget.item(i).text() for i in range(self.attacheddocuments1_NCR.fileListWidget.count())])	
# 		Date = self.date_NCR.date().toString("yyyy-MM-dd")
		
# 		Team = self.teamLineEdit_NCR.text()
# 		Issuedby = self.issuedbyLineEdit_NCR.text()
# 		Reviewedby = self.reviewedbyLineEdit_NCR.text()
# 		Approvedby = self.approvedbyLineEdit_NCR.text()
# 		Causenonconformity = self.causeofnonconformity_NCR.toPlainText()
# 		Attacheddocuments2 = ", ".join([self.attacheddocuments2_NCR.fileListWidget.item(i).text() for i in range(self.attacheddocuments2_NCR.fileListWidget.count())])
# 		Correctiocorrectiveaction = self.correctionorcorrectiveactionLineEdit_NCR.toPlainText()
# 		Actionplan = self.actionplan_NCR.toPlainText()
		
# 		Attacheddocuments3 = ", ".join([self.attacheddocuments3_NCR.fileListWidget.item(i).text() for i in range(self.attacheddocuments3_NCR.fileListWidget.count())])			
# 		Date1 = self.date1_NCR.date().toString("yyyy-MM-dd")
# 		Actionby = self.actionbyLineEdit_NCR.text()
# 		Issued1by = self.issuedby1LineEdit_NCR.text()
# 		Reviewed1by = self.reviewedby1LineEdit_NCR.text()
# 		Approved1by = self.approvedby1LineEdit_NCR.text()
# 		Decision = self.decisionComboBox_NCR.currentText()
# 		Repairprocedure = self.repairprocedureComboBox_NCR.currentText()
# 		Name1 = self.name1LineEdit_NCR.text()
# 		Date2 = self.date2_NCR.date().toString("yyyy-MM-dd")
# 		Sign1 = self.sign1LineEdit_NCR.text()
# 		Name2 = self.name2LineEdit_NCR.text()
# 		Date3 = self.date3_NCR.date().toString("yyyy-MM-dd")
# 		Sign2 = self.sign2LineEdit_NCR.text()
# 		Approvalscope = self.approvalscopComboBox_NCR.currentText()
# 		Entity = self.entityLineEdit_NCR.text()
# 		Position = self.positionLineEdit_NCR.text()
# 		Name3 = self.name3LineEdit_NCR.text()
# 		Date4 = self.date4_NCR.date().toString("yyyy-MM-dd")
# 		Sign3 = self.sign3LineEdit_NCR.text()
# 		Signedncr = ", ".join([self.attacheddocuments4_NCR.fileListWidget.item(i).text() for i in range(self.attacheddocuments4_NCR.fileListWidget.count())])
		
# 		rev_value = Rev if Rev is not None and Rev != '' else None
# 		repair_procedure_value = Repairprocedure if Repairprocedure in ['Yes', 'No'] else None

# 		ncrFormData = [ReportNo, Project, Product, Quantity, Supplier, Detection, Place, Storedat, Severity, Distribution, Train, Car, Assydwgno, rev_value, Partno, Assysno, Partserialno, Blno, Invoiceno, Responsibleparty, Materialstatus,
# 					Descriptionnonconform, Attacheddocuments1, Date, Team, Issuedby, Reviewedby, Approvedby, Causenonconformity, Attacheddocuments2, Correctiocorrectiveaction,
# 					Actionplan, Attacheddocuments3, Date1, Actionby, Issued1by, Reviewed1by, Approved1by, Decision, repair_procedure_value, Name1, Date2, Sign1,
# 					Name2, Date3, Sign2, Approvalscope, Entity, Position, Name3, Date4, Sign3, Signedncr,self.user_id ]

# 		# print('11',ncrFormData)		
	
	
# 		query = """
# 			INSERT INTO ncr
# 			(report_no, project, product, quantity, supplier, detection, place, stored_at, severity, distribution_to, trainset, car, 
# 			assy_dwg_no, rev, part_no, assy_serial_no, part_serial_no, bl_no, invoice_no, responsible_party, material_status, 
# 			description_of_nonconform, attachments_one, attachments_one_date, attachments_one_team, attachments_one_issued_by, 
# 			attachments_one_reviewed_by, attachments_one_approved_by, cause_of_nonconformity, attached_documents_two, 
# 			acorrection_corrective_action_result, baction_Plan, attachments_three, attachments_three_date, attachments_three_action_by,
# 			attachments_three_issued_by, attachments_three_reviewed_by, attachments_three_approved_by, decision, repair_procedure,
# 			correction_name, correction_date, correction_sign, correctiveaction_name, correctiveaction_date, correctiveaction_sign,
# 			approval_scope, approvedby_entity, approvedby_position, approvedby_name, approvedby_date, approvedby_sign, signed_ncr, user_id
# 			) 
# 			VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s,
# 					%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
# 		""" 
# 		# print("Query:", query)
# 		# print("Data:", ncrFormData)

# 		# Print lengths for debugging
# 		print("Number of parameters:", len(ncrFormData))
# 		print("Number of placeholders in query:", query.count('%s'))
		
# 		try:
# 			self.cursor.execute(query, tuple(ncrFormData))
# 			self.mydb.commit()
# 			print("Data saved successfully.")

# 			# Increment the report number and update it
# 			self.cursor.execute("SELECT report_no FROM ncr ORDER BY id DESC LIMIT 1")
# 			last_record = self.cursor.fetchone()

# 			if last_record:
# 				last_report_no = last_record[0]  # Get the last report number
# 				# Assuming the format is 'XXX-XXX-<number>', extract the last number part
# 				last_number_part = last_report_no.split('-')[-1].strip()
# 				current_number = int(last_number_part)  # Extract and convert to int
# 				new_number = current_number + 1
# 				self.current_ncr.setText(f"- {new_number}")  # Update the label with the new number
# 				print(f"New report number: - {new_number}")
# 			else:
# 				self.current_ncr.setText("- 1")  # If no records exist, start with 1
# 				print("New report number: - 1")

# 		except Exception as e:
# 			print(f"Error: {e}")
# 			QMessageBox.critical(self, "Database Error", f"An error occurred: {e}")
# 		# else:		
# 		# 	QMessageBox.warning(self, "Mandatory Fields", f"Please fill in the following fields")		

# 	self.submit_NCR.clicked.connect(onClickingsubmit_Ncr)



# 	def onClickingcancel_Ncr():
# 		print('gggffg')
# 		self.projectLineEdit_NCR.clear()
# 		self.productLineEdit_NCR.clear()
# 		self.quantityLineEdit_NCR.clear()
# 		self.supplierLineEdit_NCR.clear()
# 		self.detectionLineEdit_NCR.clear()
# 		self.placeComboBox_NCR.setCurrentIndex(-1) 
# 		self.storedLineEdit_NCR.clear()
# 		self.severityComboBox_NCR.setCurrentIndex(-1)
# 		self.distributiontoLineEdit_NCR.clear()
# 		self.trainComboBox_NCR.setCurrentIndex(-1)
# 		self.carComboBox_NCR.setCurrentIndex(-1)
# 		self.assydwgnoLineEdit_NCR.clear()
# 		self.revLineEdit_NCR.clear()
# 		self.partnoLineEdit_NCR.clear()

# 		self.assysnoLineEdit_NCR.clear()
# 		self.partserialnoLineEdit_NCR.clear()
# 		self.blnoLineEdit_NCR.clear()
# 		self.invoicenoLineEdit_NCR.clear()
# 		self.responsiblepartyLineEdit_NCR.clear()
# 		self.materialstatusComboBox_NCR.setCurrentIndex(-1)
# 		self.descriptionofnonconform_NCR.clear()
# 		self.attacheddocuments1_NCR.fileListWidget.clear()
# 		# self.date_NCR.date()
# 		self.teamLineEdit_NCR.clear()
# 		self.issuedbyLineEdit_NCR.clear()
# 		self.reviewedbyLineEdit_NCR.clear()
# 		self.approvedbyLineEdit_NCR.clear()
# 		self.causeofnonconformity_NCR.clear()
# 		self.attacheddocuments2_NCR.fileListWidget.clear()
# 		self.correctionorcorrectiveactionLineEdit_NCR.clear()
# 		self.actionplan_NCR.clear()
# 		self.attacheddocuments3_NCR.fileListWidget.clear()	
# 		self.date1_NCR.setDate(self.date1_NCR.minimumDate())

# 		self.actionbyLineEdit_NCR.clear()
# 		self.issuedby1LineEdit_NCR.clear()
# 		self.reviewedby1LineEdit_NCR.clear()
# 		self.approvedby1LineEdit_NCR.clear()
# 		self.decisionComboBox_NCR.setCurrentIndex(-1)
# 		self.repairprocedureComboBox_NCR.setCurrentIndex(-1)
# 		self.name1LineEdit_NCR.clear()
# 		# self.date2_NCR.date()
# 		self.sign1LineEdit_NCR.clear()
# 		self.name2LineEdit_NCR.clear()
# 		# self.date3_NCR.date()
# 		self.sign2LineEdit_NCR.clear()
# 		self.approvalscopComboBox_NCR.setCurrentIndex(-1)
# 		self.entityLineEdit_NCR.clear()
# 		self.positionLineEdit_NCR.clear()
# 		self.name3LineEdit_NCR.clear()
# 		# self.date4_NCR.date()
# 		self.sign3LineEdit_NCR.clear()
# 		self.attacheddocuments4_NCR.fileListWidget.clear()

	
# 	self.cancel_NCR.clicked.connect(onClickingcancel_Ncr)


# 		# #############################################################################











# 	def givingFunctionalityToButton(switch, func, btee, hh):
# 		switch.clicked.connect(lambda: func(btee, hh))

# 		#button.clicked.connect(onbuttonClicked(button.text()))
	
# 	def onbuttonClicked(abcd, hh):
# 		print('jkjkjkj')
# 		print(abcd, hh)


# 	for rowIndex, rowData in enumerate(NcrDataResult):
# 		self.ncrDataTable_NCR.insertRow(self.ncrDataTable_NCR.rowCount()) 
# 		for colIndex, fieldData in enumerate(rowData):
# 			if colIndex == 0: 
# 				button = QPushButton(str(fieldData))
# 				clr='red'
# 				givingFunctionalityToButton(button, onbuttonClicked, button.text(),clr)

# 				button.setStyleSheet("QPushButton { text-decoration: none; } QPushButton:hover { text-decoration: underline; }")
# 				button.setCursor(Qt.PointingHandCursor)
# 				self.ncrDataTable_NCR.setCellWidget(self.ncrDataTable_NCR.rowCount()-1, colIndex+1, button)
