from PySide6.QtWidgets import QLabel, QWidget, QVBoxLayout, QTextEdit, QSpacerItem, QDialog, QMessageBox, QSizePolicy, QFileDialog, QHBoxLayout, QCheckBox, QScrollBar, QScrollArea, QTabWidget,QTableWidget, QTableWidgetItem, QAbstractItemView, QFormLayout, QLineEdit, QComboBox, QGridLayout, QPushButton, QSpinBox
from PySide6.QtCore import Qt,QDate
from PySide6.QtGui import QIcon
from openpyxl import Workbook
def ncrUI(self):
	from PySide6.QtWidgets import QApplication	
	# from PySide6.QtCore import QDate
	# self.mainVerticalLayout_Ncr.addWidget(QLabel('NONCONFORMITY REPORT'), alignment = Qt.AlignCenter)	

	self.vboxlayout =QVBoxLayout()
	self.mainVerticalLayout_Ncr.addLayout(self.vboxlayout)

	self.ncrhboxlayout = QHBoxLayout()

	checkAllUserIconPath = self.currentTheme.get('oppositeColorCheckBoxIcon')
	unCheckAllUserIconPath = self.currentTheme.get('oppositeColorUnCheckBoxIcon')
	partiallyCheckedIconPath = self.currentTheme.get('oppositeColorPartiallyCheckedBoxIcon')

	deleteIconPath = self.currentTheme.get('whiteDeleteIcon')
	darkCheckBoxIconPath = self.currentTheme.get('darkCheckBoxIcon')
	darkUnCheckBoxIconPath = self.currentTheme.get('darkUnCheckBoxIcon')


	downloadIconPath = self.currentTheme.get('downloadIcon')

	self.createPushButton('selectAllNcrButton', '', unCheckAllUserIconPath, 30)
	self.createPushButton('deleteButton_Ncr', '', deleteIconPath, 35, 'Delete')
	self.createLineEditBox('serachBarOfNcrTable', 'Search..' )
	self.serachBarOfNcrTable.setClearButtonEnabled(True)
	self.serachBarOfNcrTable.setFixedWidth(int(0.2 * QApplication.primaryScreen().availableGeometry().width()))
	self.createPushButton('download_Ncr', '', downloadIconPath, 35, 'Download')
	self.createPushButton('newncr_NCR', '+ New NCR', '', int(0.065 * QApplication.primaryScreen().availableGeometry().width()))

	self.ncrhboxlayout.addWidget(self.selectAllNcrButton)
	self.ncrhboxlayout.addWidget(self.deleteButton_Ncr)
	self.ncrhboxlayout.addWidget(self.serachBarOfNcrTable)
	self.ncrhboxlayout.addWidget(self.download_Ncr)
	self.ncrhboxlayout.addItem(QSpacerItem(1, 0, QSizePolicy.Expanding, QSizePolicy.Minimum))
	self.ncrhboxlayout.addWidget(self.newncr_NCR)
	self.vboxlayout.addLayout(self.ncrhboxlayout)

	self.ncrDataTable_NCR = QTableWidget()
	self.ncrDataTable_NCR.setMinimumHeight(int(0.78 * QApplication.primaryScreen().availableGeometry().height()))

	self.headersOfNCRTable  = ['', 'Report No', 'Project', 'Product', 'Quantity', 'Supplier', 'Detection' ,'Place', 'Stored at', 'Severity',
						'Distribution to', 'Trainset', 'Car', 'Assy dwg no', 'Rev', 'Part No','Assy Serial No', 'Part Serial No', 'B/L No', 'Invoice no', 'Responsible party', 
						'Material status', 'Description of non-conform', 'Attached documents (if any)', 'Date', 'Team', 'Issued by',
						'Reviewed by', 'Approved by', 'Cause of nonconformity', 'Attached documents (if any)', 'A.Correction/corrective action result', 
						'B.Action Plan:', 'Attached documents (if any)', 'Date', 'Action by', 'Issued by', 'Reviewed by', 'Approved by', 
						'Decision', 'Repair procedure', 'Name', 'Date', 'Sign', 'Name', 'Date', 'Sign', 'Approval Scope', 'Entity',
						'Position', 'Name', 'Date', 'Sign', 'Signed NCR']
			
	# self.ncrDataTabWidget_NCR.setColumnCount(len(headersOfNCRTable))
	self.ncrDataTable_NCR.setColumnCount(len(self.headersOfNCRTable))

	self.ncrDataTable_NCR.setHorizontalHeaderLabels(self.headersOfNCRTable)
	self.ncrDataTable_NCR.setStyleSheet(self.tableWidgetQSS)
	self.ncrDataTable_NCR.horizontalHeader().setStyleSheet(self.headerHorizontalQSS)
	self.ncrDataTable_NCR.setAlternatingRowColors(True)
	self.ncrDataTable_NCR.setShowGrid(False)
	
	self.ncrDataTable_NCR.setEditTriggers(QAbstractItemView.NoEditTriggers)


	self.ncrDataTable_NCR.setColumnWidth(0, int(0.07 * QApplication.primaryScreen().availableGeometry().width()))
	self.ncrDataTable_NCR.setColumnWidth(1, int(0.06 * QApplication.primaryScreen().availableGeometry().width()))
	self.ncrDataTable_NCR.setColumnWidth(2, int(0.07 * QApplication.primaryScreen().availableGeometry().width()))
	self.ncrDataTable_NCR.setColumnWidth(3, int(0.07 * QApplication.primaryScreen().availableGeometry().width()))
	self.ncrDataTable_NCR.setColumnWidth(4, int(0.1 * QApplication.primaryScreen().availableGeometry().width()))
	self.ncrDataTable_NCR.setColumnWidth(5, int(0.08 * QApplication.primaryScreen().availableGeometry().width()))
	self.ncrDataTable_NCR.setColumnWidth(6, int(0.08 * QApplication.primaryScreen().availableGeometry().width()))
	self.ncrDataTable_NCR.setColumnWidth(7, int(0.07 * QApplication.primaryScreen().availableGeometry().width()))
	self.ncrDataTable_NCR.setColumnWidth(8, int(0.07 * QApplication.primaryScreen().availableGeometry().width()))
	self.ncrDataTable_NCR.setColumnWidth(9, int(0.15 * QApplication.primaryScreen().availableGeometry().width()))
	self.ncrDataTable_NCR.setColumnWidth(10, int(0.15 * QApplication.primaryScreen().availableGeometry().width()))
	self.ncrDataTable_NCR.setColumnWidth(11, int(0.1 * QApplication.primaryScreen().availableGeometry().width()))
	self.ncrDataTable_NCR.setColumnWidth(12, int(0.12 * QApplication.primaryScreen().availableGeometry().width()))
	self.ncrDataTable_NCR.setColumnWidth(13, int(0.12 * QApplication.primaryScreen().availableGeometry().width()))
	self.ncrDataTable_NCR.setColumnWidth(14, int(0.1 * QApplication.primaryScreen().availableGeometry().width()))
	self.ncrDataTable_NCR.setColumnWidth(15, int(0.14 * QApplication.primaryScreen().availableGeometry().width()))
	self.ncrDataTable_NCR.setColumnWidth(16, int(0.12 * QApplication.primaryScreen().availableGeometry().width()))
	self.ncrDataTable_NCR.setColumnWidth(17, int(0.12 * QApplication.primaryScreen().availableGeometry().width()))
	self.ncrDataTable_NCR.setColumnWidth(18, int(0.09 * QApplication.primaryScreen().availableGeometry().width()))
	self.ncrDataTable_NCR.setColumnWidth(19, int(0.11 * QApplication.primaryScreen().availableGeometry().width()))
	self.ncrDataTable_NCR.setColumnWidth(20, int(0.1 * QApplication.primaryScreen().availableGeometry().width()))
	self.ncrDataTable_NCR.setColumnWidth(21, int(0.1 * QApplication.primaryScreen().availableGeometry().width()))
	self.ncrDataTable_NCR.setColumnWidth(22, int(0.1 * QApplication.primaryScreen().availableGeometry().width()))
	self.ncrDataTable_NCR.setColumnWidth(23, int(0.14 * QApplication.primaryScreen().availableGeometry().width()))
	self.ncrDataTable_NCR.setColumnWidth(24, int(0.15 * QApplication.primaryScreen().availableGeometry().width()))
	self.ncrDataTable_NCR.setColumnWidth(25, int(0.12 * QApplication.primaryScreen().availableGeometry().width()))
	self.ncrDataTable_NCR.setColumnWidth(26, int(0.07 * QApplication.primaryScreen().availableGeometry().width()))
	self.ncrDataTable_NCR.setColumnWidth(27, int(0.08 * QApplication.primaryScreen().availableGeometry().width()))
	self.ncrDataTable_NCR.setColumnWidth(28, int(0.08 * QApplication.primaryScreen().availableGeometry().width()))
	self.ncrDataTable_NCR.setColumnWidth(29, int(0.08 * QApplication.primaryScreen().availableGeometry().width()))
	self.ncrDataTable_NCR.setColumnWidth(30, int(0.08 * QApplication.primaryScreen().availableGeometry().width()))
	self.ncrDataTable_NCR.setColumnWidth(31, int(0.08 * QApplication.primaryScreen().availableGeometry().width()))
	self.ncrDataTable_NCR.setColumnWidth(32, int(0.08 * QApplication.primaryScreen().availableGeometry().width()))
	self.ncrDataTable_NCR.setColumnWidth(33, int(0.08 * QApplication.primaryScreen().availableGeometry().width()))
	self.ncrDataTable_NCR.setColumnWidth(34, int(0.1 * QApplication.primaryScreen().availableGeometry().width()))
	self.ncrDataTable_NCR.setColumnWidth(35, int(0.08 * QApplication.primaryScreen().availableGeometry().width()))
	self.ncrDataTable_NCR.setColumnWidth(36, int(0.08 * QApplication.primaryScreen().availableGeometry().width()))
	self.ncrDataTable_NCR.setColumnWidth(37, int(0.08 * QApplication.primaryScreen().availableGeometry().width()))
	self.ncrDataTable_NCR.setColumnWidth(38, int(0.08 * QApplication.primaryScreen().availableGeometry().width()))
	self.ncrDataTable_NCR.setColumnWidth(39, int(0.08 * QApplication.primaryScreen().availableGeometry().width()))
	self.ncrDataTable_NCR.setColumnWidth(40, int(0.08 * QApplication.primaryScreen().availableGeometry().width()))
	self.ncrDataTable_NCR.setColumnWidth(41, int(0.08 * QApplication.primaryScreen().availableGeometry().width()))
	self.ncrDataTable_NCR.setColumnWidth(42, int(0.08 * QApplication.primaryScreen().availableGeometry().width()))
	self.ncrDataTable_NCR.setColumnWidth(43, int(0.1 * QApplication.primaryScreen().availableGeometry().width()))
	self.ncrDataTable_NCR.setColumnWidth(44, int(0.08 * QApplication.primaryScreen().availableGeometry().width()))
	self.ncrDataTable_NCR.setColumnWidth(45, int(0.08 * QApplication.primaryScreen().availableGeometry().width()))
	self.ncrDataTable_NCR.setColumnWidth(46, int(0.08 * QApplication.primaryScreen().availableGeometry().width()))
	self.ncrDataTable_NCR.setColumnWidth(47, int(0.08 * QApplication.primaryScreen().availableGeometry().width()))
	self.ncrDataTable_NCR.setColumnWidth(48, int(0.08 * QApplication.primaryScreen().availableGeometry().width()))
	self.ncrDataTable_NCR.setColumnWidth(49, int(0.08 * QApplication.primaryScreen().availableGeometry().width()))
	self.ncrDataTable_NCR.setColumnWidth(50, int(0.08 * QApplication.primaryScreen().availableGeometry().width()))
	self.ncrDataTable_NCR.setColumnWidth(51, int(0.1 * QApplication.primaryScreen().availableGeometry().width()))
	self.ncrDataTable_NCR.setColumnWidth(52, int(0.1 * QApplication.primaryScreen().availableGeometry().width()))
	
	
	self.selectAllNcrButton.setVisible(True)
	self.selectAllNcrButton.setCheckable(True)
	self.selectAllNcrButton.setFixedHeight(26)

	self.deleteButton_Ncr.setVisible(False)

	# self.ncrDataTable_NCR.clearContents()
	# self.ncrDataTable_NCR.setRowCount(0)		

	queryone = '''SELECT
	ncr.report_no,
	ncr.project,
	ncr.product,
	ncr.quantity,
	ncr.supplier,
	ncr.detection,
	ncr.place,
	ncr.stored_at,
	ncr.severity,
	ncr.distribution_to,
	ncr.trainset,
	ncr.car,
	ncr.assy_dwg_no,
	ncr.rev,
	ncr.part_no,
	ncr.assy_serial_no,
	ncr.part_serial_no,
	ncr.bl_no,
	ncr.invoice_no,
	ncr.responsible_party,
	ncr.material_status,
	ncr.description_of_nonconform,
	ncr.attachments_one,
	ncr.attachments_one_date,
	ncr.attachments_one_team,
	ncr.attachments_one_issued_by,
	ncr.attachments_one_reviewed_by,
	ncr.attachments_one_approved_by,
	ncr.cause_of_nonconformity,
	ncr.attached_documents_two,
	ncr.acorrection_corrective_action_result,
	ncr.baction_Plan,
	ncr.attachments_three,
	ncr.attachments_three_date,
	ncr.attachments_three_action_by,
	ncr.attachments_three_issued_by,
	ncr.attachments_three_reviewed_by,
	ncr.attachments_three_approved_by,
	ncr.decision,
	ncr.repair_procedure,
	ncr.correction_name,
	ncr.correction_date,
	ncr.correction_sign,
	ncr.correctiveaction_name,
	ncr.correctiveaction_date,
	ncr.correctiveaction_sign,
	ncr.approval_scope,
	ncr.approvedby_entity,
	ncr.approvedby_position,
	ncr.approvedby_name,
	ncr.approvedby_date,
	ncr.approvedby_sign,
	ncr.signed_ncr

	FROM
		ncr
	'''
	self.cursor.execute(queryone)
	NcrDataResult = self.cursor.fetchall()
	print('jokkop',NcrDataResult)

	# for rowIndex, rowData in enumerate(NcrDataResult):
	# 	self.ncrDataTable_NCR.insertRow(self.ncrDataTable_NCR.rowCount())  # Add a new row
	# 	for colIndex, fieldData in enumerate(rowData[1:]):
	# 		item = QTableWidgetItem(str(fieldData)) 
	# 		self.ncrDataTable_NCR.setItem(self.ncrDataTable_NCR.rowCount()-1, colIndex+2, item)

	# 	button = QPushButton(str(NcrDataResult[rowIndex][0]))
	# 	button.setStyleSheet("QPushButton { text-decoration: none; }" "QPushButton:hover { text-decoration: underline; }")
	# 	button.setCursor(Qt.PointingHandCursor)

	# 	self.ncrDataTable_NCR.setCellWidget(self.ncrDataTable_NCR.rowCount()-1, 1, button)


	for rowIndex, rowData in enumerate(NcrDataResult):
		self.ncrDataTable_NCR.insertRow(self.ncrDataTable_NCR.rowCount()) 
		for colIndex, fieldData in enumerate(rowData):
			if colIndex == 0: 
				button = QPushButton(str(fieldData))
				# connect_button_clicked(button, onButtonClicked_ncrData, rowIndex)  # Connect button click event
				print(button.text())
				button.clicked.connect(lambda: onButtonClicked_ncrData(self, button.text(), rowIndex))
				
				# button.clicked.connect(lambda : on_clicked_function(self, button.text(), rowNum))

				button.setStyleSheet("QPushButton { text-decoration: none; } QPushButton:hover { text-decoration: underline; }")
				button.setCursor(Qt.PointingHandCursor)
				self.ncrDataTable_NCR.setCellWidget(self.ncrDataTable_NCR.rowCount()-1, colIndex+1, button)
			else: 
				if fieldData is not None:
					item = QTableWidgetItem(str(fieldData))
				else:
					item = QTableWidgetItem('')
				item.setFlags(item.flags() & ~Qt.ItemIsEditable) 
				item.setTextAlignment(Qt.AlignCenter)
				item.setToolTip(item.text())
				self.ncrDataTable_NCR.setItem(self.ncrDataTable_NCR.rowCount()-1, colIndex+1, item)

	self.vboxlayout.addWidget(self.ncrDataTable_NCR)

	

	def on_searchBox_filter_ncr_table():
		print('nfnf')
		searchText = self.serachBarOfNcrTable.text().lower()

		for row in range(self.ncrDataTable_NCR.rowCount()):
			self.ncrDataTable_NCR.setRowHidden(row, True)

			if self.ncrDataTable_NCR.cellWidget(row, 1) and (searchText in self.ncrDataTable_NCR.cellWidget(row, 1).text().lower()):
				self.ncrDataTable_NCR.setRowHidden(row, False)

			for col in range(1,self.ncrDataTable_NCR.columnCount()):
				item = self.ncrDataTable_NCR.item(row, col)
				if item is not None and searchText in item.text().lower():
					self.ncrDataTable_NCR.setRowHidden(row, False)
					break

	self.serachBarOfNcrTable.textChanged.connect(on_searchBox_filter_ncr_table)



	def onclicking_selectall_NCRDT(checked):
		if checked:
			self.selectAllNcrButton.setIcon(QIcon(checkAllUserIconPath))

			for i in range(self.ncrDataTable_NCR.rowCount()):
				if not self.ncrDataTable_NCR.isRowHidden(i):
					if isinstance(self.ncrDataTable_NCR.cellWidget(i,0), QCheckBox):
						self.ncrDataTable_NCR.cellWidget(i,0).setCheckState(Qt.Checked)
		
		else:
			self.selectAllNcrButton.setIcon(QIcon(unCheckAllUserIconPath))

			for i in range(self.ncrDataTable_NCR.rowCount()):
				if not self.ncrDataTable_NCR.isRowHidden(i):
					if isinstance(self.ncrDataTable_NCR.cellWidget(i,0), QCheckBox):
						self.ncrDataTable_NCR.cellWidget(i,0).setCheckState(Qt.Unchecked)

	
	self.selectAllNcrButton.toggled.connect(onclicking_selectall_NCRDT)

	def onStateChangedOf_NCRCheckBox():
		all_checked = True
		all_unchecked = True

		for i in range(self.ncrDataTable_NCR.rowCount()):
			if not self.ncrDataTable_NCR.isRowHidden(i):
				if isinstance(self.ncrDataTable_NCR.cellWidget(i,0), QCheckBox):
					if self.ncrDataTable_NCR.cellWidget(i,0).isChecked():
						all_unchecked = False
					else:
						all_checked = False

		if all_checked or all_unchecked:
			some_checked = False
		else:
			some_checked = True


		if all_checked:
			self.deleteButton_Ncr.show()
			self.selectAllNcrButton.setIcon(QIcon(checkAllUserIconPath))
			self.selectAllNcrButton.setChecked(True)

		if all_unchecked:
			self.deleteButton_Ncr.hide()
			self.selectAllNcrButton.setIcon(QIcon(unCheckAllUserIconPath))

		if some_checked:
			self.deleteButton_Ncr.show()
			self.selectAllNcrButton.setIcon(QIcon(partiallyCheckedIconPath))

	# def populate_ncr_table(self, NcrDataResult):
	# 	for rowIndex, rowData in enumerate(NcrDataResult):
	# 		# Insert a row in the table
	# 		self.ncrDataTable_NCR.insertRow(self.ncrDataTable_NCR.rowCount()) 
			
	# 		# Create checkbox and connect its state change to the method
	# 		ncrCheckBoxWidget = QCheckBox('')
	# 		ncrCheckBoxWidget.setStyleSheet(self.checkBoxQSS)
	# 		self.ncrDataTable_NCR.setCellWidget(rowIndex, 0, ncrCheckBoxWidget)
	# 		ncrCheckBoxWidget.stateChanged.connect(lambda state, row=rowIndex: self.onStateChangedOf_NCRCheckBox())

	# 		# Populate other fields in the table with data
	# 		for colIndex, fieldData in enumerate(rowData):
	# 			if colIndex == 0:  # If the first column (i.e. fieldData is the report number)
	# 				button = QPushButton(str(fieldData))
	# 				button.clicked.connect(self.onButtonClicked_ncrData(abcd))
	# 				button.setStyleSheet("QPushButton { text-decoration: none; } QPushButton:hover { text-decoration: underline; }")
	# 				button.setCursor(Qt.PointingHandCursor)
					
	# 				# Place the button in the cell widget
	# 				self.ncrDataTable_NCR.setCellWidget(rowIndex, colIndex + 1, button)
	# 			else:  # For other columns
	# 				if fieldData is not None:
	# 					item = QTableWidgetItem(str(fieldData))
	# 				else:
	# 					item = QTableWidgetItem('')
	# 				item.setFlags(item.flags() & ~Qt.ItemIsEditable)  # Make cells non-editable
	# 				item.setTextAlignment(Qt.AlignCenter)  # Align text to center
	# 				item.setToolTip(item.text())  # Optional: set tooltips with the same text
	# 				self.ncrDataTable_NCR.setItem(rowIndex, colIndex + 1, item)
		


	def onclicking_delete_NCRDT():
			
		selectedReportnoIndices_ = []
		selectedReportnos = []

		numberOfSelectedReportnos = 0

		for i in range(self.ncrDataTable_NCR.rowCount()):
			if not self.ncrDataTable_NCR.isRowHidden(i):
				if isinstance(self.ncrDataTable_NCR.cellWidget(i,0), QCheckBox):
					if self.ncrDataTable_NCR.cellWidget(i,0).checkState() == Qt.Checked:
						selectedReportnoIndices_.append(i)

						ReportnoButton = self.ncrDataTable_NCR.cellWidget(i, 1)
						if ReportnoButton:
							# selectedCMIds = CMIdButton.text()
							selectedReportnos.append(ReportnoButton.text())
							numberOfSelectedReportnos += 1
		

		if selectedReportnos:

			confirmDeleteNCRMsgBox = QMessageBox()
			confirmDeleteNCRMsgBox.setIcon(QMessageBox.Question) 
			# confirmDeleteNCRMsgBox.setText(f'Are sure you want to delete the selected CM data')
			confirmDeleteNCRMsgBox.setText(f"Are you sure you want to delete {numberOfSelectedReportnos} Reportnos?")
			confirmDeleteNCRMsgBox.setWindowTitle("Confirm")
			confirmDeleteNCRMsgBox.setWindowIcon(QIcon('Media/ramsify.png'))
			confirmDeleteNCRMsgBox.setStandardButtons(QMessageBox.Ok | QMessageBox.No)
			
			userResponse = confirmDeleteCMMsgBox.exec()

			if userResponse == QMessageBox.Ok:
				for ind in sorted(selectedReportnoIndices_, reverse=True):
					reportnoToDelete = selectedReportNo[selectedReportnoIndices_.index(ind)]
					sql = "DELETE FROM ncr WHERE report_no = %s"
					values = (reportnoToDelete,)
					self.cursor.execute(sql, values)
					self.mydb.commit()
					self.cmDataTable.removeRow(ind)

				ncrDeleteSuccessMsgBox = QMessageBox()
				ncrDeleteSuccessMsgBox.setIcon(QMessageBox.Information) 
				ncrDeleteSuccessMsgBox.setText(f'{numberOfSelectedCMIds} NCRs deleted successfully.')
				ncrDeleteSuccessMsgBox.setWindowTitle("Message")
				ncrDeleteSuccessMsgBox.setWindowIcon(QIcon('Media/ramsify.png'))
				ncrDeleteSuccessMsgBox.setStandardButtons(QMessageBox.Ok)
				ncrDeleteSuccessMsgBox.exec()
			
				self.deleteButton_Ncr.hide()
				self.selectAllNcrButton.setIcon(QIcon(unCheckAllUserIconPath))
			
			else:
				pass



	self.deleteButton_Ncr.clicked.connect(onclicking_delete_NCRDT)


	def onClickingDownloadBtn_NCRDT():

		file_path, _ = QFileDialog.getSaveFileName(self, "Save Excel File", "", "Excel Files (*.xlsx)")

		if file_path:

			wb = Workbook()
			ws = wb.active

			headers = []
			for col in range(1, self.ncrDataTable_NCR.columnCount()):
				if not self.ncrDataTable_NCR.isColumnHidden(col):
					header_item = self.ncrDataTable_NCR.horizontalHeaderItem(col)
					if header_item is not None:
						headers.append(header_item.text())


			ws.append(headers)

			row_index = 2
			for row in range(self.ncrDataTable_NCR.rowCount()):
				if not self.ncrDataTable_NCR.isRowHidden(row):
					# ws.cell(row=row_index, column=1).value = self.ncrDataTable_NCR.cellWidget(row, 0).text()
					for col in range(1, self.ncrDataTable_NCR.columnCount()):
						if col == 1:
							wid = self.ncrDataTable_NCR.cellWidget(row, col)
							if isinstance(wid, QPushButton):
								ws.cell(row=row_index, column=col).value = wid.text()
						else:	
							item = self.ncrDataTable_NCR.item(row, col)
							if item is not None:
								ws.cell(row=row_index, column=col).value = item.text()

					row_index += 1

			wb.save(file_path)

			ncrDownloadedMsgBox = QMessageBox()
			ncrDownloadedMsgBox.setIcon(QMessageBox.Information) 
			ncrDownloadedMsgBox.setText(f'Data downloaded successfully')
			ncrDownloadedMsgBox.setWindowTitle("Message")
			ncrDownloadedMsgBox.setWindowIcon(QIcon('Media/ramsify.png'))
			ncrDownloadedMsgBox.setStandardButtons(QMessageBox.Ok)
			ncrDownloadedMsgBox.exec_()

	self.download_Ncr.clicked.connect(onClickingDownloadBtn_NCRDT)




	def onClickingNewncr():
		# print('dfsdf')
		self.stackedWidget.setCurrentIndex(15) 
	
	self.newncr_NCR.clicked.connect(onClickingNewncr)

	# def connect_button_clicked(button, on_clicked_function, rowIndex):
	# 	print(jnjn)
	# 	button.clicked.connect(lambda : on_clicked_function(self, button.text(), rowIndex))
		
def onButtonClicked_ncrData(self, abcd):
	# print('jbjsdnfns')
	print('hhhj',abcd)
	# print('ghfghjgjghjgj',self.report_no.text())
	from PySide6.QtWidgets import QApplication

	self.ncrWindow = QWidget()
	self.ncrWindow.move(400, 100)
	# self.ncrWindow.setWindowTitle(reportno)
	self.ncrWindow.setWindowIcon(QIcon('Media/ramsify.png'))
	hboxLayout = QHBoxLayout()
	vboxLayout = QVBoxLayout()
	self.ncrWindow.setLayout(vboxLayout)
	
	vboxLayout.addLayout(hboxLayout)

	formLayout1 =QFormLayout()
	formLayout2 =QFormLayout()

	hboxLayout.addLayout(formLayout1)
	spacer_item = QSpacerItem(int(0.01 * QApplication.primaryScreen().availableGeometry().width()), 5, QSizePolicy.Fixed, QSizePolicy.Minimum)
	hboxLayout.addItem(spacer_item)
	hboxLayout.addLayout(formLayout2)

	query = '''SELECT
	ncr.report_no,
	ncr.project,
	ncr.product,
	ncr.quantity,
	ncr.supplier,
	ncr.detection,
	ncr.place,
	ncr.stored_at,
	ncr.severity,
	ncr.distribution_to,
	ncr.trainset,
	ncr.car,
	ncr.assy_dwg_no,
	ncr.rev,
	ncr.part_no,
	ncr.assy_serial_no,
	ncr.part_serial_no,
	ncr.bl_no,
	ncr.invoice_no,
	ncr.responsible_party,
	ncr.material_status,
	ncr.description_of_nonconform,
	ncr.attachments_one,
	ncr.attachments_one_date,
	ncr.attachments_one_team,
	ncr.attachments_one_issued_by,
	ncr.attachments_one_reviewed_by,
	ncr.attachments_one_approved_by,
	ncr.cause_of_nonconformity,
	ncr.attached_documents_two,
	ncr.acorrection_corrective_action_result,
	ncr.baction_Plan,
	ncr.attachments_three,
	ncr.attachments_three_date,
	ncr.attachments_three_action_by,
	ncr.attachments_three_issued_by,
	ncr.attachments_three_reviewed_by,
	ncr.attachments_three_approved_by,
	ncr.decision,
	ncr.repair_procedure,
	ncr.correction_name,
	ncr.correction_date,
	ncr.correction_sign,
	ncr.correctiveaction_name,
	ncr.correctiveaction_date,
	ncr.correctiveaction_sign,
	ncr.approval_scope,
	ncr.approvedby_entity,
	ncr.approvedby_position,
	ncr.approvedby_name,
	ncr.approvedby_date,
	ncr.approvedby_sign,
	ncr.signed_ncr

	FROM
		ncr
		WHERE report_no = "{}"
	'''.format(abcd)
	self.cursor.execute(query)
	NcrResult = self.cursor.fetchone()
	print('ncrdfgsfsf',NcrResult)



	self.ckdmndl_NCR_ = QPushButton('CKD')
	self.ckdmndl_NCR_.setFixedWidth(37)
	self.ckdmndl_NCR_.setFixedHeight(25)
	self.ckdmndl_NCR_.setStyleSheet('border-radius: 2px; background:white; border: 1px solid grey;padding: 2px;')

	self.current_ncr_ = QLabel()
	self.reportno_ = QLabel('NCR-BEML MRS1-T&C-')
	

	self.createLineEditBox('projectLineEdit_NCR_')
	self.createLineEditBox('productLineEdit_NCR_')
	self.createNumberLineEditBox('quantityLineEdit_NCR_')
	self.createLineEditBox('supplierLineEdit_NCR_')
	self.createLineEditBox('detectionLineEdit_NCR_')
	self.createComboBox2(['CKD', 'Mandala'], 'placeComboBox_NCR_')
	self.createLineEditBox('storedLineEdit_NCR_')
	self.createComboBox2(['Major', 'Minor'],'severityComboBox_NCR_')
	self.createComboBox2(['Before Installation', 'Installed', 'Disassembled', 'Before receiving'], 'materialstatusComboBox_NCR_')
	self.createLineEditBox('distributiontoLineEdit_NCR_')
	self.createCheckableComboBox(self.trainsetsList, 'trainComboBox_NCR_')
	self.createCheckableComboBox(self.carsList, 'carComboBox_NCR_')
	self.createLineEditBox('assydwgnoLineEdit_NCR_')
	self.createNumberLineEditBox('revLineEdit_NCR_')
	self.createLineEditBox('partnoLineEdit_NCR_')
	self.createLineEditBox('assysnoLineEdit_NCR_')
	self.createLineEditBox('partserialnoLineEdit_NCR_')
	self.createLineEditBox('blnoLineEdit_NCR_')
	self.createLineEditBox('invoicenoLineEdit_NCR_')
	self.createLineEditBox('responsiblepartyLineEdit_NCR_')
	self.createComboBox2(['Before Installation', 'Installed', 'Disassembled', 'Before receiving'], 'materialstatusComboBox_NCR_')
	self.createTextEditBox('descriptionofnonconform_NCR_')
	self.createAttachmentWidget('attacheddocuments1_NCR_')

	self.createDateEditBox('date_NCR_')
	current_date_ = QDate.currentDate()
	self.date_NCR_.setMinimumDate(QDate(current_date_.year(), current_date_.month(), 1))
	
	self.createLineEditBox('teamLineEdit_NCR_')
	self.createLineEditBox('issuedbyLineEdit_NCR_')
	self.createLineEditBox('reviewedbyLineEdit_NCR_')
	self.createLineEditBox('approvedbyLineEdit_NCR_')
	self.createTextEditBox('causeofnonconformity_NCR_')

	self.createAttachmentWidget('attacheddocuments2_NCR_')
	self.createTextEditBox('correctionorcorrectiveactionLineEdit_NCR_')
	self.createTextEditBox('actionplan_NCR_')
	self.createAttachmentWidget('attacheddocuments3_NCR_')
	self.createDateEditBox('date1_NCR_')
	self.date1_NCR_.setMinimumDate(QDate(current_date_.year(), current_date_.month(), 1))
	
	self.createLineEditBox('actionbyLineEdit_NCR_')
	self.createLineEditBox('issuedby1LineEdit_NCR_')
	self.createLineEditBox('reviewedby1LineEdit_NCR_')
	self.createLineEditBox('approvedby1LineEdit_NCR_')
	self.createComboBox2(['Claim', 'Holding', 'Use as is', 'Rework', 'Waiver', 'Scrap', 'Repair'], 'decisionComboBox_NCR_')
	self.createComboBox2(['Yes', 'No'], 'repairprocedureComboBox_NCR_')	
	self.createLineEditBox('name1LineEdit_NCR_')

	self.createDateEditBox('date2_NCR_')
	self.date2_NCR_.setMinimumDate(QDate(current_date_.year(), current_date_.month(), 1))
	
	self.createLineEditBox('sign1LineEdit_NCR_')
	self.createLineEditBox('name2LineEdit_NCR_')

	self.createDateEditBox('date3_NCR_')
	self.date3_NCR_.setMinimumDate(QDate(current_date_.year(), current_date_.month(), 1))
	
	self.createLineEditBox('sign2LineEdit_NCR_')
	self.createComboBox2(['Internal', 'Customer'], 'approvalscopComboBox_NCR_')     	
	self.createLineEditBox('entityLineEdit_NCR_')
	self.createLineEditBox('positionLineEdit_NCR_')
	self.createLineEditBox('name3LineEdit_NCR_')

	self.createDateEditBox('date4_NCR_')
	self.date4_NCR_.setMinimumDate(QDate(current_date_.year(), current_date_.month(), 1))
	
	self.createLineEditBox('sign3LineEdit_NCR_')
	self.createAttachmentWidget('attacheddocuments4_NCR_')
	self.attacheddocuments4_NCR.fileListWidget.setMinimumHeight(140)


	ckmandlhboxlayout_NCR_ = QHBoxLayout()
	ckmandlhboxlayout_NCR_.addWidget(self.reportno_, alignment = Qt.AlignRight )
	ckmandlhboxlayout_NCR_.addWidget(self.ckdmndl_NCR_, alignment = Qt.AlignLeft )
	ckmandlhboxlayout_NCR_.addWidget(self.current_ncr_,alignment = Qt.AlignLeft)
	ckmandlhboxlayout_NCR_.addItem(QSpacerItem(1, 0, QSizePolicy.Expanding, QSizePolicy.Minimum))

	formLayout1.addRow('Report No: <font color="red">*</font>', ckmandlhboxlayout_NCR_)
	formLayout1.addRow('Project:', self.projectLineEdit_NCR_)
	formLayout1.addRow('Product:', self.productLineEdit_NCR_)
	formLayout1.addRow('Quantity: <font color="red">*</font>', self.quantityLineEdit_NCR_)
	
	formLayout1.addRow('Supplier: <font color="red">*</font>', self.supplierLineEdit_NCR_)
	formLayout1.addRow('Detection: <font color="red">*</font>', self.detectionLineEdit_NCR_)
	formLayout1.addRow('Place:', self.placeComboBox_NCR_)
	formLayout1.addRow('Stored at:', self.storedLineEdit_NCR_)	
	formLayout1.addRow('Severity:', self.severityComboBox_NCR_)
	# formLayout1.addRow('Material status:', self.materialstatusComboBox_NCR_)
	formLayout1.addRow('Distribution to: <font color="red">*</font>', self.distributiontoLineEdit_NCR_)
	formLayout1.addRow('Trainset: <font color="red">*</font>', self.trainComboBox_NCR_)
	formLayout1.addRow('Car:', self.carComboBox_NCR_)

	formLayout1.addRow('Assy dwg no:', self.assydwgnoLineEdit_NCR_)
	formLayout1.addRow('Rev:', self.revLineEdit_NCR_)
	formLayout1.addRow('Part No:', self.partnoLineEdit_NCR_)

	formLayout1.addRow('Assy Serial No:', self.assysnoLineEdit_NCR_)
	formLayout1.addRow('Part Serial No:', self.partserialnoLineEdit_NCR_)


	formLayout1.addRow('B/L No:', self.blnoLineEdit_NCR_)
	formLayout1.addRow('Invoice no:', self.invoicenoLineEdit_NCR_)
	formLayout1.addRow('Responsible party: <font color="red">*</font>', self.responsiblepartyLineEdit_NCR_)
	formLayout1.addRow('Material status:', self.materialstatusComboBox_NCR_)

	formLayout1.addRow('Description of non-conform: <font color="red">*</font>', self.descriptionofnonconform_NCR_)
	formLayout1.addRow('Attached documents (if any):', self.attacheddocuments1_NCR_)

	formLayout1.addRow('Date: <font color="red">*</font>' , self.date_NCR_)
	formLayout1.addRow('Team :', self.teamLineEdit_NCR_)
	formLayout1.addRow('Issued by: <font color="red">*</font>', self.issuedbyLineEdit_NCR_)
	formLayout1.addRow('Reviewed by: <font color="red">*</font>', self.reviewedbyLineEdit_NCR_)
	formLayout1.addRow('Approved by: <font color="red">*</font>', self.approvedbyLineEdit_NCR_)
	formLayout1.addRow('Cause of nonconformity: ', self.causeofnonconformity_NCR_)

	formLayout2.addRow('Attached documents (if any):', self.attacheddocuments2_NCR_)
	formLayout2.addRow('A. Correction/corrective action result: <font color="red">*</font>', self.correctionorcorrectiveactionLineEdit_NCR_)
	formLayout2.addRow('B. Action Plan: ', self.actionplan_NCR_)
	formLayout2.addRow('Attached documents (if any):', self.attacheddocuments3_NCR_)
	formLayout2.addRow('Date: ' , self.date1_NCR_)
	formLayout2.addRow('Action by:', self.actionbyLineEdit_NCR_)
	formLayout2.addRow('Issued by:', self.issuedby1LineEdit_NCR_)
	formLayout2.addRow('Reviewed by:', self.reviewedby1LineEdit_NCR_)
	formLayout2.addRow('Approved by:', self.approvedby1LineEdit_NCR_)
	formLayout2.addRow('Decision :', self.decisionComboBox_NCR_)
	formLayout2.addRow('Repair procedure:', self.repairprocedureComboBox_NCR_)
	formLayout2.addRow(QLabel('Verification on correction:	'))
	formLayout2.addRow('            Name:', self.name1LineEdit_NCR_)
	formLayout2.addRow('            Date:' , self.date2_NCR_)
	formLayout2.addRow('            Sign:', self.sign1LineEdit_NCR_)
	formLayout2.addRow(QLabel('Verification on corrective action:	'))
	formLayout2.addRow('            Name:', self.name2LineEdit_NCR_)
	formLayout2.addRow('            Date: ' , self.date3_NCR_)
	formLayout2.addRow('            Sign:', self.sign2LineEdit_NCR_)
	formLayout2.addRow('Approval Scope:', self.approvalscopComboBox_NCR_)

	formLayout2.addRow('Entity:', self.entityLineEdit_NCR_)
	formLayout2.addRow('Position:', self.positionLineEdit_NCR_)
	formLayout2.addRow('Name:', self.name3LineEdit_NCR_)
	formLayout2.addRow('Date:', self.date4_NCR_)
	formLayout2.addRow('Sign:', self.sign3LineEdit_NCR_)
	formLayout2.addRow('Signed NCR:', self.attacheddocuments4_NCR_)



	def toggleLabelText_():
		currentText_ = self.ckdmndl_NCR_.text()
		if currentText_ == 'CKD':
			self.ckdmndl_NCR_.setText('Mandala')		
			self.ckdmndl_NCR_.setFixedWidth(65)	
		else:
			self.ckdmndl_NCR_.setText('CKD')
			self.ckdmndl_NCR_.setFixedWidth(37)	
	self.ckdmndl_NCR_.clicked.connect(toggleLabelText_)


	self.createPushButton('updateBtn_NCR', 'Update', '', int(0.075 * QApplication.primaryScreen().availableGeometry().width()))

	vboxLayout.addWidget(self.updateBtn_NCR, alignment = Qt.AlignCenter)
	

	allFields_ = [self.reportno_, self.projectLineEdit_NCR_, self.productLineEdit_NCR_, self.quantityLineEdit_NCR_, self.supplierLineEdit_NCR_,
					self.detectionLineEdit_NCR_,self.placeComboBox_NCR_, self.storedLineEdit_NCR_, self.severityComboBox_NCR_,self.distributiontoLineEdit_NCR_,
					self.trainComboBox_NCR_, self.carComboBox_NCR_, self.assydwgnoLineEdit_NCR_, self.revLineEdit_NCR_, self.partnoLineEdit_NCR_,
					self.assysnoLineEdit_NCR_, self.partserialnoLineEdit_NCR_, self.blnoLineEdit_NCR_, self.invoicenoLineEdit_NCR_, self.responsiblepartyLineEdit_NCR,
					self.materialstatusComboBox_NCR_, self.descriptionofnonconform_NCR_, self.attacheddocuments1_NCR_, self.date_NCR_, self.teamLineEdit_NCR_, 
					self.issuedbyLineEdit_NCR_, self.reviewedbyLineEdit_NCR_, self.approvedbyLineEdit_NCR_, self.causeofnonconformity_NCR_, 
					self.attacheddocuments2_NCR_, self.correctionorcorrectiveactionLineEdit_NCR_, self.actionplan_NCR_, self.attacheddocuments3_NCR_, 
					self.date1_NCR_, self.actionbyLineEdit_NCR_, self.issuedby1LineEdit_NCR_, self.reviewedby1LineEdit_NCR_, self.approvedby1LineEdit_NCR_, 
					self.decisionComboBox_NCR_, self.repairprocedureComboBox_NCR_, self.name1LineEdit_NCR_, self.date2_NCR_, self.sign1LineEdit_NCR_, 
					self.name2LineEdit_NCR_, self.date3_NCR_, self.sign2LineEdit_NCR_, self.approvalscopComboBox_NCR_, self.entityLineEdit_NCR_, 
					self.positionLineEdit_NCR_, self.name3LineEdit_NCR_, self.date4_NCR_, self.sign3LineEdit_NCR_, self.attacheddocuments4_NCR_]

	# if not prevMonth:
	# 	for wid in allFields_:
	# 		wid.setEnabled(False)
	
	self.ncrWindow.show()


	def setToolTip(wid, text):
		wid.setToolTip(text)

	def settingToolTipps(wid):
		wid.textChanged.connect(lambda: setToolTip(wid, wid.text()))

	for wid in allFields_:
		if isinstance(wid, QLineEdit):
			settingToolTipps(wid)


	def setToolTip(wid, text):
		wid.setToolTip(text)

	def settingToolTipp(wid):
		wid.textChanged.connect(lambda: setToolTip(wid, wid.toPlainText()))

	for wid in allFields_:
		if isinstance(wid, QTextEdit):
			settingToolTipp(wid)