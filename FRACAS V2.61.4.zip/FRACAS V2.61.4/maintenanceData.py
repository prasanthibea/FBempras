from PySide6.QtWidgets import QScrollArea, QTabWidget, QVBoxLayout, QLabel, QComboBox, QToolBox, QWidget, QFormLayout, QDateEdit, QTimeEdit, QTextEdit, QPushButton, QSizePolicy, QHBoxLayout, QSpacerItem, QLineEdit, QDialog, QDialogButtonBox, QTableWidgetItem

def maintenanceDataUI(self):
	from PySide6.QtWidgets import QApplication
	from cmData import cmDataUI
	from opmData import opmDataUI
	from scData import scDataUI
	from runningMileageData import runningMileageDataUI
	from serviceFailuresData import serviceFailuresUI

	self.maintenanceDataTabWidget_MD = QTabWidget()
	self.maintenanceDataTabWidget_MD.setMinimumHeight(int(0.82 * QApplication.primaryScreen().availableGeometry().height()))



	self.mainVerticalLayout_MaintenanceData.addWidget(self.maintenanceDataTabWidget_MD)

	cmTabWidget = QWidget()
	opmTabWidget = QWidget()
	scTabWidget = QWidget()
	serviceFailuresTabWidget = QWidget()

	cmScroll = QScrollArea(cmTabWidget)
	opmScroll = QScrollArea(opmTabWidget)
	scScroll = QScrollArea(scTabWidget)
	serviceFailuresScroll = QScrollArea(serviceFailuresTabWidget)

	self.maintenanceDataTabWidget_MD.addTab(cmScroll, 'CM')
	self.maintenanceDataTabWidget_MD.addTab(opmScroll, 'PM')
	self.maintenanceDataTabWidget_MD.addTab(scScroll, 'SC')
	self.maintenanceDataTabWidget_MD.addTab(serviceFailuresScroll, 'Service Failures')

	self.correctiveDataWidget = QWidget()
	self.preventiveDataWidget = QWidget()
	self.scheduleChecksDataWidget = QWidget()
	self.serviceFailuresDataWidget = QWidget()

	correctiveDataMainLayout = QVBoxLayout(self.correctiveDataWidget)
	preventiveDataMainLayout = QVBoxLayout(self.preventiveDataWidget)
	scheduleChecksDataMainLayout = QVBoxLayout(self.scheduleChecksDataWidget)
	serviceFailuresDataMainLayout = QVBoxLayout(self.serviceFailuresDataWidget)

	self.correctiveDataWidget.setLayout(correctiveDataMainLayout)
	self.preventiveDataWidget.setLayout(preventiveDataMainLayout)
	self.scheduleChecksDataWidget.setLayout(scheduleChecksDataMainLayout)
	self.serviceFailuresDataWidget.setLayout(serviceFailuresDataMainLayout)

	cmScroll.setWidget(self.correctiveDataWidget)
	opmScroll.setWidget(self.preventiveDataWidget)
	scScroll.setWidget(self.scheduleChecksDataWidget)
	serviceFailuresScroll.setWidget(self.serviceFailuresDataWidget)

	cmScroll.setWidgetResizable(True)
	opmScroll.setWidgetResizable(True)
	scScroll.setWidgetResizable(True)
	serviceFailuresScroll.setWidgetResizable(True)

	self.totalDataToFindOverlapIds = []

	cmDataUI(self,correctiveDataMainLayout)
	opmDataUI(self, preventiveDataMainLayout)
	scDataUI(self, scheduleChecksDataMainLayout)
	runningMileageDataUI(self)
	serviceFailuresUI(self, serviceFailuresDataMainLayout)


	# print(self.totalDataToFindOverlapIds)

	train_id_dict = {}

	for tup in self.totalDataToFindOverlapIds:
		train_id = tup[2]
		if train_id not in train_id_dict:
			train_id_dict[train_id] = []

		train_id_dict[train_id].append(tup)


	def find_overlapping_sets_with_ids(datetime_pairs):

		# Sort datetime pairs by start datetime
		sorted_datetime_pairs = sorted(datetime_pairs, key=lambda x: x[0][0])

		checkedIds = []
		totalSets = []
		checkedTrain = []
		# print(sorted_datetime_pairs)
		# print('--------------------------')
		for i, ((start, end), current_id, trainId) in enumerate(sorted_datetime_pairs):
			if current_id not in checkedIds:
				currentSet = [current_id]
				for j in range(i+1, len(sorted_datetime_pairs)):
					if trainId == sorted_datetime_pairs[j][2]:
						if end > sorted_datetime_pairs[j][0][0]:
							# print(sorted_datetime_pairs[j][1])
							currentSet.append(sorted_datetime_pairs[j][1])
							end = max(end, sorted_datetime_pairs[j][0][1])
				totalSets.append(currentSet)
				checkedIds += currentSet

		return totalSets
	

	allSets = []
	for train_id, listt in train_id_dict.items():
		sett = find_overlapping_sets_with_ids(listt)
		allSets.append(sett)
	# print(allSets)

	# for i in range(self.cmDataTable.rowCount()):
	# 	tableId = self.cmDataTable.cellWidget(i, 1).text()
	# 	for trainIdsData in allSets:
	# 		for lisst in trainIdsData:
	# 			if tableId in lisst:
	# 				if len(lisst) > 1:
	# 					self.cmDataTable.setItem(i, self.cmDataTable.columnCount()-1, QTableWidgetItem(str(lisst)))

	
	for i in range(self.opmDataTable.rowCount()):
		tableId = self.opmDataTable.cellWidget(i, 1).text()
		for trainIdsData in allSets:
			for lisst in trainIdsData:
				if tableId in lisst:
					if len(lisst) > 1:
						self.opmDataTable.setItem(i, self.opmDataTable.columnCount()-1, QTableWidgetItem(str(lisst)))

	for i in range(self.scDataTable.rowCount()):
		tableId = self.scDataTable.cellWidget(i, 0).text()
		for trainIdsData in allSets:
			for lisst in trainIdsData:
				extracted_ids = []
				for itemm in lisst:
					if itemm.startswith('SC'):
						# Split the string by space and take the first part (the ID)
						extracted_ids.append(itemm.split()[0])
					else:
						extracted_ids.append(itemm)
				if tableId in extracted_ids:
					if len(extracted_ids) > 1:
						self.scDataTable.setItem(i, self.scDataTable.columnCount()-1, QTableWidgetItem(str(lisst)))