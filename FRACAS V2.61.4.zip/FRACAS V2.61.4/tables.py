import mysql.connector
from functions import *

def createTables(self):

	self.cursor.execute("""
			CREATE TABLE IF NOT EXISTS trainsets (
				id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
				trainset VARCHAR(255) NOT NULL,
				line VARCHAR(50) NOT NULL,
				depot VARCHAR(255) NOT NULL,
				hand_over DATE DEFAULT NULL,
				revenue_date DATE DEFAULT NULL,
				stabilization DATE DEFAULT NULL,
				end_of_12m_revenue DATE DEFAULT NULL,
				end_of_18m_revenue DATE DEFAULT NULL,
				warranty DATE DEFAULT NULL,
				created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
				updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
				deleted_at TIMESTAMP DEFAULT NULL
			)
		""")

	self.cursor.execute("""CREATE TABLE IF NOT EXISTS bom (
		sno INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
		id INT UNSIGNED,
		parent_id INT UNSIGNED NOT NULL,
		equipment VARCHAR(255) NOT NULL,
		dm1 INT UNSIGNED NOT NULL,
		t2 INT UNSIGNED NOT NULL,
		m3 INT UNSIGNED NOT NULL,
		m4 INT UNSIGNED NOT NULL,
		t5 INT UNSIGNED NOT NULL,
		dm6 INT UNSIGNED NOT NULL,
		quantity INT UNSIGNED NOT NULL,
		mdbcf_target BIGINT DEFAULT NULL,
		mttr_target BIGINT DEFAULT NULL,
		item_mdbcf BIGINT DEFAULT NULL,
		created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
		updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
		deleted_at TIMESTAMP DEFAULT NULL
		)
	""")

	self.cursor.execute('''CREATE TABLE IF NOT EXISTS loginlog (
		sno INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
		username VARCHAR(255) NOT NULL,
		user_id INT UNSIGNED NOT NULL,
		login TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
		role INT UNSIGNED NOT NULL,
		log_type VARCHAR(50) NOT NULL
		)
		''')

	self.cursor.execute("""
		CREATE TABLE IF NOT EXISTS db_backup (
			id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
			backupdate DATETIME DEFAULT CURRENT_TIMESTAMP,
			path VARCHAR(255)
		)
		""")


	self.cursor.execute("""
		CREATE TABLE IF NOT EXISTS trainsets_mileage (
			id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
			rm_id VARCHAR(255) NOT NULL,
			year INT UNSIGNED NOT NULL,
			month INT UNSIGNED NOT NULL,
			trainset_id INT UNSIGNED NOT NULL,
			cummulative_mileage INT UNSIGNED NOT NULL,
			monthly_mileage INT UNSIGNED NOT NULL,
			user_id INT UNSIGNED NOT NULL,
			created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
			updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
			deleted_at TIMESTAMP DEFAULT NULL
				)
			""")

	self.cursor.execute('''CREATE TABLE IF NOT EXISTS corrective_maintenance (
			id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
			cm_id VARCHAR(255) NOT NULL UNIQUE,
			event_datetime DATETIME NOT NULL,
			depot VARCHAR(100) NOT NULL,
			trainset_id INT UNSIGNED NOT NULL,
			car_no VARCHAR(20) DEFAULT NULL,
			jobcard_no VARCHAR(255) DEFAULT NULL,
			issued_to VARCHAR(255) DEFAULT NULL,
			ml_depot VARCHAR(255) DEFAULT NULL,
			location VARCHAR(255) DEFAULT NULL,
			system_id INT UNSIGNED NOT NULL,
			subsystem_id INT UNSIGNED DEFAULT NULL,
			fault_details TEXT DEFAULT NULL,
			failure_type VARCHAR(255) NOT NULL,
			service_failure_effect TEXT DEFAULT NULL,
			action_taken_at_mainline TEXT DEFAULT NULL,
			action_taken_at_depot TEXT DEFAULT NULL,
			failure_category VARCHAR(255) DEFAULT NULL,
			failure_responsibility VARCHAR(255) NOT NULL,
			equipment VARCHAR(255) DEFAULT NULL,
			component VARCHAR(255) DEFAULT NULL,
			lowest_level_component VARCHAR(255) DEFAULT NULL,
			ncr_no VARCHAR(100) DEFAULT NULL,
			component_replaced ENUM('Yes', 'No') DEFAULT NULL,
			verification ENUM('Yes', 'No') NOT NULL,
			work_start_at DATETIME NOT NULL,
			work_end_at DATETIME NOT NULL,
			down_time INT UNSIGNED NOT NULL,
			user_id INT UNSIGNED NOT NULL,
			created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
			updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
			deleted_at TIMESTAMP NULL DEFAULT NULL
			);
			''')

	self.cursor.execute("""
		CREATE TABLE IF NOT EXISTS service_checks (
			id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
			sc_id VARCHAR(255) NOT NULL,
			year INT UNSIGNED NOT NULL,
			month INT UNSIGNED NOT NULL,
			trainset_id INT UNSIGNED NOT NULL,
			A_1 DATETIME DEFAULT NULL,
			A_2 DATETIME DEFAULT NULL,
			A_3 DATETIME DEFAULT NULL,
			B1_1 DATETIME DEFAULT NULL,
			B1_2 DATETIME DEFAULT NULL,
			B4 DATETIME DEFAULT NULL,
			B8 DATETIME DEFAULT NULL,
			C1 DATETIME DEFAULT NULL,
			C2 DATETIME DEFAULT NULL,
			downtime FLOAT UNSIGNED NOT NULL,
			user_id INT UNSIGNED NOT NULL,
			created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
			updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
			deleted_at TIMESTAMP DEFAULT NULL
				)
			""")


	## Table to store the data of OPM:
	self.cursor.execute("""CREATE TABLE IF NOT EXISTS other_preventive_maintenance (
		id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
		opm_id VARCHAR(255) NOT NULL UNIQUE,
		event_datetime DATETIME NOT NULL,
		depot_id VARCHAR(100) NOT NULL,
		trainset_id INT UNSIGNED NOT NULL,
		car_number VARCHAR(255) DEFAULT NULL,
		opm_type VARCHAR(255) NOT NULL,
		opm_fault_details TEXT DEFAULT NULL,
		opm_investigation_details TEXT DEFAULT NULL,
		system_id INT UNSIGNED NOT NULL,
		subsystem_id INT UNSIGNED NOT NULL,
		work_start_at DATETIME NOT NULL,
		work_end_at DATETIME NOT NULL,
		downtime INT UNSIGNED NOT NULL,
		user_id INT UNSIGNED NOT NULL,
		created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
		updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
		deleted_at TIMESTAMP DEFAULT NULL
		)
	""")



	## Table to store the data of NCR:
	self.cursor.execute("""CREATE TABLE IF NOT EXISTS ncr (
		id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
		report_no VARCHAR(255) NULL UNIQUE,
		project VARCHAR(255) NULL,
		product VARCHAR(100) NULL,
		quantity INT UNSIGNED NULL,
		supplier VARCHAR(255) NULL,
		detection VARCHAR(255) NULL,
		place VARCHAR(255) NULL,
		stored_at VARCHAR(255) NULL,
		severity VARCHAR(255) NULL,
		distribution_to VARCHAR(255) NULL,
		trainset VARCHAR(255) NULL,
		car VARCHAR(255) NULL,
		assy_dwg_no VARCHAR(255) NULL,
		rev INT UNSIGNED NULL,
		part_no VARCHAR(255) NULL,
		assy_serial_no VARCHAR(255) NULL,
		part_serial_no VARCHAR(255) NULL,
		bl_no VARCHAR(255) NULL,
		invoice_no VARCHAR(255) NULL,
		responsible_party VARCHAR(255) NULL,
		material_status VARCHAR(255) NULL,
		description_of_nonconform TEXT NULL,
		attachments_one VARCHAR(255) NULL,

		attachments_one_date DATE NULL,
		attachments_one_team VARCHAR(255) NULL,
		attachments_one_issued_by VARCHAR(255) NULL,
		attachments_one_reviewed_by VARCHAR(255) NULL,
		attachments_one_approved_by VARCHAR(255) NULL,
		cause_of_nonconformity TEXT NULL,
		attached_documents_two VARCHAR(255) NULL,
		acorrection_corrective_action_result TEXT NULL,
		baction_plan TEXT NULL,
		attachments_three VARCHAR(255) NULL,
		attachments_three_date DATE NULL,
		attachments_three_action_by VARCHAR(255) NULL,
		attachments_three_issued_by VARCHAR(255) NULL,
		attachments_three_reviewed_by VARCHAR(255) NULL,
		attachments_three_approved_by VARCHAR(255) NULL,
		decision VARCHAR(255) NULL,
		repair_procedure ENUM('Yes', 'No') DEFAULT NULL,
		correction_name VARCHAR(255) NULL,
		correction_date DATE NULL,
		correction_sign VARCHAR(255) NULL,
		correctiveaction_name VARCHAR(255) NULL,
		correctiveaction_date DATE NULL,
		correctiveaction_sign VARCHAR(255) NULL,
		approval_scope VARCHAR(255) NULL,
		approvedby_entity VARCHAR(255) NULL,
		approvedby_position VARCHAR(255) NULL,
		approvedby_name VARCHAR(255) NULL,
		approvedby_date DATE NULL,
		approvedby_sign VARCHAR(255) NULL,
		signed_ncr VARCHAR(255) NULL,
		user_id INT UNSIGNED NULL,
		created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
		updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
		deleted_at TIMESTAMP NULL
		)
	""")

	
