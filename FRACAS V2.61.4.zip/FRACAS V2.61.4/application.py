from loginForm import *

app = QApplication(sys.argv)
ex = LoginForm()
sys.exit(app.exec()) 
