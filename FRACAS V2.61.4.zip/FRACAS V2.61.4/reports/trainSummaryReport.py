from datetime import datetime, timedelta
from dateutil.relativedelta import relativedelta
import calendar

def trainSummaryReportUi(self, month, year, selected_report_title):

	month_string = calendar.month_abbr[int(month)]

	date_object = datetime(year, month, 1)
	formatted_string = date_object.strftime('%b - %Y')

	self.monthCombobox_trainSummaryDash.setCurrentText(formatted_string)


	train_summary_data = []
	month_string = calendar.month_abbr[int(month)]

	header_title = f'TRAIN SUMMARY REPORT FOR {month_string.upper()} - {year}'

	# Add the header title as a paragraph
	train_summary_data.append(header_title)

	##########################################################

	tableNamesList = ['Train Summary']

	##########################################################

	table_data = []

	header_text = []
	for col in range(self.trainSummaryTable.columnCount()):
		header_item = self.trainSummaryTable.horizontalHeaderItem(col)
		if header_item:
			header_text.append(header_item.text())

	# Add the table to the train_summary_data
	table_data.append(header_text)



	for row in range(self.trainSummaryTable.rowCount()):
		row_data = []
		for col in range(self.trainSummaryTable.columnCount()):
			item = self.trainSummaryTable.item(row, col)

			if item:
				row_data.append(item.text())
			else:
				row_data.append('')

		table_data.append(row_data)



	# Add the caption as a paragraph
	train_summary_data.append(table_data)

	# Generate the report
	# self.generate_pdf_report(selected_report_title, train_summary_data, tableNamesList, 0, [])
	self.generate_pdf_report(selected_report_title, train_summary_data, tableNamesList, 1, [])