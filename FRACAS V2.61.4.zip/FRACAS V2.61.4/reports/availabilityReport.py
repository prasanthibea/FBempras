from datetime import datetime, timedelta
from dateutil.relativedelta import relativedelta
import calendar

from PySide6.QtWidgets import QApplication
from functions import createLineChart
from PySide6.QtCore import Qt

def availabilityReportUi(self, month, year, selected_report_title):

	six_months_ago = datetime(year, month, 1) - relativedelta(months=5)

	six_months_agoDate = six_months_ago.date()
	fromDateMonthString = six_months_agoDate.strftime('%b - %Y')
	allItems = []
	for index in range(self.fromCombobox_availDash.count()):
		item_text = self.fromCombobox_availDash.itemText(index)
		allItems.append(item_text)
	

	if fromDateMonthString in allItems:
		self.fromCombobox_availDash.setCurrentText(fromDateMonthString)
	else:
		self.fromCombobox_availDash.setCurrentIndex(0)


	# month_string = calendar.month_abbr[int(month)]
	date_object = datetime(year, month, 1)
	toMonthString = date_object.strftime('%b - %Y')

	self.toCombobox_availDash.setCurrentText(toMonthString)

	availability_data = []


	report_title = f'AVAILABILITY REPORT FOR  {toMonthString.upper()}'
	availability_data.append(report_title)

	##########################################################

	tableNamesList = []
	tableNamesList.append('Fleet Availability For Last 6 months')
	for line_name in self.uniqueLines:
		tableNamesList.append(f'Availability for {line_name}')
	##########################################################



	fleetAvailabiltyTableData = []
	
	header_text = []
	for col in range(self.availabilitySummaryTable.columnCount()):
		if not self.availabilitySummaryTable.isColumnHidden(col):
			header_item = self.availabilitySummaryTable.horizontalHeaderItem(col)
			if header_item:
				header_text.append(header_item.text())

	# Add headers to the table_data
	fleetAvailabiltyTableData.append(header_text)


	# Fetch data
	for row in range(self.availabilitySummaryTable.rowCount()):
		row_data = []
		for col in range(self.availabilitySummaryTable.columnCount()):
			if not self.availabilitySummaryTable.isColumnHidden(col):
				item = self.availabilitySummaryTable.item(row, col)

				if item:
					row_data.append(item.text())
				else:
					row_data.append('')
		
		fleetAvailabiltyTableData.append(row_data)


	availability_data.append(fleetAvailabiltyTableData)









	# for tab in self.listOfLinesTablesInAvailDash:
	# 	availabilityTablesData = []

	# 	header_text = []
	# 	for col in range(tab.columnCount()):
	# 		if not tab.isColumnHidden(col):
	# 			header_item = tab.horizontalHeaderItem(col)
	# 			if header_item:
	# 				header_text.append(header_item.text())

	# 	# Add headers to the table_data
	# 	availabilityTablesData.append(header_text)


	# 	# Fetch data
	# 	for row in range(tab.rowCount()):
	# 		row_data = []
	# 		for col in range(tab.columnCount()):
	# 			if not tab.isColumnHidden(col):
	# 				item = tab.item(row, col)

	# 				if item:
	# 					row_data.append(item.text())
	# 				else:
	# 					row_data.append('')
			
	# 		availabilityTablesData.append(row_data)


	# 	availability_data.append(availabilityTablesData)

	##########################################################


	availability_charts_list = []


	xLabelsList = []

	for col in range(1, self.availabilitySummaryTable.columnCount()):
		if not self.availabilitySummaryTable.isColumnHidden(col):
			header_item = self.availabilitySummaryTable.horizontalHeaderItem(col)
			if header_item:
				xLabelsList.append(header_item.text())





	fleetAvailabilityValues = []

	# for row in range(1,3):
	for row in range(1+len(self.uniqueLines)):
		row_data = []
		for col in range(1, self.availabilitySummaryTable.columnCount()):
			if not self.availabilitySummaryTable.isColumnHidden(col):
				item = self.availabilitySummaryTable.item(row, col)

				if item:
					row_data.append(float(item.text()))
				else:
					row_data.append(0.0)
		
		fleetAvailabilityValues.append(row_data)

	chartTitle_FAC = f"Availability (6M)"
	xLabels_FAC = "Months"
	yLabels_FAC = "Availability (%)"


	legends_FAC = ['Target Availability'] + self.uniqueLines
	colors_FAC = [Qt.red, Qt.blue, Qt.green]
	lineType_FAC = [Qt.DashLine, Qt.SolidLine, Qt.SolidLine]
	

	fleetAvailabilityChartView = self.createLineChart(xLabelsList, fleetAvailabilityValues, legends_FAC, colors_FAC, lineType_FAC, chartTitle_FAC, xLabels_FAC, yLabels_FAC)
	# fleetAvailabilityChartView.chart().axisY().setRange(0, 105)
	fleetAvailabilityChartView.chart().axisY().setMax(100)
	fleetAvailabilityChartView.setFixedHeight(525)
	fleetAvailabilityChartView.setFixedWidth(int(0.45 * QApplication.primaryScreen().availableGeometry().width()))

	availability_chart_image = fleetAvailabilityChartView.grab().toImage()
	availability_charts_list.append(availability_chart_image)


	##########################################################

	# Generate the report
	self.generate_pdf_report(selected_report_title, availability_data, tableNamesList, 0, availability_charts_list)
	self.clearAllFiltersButton_availDash.click()
	