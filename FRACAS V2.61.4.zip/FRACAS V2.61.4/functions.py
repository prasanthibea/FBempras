from PySide6.QtWidgets import (QMainWindow, QVBoxLayout, QHBoxLayout, QLabel, QWidget, QComboBox, QLayout, QPushButton, QTableView, QTableWidget, QHeaderView, 
							QToolTip, QFormLayout, QStackedWidget, QCheckBox, QAbstractItemView, QSpacerItem, QSizePolicy, QTableWidgetItem, QProgressBar, QFileDialog,
							QMessageBox, QListWidget, QLineEdit, QMenu, QTextEdit, QTimeEdit, QDateEdit, QDateTimeEdit, QDialog, QSpinBox, QApplication, QGridLayout, QListView, QScrollArea)
from PySide6.QtCore import QSettings, Qt, Signal, QSize, QRect, QPoint, QRectF, QDate, QTime, QDateTime, QFileInfo
from PySide6.QtGui import QIcon, QFont, QFontDatabase, QBrush, QColor, QPainter, QPen, QIntValidator, QPixmap, QMovie, QKeySequence, QImageReader, QAction, QStandardItemModel, QStandardItem

from PySide6.QtCharts import QChart, QChartView, QBarSet, QBarSeries, QPercentBarSeries, QBarCategoryAxis, QValueAxis ,QAbstractBarSeries, QPieSeries, QPieSlice,  QLineSeries, QCategoryAxis, QScatterSeries, QStackedBarSeries, QHorizontalBarSeries
from dateutil.relativedelta import relativedelta

import subprocess
import os
import mysql.connector
import pandas as pd
from datetime import datetime, timedelta
import csv
import math
import time
from PySide6.QtGui import QScreen
import sys
# from qtwidgets import PasswordEdit

from QSSS import *

from functools import wraps
import logging

import configparser

logging.basicConfig(filename='C:/ProgramData/RAMSify/app_log.txt', level=logging.ERROR, format='%(asctime)s - %(levelname)s - %(filename)s:%(lineno)d - %(message)s')


class FileAttachmentWidget(QWidget):
	def __init__(self, parent=None):
		super().__init__(parent)
		
		self.initUI()

	def initUI(self):
		self.layout = QVBoxLayout(self)
		self.hBoxLayout = QHBoxLayout()
		self.layout.addLayout(self.hBoxLayout)

		self.fileListWidget = QListWidget()
		self.fileListWidget.setSelectionMode(QListWidget.ExtendedSelection)
		self.fileListWidget.itemDoubleClicked.connect(self.openFile)
		self.fileListWidget.setVisible(False)


		self.layout.addWidget(self.fileListWidget)

		self.addButton = QPushButton("Attach File(s)")
		self.addButton.clicked.connect(self.attachFiles)
		self.hBoxLayout.addWidget(self.addButton)

		self.removeButton = QPushButton('')
		self.removeButton.clicked.connect(self.removeSelectedFiles)
		self.hBoxLayout.addWidget(self.removeButton)
		self.hBoxLayout.addItem(QSpacerItem(1, 0, QSizePolicy.Expanding, QSizePolicy.Minimum))
		self.removeButton.setEnabled(False)

	def attachFiles(self):
		files, _ = QFileDialog.getOpenFileNames(self, "Attach File(s)", "", "All Files (*.*);;Text Files (*.txt)")
		if files:
			for file in files:
				if not self.isItemExist(file):  # Check if item already exists
					self.fileListWidget.addItem(file)
			self.fileListWidget.setVisible(True)
			self.removeButton.setEnabled(True)

	def isItemExist(self, text):
		for i in range(self.fileListWidget.count()):
			if self.fileListWidget.item(i).text() == text:
				return True
		return False

	def removeSelectedFiles(self):
		for item in self.fileListWidget.selectedItems():
			self.fileListWidget.takeItem(self.fileListWidget.row(item))

		count = self.fileListWidget.count()
		if count == 0:
			self.fileListWidget.setVisible(False)
			self.removeButton.setEnabled(False)

	def openFile(self, item):
		file_path = item.text()
		if '/' in file_path:
			if os.path.exists(file_path):
				os.startfile(file_path)  # Open file with default application
			else:
				print(f"File {file_path} does not exist.")
		else:
			dest_folder = "C:\\ProgramData\\RAMSify\\Attachments"
			filePath = os.path.join(dest_folder, file_path)

			if os.path.exists(filePath):
				os.startfile(filePath)  # Open file with default application
			else:
				print(f"File {file_path} does not exist.")


def createAttachmentWidget(self, widgetName):
	setattr(self, widgetName, FileAttachmentWidget())
	getattr(self, widgetName).addButton.setStyleSheet(self.pushbuttonQSS)
	getattr(self, widgetName).addButton.setFixedWidth(120)
	getattr(self, widgetName).removeButton.setStyleSheet(self.pushbuttonQSS)
	icon = QIcon('Media/delete.png')
	getattr(self, widgetName).removeButton.setIcon(icon)
	getattr(self, widgetName).removeButton.setFixedWidth(24)
	getattr(self, widgetName).removeButton.setCursor(Qt.PointingHandCursor)
	getattr(self, widgetName).removeButton.setStyleSheet(f'''QPushButton {{ background: transparent;}}
											QPushButton:hover {{background: transparent;}}
												QPushButton:pressed {{
													background: transparent;
												}}''')
	getattr(self, widgetName).fileListWidget.setStyleSheet("""
		QListWidget {
			background-color: #F6F8FC;
			border: 1px solid #6C7AE0;
			padding: 3px;
		}

		
	""")

# def createComboBox(self, optionsList, comboBoxName):
# 	getattr(self, comboBoxName).setPlaceholderText("--Select--")
# 	getattr(self, comboBoxName).addItems(optionsList)
# 	getattr(self, comboBoxName).setFixedWidth(int(0.142 * QApplication.primaryScreen().availableGeometry().width()))
# 	getattr(self, comboBoxName).setFocusPolicy(Qt.NoFocus)


class NumberLineEdit(QLineEdit):
	def __init__(self, parent=None):
		super(NumberLineEdit, self).__init__(parent)
		self.validator = QIntValidator(1, 2147483647)
		self.setValidator(self.validator)


class CustomComboBox(QComboBox):
	def __init__(self, parent=None):
		super().__init__(parent)

	# def focusInEvent(self, event):
	# 	super().focusInEvent(event)
	# 	if not self.view().isVisible():
	# 		self.showPopup()

	def wheelEvent(self, event):
		# Disable changing the current index using the mouse wheel
		pass

class CustomComboBox2(QComboBox):
	def __init__(self, parent=None):
		super().__init__(parent)

	def focusInEvent(self, event):
		super().focusInEvent(event)
		if not self.view().isVisible():
			self.showPopup()

	def wheelEvent(self, event):
		# Disable changing the current index using the mouse wheel
		pass


class checkableComboBox(CustomComboBox2):
	selectionChanged = Signal()  # Signal to emit when selection changes

	def __init__(self, parent=None):
		super(checkableComboBox, self).__init__(parent)
		self.setModel(QStandardItemModel(self))
		self.view().clicked.connect(self.handleItemPressed)
		self.setEditable(True)
		self.lineEdit().setReadOnly(True)
		self.selectionChanged.connect(self.currentCheckedItems)  # Emit signal when an item is checked/unchecked

	def handleItemPressed(self, index):
		item = self.model().itemFromIndex(index)
		background_brush = item.background()
		background_color = background_brush.color().name()
		if background_color == '#f6f8fc':
			active_brush = QBrush(QColor("#6c7ae0"))
			item.setBackground(active_brush)
			item.setForeground(QColor("white"))
		else:
			inactive_brush = QBrush(QColor('#f6f8fc'))
			item.setBackground(inactive_brush)
			item.setForeground(QColor("black"))

		self.selectionChanged.emit()  # Emit signal when an item is checked/unchecked

	def addItem(self, text, data=None):
		item = QStandardItem()
		item.setText(text)
		item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsUserCheckable)
		item.setData(data)
		self.model().appendRow(item)
		brush = QBrush(QColor('#f6f8fc'))
		item.setBackground(brush)
		

	def addItems(self, texts, data=None):
		for text in texts:
			self.addItem(text, data=data)

	def currentCheckedItems(self):
		checkedItems = []
		for i in range(self.model().rowCount()):
			item = self.model().item(i)

			background_brush = item.background()
			background_color = background_brush.color().name()
			if background_color.lower() == '#6c7ae0':
				checkedItems.append(item.text())

		self.lineEdit().setText(f"{', '.join(checkedItems) if checkedItems else ''}")
		self.lineEdit().setToolTip(f"{', '.join(checkedItems) if checkedItems else ''}")


class timeLineEdit(QLineEdit):
	def __init__(self, parent=None):
		super().__init__(parent)
		self.setPlaceholderText("Time (HH:MM)")

	def keyPressEvent(self, event):
		key = event.key()
		text = event.text()
		current_text = self.text()
		cursor_position = self.cursorPosition()

		if len(current_text) >= 5 and key != Qt.Key_Backspace:
			return

		if key in (Qt.Key_Backspace, Qt.Key_Left, Qt.Key_Right):
			return super().keyPressEvent(event)

		if text.isdigit() or (text == ':' and self.isAllowedPosition(cursor_position)):
			if cursor_position == 0 and int(text) > 2:
				return
			if cursor_position == 1:
				if int(current_text[0]) == 2:
					if int(text) > 3:
					  return
			if cursor_position == 2 and text != ':':
				return
			if cursor_position == 3 and int(text) > 5:
				return
			super().keyPressEvent(event)

	def isAllowedPosition(self, cursor_position):
		return cursor_position in (2, 5) and ':' not in self.text()



class CustomValueAxis(QValueAxis):
	def __init__(self):
		super().__init__()

	def labelFormatChanged(self, format):
		# Override the label format and set it to int if the original format is exponential
		if "e" in format:
			format = "%d"
		super().labelFormatChanged(format)



def logErrors(func):
	@wraps(func)
	def wrapper(*args, **kwargs):
		# return func(*args, **kwargs)
		try:
			return func(*args, **kwargs)
		except Exception as e:
			logging.error(f"An error occurred in {func.__name__}: {str(e)}", exc_info=sys.exc_info())
			# Display an error message to the user (optional)
			# QMessageBox.critical(None, "Error", f"An error occurred: {str(e)}", QMessageBox.Ok)
			errorMsgBox = QMessageBox()
			errorMsgBox.setIcon(QMessageBox.Critical) 
			errorMsgBox.setText(f"An error occurred: {str(e)}")
			errorMsgBox.setWindowTitle("Error")
			errorMsgBox.setWindowIcon(QIcon('Media/ramsify.png'))
			errorMsgBox.setStandardButtons(QMessageBox.Ok)
			errorMsgBox.exec_()

	return wrapper

def dbBackup(self):
	current_time = datetime.now()
	backupDuration = int(self.config.get('Backup', 'duration'))
	min_backup_interval = timedelta(days=backupDuration)

	self.cursor.execute('SELECT backupdate FROM db_backup ORDER BY id DESC LIMIT 1')
	latestTime = self.cursor.fetchone()

	if (latestTime == None) or ((current_time - latestTime[0]) >= min_backup_interval):
		self.create_folder_if_not_exists("C:/ProgramData/RAMSify/Backup")
		timestamp = current_time.strftime("%Y%m%d%H%M")
		backup_file = f"C:/ProgramData/RAMSify/Backup/backup_{timestamp}.sql"

		self.cursor.execute("INSERT INTO db_backup (path) VALUES (%s)",(backup_file,))
		self.mydb.commit()

		user=self.config.get('Database', 'user')
		password=self.config.get('Database', 'password')
		database=self.config.get('Database', 'database')

		command = f"mysqldump --defaults-file=dbData.cnf {database} > {backup_file}"
		subprocess.run(command, shell=True)


def create_folder_if_not_exists(self,folder_name):
	if not os.path.exists(folder_name):
		os.makedirs(folder_name)

##### function to read ini file
def readIniFile(self):
	self.config = configparser.ConfigParser()
	self.config.read('config.ini')

##### function to connect to database
def connectDB(self):
	connection = mysql.connector.connect(
	host=self.config.get('Database', 'host'),
	user=self.config.get('Database', 'user'),
	password=self.config.get('Database', 'password')
	)
	try:
		# Create a cursor object to execute SQL statements
		cursor = connection.cursor()

		# Specify the name of the database to be created
		database_name = self.config.get('Database', 'database')

		# Create the database if it doesn't exist
		cursor.execute(f"CREATE DATABASE IF NOT EXISTS {database_name}")

	finally:
		cursor.close()
		connection.close()

	
	self.mydb = mysql.connector.connect(
	host=self.config.get('Database', 'host'),
	user=self.config.get('Database', 'user'),
	password=self.config.get('Database', 'password'),
	database=self.config.get('Database', 'database')
	)

	self.cursor = self.mydb.cursor()



def createCheckBoxes(self, optionsList, typeOfLayout, layoutName):
	OptionsList = optionsList
	if typeOfLayout == 0:
		setattr(self, layoutName, QVBoxLayout())
		getattr(self, layoutName).addSpacing(int(0.00416 * QApplication.primaryScreen().availableGeometry().width()))
		getattr(self, layoutName).setSpacing(int(0.0052 * QApplication.primaryScreen().availableGeometry().width()))
		for i in range(len(OptionsList)):
			OptionsList[i] = QCheckBox(OptionsList[i])
			getattr(self, layoutName).addWidget(OptionsList[i])

	elif typeOfLayout == 1:
		setattr(self, layoutName, QHBoxLayout())
		getattr(self, layoutName).addSpacing(int(0.00416 * QApplication.primaryScreen().availableGeometry().width()))
		getattr(self, layoutName).setSpacing(int(0.0052 * QApplication.primaryScreen().availableGeometry().width()))
		for i in range(len(OptionsList)):
			OptionsList[i] = QCheckBox(OptionsList[i])
			getattr(self, layoutName).addWidget(OptionsList[i])

	elif typeOfLayout == 2:
		setattr(self, layoutName, QGridLayout())
		getattr(self, layoutName).setSpacing(int(0.0052 * QApplication.primaryScreen().availableGeometry().width()))
		for i in range(len(OptionsList)):
			OptionsList[i] = QCheckBox(OptionsList[i])
			getattr(self, layoutName).addWidget(OptionsList[i], int(i // 2), int(i % 2))



##### function to create comboBox for given options
def createComboBox(self, optionsList, comboBoxName):
	setattr(self, comboBoxName, CustomComboBox())
	getattr(self, comboBoxName).setPlaceholderText("--Select--")
	getattr(self, comboBoxName).addItems(optionsList)
	getattr(self, comboBoxName).setFixedWidth(int(0.142 * QApplication.primaryScreen().availableGeometry().width()))
	# getattr(self, comboBoxName).setFocusPolicy(Qt.NoFocus)
	getattr(self, comboBoxName).setStyleSheet(self.comboBoxQSS)


def createComboBox2(self, optionsList, comboBoxName):
	setattr(self, comboBoxName, CustomComboBox2())
	getattr(self, comboBoxName).setPlaceholderText("--Select--")
	getattr(self, comboBoxName).addItems(optionsList)
	getattr(self, comboBoxName).setFixedWidth(int(0.142 * QApplication.primaryScreen().availableGeometry().width()))
	# getattr(self, comboBoxName).setFocusPolicy(Qt.NoFocus)
	getattr(self, comboBoxName).setStyleSheet(self.comboBoxQSS)




##### function to create checkable comboBox for given options
def createCheckableComboBox(self, optionsList, comboBoxName):
	setattr(self, comboBoxName, checkableComboBox())
	getattr(self, comboBoxName).setPlaceholderText("--Select--")
	getattr(self, comboBoxName).addItems(optionsList)
	getattr(self, comboBoxName).setFixedWidth(int(0.142 * QApplication.primaryScreen().availableGeometry().width()))
	# getattr(self, comboBoxName).setFocusPolicy(Qt.NoFocus)
	getattr(self, comboBoxName).setStyleSheet(self.comboBoxQSS)



def createDateTimeEditBox(self, dateTimeEditBoxName, width=None):
	setattr(self, dateTimeEditBoxName, CustomDateTimeEdit())
	# getattr(self, dateTimeEditBoxName).setDateTime(QDateTime.currentDateTime())
	getattr(self, dateTimeEditBoxName).setDisplayFormat("dd-MM-yyyy HH:mm")
	getattr(self, dateTimeEditBoxName).setCalendarPopup(True)
	min_dateTime = QDateTime(QDate(self.startingYear, self.startingMonth, 1), QTime(0, 0))
	getattr(self, dateTimeEditBoxName).setMinimumDateTime(min_dateTime)
	current_date = QDate.currentDate()
	max_date_time = QDateTime(current_date, QTime(23, 59))
	getattr(self, dateTimeEditBoxName).setMaximumDateTime(max_date_time)
	getattr(self, dateTimeEditBoxName).setFixedWidth(int(0.142 * QApplication.primaryScreen().availableGeometry().width()))


def createDateEditBox(self, dateEditBoxName):
	setattr(self, dateEditBoxName, CustomDateEdit())
	# getattr(self, dateEditBoxName).setDate(QDate.currentDate())
	getattr(self, dateEditBoxName).setDisplayFormat("dd-MM-yyyy")
	getattr(self, dateEditBoxName).setStyleSheet(self.dateEditBoxQSS)
	getattr(self, dateEditBoxName).setCalendarPopup(True)
	min_date = QDate(self.startingYear, self.startingMonth, 1)
	getattr(self, dateEditBoxName).setMinimumDate(min_date)
	current_date = QDate.currentDate()
	getattr(self, dateEditBoxName).setMaximumDate(current_date)

	current_date_ = datetime.now()

	currentYear = current_date_.year
	currentMonth = current_date_.month
	firstDayOfCurrentMonth = datetime(currentYear, currentMonth, 1).date()
	lastDateOfPreviousMonth = (firstDayOfCurrentMonth - relativedelta(days=1))
	firstDateOfPreviousMonth = QDate(lastDateOfPreviousMonth.year, lastDateOfPreviousMonth.month, 1)

	six_months_ago = current_date_ - relativedelta(months=6)
	firstDateOfSixMonthsAgo_ = six_months_ago.replace(day=1)
	firstDateOfSixMonthsAgo = QDate(firstDateOfSixMonthsAgo_.year, firstDateOfSixMonthsAgo_.month, 1)

	if self.userRole == 1:
		getattr(self, dateEditBoxName).setMinimumDate(firstDateOfSixMonthsAgo)

	if self.userRole in [2, 3]:
		getattr(self, dateEditBoxName).setMinimumDate(firstDateOfPreviousMonth)
	

	if ((self.userName == 'Ravikumar') and (self.editableOptionMaxDate > datetime.now().date())):
		getattr(self, dateEditBoxName).setMinimumDate(QDate(self.startingYear, self.startingMonth, 1))



	getattr(self, dateEditBoxName).setFixedWidth(int(0.142 * QApplication.primaryScreen().availableGeometry().width()))


def createTimeEditBox(self, timeEditBoxName):
	setattr(self, timeEditBoxName, CustomTimeEdit())
	# getattr(self, timeEditBoxName).setTime(QTime.currentTime())
	getattr(self, timeEditBoxName).setDisplayFormat("HH:mm")
	getattr(self, timeEditBoxName).setStyleSheet(self.timeEditBoxQSS)
	getattr(self, timeEditBoxName).setFixedWidth(int(0.052 * QApplication.primaryScreen().availableGeometry().width()))


def createSpinBox(self, spinBoxName, defaultValue=0, singleStep=1, minimum=0, maximum=1000000000):
	spin_box = CustomSpinBox()
	setattr(self, spinBoxName, spin_box)
	spin_box.setMinimum(minimum)
	spin_box.setMaximum(maximum)
	spin_box.setSingleStep(singleStep)
	spin_box.setValue(defaultValue)
	spin_box.setStyleSheet(self.spinBoxQSS)
	spin_box.setFixedWidth(int(0.142 * QApplication.primaryScreen().availableGeometry().width()))

def createTextEditBox(self, textEditBoxName, placeholderText=''):
	setattr(self, textEditBoxName, QTextEdit())
	getattr(self, textEditBoxName).setMinimumHeight(int(0.18 * QApplication.primaryScreen().availableGeometry().height()))
	getattr(self, textEditBoxName).setMaximumHeight(int(0.21 * QApplication.primaryScreen().availableGeometry().height()))
	getattr(self, textEditBoxName).setStyleSheet(self.textEditBoxQSS)
	getattr(self, textEditBoxName).setAcceptRichText(False)
	getattr(self, textEditBoxName).setPlaceholderText(placeholderText)


def createLineEditBox(self, lineEditBoxName, placeholderText=''):
	setattr(self, lineEditBoxName, QLineEdit())
	# getattr(self, lineEditBoxName).setFixedHeight(int(0.035 * QApplication.primaryScreen().availableGeometry().height()))
	getattr(self, lineEditBoxName).setStyleSheet(self.lineEditBoxQSS)
	getattr(self, lineEditBoxName).setPlaceholderText(placeholderText)


def createNumberLineEditBox(self, lineEditBoxName, placeholderText=''):
	setattr(self, lineEditBoxName, NumberLineEdit())
	# getattr(self, lineEditBoxName).setFixedHeight(int(0.035 * QApplication.primaryScreen().availableGeometry().height()))
	getattr(self, lineEditBoxName).setStyleSheet(self.lineEditBoxQSS)
	getattr(self, lineEditBoxName).setPlaceholderText(placeholderText)


def createRadioButtons(self, optionsList, typeOfLayout, layoutName, buttonGroup, widgetName):
		OptionsList = optionsList
		if typeOfLayout == 0:
			setattr(self, layoutName, QVBoxLayout())
			getattr(self, layoutName).addSpacing(int(0.00416 * QApplication.primaryScreen().availableGeometry().width()))
			getattr(self, layoutName).setSpacing(int(0.0052 * QApplication.primaryScreen().availableGeometry().width()))
			for i in range(len(OptionsList)):
				radioButton = QRadioButton(OptionsList[i])
				getattr(self, layoutName).addWidget(radioButton)
				buttonGroup.addButton(radioButton)

		elif typeOfLayout == 1:
			setattr(self, layoutName, QHBoxLayout())
			getattr(self, layoutName).addSpacing(int(0.00416 * QApplication.primaryScreen().availableGeometry().width()))
			getattr(self, layoutName).setSpacing(int(0.0052 * QApplication.primaryScreen().availableGeometry().width()))
			for i in range(len(OptionsList)):
				radioButton = QRadioButton(OptionsList[i])
				getattr(self, layoutName).addWidget(radioButton)
				buttonGroup.addButton(radioButton)
			getattr(self, layoutName).addSpacerItem(QSpacerItem(1, 1, QSizePolicy.Expanding, QSizePolicy.Minimum))

		elif typeOfLayout == 2:
			setattr(self, layoutName, QGridLayout())
			getattr(self, layoutName).setSpacing(int(0.0052 * QApplication.primaryScreen().availableGeometry().width()))
			for i in range(len(OptionsList)):
				radioButton = QCheckBox(OptionsList[i])
				getattr(self, layoutName).addWidget(radioButton, int(i // 2), int(i % 2))
				buttonGroup.addButton(radioButton)


def createPushButton(self, pushButtonName, textOnpushButton='', iconPath='', width=None, tooltip=''):
	if width is None:
		width = int(0.052 * QApplication.primaryScreen().availableGeometry().width())

	button = QPushButton(textOnpushButton, icon=QIcon(iconPath))
	button.setFixedWidth(width)
	button.setStyleSheet(self.pushbuttonQSS)
	button.setToolTip(tooltip)
	setattr(self, pushButtonName, button)



def browseFiles(self, layoutNameOfBrowseButtonAndAttachments):
	fileName = QFileDialog.getOpenFileNames(self, 'Select files')
	if len(fileName[0][::]) == 0:
		pass
	else:
		for i in range(len(fileName[0][::])):
			self.createPushButton('file' + str(i+1), str(fileName[0][i]), '', 300)
			self.createPushButton('cross' + str(i+1), '', 'Media/cross.png', 30)
			exec('self.' + layoutNameOfBrowseButtonAndAttachments + '.addWidget(self.file' + str(i+1) + ', int(self.' + layoutNameOfBrowseButtonAndAttachments + '.rowCount()), int(0))')
			exec('self.file' + str(i+1) + '.setStyleSheet(self.attachmentQSS)')
			exec('self.file' + str(i+1) + '.setCursor(QCursor(Qt.PointingHandCursor))')
			exec('self.' + layoutNameOfBrowseButtonAndAttachments + '.addWidget(self.cross' + str(i+1) + ', int(self.' + layoutNameOfBrowseButtonAndAttachments + '.rowCount()-1), int(1))')
			exec('self.cross' + str(i+1) + '.setStyleSheet(self.attachmentCrossButtonQSS)')
			exec('self.cross' + str(i+1) + '.setCursor(QCursor(Qt.PointingHandCursor))')
			exec('self.crossButtons.update({self.cross' + str(i+1) + ': self.file' + str(i+1) + '})')
			exec('self.cross' + str(i+1) + '.clicked.connect(self.removeAttachment)')
			exec('self.file' + str(i+1) + '.clicked.connect(self.openAttachment)')

def removeAttachment(self):
	senderCross = self.sender()
	attachmentButton = self.crossButtons.get(senderCross)
	senderCross.deleteLater()
	attachmentButton.deleteLater()


def openAttachment(self):
	senderPath = self.sender()
	path = senderPath.text()
	subprocess.call(('cmd', '/C', str(path).replace('/', '\\')))

def createLayout(self, typeOfLayout, layoutName, layoutContentsList):
	if typeOfLayout == 0:
		setattr(self, layoutName, QVBoxLayout())
		getattr(self, layoutName).setSpacing(int(0.0052 * QApplication.primaryScreen().availableGeometry().width()))
		for i in range(len(layoutContentsList)):
			if isinstance(layoutContentsList[i], QWidget):
				getattr(self, layoutName).addWidget(layoutContentsList[i])
			elif isinstance(layoutContentsList[i], QLayout):
				getattr(self, layoutName).addLayout(layoutContentsList[i])
			elif isinstance(layoutContentsList[i], QSpacerItem):
				getattr(self, layoutName).addItem(layoutContentsList[i])

	elif typeOfLayout == 1:
		setattr(self, layoutName, QHBoxLayout())
		getattr(self, layoutName).setSpacing(int(0.052 * QApplication.primaryScreen().availableGeometry().width()))
		for i in range(len(layoutContentsList)):
			if isinstance(layoutContentsList[i], QWidget):
				getattr(self, layoutName).addWidget(layoutContentsList[i])
			elif isinstance(layoutContentsList[i], QLayout):
				getattr(self, layoutName).addLayout(layoutContentsList[i])
			elif isinstance(layoutContentsList[i], QSpacerItem):
				getattr(self, layoutName).addItem(layoutContentsList[i])

	elif typeOfLayout == 2:
		setattr(self, layoutName, QGridLayout())
		getattr(self, layoutName).setSpacing(int(0.052 * QApplication.primaryScreen().availableGeometry().width()))
		for i in range(len(layoutContentsList)):
			if isinstance(layoutContentsList[i], QWidget):
				getattr(self, layoutName).addWidget(layoutContentsList[i], i // 2, i % 2)
			elif isinstance(layoutContentsList[i], QLayout):
				getattr(self, layoutName).addLayout(layoutContentsList[i], i // 2, i % 2)
			elif isinstance(layoutContentsList[i], QSpacerItem):
				getattr(self, layoutName).addItem(layoutContentsList[i], i // 2, i % 2)





def childrenOf(self, Data, parentID):
	childrenDF = Data.loc[Data['Parent_Id'] == parentID]
	return(childrenDF)

def topItems(self, data):
	return data.loc[data['Parent_Id'] == 0, 'Reference_ID'].tolist()
	

def readTreeData(self, tableNameList, lableLayoutName):
	sendingButton = self.sender()
	crossButtonsDict = {}

	self.treeDataWindow = QWidget()
	layout = QVBoxLayout()
	self.popupTree = QTreeWidget()
	#self.popupTree.setStyleSheet(treeWidgetQSS2)
	#self.popupTree.header().setStyleSheet(self.headerVerticalQSS)
	self.treeDataWindow.resize(900, 620)
	self.popupTree.setHeaderLabels(['ID', 'Part Number', 'Reference ID', 'Description', 'Quantity'])
	topTreeWidgetItem = QTreeWidgetItem(['Total System'])
	self.popupTree.addTopLevelItem(topTreeWidgetItem)
	self.popupTree.expandItem(topTreeWidgetItem)
	self.popupTree.setAlternatingRowColors(True)
	self.popupTree.setColumnWidth(0, 190)
	self.popupTree.setColumnWidth(1, 180)
	self.popupTree.setColumnWidth(2, 160)
	self.popupTree.setColumnWidth(3, 170)

	
	for i in range(len(tableNameList)):
		self.cursor.execute('SELECT * FROM {}'.format(tableNameList[i]))
		data = self.cursor.fetchall()
		BOMData = pd.DataFrame(data, columns=['Id','Parent_Id', 'Part_Number', 'Reference_ID', 'Description', 'Quantity', 'Target_MTBF'])
		#self.popupTree.setStyleSheet(treeWidgetQSS)

		def displayTree(parentItem, data, parentID):

			children = self.childrenOf(data,parentID)
			for i in range(len(children)):
				branch = QTreeWidgetItem([str(children.iat[i, 0])])
				parentItem.addChild(branch)
				parentItem.setCheckState(0, Qt.Unchecked)
				branch.setText(1, str(children.iat[i,2]))
				branch.setText(2, str(children.iat[i,3]))
				branch.setText(3, str(children.iat[i,4]))
				branch.setText(4, str(children.iat[i,5]))
				branch.setFlags(branch.flags() | Qt.ItemIsTristate | Qt.ItemIsUserCheckable)
				branch.setCheckState(0, Qt.Unchecked)
				#if len(self.checkedItemsOfBOMWindow) == 0:
				#elif len(self.checkedItemsOfBOMWindow) == 1:
				#	if branch.text(0) in self.checkedItemsOfBOMWindow[str(sendingButton)][1]:
				#		print('#',branch.text(0),branch.checkState(0))
				#		branch.setCheckState(0, Qt.Checked)
				#	else:
				#		branch.setCheckState(0, Qt.Unchecked)

				if len(self.childrenOf(BOMData,int(children.iat[i, 1]))) > 0:
					displayTree(branch,self.childrenOf(BOMData, children.iat[i, 0]), int(children.iat[i, 0]))

		displayTree(topTreeWidgetItem, BOMData, 0)

	layout.addWidget(self.popupTree)

	okButton_BOMTree = QPushButton('OK')
	#okButton_BOMTree.setStyleSheet(self.pushbuttonQSS)
	okButton_BOMTree.setFixedWidth(int(0.078 * QApplication.primaryScreen().availableGeometry().width()))
	okButton_BOMTree.setFixedHeight(int(0.0156 * QApplication.primaryScreen().availableGeometry().width()))
	layout.addWidget(okButton_BOMTree, alignment= Qt.AlignRight)
	self.treeDataWindow.setLayout(layout)
	#self.treeDataWindow.setStyleSheet('QWidget{ background-color:#27263c}')
	self.treeDataWindow.show()

	def get_selected_leaves():
		checked_items = []
		checked_items_serial_numbers = []
		def recurse(parent_item):
			for i in range(parent_item.childCount()):
				child = parent_item.child(i)
				#if len(self.checkedItemsOfBOMWindow) == 1:
				#	if child.text(0) in self.checkedItemsOfBOMWindow[str(sendingButton)][1]:
				#		print('$',child.text(0),child.checkState(0))
				grand_children = child.childCount()
				if grand_children > 0 and child.checkState(0) == Qt.PartiallyChecked:
					recurse(child)

				elif child.checkState(0) == Qt.Checked:

					checked_items.append(child.text(2))
					checked_items_serial_numbers.append(child.text(0))


		recurse(topTreeWidgetItem)
		self.treeDataWindow.close()
		self.checkedItemsOfBOMWindow[str(sendingButton)] = [checked_items,checked_items_serial_numbers]
		

		def removeComponent():
			senderCross = self.sender()
			selectedComponentButton = crossButtonsDict.get(senderCross)
			senderCross.deleteLater()
			selectedComponentButton.deleteLater()
		for i in range(lableLayoutName.rowCount()):
			for j in range(lableLayoutName.columnCount()):
				if lableLayoutName.itemAtPosition(i,j) != None:
					lableLayoutName.itemAtPosition(i,j).widget().setParent(None)
		for index, selection in zip(list(range(len(self.checkedItemsOfBOMWindow[str(sendingButton)][0]))),self.checkedItemsOfBOMWindow[str(sendingButton)][0]):
			if len(self.checkedItemsOfBOMWindow[str(sendingButton)][0]) == 0:
				pass
			else:
				label = QPushButton(str(selection))
				label.setFixedWidth(int(0.156 * QApplication.primaryScreen().availableGeometry().width()))
				label.setStyleSheet('background:#27263c; border-radius: 5px')
				lableLayoutName.addWidget(label, index, 0)
				self.createPushButton('crossButton', '', 'Media/cross.png', 30)
				self.crossButton.setStyleSheet(attachmentCrossButtonQSS)
				lableLayoutName.addWidget(self.crossButton, index, 1)
				self.crossButton.clicked.connect(removeComponent)
				crossButtonsDict.update({self.crossButton : label})


	okButton_BOMTree.clicked.connect(get_selected_leaves)




class CustomSpinBox(QSpinBox):
	def __init__(self, parent=None):
		super().__init__(parent)

	def wheelEvent(self, event):
		# Disable changing the current index using the mouse wheel
		pass

class CustomDateEdit(QDateEdit):
	def __init__(self, parent=None):
		super().__init__(parent)
		self.setButtonSymbols(QDateEdit.NoButtons)

	def wheelEvent(self, event):
		# Disable changing the current index using the mouse wheel
		pass

class CustomDateTimeEdit(QDateTimeEdit):
	def __init__(self, parent=None):
		super().__init__(parent)
		self.setButtonSymbols(QDateTimeEdit.NoButtons)

	def wheelEvent(self, event):
		# Disable changing the current index using the mouse wheel
		pass

class CustomTimeEdit(QTimeEdit):
	def __init__(self, parent=None):
		super().__init__(parent)

	def wheelEvent(self, event):
		# Disable changing the current index using the mouse wheel
		pass


##### function to create QTableView:
class TableView(QTableView):
	def wheelEvent(self, event):
		if event.modifiers() == Qt.ShiftModifier:
			QApplication.sendEvent(self.horizontalScrollBar(), event)
		else:
			QTableView.wheelEvent(self, event)

class TableWidget(QTableWidget):
	def __init__(self, *args, actions = None, **kwargs):
		super().__init__(*args, **kwargs)

		# Set up the context menu
		self.setContextMenuPolicy(Qt.CustomContextMenu)
		self.customContextMenuRequested.connect(self.showContextMenu)

		self.actions = actions or ["Copy", "Delete", "Paste"]
		self.context_menu = QMenu(self)
		self.createActions()

		self.setHorizontalScrollMode(QTableWidget.ScrollPerPixel)
		self.setVerticalScrollMode(QTableWidget.ScrollPerPixel)

	def createActions(self):
		for action_name in self.actions:
			if action_name == "Copy":
				self.copy_action = QAction("Copy", self)
				self.copy_action.triggered.connect(self.copySelectedCells)
				self.context_menu.addAction(self.copy_action)

			# elif action_name == "Delete":
			# 	self.delete_action = QAction("Delete", self)
			# 	self.delete_action.triggered.connect(self.deleteSelectedCells)
			# 	self.context_menu.addAction(self.delete_action)
			# elif action_name == "Paste":
			# 	self.paste_action = QAction("Paste", self)
			# 	self.paste_action.triggered.connect(self.pasteToSelectedCell)
			# 	self.context_menu.addAction(self.paste_action)


	def showContextMenu(self, pos):
		self.context_menu.exec_(self.mapToGlobal(pos))

	def copySelectedCells(self):
		selected_ranges = self.selectedRanges()
		if not selected_ranges:
			return

		rows = selected_ranges[0].rowCount()
		cols = selected_ranges[0].columnCount()

		clipboard = QApplication.clipboard()
		text = ""

		for range_ in selected_ranges:
			for row in range(range_.topRow(), range_.bottomRow() + 1):
				for col in range(range_.leftColumn(), range_.rightColumn() + 1):
					item = self.item(row, col)
					if item:
						text += item.text().replace('\n',' ')
					if col < range_.rightColumn():
						text += "\t"
				text += "\n"

		clipboard.setText(text)


	def deleteSelectedCells(self):
		selected_ranges = self.selectedRanges()
		for range_ in selected_ranges:
			for row in range(range_.topRow(), range_.bottomRow() + 1):
				for col in range(range_.leftColumn(), range_.rightColumn() + 1):
					item = self.item(row, col)
					if item:
						item.setText("")

	def pasteToSelectedCell(self):
		clipboard = QApplication.clipboard()
		clipboard_text = clipboard.text()
		selected_ranges = self.selectedRanges()

		for rangee in selected_ranges:
			top_row = rangee.topRow()
			bottom_row = rangee.bottomRow()
			left_column = rangee.leftColumn()
			right_column = rangee.rightColumn()

		rows = clipboard_text.split('\n')

		if clipboard_text and selected_ranges:
			for r, row in enumerate(rows):
				columns = row.split('\t')
				for c, text in enumerate(columns):
					# Insert the text into the table, starting from the selected cell
					item = QTableWidgetItem(text)
					self.setItem(top_row + r, left_column + c, item)


	# def keyPressEvent(self, event):
	# 	if event.matches(QKeySequence.Copy):
	# 		self.copySelectedCells()
	# 	elif event.matches(QKeySequence.Paste):
	# 		self.pasteToSelectedCell()
	# 	elif event.key() == Qt.Key_Delete:
	# 		self.deleteSelectedCells()
	# 	else:
	# 		super().keyPressEvent(event)


	def wheelEvent(self, event):
		if event.modifiers() == Qt.ShiftModifier:
			QApplication.sendEvent(self.horizontalScrollBar(), event)
		else:
			QTableView.wheelEvent(self, event)


def createTableView(self, tableViewName):
	setattr(self, tableViewName, QTableView())

	# Access the horizontal header
	header = getattr(self, tableViewName).horizontalHeader()

	# Set properties directly
	getattr(self, tableViewName).setFont(QFont("Times", 10))
	getattr(self, tableViewName).setStyleSheet(self.tableViewQSS)
	getattr(self, tableViewName).setSortingEnabled(True)
	getattr(self, tableViewName).setEditTriggers(QAbstractItemView.NoEditTriggers)
	getattr(self, tableViewName).setAlternatingRowColors(True)
	header.setDefaultSectionSize(int(0.078 * QApplication.primaryScreen().availableGeometry().width()))
	header.setStyleSheet(self.headerVerticalQSS)

	# Access the vertical header and set its style sheet
	getattr(self, tableViewName).verticalHeader().setStyleSheet(self.headerVerticalQSS)


def createListView(self, listOfItems, listViewName):
	setattr(self, listViewName, QListView())
	getattr(self, listViewName).setFixedWidth(int(0.182 * QApplication.primaryScreen().availableGeometry().width()))

	listViewModel = QStandardItemModel()
	getattr(self, listViewName).setModel(listViewModel)

	for i in listOfItems:
		item = QStandardItem(i)
		listViewModel.appendRow(item)


def logout(self):
	from loginForm import LoginForm
	
	message_box = QMessageBox()
	message_box.setWindowTitle("Logout")
	message_box.setWindowIcon(QIcon('Media/logout.png'))
	message_box.setText("Are you sure you want to logout?")
	message_box.setStandardButtons(QMessageBox.Yes | QMessageBox.Cancel)
	message_box.setDefaultButton(QMessageBox.Cancel)

	button_yes = message_box.button(QMessageBox.Yes)
	button_yes.setText("Yes")
	button_cancel = message_box.button(QMessageBox.Cancel)
	button_cancel.setText("Cancel")
	message_box.setIcon(QMessageBox.Question)
	result = message_box.exec_()

	if result == QMessageBox.Yes:
		
		self.cursor.execute("SELECT * FROM loginlog ORDER BY sno DESC LIMIT 1")
		last_row = self.cursor.fetchone()
		sql = "INSERT INTO loginlog (username, user_id, role, log_type) VALUES (%s, %s, %s, %s)"
		val = (last_row[1], last_row[2], last_row[4], 'logout')
		self.cursor.execute(sql, val)
		self.mydb.commit()
		self.cursor.close()
		self.close()
		newLoginWindow = LoginForm()
		newLoginWindow.loginWindow.show()
	else:
		message_box.close()


def mapImportedDataToWidgets(self, gridLayout, plusBtn, listOfFields):

	# Get the file path to fetch the data from the excel file:
	file_path, _ = QFileDialog.getOpenFileName(None, "Select Excel File", "", "Excel Files (*.xlsx)")

	if file_path:
		# Read the excel file into pandas dataframe
		dataf = pd.read_excel(file_path)
		dataf = dataf.map(lambda x: x.strip() if isinstance(x, str) else x)

		# Get the headers as a list
		excelHeaders = dataf.columns.tolist()

		excelDataMappingWindowWidth = int(0.3* QApplication.primaryScreen().availableGeometry().width())
		excelDataMappingWindowHeight = int(0.6 * QApplication.primaryScreen().availableGeometry().height())

		self.excelAndTableColumnsMappingWindow = QWidget()
		self.excelAndTableColumnsMappingWindow.setWindowIcon(QIcon('Media/ramsify.png'))
		self.excelAndTableColumnsMappingWindow.setWindowTitle('Map Columns')
		self.excelAndTableColumnsMappingWindow.setStyleSheet(self.widgetQSS)
		self.excelAndTableColumnsMappingWindow.setFixedHeight(excelDataMappingWindowHeight)
		self.excelAndTableColumnsMappingWindow.setFixedWidth(excelDataMappingWindowWidth)
		# self.excelAndTableColumnsMappingWindow.resize(excelDataMappingWindowWidth,excelDataMappingWindowHeight)

		VLayoutForColumnsMappingWindow = QVBoxLayout()

		columnsMappingHeaderLabel = QLabel('Map Columns')
		columnsMappingHeaderLabel.setAlignment(Qt.AlignHCenter)
		columnsMappingHeaderLabel.setContentsMargins(20, 0, 0, 0)


		scrollArea_ExcelImportWindow = QScrollArea()
		scrollArea_ExcelImportWindow.setStyleSheet(self.scrollAreaQSS)
		scrollArea_ExcelImportWindow.setWidgetResizable(True)
		

		VLayoutForColumnsMappingWindow.addWidget(columnsMappingHeaderLabel)


		excelColumnsWithTableColumnsWidget = QWidget()
		# excelColumnsWithTableColumnsWidget.setAlignment(Qt.AlignTop)

		scrollArea_ExcelImportWindow.setWidget(excelColumnsWithTableColumnsWidget)


		excelAndTableColumnsGridLayout = QGridLayout()

		widgetHeadersLabel = QLabel('Fields')
		widgetHeadersLabel.setStyleSheet("font-size: 13pt;")

		excelHeadersLabel = QLabel('Imported Excel Columns')
		excelHeadersLabel.setStyleSheet("font-size: 13pt;")

		

		excelAndTableColumnsGridLayout.addWidget(widgetHeadersLabel, 0, 0)
		excelAndTableColumnsGridLayout.addWidget(excelHeadersLabel, 0, 1)

		for i in range(len(listOfFields)):
			fieldLabel_mappingWindow = QLabel(listOfFields[i])
			excelAndTableColumnsGridLayout.addWidget(fieldLabel_mappingWindow, i + 1, 0)

			self.createComboBox(excelHeaders, 'excelColumnNames')
			if i < len(excelHeaders):
				if (listOfFields[i]).lower() in [s.lower() for s in excelHeaders]:
					self.excelColumnNames.setCurrentText(listOfFields[i])

			excelAndTableColumnsGridLayout.addWidget(self.excelColumnNames, i + 1, 1)


		excelColumnsWithTableColumnsWidget.setLayout(excelAndTableColumnsGridLayout)

		VLayoutForColumnsMappingWindow.addWidget(scrollArea_ExcelImportWindow)



		self.createPushButton('submitImportedExcelData', 'SUBMIT', width=int(0.050 * QApplication.primaryScreen().availableGeometry().width()))
		self.submitImportedExcelData.setFixedHeight(30)

		def mapData():
			self.excelAndTableColumnsMappingWindow.close()
			excelIndices = []
			for i in range(excelAndTableColumnsGridLayout.rowCount()):
				if excelAndTableColumnsGridLayout.itemAtPosition(i, 1):
					if excelAndTableColumnsGridLayout.itemAtPosition(i, 1).widget():
						if isinstance(excelAndTableColumnsGridLayout.itemAtPosition(i, 1).widget(), CustomComboBox):
							excelIndices.append(excelAndTableColumnsGridLayout.itemAtPosition(i, 1).widget().currentIndex())

			dataf_ = dataf.iloc[:, excelIndices]

			self.CMImportTable.setRowCount(dataf_.shape[0])
			



			for row_index, rowData in dataf_.iterrows():
				for col_index, value in enumerate(rowData):
					if col_index in [0, 24, 26]:

						try:
							if isinstance(value, datetime):
								date_value = value.date()
								formatted_date = date_value.strftime('%d-%m-%Y')
								item = QTableWidgetItem(str(formatted_date))
								self.CMImportTable.setItem(row_index, col_index, item)
							else:

								calenderWidget = QWidget()
								layout = QHBoxLayout()
								calenderWidget.setLayout(layout)
								calenderWidget.setFixedWidth(140)
								layout.setSpacing(0)
								layout.setContentsMargins(0, 0, 0, 0)
								self.dateBox = QDateEdit()
								self.dateBox.setCalendarPopup(True)
								self.dateBox.setFixedHeight(24)
								self.dateBox.setFixedWidth(19)
								self.dateBox.setButtonSymbols(QDateEdit.NoButtons)
								

								self.dateBox.setStyleSheet("""
									QDateEdit {
									color: transparent;
									border: 1px solid transparent;
									border-radius: 0px;
									}
									QDateEdit:hover {
									border: 1px solid transparent;
									}
									QDateEdit::drop-down{
									border-bottom-right-radius: 1px;
									}
									QDateEdit::down-arrow{
									width: 24px;
									height: 24px;
									image: url('Media/calendar.png');
									}
									""")

								self.createLineEditBox('lineBoxInCalenderWidget')
								self.lineBoxInCalenderWidget.setReadOnly(True)
								self.lineBoxInCalenderWidget.setFixedHeight(24)
								self.lineBoxInCalenderWidget.setFixedWidth(110)
								self.lineBoxInCalenderWidget.setProperty("error", True)
								self.lineBoxInCalenderWidget.setStyleSheet(self.lineEditBoxQSS)

								layout.addWidget(self.lineBoxInCalenderWidget)
								layout.addWidget(self.dateBox)


								def dateChangedd(dateEdit, lineEdit):
									lineEdit.setText(str(dateEdit.date().toString("dd-MM-yyyy")))

								def dateEditFunctionInCell(dateEdit, lineEdit):

									dateEdit.dateChanged.connect(lambda: dateChangedd(dateEdit, lineEdit))

								dateEditFunctionInCell(self.dateBox, self.lineBoxInCalenderWidget)

								current_date_ = datetime.now()

								currentYear = current_date_.year
								currentMonth = current_date_.month
								firstDayOfCurrentMonth = datetime(currentYear, currentMonth, 1).date()
								lastDateOfPreviousMonth = (firstDayOfCurrentMonth - relativedelta(days=1))
								firstDateOfPreviousMonth = QDate(lastDateOfPreviousMonth.year, lastDateOfPreviousMonth.month, 1)

								six_months_ago = current_date_ - relativedelta(months=6)
								firstDateOfSixMonthsAgo_ = six_months_ago.replace(day=1)
								firstDateOfSixMonthsAgo = QDate(firstDateOfSixMonthsAgo_.year, firstDateOfSixMonthsAgo_.month, 1)

								if self.userRole == 1:
									self.dateBox.setMinimumDate(firstDateOfSixMonthsAgo)

								if self.userRole in [2, 3]:
									self.dateBox.setMinimumDate(firstDateOfPreviousMonth)
								

								if ((self.userName == 'Ravikumar') and (self.editableOptionMaxDate > datetime.now().date())):
									self.dateBox.setMinimumDate(QDate(self.startingYear, self.startingMonth, 1))



								
								# if self.userRole != 0:
								# 	self.dateBox.setMinimumDate(firstDateOfPreviousMonth)

								# if (self.userName == 'Ravikumar') and (self.editableOptionMaxDate > datetime.now().date()):
								# 	self.dateBox.setMinimumDate(QDate(self.startingYear, self.startingMonth, 1))

								self.CMImportTable.setCellWidget(row_index, col_index, calenderWidget)
						except ValueError:
							self.createDateEditBox('dateBox')
							# if self.userRole != 0:
							# 	self.dateBox.setMinimumDate(firstDateOfPreviousMonth)

							# if (self.userName == 'Ravikumar') and (self.editableOptionMaxDate > datetime.now().date()):
							# 	self.dateBox.setMinimumDate(QDate(self.startingYear, self.startingMonth, 1))

							self.CMImportTable.setCellWidget(row_index, col_index, self.dateBox)

					if col_index in [1, 25, 27]:
						try:
							if str(type(value)) == "<class 'datetime.time'>":
								formatted_time = value.strftime('%H:%M')
								item = QTableWidgetItem(str(formatted_time))
								self.CMImportTable.setItem(row_index, col_index, item)
							else:
								# self.createTimeEditBox('timeBox')
								TimeLineEdit = timeLineEdit()
								TimeLineEdit.setFixedHeight(28)
								TimeLineEdit.setFixedWidth(120)
								TimeLineEdit.setProperty("error", True)
								TimeLineEdit.setStyleSheet(self.lineEditBoxQSS)
								TimeLineEdit.setStyleSheet(self.lineEditBoxQSS)
								self.CMImportTable.setCellWidget(row_index, col_index, TimeLineEdit)
						except ValueError:
							TimeLineEdit = timeLineEdit()
							TimeLineEdit.setFixedHeight(28)
							TimeLineEdit.setFixedWidth(120)
							TimeLineEdit.setStyleSheet(self.lineEditBoxQSS)
							self.CMImportTable.setCellWidget(row_index, col_index, TimeLineEdit)

					if col_index == 2:
						invalidVal = True
						for depo in self.depotsList:
							if str(value).lower() == depo.lower():
								item = QTableWidgetItem(depo)
								self.CMImportTable.setItem(row_index, col_index, item)
								invalidVal = False
								break
						if invalidVal:
							self.createComboBox(self.depotsList, 'depoComboBox')
							self.depoComboBox.setProperty("error", True)
							self.depoComboBox.setStyleSheet(self.comboBoxQSS)
							self.CMImportTable.setCellWidget(row_index, col_index, self.depoComboBox)

					if col_index == 3:
						invalidVal = True
						for train in self.trainsetsList:
							if str(value).lower() == train.lower():
								item = QTableWidgetItem(train)
								self.CMImportTable.setItem(row_index, col_index, item)
								invalidVal = False
								break
						if invalidVal:
							self.createComboBox(self.trainsetsList, 'trainComboBox')
							self.trainsetsList.setProperty("error", True)
							self.trainsetsList.setStyleSheet(self.comboBoxQSS)
							self.CMImportTable.setCellWidget(row_index, col_index, self.trainComboBox)

					if col_index == 4:
						for car in self.carsList:
							if str(value).lower() == car.lower():
								item = QTableWidgetItem(car)
								self.CMImportTable.setItem(row_index, col_index, item)
								break

					if col_index in [5, 6, 8, 11, 14, 15, 18, 19, 20, 21]:
						if not pd.isna(value):
							item = QTableWidgetItem(str(value))
							self.CMImportTable.setItem(row_index, col_index, item)

					if col_index in [11, 15]:
						if not pd.isna(value):
							if not str(value) == '':
								item = QTableWidgetItem(str(value))
								self.CMImportTable.setItem(row_index, col_index, item)
							else:
								self.createLineEditBox('lineBox')
								self.lineBox.setProperty("error", True)
								self.lineBox.setStyleSheet(self.lineEditBoxQSS)
								self.CMImportTable.setCellWidget(row_index, col_index, self.lineBox)
						else:
							self.createLineEditBox('lineBox')
							self.lineBox.setProperty("error", True)
							self.lineBox.setStyleSheet(self.lineEditBoxQSS)
							self.CMImportTable.setCellWidget(row_index, col_index, self.lineBox)


					if col_index == 7:
						# invalidVal = True
						for option in ['M/L', 'Depot']:
							if str(value).lower() == option.lower():
								item = QTableWidgetItem(option)
								self.CMImportTable.setItem(row_index, col_index, item)
								invalidVal = False
								break
						# if invalidVal:
						# 	self.createComboBox(['M/L', 'Depot'], 'mlDepotComboBox')
						# 	self.mlDepotComboBox.setProperty("error", True)
						# 	self.mlDepotComboBox.setStyleSheet(self.comboBoxQSS)
						# 	self.CMImportTable.setCellWidget(row_index, col_index, self.mlDepotComboBox)

					failCategoryOptions = ['External', 'Maintenance', 'Material', 'NFF', 'Operation', 'Software', 'Workmanship', 'Others']
					if col_index == 16:
						for option in failCategoryOptions:
							if str(value).lower() == option.lower():
								item = QTableWidgetItem(option)
								self.CMImportTable.setItem(row_index, col_index, item)
								break


					if col_index == 17:
						invalidVal = True
						for responsibilityOption in ['BEML', 'MMMOCL', 'Others']:
							if str(value).lower() == responsibilityOption.lower():
								item = QTableWidgetItem(responsibilityOption)
								self.CMImportTable.setItem(row_index, col_index, item)
								invalidVal = False
								break
						if invalidVal:
							self.createComboBox(['BEML', 'MMMOCL', 'Others'], 'responsibilComboBox')
							self.responsibilComboBox.setProperty("error", True)
							self.responsibilComboBox.setStyleSheet(self.comboBoxQSS)
							self.CMImportTable.setCellWidget(row_index, col_index, self.responsibilComboBox)

					if col_index == 22:
						for componentReplaced in ['Yes', 'No']:
							if str(value).lower() == componentReplaced.lower():
								item = QTableWidgetItem(componentReplaced)
								self.CMImportTable.setItem(row_index, col_index, item)
								break

					if col_index == 23:
						invalidVal = True
						for verificationOption in ['Yes', 'No']:
							if str(value).lower() == verificationOption.lower():
								item = QTableWidgetItem(verificationOption)
								self.CMImportTable.setItem(row_index, col_index, item)
								invalidVal = False
								break
						if invalidVal:
							self.createComboBox(['Yes', 'No'], 'varificaComboBox')
							self.varificaComboBox.setProperty("error", True)
							self.varificaComboBox.setStyleSheet(self.comboBoxQSS)
							self.CMImportTable.setCellWidget(row_index, col_index, self.varificaComboBox)


					if col_index == 9:
						invalidVal = True
						for systemOption in list(self.BOMSystemDictionary.keys()):
							if str(value).lower() == systemOption.lower():
								item = QTableWidgetItem(systemOption)
								self.CMImportTable.setItem(row_index, col_index, item)
								invalidVal = False


								invalidVal2 = True
								subSysOptions = self.BOMSystemDictionary[systemOption]
								for subSystemOption in subSysOptions:
									subSys = rowData.iloc[col_index + 1]
									if str(subSys).lower() == subSystemOption.lower():
										item2 = QTableWidgetItem(subSystemOption)
										self.CMImportTable.setItem(row_index, col_index + 1, item2)
										invalidVal2 = False
										break
								if invalidVal2:
									self.createComboBox(subSysOptions, 'subsystComboBox')
									self.subsystComboBox.setProperty("error", True)
									self.subsystComboBox.setStyleSheet(self.comboBoxQSS)
									self.CMImportTable.setCellWidget(row_index, col_index + 1, self.subsystComboBox)

								break
						if invalidVal:
							self.createComboBox(list(self.BOMSystemDictionary.keys()), 'systComboBox')
							self.systComboBox.setProperty("error", True)
							self.systComboBox.setStyleSheet(self.comboBoxQSS)
							self.CMImportTable.setCellWidget(row_index, col_index, self.systComboBox)

							self.createComboBox([], 'subsystComboBox')
							self.subsystComboBox.setProperty("error", True)
							self.subsystComboBox.setStyleSheet(self.comboBoxQSS)
							self.subsystComboBox.setEnabled(False)
							self.CMImportTable.setCellWidget(row_index, col_index + 1, self.subsystComboBox)

							def onChangingSysCombobox_CMImport2(sysCMCB, subSysCMCB):
								subSysCMCB.setEnabled(True)
								subSysCMCB.clear()
								if sysCMCB.currentText() != '':
									subSysCMCB.addItems(self.BOMSystemDictionary[sysCMCB.currentText()])
								else:
									subSysCMCB.setEnabled(False)

							def functionalityOfSystemSubsysCB_CMI2(sysCMCB, subSysCMCB):
								sysCMCB.currentTextChanged.connect(lambda:onChangingSysCombobox_CMImport2(sysCMCB, subSysCMCB))

							functionalityOfSystemSubsysCB_CMI2(self.systComboBox, self.subsystComboBox)


					if col_index == 12:
						invalidVal3 = True
						failureTypeOptions = ['Relevant Failure', 'Service Failure', 'Non Relevant Failure']
						for opti in failureTypeOptions:
							if str(value).lower() == opti.lower():
								item = QTableWidgetItem(opti)
								self.CMImportTable.setItem(row_index, col_index, item)
								invalidVal3 = False

								if opti == 'Service Failure':
									invalidVal4 = True
									serviceFailureEffectOptions = ['Pre-departure Withdrawal', 'Withdrawal', '3 min delay', 'Deboarding']

									serviceFialureValue = rowData.iloc[col_index + 1]
									for serviceFailEffectValue in serviceFailureEffectOptions:
										if serviceFialureValue.lower() == serviceFailEffectValue.lower():
											item2 = QTableWidgetItem(serviceFailEffectValue)
											self.CMImportTable.setItem(row_index, col_index + 1, item2)
											invalidVal4 = False
											break

									if invalidVal4:
										self.createComboBox(serviceFailureEffectOptions, 'serviceFailEffectComboBox')
										self.serviceFailEffectComboBox.setProperty("error", True)
										self.serviceFailEffectComboBox.setStyleSheet(self.comboBoxQSS)
										self.CMImportTable.setCellWidget(row_index, col_index + 1, self.serviceFailEffectComboBox)
									
								break


						if invalidVal3:
							self.createComboBox(failureTypeOptions, 'failureTypeCB2')
							self.failureTypeCB2.setProperty("error", True)
							self.failureTypeCB2.setStyleSheet(self.comboBoxQSS)
							self.CMImportTable.setCellWidget(row_index, col_index, self.failureTypeCB2)

							self.createComboBox([], 'serviceFailureEffectCombobox_ICM2')
							# self.serviceFailureEffectCombobox_ICM2.setProperty("error", True)
							# self.serviceFailureEffectCombobox_ICM2.setStyleSheet(self.comboBoxQSS)
							self.serviceFailureEffectCombobox_ICM2.setEnabled(False)
							self.CMImportTable.setCellWidget(row_index, col_index + 1, self.serviceFailureEffectCombobox_ICM2)



							def onChangingFailureTypeCombobox_CMImport(failureTypeCB, serviceFailureCB):

								if failureTypeCB.currentIndex() == 1:
									serviceFailureCB.setEnabled(True)
									serviceFailureCB.clear()
									serviceFailureCB.addItems(['Pre-departure Withdrawal', 'Withdrawal', '3 min delay', 'Deboarding'])
								else:
									serviceFailureCB.setEnabled(False)
									serviceFailureCB.clear()

							def functionalityOfServiceFailureTypeCB2(failureTypeCB, serviceFailureCB):
								failureTypeCB.currentTextChanged.connect(lambda:onChangingFailureTypeCombobox_CMImport(failureTypeCB, serviceFailureCB))

							functionalityOfServiceFailureTypeCB2(self.failureTypeCB2, self.serviceFailureEffectCombobox_ICM2)


				startDate = None
				startTime = None
				endDate = None
				endTime = None

				# Start Date
				if self.CMImportTable.item(row_index, self.CMImportTable.columnCount()-6):
					date_string = self.CMImportTable.item(row_index, self.CMImportTable.columnCount()-6).text()
					date_object = datetime.strptime(date_string, "%d-%m-%Y")
					startDate = QDate(date_object.year, date_object.month, date_object.day)

				elif isinstance(self.CMImportTable.cellWidget(row_index, self.CMImportTable.columnCount()-6).layout().itemAt(0).widget(), QLineEdit):
					lineEdit = self.CMImportTable.cellWidget(row_index, self.CMImportTable.columnCount()-6).layout().itemAt(0).widget()
					startDate_ = lineEdit.text()
					if startDate_ != '':
						startDate = QDate.fromString(startDate_, "dd-MM-yyyy")


				# Start Time
				if self.CMImportTable.item(row_index, self.CMImportTable.columnCount()-5):
					time_string = self.CMImportTable.item(row_index, self.CMImportTable.columnCount()-5).text()
					time_object = datetime.strptime(time_string, "%H:%M")
					startTime = QTime(time_object.hour, time_object.minute)

				elif isinstance(self.CMImportTable.cellWidget(row_index, self.CMImportTable.columnCount()-5), QLineEdit):
					lineEdit = self.CMImportTable.cellWidget(row_index, self.CMImportTable.columnCount()-5)
					startTime_ = lineEdit.text()
					if len(startTime_) == 5:
						startTime = QTime.fromString(time_string, "HH:mm")






				# End Date
				if self.CMImportTable.item(row_index, self.CMImportTable.columnCount()-4):
					date_string = self.CMImportTable.item(row_index, self.CMImportTable.columnCount()-4).text()
					date_object = datetime.strptime(date_string, "%d-%m-%Y")
					endDate = QDate(date_object.year, date_object.month, date_object.day)

				elif isinstance(self.CMImportTable.cellWidget(row_index, self.CMImportTable.columnCount()-4).layout().itemAt(0).widget(), QLineEdit):
					lineEdit = self.CMImportTable.cellWidget(row_index, self.CMImportTable.columnCount()-4).layout().itemAt(0).widget()
					endDate_ = lineEdit.text()
					if endDate_ != '':
						endDate = QDate.fromString(endDate_, "dd-MM-yyyy")
				

				# End Time
				if self.CMImportTable.item(row_index, self.CMImportTable.columnCount()-3):
					time_string = self.CMImportTable.item(row_index, self.CMImportTable.columnCount()-3).text()
					time_object = datetime.strptime(time_string, "%H:%M")
					endTime = QTime(time_object.hour, time_object.minute)

				elif isinstance(self.CMImportTable.cellWidget(row_index, self.CMImportTable.columnCount()-3), QLineEdit):
					lineEdit = self.CMImportTable.cellWidget(row_index, self.CMImportTable.columnCount()-3)
					startTime_ = lineEdit.text()
					if len(startTime_) == 5:
						endTime = QTime.fromString(time_string, "HH:mm")


				if startDate and startTime and endDate and endTime:
					startDateTime = QDateTime(startDate, startTime)
					endDateTime = QDateTime(endDate, endTime)

					difference_seconds = startDateTime.secsTo(endDateTime)
					minutes = int(difference_seconds/60)
					if minutes >= 0:
						self.CMImportTable.setItem(row_index, self.CMImportTable.columnCount()-2, QTableWidgetItem(str(minutes)))
					else:
						for colInd in [self.CMImportTable.columnCount()-4, self.CMImportTable.columnCount()-6]:
							calenderWidget = QWidget()
							calenderWidget.setStyleSheet('')
							layout = QHBoxLayout()
							calenderWidget.setLayout(layout)
							calenderWidget.setFixedWidth(140)
							layout.setSpacing(0)
							layout.setContentsMargins(0, 0, 0, 0)
							self.dateBox = QDateEdit()
							self.dateBox.setCalendarPopup(True)
							self.dateBox.setFixedHeight(24)
							self.dateBox.setFixedWidth(19)
							self.dateBox.setButtonSymbols(QDateEdit.NoButtons)
							

							self.dateBox.setStyleSheet("""
								QDateEdit {
								color: transparent;
								border: 1px solid transparent;
								border-radius: 0px;
								}
								QDateEdit:hover {
								border: 1px solid transparent;
								}
								QDateEdit::drop-down{
								border-bottom-right-radius: 1px;
								}
								QDateEdit::down-arrow{
								width: 24px;
								height: 24px;
								image: url('Media/calendar.png');
								}
								""")

							self.createLineEditBox('lineBoxInCalenderWidget')
							self.lineBoxInCalenderWidget.setReadOnly(True)
							self.lineBoxInCalenderWidget.setFixedHeight(24)
							self.lineBoxInCalenderWidget.setFixedWidth(110)
							self.lineBoxInCalenderWidget.setProperty("error", True)
							self.lineBoxInCalenderWidget.setStyleSheet(self.lineEditBoxQSS)
							layout.addWidget(self.lineBoxInCalenderWidget)
							layout.addWidget(self.dateBox)


							def dateChangedd(dateEdit, lineEdit):
								lineEdit.setText(str(dateEdit.date().toString("dd-MM-yyyy")))

							def dateEditFunctionInCell(dateEdit, lineEdit):

								dateEdit.dateChanged.connect(lambda: dateChangedd(dateEdit, lineEdit))

							dateEditFunctionInCell(self.dateBox, self.lineBoxInCalenderWidget)
							

							current_date_ = datetime.now()

							currentYear = current_date_.year
							currentMonth = current_date_.month
							firstDayOfCurrentMonth = datetime(currentYear, currentMonth, 1).date()
							lastDateOfPreviousMonth = (firstDayOfCurrentMonth - relativedelta(days=1))
							firstDateOfPreviousMonth = QDate(lastDateOfPreviousMonth.year, lastDateOfPreviousMonth.month, 1)

							six_months_ago = current_date_ - relativedelta(months=6)
							firstDateOfSixMonthsAgo_ = six_months_ago.replace(day=1)
							firstDateOfSixMonthsAgo = QDate(firstDateOfSixMonthsAgo_.year, firstDateOfSixMonthsAgo_.month, 1)

							if self.userRole == 1:
								self.dateBox.setMinimumDate(firstDateOfSixMonthsAgo)

							if self.userRole in [2, 3]:
								self.dateBox.setMinimumDate(firstDateOfPreviousMonth)
							

							if ((self.userName == 'Ravikumar') and (self.editableOptionMaxDate > datetime.now().date())):
								self.dateBox.setMinimumDate(QDate(self.startingYear, self.startingMonth, 1))



							# if self.userRole != 0:
							# 	self.dateBox.setMinimumDate(firstDateOfPreviousMonth)

							# if (self.userName == 'Ravikumar') and (self.editableOptionMaxDate > datetime.now().date()):
							# 	self.dateBox.setMinimumDate(QDate(self.startingYear, self.startingMonth, 1))


							item = self.CMImportTable.takeItem(row_index, colInd)
							del item
							self.CMImportTable.setCellWidget(row_index, colInd, calenderWidget)



						for colInd in [self.CMImportTable.columnCount()-3, self.CMImportTable.columnCount()-5]:
							TimeLineEdit = timeLineEdit()
							TimeLineEdit.setFixedHeight(28)
							TimeLineEdit.setFixedWidth(120)
							TimeLineEdit.setProperty("error", True)
							TimeLineEdit.setStyleSheet(self.lineEditBoxQSS)
							TimeLineEdit.setStyleSheet(self.lineEditBoxQSS)

							item = self.CMImportTable.takeItem(row_index, colInd)
							del item
							self.CMImportTable.setCellWidget(row_index, colInd, TimeLineEdit)


				for row in range(self.CMImportTable.rowCount()):
					for col in range(self.CMImportTable.columnCount()):
						item = self.CMImportTable.item(row, col)
						if item:
							item.setToolTip(item.text())

				

				self.createPushButton('minusButn', '', 'Media/delete.png', 35, 'Remove')
				self.minusButn.setStyleSheet(f'''{self.pushbuttonQSS} QPushButton {{ background: transparent; }}
														QPushButton:hover {{background: transparent;
															}}
															QPushButton:pressed {{
																background: transparent;
															}}''')
				self.minusButn.clicked.connect(self.onClickingRemoveButn)
				self.CMImportTable.setCellWidget(row_index, self.CMImportTable.columnCount()-1, self.minusButn)



					

			# if dataf_.iloc[:, 5].dtype == float:
			# 	# Convert float to integer
			# 	dataf_.iloc[:, 5] = dataf_.iloc[:, 5].astype(int)
			# 	# Convert integer to string
			# 	dataf_.iloc[:, 5] = dataf_.iloc[:, 5].astype(str)



			# column_data_types = dataf_.dtypes
			# print(column_data_types)
			# dataf_.iloc[:, 5] = dataf_.iloc[:, 5].astype(str)
			# column_data_types = dataf_.dtypes
			# print(column_data_types)

			widgetRowCount = 0

			for row in range(gridLayout.rowCount()):
				if gridLayout.itemAtPosition(row, 0) is not None:
					if gridLayout.itemAtPosition(row, 0).widget():
						widgetRowCount += 1

			diff = dataf.shape[0] - (widgetRowCount-1)

			def deleteRows(n):
				if gridLayout.itemAtPosition(n, gridLayout.columnCount()-1) is not None:
					if isinstance(gridLayout.itemAtPosition(n, gridLayout.columnCount()-1).widget(), QPushButton):
						gridLayout.itemAtPosition(n, gridLayout.columnCount()-1).widget().click()
				else:
					deleteRows(n+1)

			if diff > 0:
				self.progress_bar = QProgressBar()
				self.progress_bar.show()
				self.progress_bar.setMaximum(diff)
				for i in range(diff):
					plusBtn.click()
					self.progress_bar.setValue(i)
					QApplication.processEvents()
			elif diff < 0:
				for i in range(0-diff):
					deleteRows(i)


			widgetsRowsList = []
			for i in range(gridLayout.rowCount()):
				if gridLayout.itemAtPosition(i, 0):
					if gridLayout.itemAtPosition(i, 0).widget():
						if isinstance(gridLayout.itemAtPosition(i, 0).widget(), CustomDateEdit):
							widgetsRowsList.append(i)

			for row, inde in enumerate(widgetsRowsList):
				for column in range(gridLayout.columnCount()-2):
					item = gridLayout.itemAtPosition(inde, column)
					if (item is not None) and (item.widget() is not None):
						widget = item.widget()
						value = dataf_.iloc[row-1, column]
						if isinstance(widget, QLineEdit):
							if not pd.isna(value):
								try:
									if pd.api.types.is_float_dtype(dataf_.iloc[row-1, column]):
										int_value = int(dataf_.iloc[row-1, column])
										string_value = str(int_value)
										widget.setText(string_value)
										widget.setToolTip(str(string_value))

									else:
										widget.setText(str(value))
										widget.setToolTip(str(value))
								except:
									pass
						
						elif isinstance(widget, QComboBox):
							if not pd.isna(value):
								try:
									items = [widget.itemText(index).lower() for index in range(widget.count())]
									widget.setCurrentIndex(-1)
									for v, item in enumerate(items):
										if value.lower() == item:
											widget.setCurrentIndex(v)
								except:
									pass
						
						elif isinstance(widget, QSpinBox):
							if not pd.isna(value):
								try:
									widget.setMaximum(100000000)
									widget.setValue(int(value))
								except:
									pass
						
						elif isinstance(widget, CustomDateEdit):
							if not pd.isna(value):
								try:
									date_time = QDateTime.fromString(str(value), Qt.ISODate)
									widget.setDate(date_time.date())
								except:
									pass
						
						elif isinstance(widget, CustomTimeEdit):
							if not pd.isna(value):
								try:
									formatted_value = value.strftime("%H:%M")
									widget.setTime(QTime.fromString(str(formatted_value), "hh:mm"))
								except:
									pass
						
						elif isinstance(widget, QLabel):
							if not pd.isna(value):
								try:
									widget.setText(str(value))
									widget.setAlignment(Qt.AlignCenter)
								except:
									pass
						
						elif isinstance(widget, QDateTimeEdit):
							if not pd.isna(value):
								try:
									date_and_time = QDateTime.fromString(str(value), Qt.ISODate)
									widget.setDateTime(date_and_time)
								except:
									pass
									
			

		self.submitImportedExcelData.clicked.connect(mapData)


		self.createPushButton('cancelImportedExcelData', 'CANCEL', width=int(0.050 * QApplication.primaryScreen().availableGeometry().width()))
		self.cancelImportedExcelData.setFixedHeight(30)
		self.cancelImportedExcelData.clicked.connect(lambda: self.excelAndTableColumnsMappingWindow.close())


		submitAndCancelBtnOfExcelImportWindow = QHBoxLayout()
		submitAndCancelBtnOfExcelImportWindow.addWidget(self.submitImportedExcelData, alignment=Qt.AlignRight)
		submitAndCancelBtnOfExcelImportWindow.addWidget(self.cancelImportedExcelData, alignment=Qt.AlignLeft)


		VLayoutForColumnsMappingWindow.addLayout(submitAndCancelBtnOfExcelImportWindow)


		self.excelAndTableColumnsMappingWindow.setLayout(VLayoutForColumnsMappingWindow)

		
		self.excelAndTableColumnsMappingWindow.show()

	else:
		pass

def onClickingRemoveButn(self):
	button = self.sender()
	if button:
		index = self.CMImportTable.indexAt(button.pos())
		if index.isValid():
			row = index.row()
			self.CMImportTable.setCurrentCell(row, self.CMImportTable.columnCount()-2)
			self.CMImportTable.removeRow(row)


def onClickingRemoveButn_OPM(self):
	button = self.sender()
	if button:
		index = self.OPMImportTable.indexAt(button.pos())
		if index.isValid():
			row = index.row()
			self.OPMImportTable.setCurrentCell(row, self.OPMImportTable.columnCount()-2)
			self.OPMImportTable.removeRow(row)


####################################################################################################
## Function to create a pdf report with headers and footers:
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import letter,landscape, portrait, A4
from reportlab.platypus import SimpleDocTemplate, Paragraph, Table, LongTable, PageTemplate, TableStyle, Frame, KeepInFrame, Spacer, PageBreak, BaseDocTemplate
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib import colors, pdfencrypt
from reportlab.lib.enums import TA_CENTER, TA_LEFT
from reportlab.lib.units import inch, cm
from reportlab.graphics.shapes import Drawing, Rect
from reportlab.pdfgen.canvas import Canvas
from reportlab.platypus.flowables import Image
from reportlab.graphics import shapes
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

# Register the TrueType font
pdfmetrics.registerFont(TTFont('RobotoFont', 'Roboto-Regular.ttf'))
pdfmetrics.registerFont(TTFont('Roboto_Italics_Font', 'Roboto-Italic.ttf'))

def reportHeaderSection_Landscape(c, report_title):
	
	c.setFont('RobotoFont', 18)

	# c.setFillColor(colors.HexColor('#003366'))
	# width, height = letter
	# c.drawCentredString(420 , 550, report_title)  # Centered header text
	# c.drawCentredString(width/2 , 530, report_title)  # Centered header text
	# print(width/2)
	# BEML Logo at the left end of header part:
	beml_logo_path = 'Media/BEML.png'
	beml_logo_width = 120
	beml_logo_height = 45
	c.drawInlineImage(beml_logo_path, 30, 530, width=beml_logo_width, height=beml_logo_height)

	# DMRC logo at the center of the header
	dmrc_logo_path = 'Media/dmrc.jpg'
	dmrc_logo_width = 90
	dmrc_logo_height = 50
	dmrc_logo_x = (A4[1] - dmrc_logo_width) / 2  # Calculate X-coordinate for the center logo
	c.drawInlineImage(dmrc_logo_path, dmrc_logo_x, 530, width=dmrc_logo_width, height=dmrc_logo_height)

	# MMRC Logo at the right end of header part:
	mmrc_logo_path = 'Media/MMRC.png'
	mmrc_logo_width = 120
	mmrc_logo_height = 65
	mmrc_logo_x = A4[1] - 30 - mmrc_logo_width  # Calculate X-coordinate for the right logo
	c.drawInlineImage(mmrc_logo_path, mmrc_logo_x, 520, width=mmrc_logo_width, height=mmrc_logo_height)

	# Set the line thickness to reduce the thickness
	c.setLineWidth(0.3)  # Adjust this value as needed

	# Draw a horizontal line below the header
	lineBelowTheHeader = 525  # Adjust the Y-coordinate based on your layout
	c.line(20, lineBelowTheHeader, A4[1] - 20, lineBelowTheHeader)




def reportFooterSection_Landscape(c):
	# Draw a horizontal line above the footer:
	lineAboveTheFooter = 65  # Adjust the Y-coordinate based on your layout
	c.line(20, lineAboveTheFooter, A4[1] - 20, lineAboveTheFooter)

	# BEA Logo at the left end of footer part:
	bea_logo_path = 'Media/ramsify3.png'
	bea_logo_width = 150
	bea_logo_height = 40
	c.drawInlineImage(bea_logo_path, 30, 20, width=bea_logo_width, height=bea_logo_height)

	# Common Footer
	c.setFont('Helvetica-Oblique', 8)

	# Display the current date and time
	current_datetime = datetime.now().strftime('%d-%b-%y %H:%M')
	c.drawRightString(A4[1] - 20, 40, f'Report Generated on: {current_datetime}')

	# Display the page number
	c.drawRightString(A4[1] - 20, 25, 'Page %d' % c.getPageNumber())



################################################################################################################

def reportHeaderSection_Portrait(c, report_title):

	
	c.setFont('RobotoFont', 16)

	# c.setFillColor(colors.HexColor('#003366'))

	# c.drawCentredString(A4[0] / 1.8 , A4[1] - 50, report_title)  # Centered header text

	# BEML Logo at the left end of header part:
	beml_logo_path = 'Media/BEML.png'
	beml_logo_width = 120
	beml_logo_height = 45
	c.drawInlineImage(beml_logo_path, 20, A4[1] - 70, width=beml_logo_width, height=beml_logo_height)

	#dmrc logo at the center of the header
	dmrc_logo_path = 'Media/dmrc.jpg'
	dmrc_logo_width = 90
	dmrc_logo_height = 50
	dmrc_logo_x = (A4[0] - dmrc_logo_width) / 2  # Calculate X-coordinate for the center logo
	c.drawInlineImage(dmrc_logo_path, dmrc_logo_x, A4[1] - 70, width=dmrc_logo_width, height=dmrc_logo_height)


	# MMRC Logo at the right end of header part:
	mmrc_logo_path = 'Media/MMRC.png'
	mmrc_logo_width = 120
	mmrc_logo_height = 65
	mmrc_logo_x = A4[0] - 18 - mmrc_logo_width  # Calculate X-coordinate for the right logo
	c.drawInlineImage(mmrc_logo_path, mmrc_logo_x, A4[1] - 85, width=mmrc_logo_width, height=mmrc_logo_height)

	# Set the line thickness to reduce the thickness
	c.setLineWidth(0.3)  # Adjust this value as needed

	# Draw a horizontal line below the header
	lineBelowTheHeader = A4[1] - 80  # Adjust the Y-coordinate based on your layout
	c.line(20, lineBelowTheHeader, A4[0] - 20, lineBelowTheHeader)


def reportFooterSection_Portrait(c):
	# Draw a horizontal line above the footer:
	lineAboveTheFooter = 65  # Adjust the Y-coordinate based on your layout
	c.line(20, lineAboveTheFooter, A4[0] - 20, lineAboveTheFooter)

	# BEA Logo at the left end of footer part:
	bea_logo_path = 'Media/ramsify3.png'
	bea_logo_width = 150
	bea_logo_height = 40
	c.drawInlineImage(bea_logo_path, 30, 20, width=bea_logo_width, height=bea_logo_height)

	# Common Footer
	c.setFont('Helvetica-Oblique', 8)

	# Display the current date and time
	current_datetime = datetime.now().strftime('%d-%b-%y %H:%M')
	c.drawRightString(A4[0] - 20, 40, f'Report Generated on: {current_datetime}')

	# Display the page number
	c.drawRightString(A4[0] - 20, 25, 'Page %d' % c.getPageNumber())



def generate_pdf_report(self, report_title, report_data, table_names, orientation, chart_images,  boldCells = None):
	file_path, _ = QFileDialog.getSaveFileName(None, "Save Report", "", "Pdf Files (*.pdf)")

	if file_path:
		
		styles = getSampleStyleSheet()

		if orientation == 0:
			pagesize = A4
		elif orientation == 1:
			pagesize = landscape(A4)

		report_title_style = ParagraphStyle(
			'TitleStyle',
			fontName='RobotoFont',
			fontSize=16,
			leading=18,
			textColor='#ffffff',
			alignment=TA_CENTER,
			backColor='#44546a',
			# borderColor='#000000',
			borderPadding=(7, 0, 8),
			# borderRadius=20,
			borderWidth=0.5,
		)

		
		report_label_style = ParagraphStyle(
			'Heading1',
			fontName='Times-BoldItalic',
			fontSize=14,
			# leading=18,
			textColor='#003366',
			# alignment=TA_LEFT,
			spaceBefore=15,
		)

		notes_style = ParagraphStyle(
			'NotesStyle',
			fontName='Times-Italic',
			fontSize=13,
			textColor='#333333',
			spaceBefore=20,
			spaceAfter=20,
			borderPadding=7,
			borderColor='#000000',
			borderWidth=0.3,
		)

		

		def my_first_page(canvas, doc):
			_header_footer(canvas, report_title, orientation)

		def my_later_pages(canvas, doc):
			_header_footer(canvas, report_title, orientation)

		def _header_footer(canvas, report_title, orientation):
			
			if orientation == 0:
				reportHeaderSection_Portrait(canvas, report_title)
				reportFooterSection_Portrait(canvas)

			elif orientation == 1:
				reportHeaderSection_Landscape(canvas, report_title)
				reportFooterSection_Landscape(canvas)

		page_template = PageTemplate(id='AllPages', frames=[Frame(20, 70, pagesize[0] - 40, pagesize[1] - 170, showBoundary=0)], onPage=my_first_page)

		doc = BaseDocTemplate(file_path, pagesize=pagesize)
		doc.addPageTemplates([page_template, page_template])

		elements = []

		y_coordinate = A4[1] - 110
		line_height = 14

		# Extract report title from the report_data list
		report_header_title = report_data[0]

		# Add the title as a paragraph
		title_paragraph = Paragraph(report_header_title, style=report_title_style)
		title_paragraph.wrap(A4[0] - 30, line_height)  ## This was 50
		elements.append(title_paragraph)

		# Adjust the starting y_coordinate accordingly to maintain proper vertical spacing.
		y_coordinate -= title_paragraph.height + line_height

		frame_height = y_coordinate - 20
		y_coordinate -= 20
		frame_width = A4[0] - 60

		if len(report_data) > 2:
			iterr = 0
			for table_list, table_name in zip(report_data[1:], table_names):
				# Add the table name above the table
				report_table_style = TableStyle([
						('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#669999')),
						('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
						('ALIGN', (0, 0), (-1, -1), 'CENTER'),
						('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
						('ALIGN', (0, 1), (0, -1), 'LEFT'),
						('FONT', (0, 0), (-1, -1), 'RobotoFont', 9),
						('GRID', (0, 0), (-1, -1), 0.5, colors.black),
						('REPEATROWS', (0, 0), (-1, -1), 1)
					])

				for row_index, row_list in enumerate(table_list[1:]):  # Access the inner list

					for col_index, cell_value in enumerate(row_list):
						if isinstance(cell_value, str) and cell_value.lower() == 'pass' or cell_value.lower() =='achieved':
							# print(row_index, col_index, cell_value)
							report_table_style.add('BACKGROUND', (col_index,  row_index+1), (col_index, row_index+1), colors.HexColor('#00cc00'))
						elif isinstance(cell_value, str) and cell_value.lower() == 'fail' or cell_value.lower() == 'not achieved':
							# print(row_index, col_index, cell_value)
							report_table_style.add('BACKGROUND', (col_index, row_index+1), (col_index, row_index+1), colors.HexColor('#ff3333'))

				if boldCells:
					for ind in boldCells:
						report_table_style.add('FONTNAME', (0, ind+1), (0, ind+1), 'Roboto-Bold')


				table = Table(table_list, repeatRows=1)
				table.setStyle(report_table_style)
				table_width, table_height = table.wrap(0, 0)
				if iterr:
					if y_coordinate < 260 + table_height:
						elements.append(PageBreak())
						y_coordinate = A4[1] - 110

				table_name_paragraph = Paragraph(table_name, style = report_label_style)
				elements.append(table_name_paragraph)


				spacer = Spacer(1, 7)
				elements.extend([spacer, table])
				y_coordinate -= table_height + 5
				iterr += 1

		else:
			[report_data] = report_data[1:]
			report_table_style = TableStyle([
						('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#669999')),
						('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
						('ALIGN', (0, 0), (-1, -1), 'CENTER'),
						('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
						('ALIGN', (0, 1), (0, -1), 'LEFT'),
						('FONT', (0, 0), (-1, -1), 'RobotoFont', 9),
						('GRID', (0, 0), (-1, -1), 0.5, colors.black),
						('REPEATROWS', (0, 0), (-1, -1), 1)
					])
			for row_index, row_list in enumerate(report_data):
				for col_index, cell_value in enumerate(row_list):
					

					if isinstance(cell_value, str) and cell_value.lower() == 'pass' or cell_value.lower() =='achieved':
					
						report_table_style.add('BACKGROUND', (col_index, row_index), (col_index, row_index), colors.HexColor('#00cc00'))
					elif isinstance(cell_value, str) and cell_value.lower() == 'fail' or cell_value.lower() == 'not achieved':
						report_table_style.add('BACKGROUND', (col_index, row_index), (col_index, row_index), colors.HexColor('#ff3333'))


			if boldCells:
				for ind in boldCells:
					report_table_style.add('FONTNAME', (0, ind+1), (0, ind+1), 'Roboto-Bold')
					report_table_style.add('FONT', (0, ind+1), (0, ind+1), 'Roboto-Bold', 10)



			table = Table(report_data, repeatRows=1)
			table.setStyle(report_table_style)
			spacer = Spacer(1, 7)
			elements.extend([Paragraph(table_names[0], style = report_label_style), spacer, table])


		import tempfile

		elements.append(Spacer(1, 0.1*inch))

		# # Assuming you have a list of QImage object
		for chart_image in chart_images:
			# Save QImage to a temporary file
			temp_file_path = tempfile.mktemp(suffix=".png")
			chart_image.save(temp_file_path, "PNG", quality=100)  # Ensure the format and quality are specified

			# Create Image object from the temporary file with desired dimensions
			report_image = Image(temp_file_path, width=7*inch, height=5*inch)

			elements.append(Spacer(1, 0.5*inch))

			# Append the Image object to the elements list
			elements.append(report_image)




		elements.append(Spacer(1, 0.2*inch))

		# draw your shapes and add to the platypus doc which is letter 8.5x11 inch
		x = 0  # Starting from the left edge of the page
		y = 0  # Starting from the bottom edge of the page
		height = 4 * inch  # Increased height

		if orientation == 0:
			# For portrait orientation:
			width = A4[0] - 0.5 * inch  # Width of A4 minus 0.5 inches margin on each side
			x_translate = (A4[0] - width) / 2 - 0.35 * inch  # Adjust as needed
		elif orientation == 1:
			# For landscape orientation:
			width = A4[1] - 2 * inch  # Width of A4 minus 2 inches margin on each side
			x_translate = (A4[1] - width) / 2 - 0.35 * inch  # Adjust as needed

		# Create drawing with rectangle
		d = shapes.Drawing(width, height)
		r = shapes.Rect(x, y, width, height, fillColor=colors.white, strokeColor=colors.black, strokeWidth=0.5) 
		d.add(r)

		# Add 'Note:' text to the top-left corner of the rectangle
		note_text = shapes.String(0.1 * inch, height - 0.3 * inch, "Note:", fontSize=12, fillColor=colors.black)
		d.add(note_text)

		# Move the drawing to the desired position on the page
		d.translate(x_translate, y)

		elements.append(d)

		# Finally, add the report notes at the end
		# report_notes = ''
		# notes_paragraph = Paragraph(f"<b>Notes:</b> {report_notes}", style=notes_style)
		# # notes_paragraph = Paragraph(f"{report_notes}", style=notes_style)
		# elements.append(Spacer(1, 12))
		# elements.append(notes_paragraph)


		# Add a spacer
		# elements.append(Spacer(1, 0.1*inch))

		# # draw your shapes and add to the platypus doc which is letter 8.5x11 inch
		# x = 0  # Starting from the left edge of the page
		# y = 0  # Starting from the bottom edge of the page
		# width = A4[0] - 1 * inch  # Width of A4 minus 2 inches margin on each side
		# height = 2 * inch  # Increased height

		# d = shapes.Drawing(width, height)
		# r = shapes.Rect(x, y, width, height, fillColor=colors.white, strokeColor=colors.black, strokeWidth=0.5) 
		# d.add(r)

		# # Calculate the x-coordinate for aligning with the right edge of the page
		# # x_translate = A4[0] - width - 0.5 # A4 width - rectangle width - 1 inch margin
		# x_translate = (A4[0] - width) / 2  # Half of the page width minus half of the rectangle width
		
		# # # Add 'Note:' text to the top-left corner of the rectangle
		# note_text = shapes.String(0.1 * inch, height - 0.3 * inch, "Note:", fontSize=12, fillColor=colors.black)
		# d.add(note_text)

		# # Move the drawing to the desired position on the page
		# d.translate(x_translate, y)

		# elements.append(d)



		# report_image2 = Image('C:\\Users\\fraca\\Desktop\\notes.png', width=7*inch, height=2*inch)

		# elements.append(Spacer(1, 0.5*inch))

		# # Append the Image object to the elements list
		# elements.append(report_image2)




		# Add the box Drawing object to the elements list
		# elements.append(box_drawing)


		doc.build(elements)

		reportMsgBox = QMessageBox()
		reportMsgBox.setIcon(QMessageBox.Information) 
		reportMsgBox.setText('Report Generated Successfully')
		reportMsgBox.setWindowTitle("Message")
		reportMsgBox.setWindowIcon(QIcon('Media/ramsify.png'))
		reportMsgBox.setStandardButtons(QMessageBox.Ok)
		reportMsgBox.exec_()

########################################################################################


def showContextMenu(self, pos):
	chart_view = self.sender()
	if chart_view:
		contextMenu = QMenu(chart_view)
		saveAsMenu = contextMenu.addMenu("Save As")
		saveAsActs = []
		for format_ in ['PNG', 'JPG', 'JPEG']:
			saveAsActs.append(saveAsMenu.addAction(format_))

		action = contextMenu.exec_(chart_view.mapToGlobal(pos))
		if action in saveAsActs:
			file_choices = "." + action.text().lower() + " (*." + action.text().lower() + ")"

			chart_size = chart_view.size()
			self.sizeWidget = QDialog()
			self.sizeWidgetLayout = QFormLayout()

			self.createSpinBox('widthSpinBox', chart_size.width(), 1, 50, 5000)
			self.widthSpinBox.setFixedWidth(140)

			self.createSpinBox('heightSpinBox', chart_size.height(), 1, 50, 5000)
			self.heightSpinBox.setFixedWidth(140)

			self.sizeWidgetLayout.addRow(QLabel('Width: '), self.widthSpinBox)
			self.sizeWidgetLayout.addRow(QLabel('Height: '), self.heightSpinBox)

			layoutForOKandCancelButtons_chartSizeWindow = QHBoxLayout()
			self.createPushButton('okButton_chartSizeSelectionWindow', 'OK')
			self.okButton_chartSizeSelectionWindow.setFixedWidth(70)
			self.createPushButton('cancelButton_chartSizeSelectionWindow', 'Cancel')
			self.cancelButton_chartSizeSelectionWindow.setFixedWidth(70)

			layoutForOKandCancelButtons_chartSizeWindow.addWidget(self.okButton_chartSizeSelectionWindow)
			layoutForOKandCancelButtons_chartSizeWindow.addWidget(self.cancelButton_chartSizeSelectionWindow)
			self.sizeWidgetLayout.addRow(QLabel(''),layoutForOKandCancelButtons_chartSizeWindow)

			self.sizeWidget.setLayout(self.sizeWidgetLayout)
			#self.sizeWidget.resize(250,100)
			self.sizeWidget.setWindowTitle('Select Dimensions')
			self.sizeWidget.setWindowIcon(QIcon('Media/ramsify.png'))
			self.sizeWidget.show()


			def onOkButtonClicked_chartSizeWindow():
				self.sizeWidget.close()
				dlg = QFileDialog()
				dlg.setWindowTitle("Save the chart as:")
				dlg.setFileMode(QFileDialog.AnyFile)
				dlg.setAcceptMode(QFileDialog.AcceptSave)
				dlg.setNameFilter(file_choices)
				dlg.exec_()
				if dlg.selectedFiles():
					file_path = dlg.selectedFiles()[0]
					file_format = file_path.split(".")[-1]

					chart_size = QSize(self.widthSpinBox.value(), self.heightSpinBox.value())
					pixmap = QPixmap(chart_size)
					pixmap.fill(Qt.white)
					painter = QPainter(pixmap)
					chart_view.render(painter)
					painter.end()
					pixmap.save(file_path, file_format)

					msg = QMessageBox()
					msg.setIcon(QMessageBox.Information)
					msg.setText("Graph Saved Successfully")
					msg.setWindowTitle("Message")
					msg.setWindowIcon(QIcon('Media/ramsify.png'))
					msg.exec_()
			
			def onCancelButtonClicked_chartSizeWindow():
				self.sizeWidget.close()


			self.okButton_chartSizeSelectionWindow.clicked.connect(onOkButtonClicked_chartSizeWindow)
			self.cancelButton_chartSizeSelectionWindow.clicked.connect(onCancelButtonClicked_chartSizeWindow)



def createStackedBarChart(self, x, data, title, x_label, y_label, legends):
	# Create custom stacked bar series
	series = QStackedBarSeries()

	#maxValuesOfYLists = []
	#Loop through data and add bar sets
	for i, y in enumerate(data):

		if i != len(data) - 1:
			bar_set = QBarSet(str(legends[i]))
			bar_set.setLabelColor(Qt.black)
			bar_set.setLabelFont(QFont("Roboto", 10))
			#maxValuesOfYLists.append(max(data[i]))
		else:
			bar_set = QBarSet('')
			bar_set.setColor(Qt.transparent)
			bar_set.setLabelColor(Qt.black)
			bar_set.setLabelFont(QFont("Roboto", 10, QFont.Bold))



		bar_set.append(y)
		series.append(bar_set)


	series.setLabelsVisible(True)
	series.setLabelsPosition(QStackedBarSeries.LabelsInsideBase)

	# Create chart and set series
	chart = QChart()
	backgroundColorOfCharts = self.currentTheme.get('chartBackGroundColor')
	chart.setBackgroundBrush(QBrush(QColor(backgroundColorOfCharts)))
	chart.addSeries(series)
	#chart.setAnimationOptions(QChart.SeriesAnimations)


	##To customize chart title color and font:
	chart.setTitle(title)
	titleFont = QFont("Roboto", 16, QFont.Bold)
	chart.setTitleFont(titleFont)
	titleBrush = QBrush(Qt.red)
	chart.setTitleBrush(titleBrush)

	## Get the legend markers for the series
	legend_markers = chart.legend().markers(series)
	legend_markers[len(data)-1].setVisible(False)  # Hide the third legend


	# Create X axis and set categories
	axis_x = QBarCategoryAxis()
	axis_x.append(x)
	if len(x) > 6:
		axis_x.setLabelsAngle(90)
	else:
		pass
	chart.addAxis(axis_x, Qt.AlignBottom)
	series.attachAxis(axis_x)

	# Create Y axis
	axis_y = CustomValueAxis()
	chart.addAxis(axis_y, Qt.AlignLeft)
	axis_y.setRange(0, max(data[-1])*1.1)
	#axis_y.setLabelFormat("%i")
	#axis_y.setLabelFormat("%0.f")
	series.attachAxis(axis_y)



	# Create chart view
	chart_view = QChartView(chart)
	backgroundColorOfCharts = self.currentTheme.get('chartBackGroundColor')
	chart_view.setStyleSheet(f'background-color: {backgroundColorOfCharts}; border-radius: 30px;')
	chart_view.setRenderHint(QPainter.Antialiasing)


	# Set axis labels
	axisLabelFont = QFont("Roboto", 12, QFont.Bold)

	axis_x.setTitleText(x_label)
	axis_x.setTitleFont(axisLabelFont)
	axis_y.setTitleText(y_label)
	axis_y.setTitleFont(axisLabelFont)

	# Set font for the legend
	chart.legend().setFont(axisLabelFont)


	chart_view.setContextMenuPolicy(Qt.CustomContextMenu)
	chart_view.customContextMenuRequested.connect(self.showContextMenu)

	return chart_view


def createPieChart(self, data, title):

	def hover_slice(bool, slice):
		if bool:
			slice.setExploded(True)
			slice.setLabelVisible(True)
		else:
			slice.setExploded(False)
			slice.setLabelVisible(True)
	

	# Create a QPieSeries object
	series = QPieSeries()
	labels = list(data.keys())
	# series.setHoleSize(0.35)
	for label, value in data.items():
		if isinstance(value, list):
			value = value[0]
		slice = QPieSlice(label, value)
		slice.setLabel("{} ({})".format(label, value))
		slice.setLabelColor(Qt.black)
		slice.setLabelVisible(True)
		slice.setLabelPosition(QPieSlice.LabelOutside)

		font = QFont("Roboto", 12, QFont.Bold)
		slice.setLabelFont(font)
		slice.hovered.connect(lambda bool, slice=slice: hover_slice(bool, slice))
		series.append(slice)

		
	# Create a QChart object and add the series to it
	chart = QChart()
	backgroundColorOfCharts = self.currentTheme.get('chartBackGroundColor')
	chart.setBackgroundBrush(QBrush(QColor(backgroundColorOfCharts)))
	chart.addSeries(series)
	chart.setTitle(title)
	chart.legend().setVisible(True)
	chart.legend().setAlignment(Qt.AlignBottom)


	##To customize chart title color and font:
	titleFont = QFont("Roboto", 16, QFont.Bold)
	chart.setTitleFont(titleFont)
	titleBrush = QBrush(Qt.red)
	chart.setTitleBrush(titleBrush)


	axisLabelFont = QFont("Roboto", 12, QFont.Bold)
	
	chart.legend().setFont(axisLabelFont)
	# Set legend to display only labels
	for index, label in enumerate(labels):
		chart.legend().markers(series)[index].setLabel(label)

	
	# Create a QChartView object to display the chart
	pie_chartView = QChartView(chart)
	backgroundColorOfCharts = self.currentTheme.get('chartBackGroundColor')
	pie_chartView.setStyleSheet(f'background-color: {backgroundColorOfCharts}; border-radius: 30px;')
	pie_chartView.setRenderHint(QPainter.Antialiasing)

	pie_chartView.setContextMenuPolicy(Qt.CustomContextMenu)
	pie_chartView.customContextMenuRequested.connect(self.showContextMenu)

	
	return pie_chartView

def createLineChart(self, xLabelsList, yValuesList,  listOflegends, colorsForLines, lineTypeList,  titleOfPlot, xAxisName, yAxisName, widthOfLine = 3):
	
	# Create the line chart
	chart = QChart()
	backgroundColorOfCharts = self.currentTheme.get('chartBackGroundColor')
	chart.setBackgroundBrush(QBrush(QColor(backgroundColorOfCharts)))

	# Set the title of the chart
	chart.setTitle(titleOfPlot)

	titleFont = QFont("Roboto", 16, QFont.Bold)
	chart.setTitleFont(titleFont)
	titleBrush = QBrush(Qt.red)
	chart.setTitleBrush(titleBrush)


	font = QFont()
	font.setPointSize(12)

	axisLabelFont = QFont("Roboto", 12, QFont.Bold)

	# Create the x-axis
	axis_x = QCategoryAxis()
	axis_x.setLabelsVisible(True)
	axis_x.setTitleText(xAxisName)
	axis_x.setTitleFont(axisLabelFont)
	axis_x.setGridLineVisible(True)
	axis_x.setLabelsPosition(QCategoryAxis.AxisLabelsPositionOnValue)
	chart.addAxis(axis_x, Qt.AlignBottom)
	if len(xLabelsList) > 6:
		axis_x.setLabelsAngle(90)
	else:
		pass



	# Create the y-axis
	axis_y = QValueAxis()
	axis_y.setLabelsVisible(True)
	axis_y.setTitleText(yAxisName)
	axis_y.setTitleFont(axisLabelFont)
	axis_y.setGridLineVisible(True)
	axis_y.setTickCount(11)
	chart.addAxis(axis_y, Qt.AlignLeft)


	# Create scatter points series to show the value points:
	scatterSeries = QScatterSeries()
	scatterSeries.setMarkerSize(8)


	scatterSeriesForStraightLines = QScatterSeries()
	scatterSeriesForStraightLines.setMarkerSize(0)


	x_min = -0.2
	x_max = len(xLabelsList) -1 - x_min

	axis_x.setRange(x_min, x_max)

	allYValues = []
	for yValues in yValuesList:
		for y in yValues:
			try:
				allYValues.append(float(y))
			except ValueError:
				pass  # Skip non-numeric values


	min_y = min(allYValues)
	max_y = max(allYValues)

	# Adjust the range of the y-axis
	axis_y.setRange(min_y*0.9 , max_y * 1.1)
	# axis_y.setRange(0 , max_y * 1.1)


	# Create and add line series to the chart
	for i, yValues in enumerate(yValuesList):
		series = QLineSeries()
		series.setName(listOflegends[i])
		series.setPen(QPen(QColor(colorsForLines[i]), widthOfLine, lineTypeList[i]))

		
		if len(yValues) == 1:
			# Add a horizontal line for a single value
			singleValue = yValues[0]
			if singleValue != 'NA':
				singleValue = float(singleValue)
			else:
				singleValue = 0
			series.append(0, singleValue)
			series.append(len(xLabelsList) - 1, float(singleValue))
			scatterSeriesForStraightLines.append(0.0, float(singleValue))
			scatterSeriesForStraightLines.setPointLabelsVisible(True)
			#scatterSeriesForStraightLines.setPointLabelsColor(QColor('#000000'))
			scatterSeriesForStraightLines.setPointLabelsFont(font)
			scatterSeriesForStraightLines.setPointLabelsFormat("@yPoint")
			
		else:  
			# Add data points to the line series and scatter series
			for j, y in enumerate(yValues):
				try:
					series.append(j, float(y))
					scatterSeries.append(j, float(y))
				except ValueError:
					series.append(j, 0.0)
					scatterSeries.append(j, 0.0)

				
				series.setPointLabelsVisible(True)
				#series.setPointLabelsColor(QColor('#000000'))
				series.setPointLabelsFont(font)
				series.setPointLabelsFormat("@yPoint")


		### Add the series to the chart
		chart.addSeries(series)
		series.attachAxis(axis_x)
		series.attachAxis(axis_y)

	# Add x-labels to the x-axis
	for index, label in enumerate(xLabelsList):
		axis_x.append(label, index)

	
	# Add scatter series to the chart
	chart.addSeries(scatterSeries)
	scatterSeries.attachAxis(axis_x)
	scatterSeries.attachAxis(axis_y)

	chart.addSeries(scatterSeriesForStraightLines)
	scatterSeriesForStraightLines.attachAxis(axis_x)
	scatterSeriesForStraightLines.attachAxis(axis_y)

	## To hide the scatterpoint from the legend:
	legend_markers = chart.legend().markers(scatterSeriesForStraightLines)
	legend_markers2 = chart.legend().markers(scatterSeries)
	legend_markers[0].setVisible(False)
	legend_markers2[0].setVisible(False)


	chart.legend().setFont(axisLabelFont)


	# Create the chart view and set the chart
	chart_view = QChartView(chart)
	backgroundColorOfCharts = self.currentTheme.get('chartBackGroundColor')
	chart_view.setStyleSheet(f'background-color: {backgroundColorOfCharts}; border-radius: 30px;')
	chart_view.setRenderHint(QPainter.Antialiasing)

	chart_view.setContextMenuPolicy(Qt.CustomContextMenu)
	chart_view.customContextMenuRequested.connect(self.showContextMenu)

	def show_tooltip(point, series, chart_view):
		if not series:
			return

		pos = series.chart().mapToPosition(point)
		pos = series.chart().mapToScene(pos.toPoint())
		pos = chart_view.mapToGlobal(pos.toPoint())
		QToolTip.showText(pos, f"{point.y()}")

	scatterSeries.hovered.connect(lambda point, state: show_tooltip(point, scatterSeries, chart_view))

	return chart_view


def createBarChart(self, xLabels, yValues, title, xAxisName, yAxisName, legends):

	chart = QChart()
	backgroundColorOfCharts = self.currentTheme.get('chartBackGroundColor')
	chart.setBackgroundBrush(QBrush(QColor(backgroundColorOfCharts)))

	series = QBarSeries()
	maxOfYValues = []
	for i in range(len(yValues)):
		barSet = QBarSet(legends[i])
		font = QFont("Roboto", 10)
		barSet.setLabelFont(font)
		barSet.append(yValues[i])
		series.append(barSet)
		barSet.setLabelColor(QColor('#000000'))
		maxOfYValues.append(max(yValues[i]))


	maxYValue = max(maxOfYValues)

	chart.addSeries(series)
	series.setLabelsVisible(True)
	series.setLabelsPosition(QAbstractBarSeries.LabelsOutsideEnd)

	xAxis = QBarCategoryAxis()
	xAxis.append(xLabels)
	if len(xLabels) > 6:
 		xAxis.setLabelsAngle(90)
	else:
		pass


	axisLabelFont = QFont("Roboto", 12, QFont.Bold)

	#xAxis.setReverse(False)
	chart.addAxis(xAxis, Qt.AlignBottom)
	series.attachAxis(xAxis)
	xAxis.setTitleText(xAxisName)
	xAxis.setTitleFont(axisLabelFont)
	

	yAxis = QValueAxis()
	chart.addAxis(yAxis, Qt.AlignLeft)
	series.attachAxis(yAxis)
	yAxis.setTitleText(yAxisName)
	yAxis.setTitleFont(axisLabelFont)
	# yAxis.setMax(maxYValue * 1.1)


	# Set a minimum range for the y-axis to ensure zero is always visible
	yAxis.setRange(0, maxYValue * 1.1)

	# Set Roboto font for x-axis and y-axis labels
	# axisValuesFont = QFont("Roboto", 10)
	# xAxis.setLabelsFont(axisValuesFont)
	# yAxis.setLabelsFont(axisValuesFont)


	chart.setTitle(title)
	titleFont = QFont("Roboto", 16, QFont.Bold)
	chart.setTitleFont(titleFont)
	titleBrush = QBrush(Qt.red)
	#titleBrush = QBrush(QColor('#1A8BEB'))
	chart.setTitleBrush(titleBrush)


	chart.legend().setVisible(True)
	chart.legend().setFont(axisLabelFont)


	chart_view = QChartView(chart)
	backgroundColorOfCharts = self.currentTheme.get('chartBackGroundColor')
	chart_view.setStyleSheet(f'background-color: {backgroundColorOfCharts}; border-radius: 30px;')
	chart_view.setRenderHint(QPainter.Antialiasing)

	chart_view.setContextMenuPolicy(Qt.CustomContextMenu)
	chart_view.customContextMenuRequested.connect(self.showContextMenu)

	return chart_view




# def createStackedTwoBarChart(self, x, y_list, title, x_label, y_label, legends):
# 	# Create custom stacked bar series
# 	series = QStackedBarSeries()

# 	# Loop through y_list and add bar sets
# 	for i, y in enumerate(y_list):
# 		bar_set = QBarSet(str(legends[i]))
# 		bar_set.setLabelColor(Qt.black)
# 		bar_set.setLabelFont(QFont("Roboto", 10))
# 		bar_set.append(y)
# 		series.append(bar_set)

# 	series.setLabelsVisible(True)
# 	series.setLabelsPosition(QStackedBarSeries.LabelsInsideBase)

# 	# Create chart and set series
# 	chart = QChart()
# 	backgroundColorOfCharts = self.currentTheme.get('chartBackGroundColor')
# 	chart.setBackgroundBrush(QBrush(QColor(backgroundColorOfCharts)))
# 	chart.addSeries(series)

# 	# Customize chart title
# 	chart.setTitle(title)
# 	title_font = QFont("Roboto", 16, QFont.Bold)
# 	chart.setTitleFont(title_font)
# 	title_brush = QBrush(Qt.red)
# 	chart.setTitleBrush(title_brush)



# 	# Create X axis and set categories
# 	axis_x = QBarCategoryAxis()
# 	axis_x.append(x)
# 	if len(x) > 6:
#  		axis_x.setLabelsAngle(90)
# 	else:
# 		pass
# 	chart.addAxis(axis_x, Qt.AlignBottom)
# 	series.attachAxis(axis_x)

# 	# Create Y axis
# 	axis_y = CustomValueAxis()
# 	chart.addAxis(axis_y, Qt.AlignLeft)
# 	axis_y.setRange(0, max(y_list[-1])*1.1)
# 	series.attachAxis(axis_y)

# 	# Create chart view
# 	chart_view = QChartView(chart)
# 	backgroundColorOfCharts = self.currentTheme.get('chartBackGroundColor')
# 	chart_view.setStyleSheet(f'background-color: {backgroundColorOfCharts}; border-radius: 30px;')
# 	chart_view.setRenderHint(QPainter.Antialiasing)

# 	# Set axis labels
# 	axisLabelFont = QFont("Roboto", 12, QFont.Bold)
	
# 	axis_x.setTitleText(x_label)
# 	axis_x.setTitleFont(axisLabelFont)
# 	axis_y.setTitleText(y_label)
# 	axis_y.setTitleFont(axisLabelFont)

# 	# Set font for the legend
# 	chart.legend().setFont(axisLabelFont)

# 	chart_view.setContextMenuPolicy(Qt.CustomContextMenu)
# 	chart_view.customContextMenuRequested.connect(self.showContextMenu)

# 	return chart_view