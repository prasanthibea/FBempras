from PySide6.QtCore import QUrl, QDate
from PySide6.QtGui import QIcon, QFont
from PySide6.QtWidgets import QWidget, QPushButton, QLabel, QGridLayout, QMessageBox
from PySide6.QtWebEngineWidgets import QWebEngineView

from datetime import datetime

def toolBarFunction(self):
	self.actionsettings.triggered.connect(self.onTriggeringSettingsAction)
	self.actionhelp.triggered.connect(self.onTriggeringHelpAction)
	self.actionexport.triggered.connect(self.generateReportFunction)



def onTriggeringSettingsAction(self):
	self.settingsWidget.show()

def onTriggeringHelpAction(self):
	# self.webview = QWebEngineView()
	# self.webview.setWindowTitle('Help')
	# self.webview.setWindowIcon(QIcon('Media/question.png'))
	# file_path = "help/index.html"
	# self.webview.load(QUrl.fromLocalFile(file_path))
	# self.webview.show()
	helpMsgBox = QMessageBox()
	helpMsgBox.setIcon(QMessageBox.Information) 
	helpMsgBox.setText('Help page will be available in the next update.')
	helpMsgBox.setWindowTitle("Message")
	helpMsgBox.setWindowIcon(QIcon('Media/ramsify.png'))
	helpMsgBox.setStandardButtons(QMessageBox.Ok)
	helpMsgBox.exec_()


# def onTriggeringPendingTasksAction(self):

# 	self.pendingTasksWindow= QWidget()
# 	layoutForPendingTaskWindow = QGridLayout()
# 	self.pendingTasksWindow.setLayout(layoutForPendingTaskWindow)
# 	self.pendingTasksWindow.setWindowIcon(QIcon('Media/ramsify.png'))
# 	self.pendingTasksWindow.setWindowTitle('Pending Tasks')





# 	date = QDate.currentDate()
# 	for i in range(11):
# 		year = date.year()
# 		month = date.toString('MMM')
# 		monthNumber = datetime.strptime(month, '%b').month
# 		enableEditPushButton = QPushButton()
# 		# enableEditPushButton.setFont(self.labelsAndPushBtnsFont_pendingTasks)
# 		enableEditPushButton.setCheckable(True)
# 		self.cursor.execute('SELECT * FROM pending_tasks WHERE month = "{}" and year = "{}"'.format(monthNumber, year))
# 		result = self.cursor.fetchall()
# 		if len(result) > 0:
# 			enableEditPushButton.setText('Disable Edit')
# 			enableEditPushButton.setChecked(False)
# 		elif len(result) == 0:
# 			enableEditPushButton.setText('Enable Edit')
# 			enableEditPushButton.setChecked(True)


# 		def onClickingEnableEditButton():
# 			button = self.sender()
# 			index = layoutForPendingTaskWindow.getItemPosition(layoutForPendingTaskWindow.indexOf(button))

# 			if not button.isChecked():
# 				year_ = layoutForPendingTaskWindow.itemAtPosition(index[0], 0).widget().text()
# 				month_ = layoutForPendingTaskWindow.itemAtPosition(index[0], 1).widget().text()
# 				monthNumber = datetime.strptime(month_, '%b').month


# 				sql = 'INSERT INTO pending_tasks (month, year) VALUES (%s, %s)'
# 				values = (monthNumber, year_)
# 				self.cursor.execute(sql,values)
# 				self.mydb.commit()

# 				button.setText('Disable Edit')
# 				button.setChecked(False)

# 			else:
# 				year_ = layoutForPendingTaskWindow.itemAtPosition(index[0], 0).widget().text()
# 				month_ = layoutForPendingTaskWindow.itemAtPosition(index[0], 1).widget().text()
# 				monthNumber = datetime.strptime(month_, '%b').month

# 				self.cursor.execute("DELETE FROM pending_tasks WHERE month = '{}' and year = '{}'".format(monthNumber, year_))
# 				self.mydb.commit()
# 				button.setText('Enable Edit')
# 				button.setChecked(True)


# 		label_year = QLabel(str(year))
# 		# label_year.setFont(self.labelsAndPushBtnsFont_pendingTasks)
# 		layoutForPendingTaskWindow.addWidget(label_year, i, 0,)

# 		label_month = QLabel(date.toString('MMM'))
# 		# label_month.setFont(self.labelsAndPushBtnsFont_pendingTasks)
# 		layoutForPendingTaskWindow.addWidget(label_month, i, 1,)
		
# 		layoutForPendingTaskWindow.addWidget(enableEditPushButton, i, 2,)
# 		enableEditPushButton.clicked.connect(onClickingEnableEditButton)
# 		date = date.addMonths(-1)




# 	self.pendingTasksWindow.show()
