from PySide6.QtWidgets import QLabel, QWidget, QVBoxLayout, QSpacerItem, QMessageBox, QSizePolicy, QFileDialog, QHBoxLayout, QScrollArea, QTableWidgetItem, QAbstractItemView, QFormLayout, QLineEdit, QComboBox, QGridLayout, QPushButton, QSpinBox
from PySide6.QtCore import Qt
from PySide6.QtGui import QIcon
from datetime import datetime, timedelta
from functions import CustomSpinBox
from functions import TableWidget
from openpyxl import Workbook
from dateutil.relativedelta import relativedelta

def runningMileageDataUI(self):
	from PySide6.QtWidgets import QApplication
	self.layoutForFilters_RMDataTable = QHBoxLayout()

	self.createLineEditBox('serachBarOfRMDataTable', 'Search..' )
	self.serachBarOfRMDataTable.setClearButtonEnabled(True)
	self.serachBarOfRMDataTable.setFixedWidth(int(0.2 * QApplication.primaryScreen().availableGeometry().width()))

	self.layoutForFilters_RMDataTable.addItem(QSpacerItem(1, 0, QSizePolicy.Expanding, QSizePolicy.Minimum))
	self.layoutForFilters_RMDataTable.addWidget(self.serachBarOfRMDataTable)



	self.rmDataTable = TableWidget()
	headers = ['Id', 'Year', 'Month', 'Total running mielage']
	self.rmDataTable.setColumnCount(len(headers))
	self.rmDataTable.setHorizontalHeaderLabels(headers)
	self.rmDataTable.setStyleSheet(self.tableWidgetQSS)
	self.rmDataTable.horizontalHeader().setStyleSheet(self.headerHorizontalQSS)
	# self.rmDataTable.verticalHeader().setStyleSheet(self.headerVerticalQSS)
	self.rmDataTable.setAlternatingRowColors(True)
	self.rmDataTable.setShowGrid(False)
	self.rmDataTable.setEditTriggers(QAbstractItemView.NoEditTriggers)

	self.mainVerticalLayout_Maintenance_2.addLayout(self.layoutForFilters_RMDataTable)
	self.rmDataTable.setMinimumHeight(int(0.75 * QApplication.primaryScreen().availableGeometry().height()))
	self.mainVerticalLayout_Maintenance_2.addWidget(self.rmDataTable)
	self.rmDataTable.setColumnWidth(0, int(0.11 * QApplication.primaryScreen().availableGeometry().width()))
	self.rmDataTable.setColumnWidth(3, int(0.15 * QApplication.primaryScreen().availableGeometry().width()))

	


	query = '''SELECT DISTINCT rm_id, year, month FROM trainsets_mileage'''
	
	self.cursor.execute(query)
	uniqueRmData = self.cursor.fetchall()
	self.rmDataTable.setRowCount(len(uniqueRmData))
	# print(uniqueRmData)



	def connect_button_clicked_RM(button, on_clicked_function):
		button.clicked.connect(lambda : on_clicked_function(self, button.text()))

	for i, rmRowData in enumerate(uniqueRmData):
		for j, value in enumerate(rmRowData):
			if j == 0:
				button = QPushButton(str(value))
				button.setStyleSheet("QPushButton { text-decoration: none; }"
					"QPushButton:hover { text-decoration: underline; }")
				connect_button_clicked_RM(button, onButtonClicked_rmData)

				button.setCursor(Qt.PointingHandCursor)
				self.rmDataTable.setCellWidget(i, j, button)

			else:
				item = QTableWidgetItem(str(value))
				item.setFlags(item.flags() ^ Qt.ItemIsEditable)
				self.rmDataTable.setItem(i, j, item)

		totalRunningMielage_query = "SELECT SUM(monthly_mileage) FROM trainsets_mileage WHERE rm_id = %s"
		self.cursor.execute(totalRunningMielage_query, (rmRowData[0],))
		total_RunningMielage = self.cursor.fetchone()[0]


		item = QTableWidgetItem(str(total_RunningMielage))
		self.rmDataTable.setItem(i, len(rmRowData), item)
		item.setFlags(item.flags() ^Qt.ItemIsEditable)

	def onChangingSearchbarOf_RMDT():
		searchText = self.serachBarOfRMDataTable.text().lower()
		for row in range(self.rmDataTable.rowCount()):
			self.rmDataTable.setRowHidden(row, True)
			if searchText in self.rmDataTable.cellWidget(row, 0).text().lower():
				self.rmDataTable.setRowHidden(row, False)

			for col in range(1, self.rmDataTable.columnCount()):
				item = self.rmDataTable.item(row, col)
				if item is not None and searchText in item.text().lower():
					self.rmDataTable.setRowHidden(row, False)
					break

	self.serachBarOfRMDataTable.textChanged.connect(onChangingSearchbarOf_RMDT)
	onChangingSearchbarOf_RMDT()	
	
	for row in range(self.rmDataTable.rowCount()):
		for col in range(1, self.rmDataTable.columnCount()):
			item = self.rmDataTable.item(row, col)
			item.setTextAlignment(Qt.AlignCenter)

def onButtonClicked_rmData(self, rmId):
	# print(f"Button {rmId} clicked!")
	from PySide6.QtWidgets import QApplication


	query = '''SELECT
		trainsets.trainset,
		trainsets_mileage.year,
		trainsets_mileage.month,
		trainsets_mileage.cummulative_mileage,
		trainsets_mileage.monthly_mileage
	FROM
		trainsets_mileage
	LEFT JOIN
		trainsets ON trainsets_mileage.trainset_id = trainsets.id
	WHERE
		trainsets_mileage.rm_id = %s
	'''
	self.cursor.execute(query, tuple([rmId]))
	clickedRMData = self.cursor.fetchall()
	# print('ckiuhrm',clickedRMData)




	selected_year_Rm = clickedRMData[0][1]
	selected_month_Rm = clickedRMData[0][2]


	# selected_year_Rm = int(selected_year_Rm)
	# selected_month_Rm= int(selected_month_Rm)
				
	previous_month = selected_month_Rm - 1
	previous_year = selected_year_Rm		

	if previous_month == 0:
		previous_month = 12
		previous_year -= 1

	query = '''SELECT
		trainsets_mileage.cummulative_mileage, trainsets.trainset
		FROM trainsets_mileage
		JOIN trainsets ON trainsets_mileage.trainset_id = trainsets.id
		WHERE trainsets_mileage.year = %s AND trainsets_mileage.month = %s
		AND trainsets.deleted_at IS NULL;
	'''
	# print((previous_year, previous_month))
	self.cursor.execute(query, (previous_year, previous_month))


	# self.cursor.execute(query, (previous_year, previous_month))
	clickedRMDataOfPreviousMonth = self.cursor.fetchall()




	self.rmWindow = QWidget()
	self.rmWindow.setWindowTitle(rmId)
	self.rmWindow.setWindowIcon(QIcon('Media/ramsify.png'))
	self.rmWindow.setStyleSheet(self.widgetQSS)
	self.rmWindow.setGeometry(400, 200, 530, 800)


	# Create a scroll area
	scrollArea = QScrollArea()
	scrollArea.setWidgetResizable(True)  # Allow the scroll area's widget to resize
	scrollArea.setStyleSheet(self.scrollAreaQSS)

	self.rmWindow.setLayout(QVBoxLayout())  # Set a layout for the main window
	self.rmWindow.layout().addWidget(scrollArea)



	contentsWidget = QWidget()
	VLayout = QVBoxLayout()
	contentsWidget.setLayout(VLayout)
	# VLayout.addWidget(scrollArea)
	scrollArea.setWidget(contentsWidget)

	##############################

	HLayout = QHBoxLayout()
	downloadIconPath = self.currentTheme.get('downloadIcon')
	self.createPushButton('downloadButton_RMDT','', downloadIconPath, 35, 'Download')
	HLayout.addWidget(self.downloadButton_RMDT, alignment=Qt.AlignRight)
	self.downloadButton_RMDT.setFixedHeight(24)
	VLayout.addLayout(HLayout)

	#######################################

	formLayout_RM_= QFormLayout()
	formLayout_RM_.addRow('Year:', QLabel(str(clickedRMData[0][1]))) 
	formLayout_RM_.addRow('Month:', QLabel(str(clickedRMData[0][2])))

	VLayout.addLayout(formLayout_RM_)

	self.cummulativeMileageSpinbox_RM__ = []

	gridLayout_Rm_ = QGridLayout()

	gridLayout_Rm_.addWidget(QLabel('Trainset'), 0, 0)
	gridLayout_Rm_.addWidget(QLabel('Odometer Reading'), 0, 1)
	gridLayout_Rm_.addWidget(QLabel('Monthly Running Mileage'), 0, 2)

	self.spinboxlist_Rm_= []

	selected_year, selected_month = clickedRMData[0][1], clickedRMData[0][2]
	current_date_ = datetime.now().date()
	currentMonthStartingDate = datetime(current_date_.year, current_date_.month, 1)
	previous_month = currentMonthStartingDate - timedelta(days=1)
	six_months_ago = current_date_ - relativedelta(months=6)
	six_months_ago = six_months_ago.replace(day=1)

	firstDayOfSelectedYearMonth = datetime(selected_year, selected_month, 1).date()

	if (selected_year == previous_month.year and selected_month == previous_month.month) or (selected_year == current_date_.year and selected_month == current_date_.month):
		prevMonth = True
	else:
		prevMonth = False

	if ((self.userName == 'Ravikumar') and (self.editableOptionMaxDate > datetime.now().date())):
		prevMonth = True

	if self.userRole == 0:
		prevMonth = True

	if (self.userRole == 1) and (six_months_ago <= firstDayOfSelectedYearMonth <= current_date_):
		prevMonth = True


	
	for i, trainset in enumerate(self.trainsetsList):
		trainsetlabel = QLabel(trainset + ':')

		cummulativeMileageSpinbox_RM_ = CustomSpinBox()
		cummulativeMileageSpinbox_RM_.setStyleSheet(self.spinBoxQSS)
		cummulativeMileageSpinbox_RM_.setMinimumWidth(200)
		cummulativeMileageSpinbox_RM_.setEnabled(True)
		cummulativeMileageSpinbox_RM_.setMaximum(100000000)   
	
		monthlyMileageSpinbox_RM_ = CustomSpinBox()
		monthlyMileageSpinbox_RM_.setStyleSheet(self.spinBoxQSS)
		monthlyMileageSpinbox_RM_.setValue(0)
		monthlyMileageSpinbox_RM_.setMinimumWidth(200)
		monthlyMileageSpinbox_RM_.setEnabled(True)
		monthlyMileageSpinbox_RM_.setMaximum(100000000)   
			
		gridLayout_Rm_.addWidget(trainsetlabel, i+1, 0)
		gridLayout_Rm_.addWidget(cummulativeMileageSpinbox_RM_, i+1, 1, alignment = Qt.AlignLeft)
		gridLayout_Rm_.addWidget(monthlyMileageSpinbox_RM_, i+1, 2, alignment = Qt.AlignLeft)
		self.spinboxlist_Rm_.append((cummulativeMileageSpinbox_RM_, monthlyMileageSpinbox_RM_))	


		# def onChangingMonthlyMileageCB(value, row, spinboxlist_Rm):
		# 	spinbox1 = spinboxlist_Rm[row][0]
		# 	if lastMonthCumulativeMileage_RM:
		# 		spinbox1.setValue(value + lastMonthCumulativeMileage_RM[row])
		# 	else:
		# 		spinbox1.setValue(value)
		# monthlyMileageSpinbox_RM_.valueChanged.connect(lambda value, row=i: onChangingMonthlyMileageCB(value, row, self.spinboxlist_Rm_))

		# def onChangingCumulativeMileageCB(value, row, spinboxlist_Rm):
		# 	spinbox2 = spinboxlist_Rm[row][1]
		# 	if lastMonthCumulativeMileage_RM:		
		# 		spinbox2.setValue(value - lastMonthCumulativeMileage_RM[row])
		# 	else:
		# 		spinbox2.setValue(value)
		# cummulativeMileageSpinbox_RM.valueChanged.connect(lambda value, row=i: onChangingCumulativeMileageCB(value, row, self.spinboxlist_Rm))



		if i < len(clickedRMData):
			cummulativeMileageSpinbox_RM_.setValue(clickedRMData[i][3])
		else:
			cummulativeMileageSpinbox_RM_.setValue(0)

		if i < len(clickedRMDataOfPreviousMonth):
			prevMonthValue = clickedRMDataOfPreviousMonth[i][0]
		else:
			prevMonthValue = 0


		cummulativeMileageSpinbox_RM_.setMinimum(prevMonthValue)


		if i < len(clickedRMData):
			monthlyMileageSpinbox_RM_.setValue(clickedRMData[i][4])
		else:
			monthlyMileageSpinbox_RM_.setValue(0)

		# monthlyMileageSpinbox_RM_.setValue(clickedRMData[i][4])

		def onChangingMonthlyMileageCB_(value, row, spinboxlist_Rm):
			spinbox1 = spinboxlist_Rm[row][0]

			if row < len(clickedRMDataOfPreviousMonth):
				spinbox1.setValue(value + clickedRMDataOfPreviousMonth[row][0])
			else:
				spinbox1.setValue(value)

		monthlyMileageSpinbox_RM_.valueChanged.connect(lambda value, row=i: onChangingMonthlyMileageCB_(value, row, self.spinboxlist_Rm_))


		def onChangingCumulativeMileageCB_(value, row, spinboxlist_Rm):
			spinbox2 = spinboxlist_Rm[row][1]

			if row < len(clickedRMDataOfPreviousMonth):
				spinbox2.setValue(value - clickedRMDataOfPreviousMonth[row][0])
			else:	
				spinbox2.setValue(value)
		
		cummulativeMileageSpinbox_RM_.valueChanged.connect(lambda value, row=i: onChangingCumulativeMileageCB_(value, row, self.spinboxlist_Rm_))




		if prevMonth:
			cummulativeMileageSpinbox_RM_.setEnabled(True)
			monthlyMileageSpinbox_RM_.setEnabled(True)
		else:
			cummulativeMileageSpinbox_RM_.setEnabled(False)
			monthlyMileageSpinbox_RM_.setEnabled(False)



	self.rmWindow.show()

	# layoutForHeadingsInRMButtonClickWindow = QHBoxLayout()

	

	# VLayout.addLayout(layoutForHeadingsInRMButtonClickWindow)
	VLayout.addLayout(gridLayout_Rm_)
	########################################


	def onClickingDownloadButton_RMDT():
		file_path, _ = QFileDialog.getSaveFileName(self, "Save Excel File", "", "Excel Files (*.xlsx)")
		if file_path:
			wb = Workbook()
			ws = wb.active
			
			year_label = clickedRMData[0][1]
			month_label = clickedRMData[0][2]
			ws.append(['Year:', year_label])
			ws.append(['Month:', month_label])
			
			headers = ['Trainset', 'Odometer Reading', 'Monthly Running Mileage']
			ws.append(headers)

		
			for i, (cummulativeMileageSpinbox_RM_, monthlyMileageSpinbox_RM_) in enumerate(self.spinboxlist_Rm_):
				trainset = self.trainsetsList[i]
				odometer_reading = cummulativeMileageSpinbox_RM_.value()
				monthly_runningmileage = monthlyMileageSpinbox_RM_.value()
				ws.append([trainset, odometer_reading, monthly_runningmileage])		

			wb.save(file_path)

			
			rmDownloadMsgBox = QMessageBox()
			rmDownloadMsgBox.setIcon(QMessageBox.Information) 
			rmDownloadMsgBox.setText(f'Data downloaded successfully')
			rmDownloadMsgBox.setWindowTitle("Message")
			rmDownloadMsgBox.setWindowIcon(QIcon('Media/ramsify.png'))
			rmDownloadMsgBox.setStandardButtons(QMessageBox.Ok)
			rmDownloadMsgBox.exec_()
			
	self.downloadButton_RMDT.clicked.connect(onClickingDownloadButton_RMDT)



	#########################################
	if prevMonth:	
		self.createPushButton('rmUpdateButton', 'Update')
		VLayout.addWidget(self.rmUpdateButton, alignment=Qt.AlignCenter)
	
		def update_running_mileage(rmId):

			trainset_id_query = "SELECT trainset_id FROM trainsets_mileage WHERE rm_id = %s"
			self.cursor.execute(trainset_id_query, (str(rmId),))
			trainset_id_result = self.cursor.fetchall()

			for i, (cummulativeMileageSpinbox_RM_, monthlyMileageSpinbox_RM_) in enumerate(self.spinboxlist_Rm_):
				new_cumulative_mileage = cummulativeMileageSpinbox_RM_.value()
				new_monthly_mileage = monthlyMileageSpinbox_RM_.value()

				trainset_id_ = trainset_id_result[i][0]
		 
				update_query = "UPDATE trainsets_mileage SET cummulative_mileage = %s, monthly_mileage = %s WHERE rm_id = %s AND trainset_id = %s"
				self.cursor.execute(update_query, (new_cumulative_mileage, new_monthly_mileage, rmId, trainset_id_))
				self.mydb.commit()



			totalRunningMielage_query = "SELECT SUM(monthly_mileage) FROM trainsets_mileage WHERE rm_id = %s"
			self.cursor.execute(totalRunningMielage_query, (rmId,))
			total_RunningMielage = self.cursor.fetchone()[0]

			for i in range(self.rmDataTable.rowCount()):
				#button_ = self.rmDataTable.cellWidget(i,0)
				if self.rmDataTable.cellWidget(i,0).text() == rmId:
					item = QTableWidgetItem(str(total_RunningMielage))
					item.setTextAlignment(Qt.AlignCenter)
					item.setFlags(item.flags() ^Qt.ItemIsEditable)
					self.rmDataTable.setItem(i, 3, item)

			rmUpdateMsgBox = QMessageBox()
			rmUpdateMsgBox.setIcon(QMessageBox.Information) 
			rmUpdateMsgBox.setText(f'Data Updated successfully.\nID:{rmId}')
			rmUpdateMsgBox.setWindowTitle("Message")
			rmUpdateMsgBox.setWindowIcon(QIcon('Media/ramsify.png'))
			rmUpdateMsgBox.setStandardButtons(QMessageBox.Ok)
			rmUpdateMsgBox.exec_()

			self.rmWindow.close()


		self.rmUpdateButton.clicked.connect(lambda: update_running_mileage(rmId))