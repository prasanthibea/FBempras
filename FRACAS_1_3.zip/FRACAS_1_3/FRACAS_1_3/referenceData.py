from PySide6.QtWidgets import QTableWidgetItem, QSpacerItem, QSizePolicy, QMessageBox, QPushButton, QCheckBox, QScrollArea, QFileDialog, QAbstractItemView, QTextEdit, QLineEdit, QWidget, QLabel, QHBoxLayout, QVBoxLayout, QFormLayout, QHeaderView
from functions import TableWidget
from PySide6.QtCore import Qt
from PySide6.QtGui import QIcon, QColor 
from datetime import date, datetime
from openpyxl import Workbook

def referenceDataUI(self, layout):
	from PySide6.QtWidgets import QApplication, QLabel

	checkAllUserIconPath = self.currentTheme.get('oppositeColorCheckBoxIcon')
	unCheckAllUserIconPath = self.currentTheme.get('oppositeColorUnCheckBoxIcon')
	partiallyCheckedIconPath = self.currentTheme.get('oppositeColorPartiallyCheckedBoxIcon')
	deleteIconPath = self.currentTheme.get('whiteDeleteIcon')
	downloadIconPath = self.currentTheme.get('downloadIcon')
	refreshTableIconPath = self.currentTheme.get('refreshIcon')


	self.createPushButton('selectAllRefButton', '', unCheckAllUserIconPath, 30)
	self.createPushButton('deleteButton_Ref', '', deleteIconPath, 35, 'Delete')
	self.createLineEditBox('serachBarOfRef', 'Search...' )
	self.serachBarOfRef.setClearButtonEnabled(True)
	self.serachBarOfRef.setFixedWidth(self.geometryWidth(0.2))
	self.createPushButton('download_Ref', '', downloadIconPath, 35, 'Download')
	self.createPushButton('refreshButton_Ref', '', refreshTableIconPath, 35, 'Refresh')
	self.createPushButton('newConsumable_Ref', '+ New Consumable', '', self.geometryWidth(0.079))
	
	self.refHBoxLayout = QHBoxLayout()
	self.refHBoxLayout.addWidget(self.selectAllRefButton)
	self.refHBoxLayout.addWidget(self.deleteButton_Ref)
	self.refHBoxLayout.addWidget(self.serachBarOfRef)
	self.refHBoxLayout.addWidget(self.download_Ref)
	self.refHBoxLayout.addWidget(self.refreshButton_Ref)
	self.refHBoxLayout.addItem(QSpacerItem(1, 0, QSizePolicy.Expanding, QSizePolicy.Minimum))
	self.refHBoxLayout.addWidget(self.newConsumable_Ref)
	layout.addLayout(self.refHBoxLayout)

	
	self.referenceDataTable = TableWidget()
	
	self.headersOfreferenceDataTable  = [' ', 'Sr No', 'Consumables', 'Units', 'A CHECK', 'Consumable for \n1 Train in a Year-16nos', 'B1 CHECK',
	 'Consumable for\n1 Train in a Year-6nos', 'B4 CHECK', 'Consumable for\n1 Train in a Year-1nos', 'B8 CHECK', 'Consumable for\n1 Train in a Year-1nos',
	 'Total Consumable for\nAll Service Check', 'Total Consumables\nRequired for 34 Trainset\nfor 1 Month(approx)', 'Total Consumables\nRequired for 34 Trainset\n for 1 Year', 'Remarks']
			
	
	self.referenceDataTable.setColumnCount(len(self.headersOfreferenceDataTable))
	self.referenceDataTable.setHorizontalHeaderLabels(self.headersOfreferenceDataTable)
	self.referenceDataTable.setStyleSheet(self.tableWidgetQSS)
	self.referenceDataTable.horizontalHeader().setStyleSheet(self.headerHorizontalQSS)
	self.referenceDataTable.setAlternatingRowColors(True)
	self.referenceDataTable.setShowGrid(False)
	layout.addWidget(self.referenceDataTable)
	self.referenceDataTable.setEditTriggers(QAbstractItemView.NoEditTriggers)

	self.selectAllRefButton.setCheckable(True)
	self.deleteButton_Ref.setVisible(False)

	self.referenceDataTable.setColumnWidth(0, self.geometryWidth(0.04))
	self.referenceDataTable.setColumnWidth(1, self.geometryWidth(0.09))
	self.referenceDataTable.setColumnWidth(2, self.geometryWidth(0.12))
	self.referenceDataTable.setColumnWidth(3, self.geometryWidth(0.06))
	self.referenceDataTable.setColumnWidth(4, self.geometryWidth(0.09))
	self.referenceDataTable.setColumnWidth(5, self.geometryWidth(0.12))
	self.referenceDataTable.setColumnWidth(6, self.geometryWidth(0.06))
	self.referenceDataTable.setColumnWidth(7, self.geometryWidth(0.1))
	self.referenceDataTable.setColumnWidth(8, self.geometryWidth(0.09))
	self.referenceDataTable.setColumnWidth(9, self.geometryWidth(0.1))
	self.referenceDataTable.setColumnWidth(10, self.geometryWidth(0.09))
	self.referenceDataTable.setColumnWidth(11, self.geometryWidth(0.1))
	self.referenceDataTable.setColumnWidth(12, self.geometryWidth(0.1))
	self.referenceDataTable.setColumnWidth(13, self.geometryWidth(0.11))
	self.referenceDataTable.setColumnWidth(14, self.geometryWidth(0.11))
	self.referenceDataTable.setColumnWidth(15, self.geometryWidth(0.10))



	def onClickingNewConsumable_Ref():
		self.newRefWindow = QWidget()
		# self.newRefWindow.move(600, 200)
		# self.newRefWindow.resize(800, 100)
		self.newRefWindow.setFixedHeight(self.geometryHeight(0.75))
		self.newRefWindow.setFixedWidth(self.geometryWidth(0.4))

		self.newRefWindow.setWindowTitle('New Consumable')
		self.newRefWindow.setWindowIcon(QIcon('Media/ramsify.png'))

		vboxLayout = QVBoxLayout()
		formLayout = QFormLayout()
		vboxLayout.addLayout(formLayout)

		self.newRefWindow.setLayout(vboxLayout)

		self.createNumberLineEditBox('srNoLineEdit_Ref')
		self.createLineEditBox('consumablesLineEdit_Ref')
		self.createLineEditBox('unitLineEdit_Ref')
		self.createFloatLineEditBox('aCheckLineEdit_Ref')
		self.createFloatLineEditBox('consumableFor1Train16nosLineEdit_Ref')
		self.createFloatLineEditBox('b1CheckLineEdit_Ref')
		self.createFloatLineEditBox('consumableFor1Train6nosLineEdit_Ref')
		self.createFloatLineEditBox('b4CheckLineEdit_Ref')
		self.createFloatLineEditBox('consumableFor1Train1nosOfb4LineEdit_Ref')
		self.createFloatLineEditBox('b8CheckLineEdit_Ref')
		self.createFloatLineEditBox('consumableFor1Train1nosOfb8LineEdit_Ref')
		self.createFloatLineEditBox('totalConsumableForAllServiceCheckLineEdit_Ref')
		self.createFloatLineEditBox('totalConsumablesMonthLineEdit_Ref')
		self.createFloatLineEditBox('totalConsumablesYearLineEdit_Ref')
		self.createTextEditBox('remarksLineEdit_Ref')

		formLayout.addRow('SR No: ', self.srNoLineEdit_Ref)
		formLayout.addRow('Consumables: <font color="red">*</font>', self.consumablesLineEdit_Ref)
		formLayout.addRow('Unit: <font color="red">*</font>', self.unitLineEdit_Ref)
		formLayout.addRow('A Check: ', self.aCheckLineEdit_Ref)
		formLayout.addRow('Consumable For 1 Train In a Year 16n0s: ', self.consumableFor1Train16nosLineEdit_Ref)
		formLayout.addRow('B1 Check: ', self.b1CheckLineEdit_Ref)
		formLayout.addRow('Consumable For 1 Train In a Year 6n0s: ', self.consumableFor1Train6nosLineEdit_Ref)
		formLayout.addRow('B4 Check: ', self.b4CheckLineEdit_Ref)
		formLayout.addRow('Consumable For 1 train In a Year 1n0s: ', self.consumableFor1Train1nosOfb4LineEdit_Ref)
		formLayout.addRow('B8 Check: ', self.b8CheckLineEdit_Ref)
		formLayout.addRow('Consumable For 1 Train In a Year 1n0s: ', self.consumableFor1Train1nosOfb8LineEdit_Ref)
		formLayout.addRow('Total Consumable For All Service Checks: ', self.totalConsumableForAllServiceCheckLineEdit_Ref)
		formLayout.addRow('Total Consumables Required For 34 Trainset For 1 Month (approx): <font color="red">*</font> ', self.totalConsumablesMonthLineEdit_Ref)
		formLayout.addRow('Total Consumables Required For 34 Trainset For 1 Year: <font color="red">*</font> ', self.totalConsumablesYearLineEdit_Ref)
		formLayout.addRow('Remarks: ', self.remarksLineEdit_Ref)

		self.createPushButton('submitBtn_Ref', 'Submit', '', self.geometryWidth(0.04))
		self.createPushButton('cancelBtn_Ref', 'Cancel', '', self.geometryWidth(0.04))

		# vboxLayout.addWidget(self.submitBtn_Ref, alignment = Qt.AlignCenter)
		hBoxLayout = QHBoxLayout()
		hBoxLayout.addWidget(self.submitBtn_Ref, alignment = Qt.AlignRight)
		hBoxLayout.addWidget(self.cancelBtn_Ref, alignment = Qt.AlignLeft)

		vboxLayout.addLayout(hBoxLayout)
			
		formFields_REF = [self.srNoLineEdit_Ref, self.consumablesLineEdit_Ref, self.unitLineEdit_Ref, self.aCheckLineEdit_Ref, self.consumableFor1Train16nosLineEdit_Ref, 
						self.b1CheckLineEdit_Ref, self.consumableFor1Train6nosLineEdit_Ref, self.b4CheckLineEdit_Ref, self.consumableFor1Train1nosOfb4LineEdit_Ref,
						self.b8CheckLineEdit_Ref, self.consumableFor1Train1nosOfb8LineEdit_Ref, self.totalConsumableForAllServiceCheckLineEdit_Ref,
						self.totalConsumablesMonthLineEdit_Ref, self.totalConsumablesYearLineEdit_Ref, self.remarksLineEdit_Ref]

		def onClickingSubmit_Ref():
			mandatoryVerification_Ref = True
			mandatoryIndexesRef = [1, 2, 12, 13]
			refData = []

			for i, wid in enumerate(formFields_REF):
				if isinstance(wid, QLineEdit):
					if wid.text() == '':
						refData.append(None)
						if i in mandatoryIndexesRef:
							mandatoryVerification_Ref = False
							wid.setProperty("error", True)
							wid.setStyleSheet(self.lineEditBoxQSS)
					else:
						if wid.text().isdigit():
							refData.append(int(wid.text()))
						else:
							refData.append(wid.text()) 	

						wid.setProperty("error", False)
						wid.setStyleSheet(self.lineEditBoxQSS)

				if isinstance(wid, QTextEdit):
					if wid.toPlainText() == '':
						refData.append(None)
						if i in mandatoryIndexesRef:
							mandatoryVerification_Ref = False
							wid.setProperty("error", True)
							wid.setStyleSheet(self.textEditBoxQSS)

					else:
						refData.append(wid.toPlainText())
						wid.setProperty("error", False)
						wid.setStyleSheet(self.textEditBoxQSS)

				

			if not mandatoryVerification_Ref:
				print('Mandatory fields missing.')

			else:
				
				refData.append(self.user_id)
			
				query = """
					INSERT INTO reference				
					( sr_no, consumables, unit, a_check, consumable_onetrain_year_16nos, b1_check, consumable_onetrain_year_6nos, b4_check, consumable_onetrainb4_year_1nos,
					b8_check, consumable_onetrain_yeab8r_1nos, totalconsumables_allservicechecks, totalconsumables_34trainset_1month, totalconsumables_34trainset_1year,
					remarks, user_id) 
					VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
				""" 

				try:
					self.cursor.execute(query, tuple(refData))
					self.mydb.commit()
					self.refreshButton_Ref.click()
					self.refreshButton_Cons.click()

					refSubmitMsgBox = QMessageBox()
					refSubmitMsgBox.setIcon(QMessageBox.Information)
					refSubmitMsgBox.setText(f'Data Submitted successfully.')
					refSubmitMsgBox.setWindowTitle("Message")
					refSubmitMsgBox.setWindowIcon(QIcon('Media/ramsify.png'))
					refSubmitMsgBox.setStandardButtons(QMessageBox.Ok)
					refSubmitMsgBox.exec_()

					self.newRefWindow.close()

				except Exception as e:
					QMessageBox.critical(self, "Database Error", f"An error occurred: {e}")	

		self.submitBtn_Ref.clicked.connect(onClickingSubmit_Ref)	

		self.newRefWindow.show()

		def onClickingCancel_Ref():
			for wid in formFields_REF:
				if isinstance(wid, QLineEdit):
					wid.clear()
					wid.setProperty("error", False)
					wid.setStyleSheet(self.lineEditBoxQSS)

			self.remarksLineEdit_Ref.clear()

		self.cancelBtn_Ref.clicked.connect(onClickingCancel_Ref)


	self.newConsumable_Ref.clicked.connect(onClickingNewConsumable_Ref)

	
	def onClickingrefreshbutton_ref():
		self.deleteButton_Ref.hide()
		self.selectAllRefButton.setIcon(QIcon(unCheckAllUserIconPath))
		self.selectAllRefButton.setChecked(False)


		queryone = '''
						SELECT
							sr_no,
							consumables,
							unit,
							a_check,
							consumable_onetrain_year_16nos,
							b1_check,
							consumable_onetrain_year_6nos,
							b4_check,
							consumable_onetrainb4_year_1nos,
							b8_check,
							consumable_onetrain_yeab8r_1nos,
							totalconsumables_allservicechecks,
							totalconsumables_34trainset_1month,
							totalconsumables_34trainset_1year,
							remarks,
							id
						FROM
							reference
						WHERE
							deleted_at IS NULL
					'''

		self.cursor.execute(queryone)
		refDataResult = self.cursor.fetchall()

		def givingFunctionalityToButton(button, funct, data):
			button.clicked.connect(lambda:funct(data))

		def onbuttonClickedRef(refData):
			from PySide6.QtWidgets import QApplication

			self.refUpdateWindow = QWidget()
			# self.refUpdateWindow.move(400, 100)
			self.refUpdateWindow.setMinimumHeight(self.geometryHeight(0.72))
			self.refUpdateWindow.setMinimumWidth(self.geometryWidth(0.4))		

			self.refUpdateWindow.setWindowTitle(refData[1])
			self.refUpdateWindow.setWindowIcon(QIcon('Media/ramsify.png'))


			scrollArea = QScrollArea()
			scrollArea.setWidgetResizable(True)
			scrollArea.setStyleSheet(self.scrollAreaQSS)
			self.refUpdateWindow.setLayout(QVBoxLayout())
			self.refUpdateWindow.layout().addWidget(scrollArea)

			contentsWidget = QWidget()
			vboxLayout = QVBoxLayout()
			contentsWidget.setLayout(vboxLayout)
			scrollArea.setWidget(contentsWidget)

			formLayout = QFormLayout()
			vboxLayout.addLayout(formLayout)

		
			self.createNumberLineEditBox('srNoLineEdit_Ref_')
			if refData[0]:
				self.srNoLineEdit_Ref_.setText(str(refData[0]))
				self.srNoLineEdit_Ref_.setToolTip(str(refData[0]))
			else:
				pass

			self.createLineEditBox('consumablesLineEdit_Ref_')
			self.consumablesLineEdit_Ref_.setText(refData[1])

			self.createLineEditBox('unitLineEdit_Ref_')
			self.unitLineEdit_Ref_.setText(refData[2])
			self.unitLineEdit_Ref_.setToolTip(refData[2])

			self.createFloatLineEditBox('aCheckLineEdit_Ref_')
			if refData[3]:
				formatted_value = refData[3]		
				self.aCheckLineEdit_Ref_.setText(str(formatted_value))
				self.aCheckLineEdit_Ref_.setToolTip(str(formatted_value))
			else:
				pass

			self.createFloatLineEditBox('consumableFor1Train16nosLineEdit_Ref_')
			if refData[4]:
				formatted_valueone = refData[4]
				self.consumableFor1Train16nosLineEdit_Ref_.setText(str(formatted_valueone))
				self.consumableFor1Train16nosLineEdit_Ref_.setToolTip(str(formatted_valueone))
			else:
				pass

			self.createFloatLineEditBox('b1CheckLineEdit_Ref_')
			if refData[5]:
				formatted_valuetwo = refData[5]  # Optional formatting
				self.b1CheckLineEdit_Ref_.setText(str(formatted_valuetwo))
				self.b1CheckLineEdit_Ref_.setToolTip(str(formatted_valuetwo))
			else:
				pass

			self.createFloatLineEditBox('consumableFor1Train6nosLineEdit_Ref_')
			if refData[6]:
				formatted_valuethree = refData[6]  # Optional formatting
				self.consumableFor1Train6nosLineEdit_Ref_.setText(str(formatted_valuethree))
				self.consumableFor1Train6nosLineEdit_Ref_.setToolTip(str(formatted_valuethree))
			else:
				pass

			self.createFloatLineEditBox('b4CheckLineEdit_Ref_')
			if refData[7]:
				formatted_valuefour = refData[7]
				self.b4CheckLineEdit_Ref_.setText(str(formatted_valuefour))
				self.b4CheckLineEdit_Ref_.setToolTip(str(formatted_valuefour))
			else:
				pass

			self.createFloatLineEditBox('consumableFor1Train1nosOfb4LineEdit_Ref_')
			if refData[8]:
				formatted_valuefive = refData[8]
				self.consumableFor1Train1nosOfb4LineEdit_Ref_.setText(str(formatted_valuefive))
				self.consumableFor1Train1nosOfb4LineEdit_Ref_.setToolTip(str(formatted_valuefive))
			else:
				pass

			self.createFloatLineEditBox('b8CheckLineEdit_Ref_')
			if refData[9]:
				formatted_valuesix = refData[9]
				self.b8CheckLineEdit_Ref_.setText(str(formatted_valuesix))
				self.b8CheckLineEdit_Ref_.setToolTip(str(formatted_valuesix))
			else:
				pass

			self.createFloatLineEditBox('consumableFor1Train1nosOfb8LineEdit_Ref_')
			if refData[10]:
				formatted_valueseven = refData[10]
				self.consumableFor1Train1nosOfb8LineEdit_Ref_.setText(str(formatted_valueseven))
				self.consumableFor1Train1nosOfb8LineEdit_Ref_.setToolTip(str(formatted_valueseven))
			else:
				pass

			self.createFloatLineEditBox('totalConsumableForAllServiceCheckLineEdit_Ref_')
			if refData[11]:
				formatted_valueeight = refData[11]
				self.totalConsumableForAllServiceCheckLineEdit_Ref_.setText(str(formatted_valueeight))
				self.totalConsumableForAllServiceCheckLineEdit_Ref_.setToolTip(str(formatted_valueeight))
			else:
				pass

			self.createFloatLineEditBox('totalConsumablesMonthLineEdit_Ref_')
			if refData[12]:
				formatted_value9 = refData[12]
				self.totalConsumablesMonthLineEdit_Ref_.setText(str(formatted_value9))
				self.totalConsumablesMonthLineEdit_Ref_.setToolTip(str(formatted_value9))
			else:
				pass

			self.createFloatLineEditBox('totalConsumablesYearLineEdit_Ref_')
			if refData[13]:
				formatted_value10 = refData[13]
				self.totalConsumablesYearLineEdit_Ref_.setText(str(formatted_value10))
				self.totalConsumablesYearLineEdit_Ref_.setToolTip(str(formatted_value10))
			else:
				pass

			self.createTextEditBox('remarksLineEdit_ref_')
			self.remarksLineEdit_ref_.setText(refData[14])
			self.remarksLineEdit_ref_.setToolTip(refData[14])
			

			formLayout.addRow('SR No: ', self.srNoLineEdit_Ref_)
			formLayout.addRow('Consumables: <font color="red">*</font>', self.consumablesLineEdit_Ref_)
			formLayout.addRow('Unit: <font color="red">*</font>', self.unitLineEdit_Ref_)
			formLayout.addRow('A Check: ', self.aCheckLineEdit_Ref_)
			formLayout.addRow('Consumable for 1 Train In a Year 16n0s: ', self.consumableFor1Train16nosLineEdit_Ref_)
			formLayout.addRow('B1 Check: ', self.b1CheckLineEdit_Ref_)
			formLayout.addRow('Consumable for 1 Train In a Year 6n0s: ', self.consumableFor1Train6nosLineEdit_Ref_)
			formLayout.addRow('B4 Check: ', self.b4CheckLineEdit_Ref_)
			formLayout.addRow('Consumable for 1 Train In a Year 1n0s: ', self.consumableFor1Train1nosOfb4LineEdit_Ref_)
			formLayout.addRow('B8 Check: ', self.b8CheckLineEdit_Ref_)
			formLayout.addRow('Consumable for 1 Train In a Year 1n0s: ', self.consumableFor1Train1nosOfb8LineEdit_Ref_)
			formLayout.addRow('Total Consumable for All Service Checks: ', self.totalConsumableForAllServiceCheckLineEdit_Ref_)
			formLayout.addRow('Total Consumables Required for 34 Trainset for 1 Month (approx): <font color="red">*</font>', self.totalConsumablesMonthLineEdit_Ref_)
			formLayout.addRow('Total Consumables Required for 34 Trainset for 1 Year: <font color="red">*</font>', self.totalConsumablesYearLineEdit_Ref_)
			formLayout.addRow('Remarks: ', self.remarksLineEdit_ref_)


			self.createPushButton('updateBtn_Ref', 'Update', '', self.geometryWidth(0.042))

			vboxLayout.addWidget(self.updateBtn_Ref, alignment = Qt.AlignCenter)

			allFieldsData_ = [self.srNoLineEdit_Ref_, self.consumablesLineEdit_Ref_, self.unitLineEdit_Ref_, self.aCheckLineEdit_Ref_, self.consumableFor1Train16nosLineEdit_Ref_, 
							self.b1CheckLineEdit_Ref_, self.consumableFor1Train6nosLineEdit_Ref_, self.b4CheckLineEdit_Ref_, self.consumableFor1Train1nosOfb4LineEdit_Ref_,
							self.b8CheckLineEdit_Ref_, self.consumableFor1Train1nosOfb8LineEdit_Ref_, self.totalConsumableForAllServiceCheckLineEdit_Ref_,
							self.totalConsumablesMonthLineEdit_Ref_, self.totalConsumablesYearLineEdit_Ref_, self.remarksLineEdit_ref_]


			def setToolTip(wid, text):
				wid.setToolTip(text)

			def settingToolTipToLineEdits(wid):
				wid.textChanged.connect(lambda: setToolTip(wid, wid.text()))

			def settingToolTipToTextEdits(wid):
				wid.textChanged.connect(lambda: setToolTip(wid, wid.toPlainText()))

			for wid in allFieldsData_:
				if isinstance(wid, QLineEdit):
					settingToolTipToLineEdits(wid)

				if isinstance(wid, QTextEdit):
					settingToolTipToTextEdits(wid)

			def onClickingUpdateRef():
				mandatoryVerification_Ref = True
				mandatoryIndexesRef = [1, 2, 12, 13]
				clickedFormData = []

				for i, wid in enumerate(allFieldsData_):
					if isinstance(wid, QLineEdit):
						text = wid.text()
						if text == '':
							clickedFormData.append(None)
							if i in mandatoryIndexesRef:
								mandatoryVerification_Ref = False
								wid.setProperty("error", True)
								wid.setStyleSheet(self.lineEditBoxQSS)
						else:
							if wid.text().isdigit():
								if '.' in text :
									clickedFormData.append(float(text))
								else:
									clickedFormData.append(int(text))
							else:
								clickedFormData.append(wid.text())
							
							wid.setProperty("error", False)
							wid.setStyleSheet(self.lineEditBoxQSS)

					if isinstance(wid, QTextEdit):
						if wid.toPlainText() == '':
							clickedFormData.append(None)
							if i in mandatoryIndexesRef:
								mandatoryVerification_Ref = False
								wid.setProperty("error", True)
								wid.setStyleSheet(self.textEditBoxQSS)
						else:
							clickedFormData.append(wid.toPlainText())
							wid.setProperty("error", False)
							wid.setStyleSheet(self.textEditBoxQSS)

			
				if not mandatoryVerification_Ref:
					print('Mandatory fields missing.')
					
				else:
					clickedFormData.append(self.user_id)
					clickedId = refData[-1]
					clickedFormData.append(clickedId)

					update_queryone = """
						UPDATE reference
						SET
							sr_no = %s,
							consumables = %s,
							unit = %s,
							a_check = %s,
							consumable_onetrain_year_16nos = %s,
							b1_check = %s,
							consumable_onetrain_year_6nos = %s,
							b4_check = %s,
							consumable_onetrainb4_year_1nos = %s,
							b8_check = %s,
							consumable_onetrain_yeab8r_1nos = %s,
							totalconsumables_allservicechecks = %s,
							totalconsumables_34trainset_1month = %s,
							totalconsumables_34trainset_1year = %s,
							remarks	= %s,
							user_id = %s
						WHERE id = %s
					"""
				
					self.cursor.execute(update_queryone, tuple(clickedFormData))
					self.mydb.commit()
					self.refreshButton_Ref.click()

					refUpdateMsgBox = QMessageBox()
					refUpdateMsgBox.setIcon(QMessageBox.Information) 
					refUpdateMsgBox.setText(f'Data Updated successfully.')
					refUpdateMsgBox.setWindowTitle("Message")
					refUpdateMsgBox.setWindowIcon(QIcon('Media/ramsify.png'))
					refUpdateMsgBox.setStandardButtons(QMessageBox.Ok)
					refUpdateMsgBox.exec_()

					
					self.refreshButton_Cons.click()
					self.refUpdateWindow.close()
	
			self.updateBtn_Ref.clicked.connect(onClickingUpdateRef)
		
			self.refUpdateWindow.show()

		self.referenceDataTable.setRowCount(0)
	
		for rowIndex, rowData in enumerate(refDataResult):
			self.referenceDataTable.insertRow(self.referenceDataTable.rowCount())

			refCheckBoxWidget = QCheckBox('')
			refCheckBoxWidget.setProperty("id", rowData[-1])
			refCheckBoxWidget.setStyleSheet(self.checkBoxQSS)
			self.referenceDataTable.setCellWidget(self.referenceDataTable.rowCount()-1, 0, refCheckBoxWidget)
			refCheckBoxWidget.stateChanged.connect(onStateChangedOf_RefCheckBox)

			for colIndex, refData in enumerate(rowData):
				if colIndex == 1: 
					button = QPushButton(str(refData))
					givingFunctionalityToButton(button, onbuttonClickedRef, rowData)				
					button.setStyleSheet(self.tableButtonQSS)
					button.setCursor(Qt.PointingHandCursor)

					self.referenceDataTable.setCellWidget(self.referenceDataTable.rowCount()-1, 2, button)

				else:
					if refData:
						item = QTableWidgetItem(str(refData))
					else:
						item = QTableWidgetItem('')
					item.setTextAlignment(Qt.AlignCenter)
					item.setToolTip(item.text())
					self.referenceDataTable.setItem(self.referenceDataTable.rowCount() - 1, colIndex + 1, item)
			

	self.refreshButton_Ref.clicked.connect(onClickingrefreshbutton_ref)


	def Onsearchbox_ref_Button():

		searchText = self.serachBarOfRef.text().lower()
		for row in range(self.referenceDataTable.rowCount()):
			self.referenceDataTable.setRowHidden(row, True)

			if self.referenceDataTable.cellWidget(row, 2) and (searchText in self.referenceDataTable.cellWidget(row, 2).text().lower()):
				self.referenceDataTable.setRowHidden(row, False)
				continue

			for col in range(1, self.referenceDataTable.columnCount()):
				if col != 2:
					item = self.referenceDataTable.item(row, col)
					if item is not None and searchText in item.text().lower():
						self.referenceDataTable.setRowHidden(row, False)
						break

	self.serachBarOfRef.textChanged.connect(Onsearchbox_ref_Button)


	def onClickingDownloadBtn_REFDT():

		file_path, _ = QFileDialog.getSaveFileName(self, "Save Excel File", "", "Excel Files (*.xlsx)")

		if file_path:

			wb = Workbook()
			ws = wb.active


			headers = []
			for col in range(1, self.referenceDataTable.columnCount()):
				if not self.referenceDataTable.isColumnHidden(col):
					header_item = self.referenceDataTable.horizontalHeaderItem(col)
					if header_item is not None:
						headers.append(header_item.text())


			ws.append(headers)

			row_index = 2
			for row in range(self.referenceDataTable.rowCount()):
				if not self.referenceDataTable.isRowHidden(row):
					for col in range(self.referenceDataTable.columnCount()):
						if col == 2:
							wid = self.referenceDataTable.cellWidget(row, col)
							if isinstance(wid, QPushButton):
								ws.cell(row=row_index, column=col).value = wid.text()
						else:	
							item = self.referenceDataTable.item(row, col)
							if item is not None:
								ws.cell(row=row_index, column=col).value = item.text()

					row_index += 1


			wb.save(file_path)

			refDownloadedMsgBox = QMessageBox()
			refDownloadedMsgBox.setIcon(QMessageBox.Information) 
			refDownloadedMsgBox.setText(f'Data downloaded successfully')
			refDownloadedMsgBox.setWindowTitle("Message")
			refDownloadedMsgBox.setWindowIcon(QIcon('Media/ramsify.png'))
			refDownloadedMsgBox.setStandardButtons(QMessageBox.Ok)
			refDownloadedMsgBox.exec_()

	self.download_Ref.clicked.connect(onClickingDownloadBtn_REFDT)

	def onclicking_selectall_RefDT(checked):
		if checked:
			self.selectAllRefButton.setIcon(QIcon(checkAllUserIconPath))
			for i in range(self.referenceDataTable.rowCount()):
				if not self.referenceDataTable.isRowHidden(i):
					if isinstance(self.referenceDataTable.cellWidget(i,0), QCheckBox):
						self.referenceDataTable.cellWidget(i,0).setCheckState(Qt.Checked)
		
		else:
			self.selectAllRefButton.setIcon(QIcon(unCheckAllUserIconPath))

			for i in range(self.referenceDataTable.rowCount()):
				if not self.referenceDataTable.isRowHidden(i):
					if isinstance(self.referenceDataTable.cellWidget(i,0), QCheckBox):
						self.referenceDataTable.cellWidget(i,0).setCheckState(Qt.Unchecked)

	self.selectAllRefButton.toggled.connect(onclicking_selectall_RefDT)


	def onStateChangedOf_RefCheckBox():
		all_checked = True
		all_unchecked = True

		for i in range(self.referenceDataTable.rowCount()):
			if not self.referenceDataTable.isRowHidden(i):
				if isinstance(self.referenceDataTable.cellWidget(i,0), QCheckBox):
					if self.referenceDataTable.cellWidget(i,0).isChecked():
						all_unchecked = False
					else:
						all_checked = False

		if all_checked or all_unchecked:
			some_checked = False
		else:
			some_checked = True


		if all_checked:
			self.deleteButton_Ref.show()
			self.selectAllRefButton.setIcon(QIcon(checkAllUserIconPath))
			self.selectAllRefButton.setChecked(True)
			

		if all_unchecked:
			self.deleteButton_Ref.hide()
			self.selectAllRefButton.setIcon(QIcon(unCheckAllUserIconPath))
			self.selectAllRefButton.setChecked(False)

		if some_checked:
			self.deleteButton_Ref.show()
			self.selectAllRefButton.setIcon(QIcon(partiallyCheckedIconPath))


	def onclicking_delete_RefDT():
		selectedrefIndices_ = []
		selectedIndicesInUITable = []

		numberOfSelectedRef = 0

		for i in range(self.referenceDataTable.rowCount()):
			if not self.referenceDataTable.isRowHidden(i):
				if isinstance(self.referenceDataTable.cellWidget(i,0), QCheckBox):
					currentCheckBox = self.referenceDataTable.cellWidget(i,0)
					if currentCheckBox.checkState() == Qt.Checked:
						selectedIndicesInUITable.append(i)
						selectedrefIndices_.append(currentCheckBox.property("id"))
						numberOfSelectedRef += 1
		

		if selectedrefIndices_:

			confirmDeleteRefMsgBox = QMessageBox()
			confirmDeleteRefMsgBox.setIcon(QMessageBox.Question) 
			confirmDeleteRefMsgBox.setText(f"Are you sure you want to delete {numberOfSelectedRef} RefNo(s)?")
			confirmDeleteRefMsgBox.setWindowTitle("Confirm")
			confirmDeleteRefMsgBox.setWindowIcon(QIcon('Media/ramsify.png'))
			confirmDeleteRefMsgBox.setStandardButtons(QMessageBox.Ok | QMessageBox.No)
			
			userResponse = confirmDeleteRefMsgBox.exec()

			if userResponse == QMessageBox.Ok:
				current_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
				for ind in sorted(selectedrefIndices_, reverse=True):
					sql = "UPDATE reference SET deleted_at = %s WHERE id = %s"
					values = (current_time, ind)
					self.cursor.execute(sql, values)
					self.mydb.commit()
				
				for ind in sorted(selectedIndicesInUITable, reverse=True):
					self.referenceDataTable.removeRow(ind)

				refDeleteSuccessMsgBox = QMessageBox()
				refDeleteSuccessMsgBox.setIcon(QMessageBox.Information) 
				refDeleteSuccessMsgBox.setText(f'{numberOfSelectedRef} Refs deleted successfully.')
				refDeleteSuccessMsgBox.setWindowTitle("Message")
				refDeleteSuccessMsgBox.setWindowIcon(QIcon('Media/ramsify.png'))
				refDeleteSuccessMsgBox.setStandardButtons(QMessageBox.Ok)
				refDeleteSuccessMsgBox.exec()
			
				self.deleteButton_Ref.hide()
				self.selectAllRefButton.setIcon(QIcon(unCheckAllUserIconPath))

				for ind in sorted(selectedrefIndices_, reverse=True):
					sql = "UPDATE consumables_form_beml SET deleted_at = %s, user_id = %s WHERE consumable_id = %s"
					values = (current_time, self.user_id, ind)
					self.cursor.execute(sql, values)
					self.mydb.commit()


				self.refreshButton_Cons.click()
			
			else:
				pass


	self.deleteButton_Ref.clicked.connect(onclicking_delete_RefDT)

	onClickingrefreshbutton_ref()