from PySide6.QtWidgets import QTableWidgetItem, QSpacerItem, QSizePolicy, QMessageBox, QPushButton, QAbstractItemView, QDateEdit, QLineEdit, QFileDialog, QTextEdit, QWidget, QLabel, QScrollArea, QHBoxLayout, QVBoxLayout, QFormLayout, QHeaderView
from functions import TableWidget
from PySide6.QtCore import Qt, QDate
from PySide6.QtGui import QIcon, QColor, QBrush
from datetime import date, datetime
from openpyxl import Workbook

def consumableDataUI(self, layout):
	from PySide6.QtWidgets import QApplication, QLabel

	downloadIconPath = self.currentTheme.get('downloadIcon')
	refreshTableIconPath = self.currentTheme.get('refreshIcon')
	deleteIconPath = self.currentTheme.get('deleteIcon')

	self.createLineEditBox('serachBarOfCons', 'Search...' )
	self.serachBarOfCons.setClearButtonEnabled(True)
	self.serachBarOfCons.setFixedWidth(self.geometryWidth(0.2))
	self.createPushButton('download_Cons', '', downloadIconPath, 35, 'Download')
	self.createPushButton('refreshButton_Cons', '', refreshTableIconPath, 35, 'Refresh')
	self.createPushButton('reportButton_Cons', 'Report', '', 69)

	self.fromFormLayout_Cons = QFormLayout()
	self.toFormLayout_Cons = QFormLayout()

	self.createDateEditBox('fromDateEditBox_Cons')
	self.fromDateEditBox_Cons.setMinimumDate(QDate(2000, 1, 1))
	
	self.createDateEditBox('toDateEditBox_Cons')
	self.toDateEditBox_Cons.setMinimumDate(QDate(2000, 1, 1))

	current_date = QDate.currentDate()
	start_of_month = QDate(current_date.year(), current_date.month(), 1)
	self.toDateEditBox_Cons.setDate(start_of_month)	

	self.fromFormLayout_Cons.addRow(QLabel('From:'), self.fromDateEditBox_Cons)
	self.toFormLayout_Cons.addRow(QLabel('To:'), self.toDateEditBox_Cons)

	self.createPushButton('editButton_Cons', 'Edit', '', self.geometryWidth(0.025))
	self.createPushButton('saveButton_Cons',  'Save', '', self.geometryWidth(0.028))
	self.createPushButton('editCancelButton_Cons', 'Cancel', '', self.geometryWidth(0.037))


	self.consHboxLayout = QHBoxLayout()
	self.consHboxLayout.addWidget(self.serachBarOfCons)
	self.consHboxLayout.addWidget(self.download_Cons)
	self.consHboxLayout.addWidget(self.refreshButton_Cons)
	self.consHboxLayout.addLayout(self.fromFormLayout_Cons)
	self.consHboxLayout.addLayout(self.toFormLayout_Cons)
	self.consHboxLayout.addItem(QSpacerItem(1, 0, QSizePolicy.Expanding, QSizePolicy.Minimum))
	self.consHboxLayout.addWidget(self.saveButton_Cons)
	self.consHboxLayout.addWidget(self.editCancelButton_Cons)
	self.consHboxLayout.addWidget(self.editButton_Cons)
	self.consHboxLayout.addWidget(self.reportButton_Cons)
	layout.addLayout(self.consHboxLayout)
	self.saveButton_Cons.setVisible(False)
	self.editCancelButton_Cons.setVisible(False)

	self.consumableDataTable = TableWidget()
	
	self.headersOfconsumableDataTable  = ['Sr No', 'Consumables', 'Unit', 'Total Consumables Required\nfor 34 Trainsets for 1Year', 'Total Consumables Supplied By BEML\nfrom Start of Revenue Till Date',
										 'Consumables Availaible\nWith MMMOCL', 'No of Months\ncan be Covered']

	self.consumableDataTable.setColumnCount(len(self.headersOfconsumableDataTable))
	self.consumableDataTable.setHorizontalHeaderLabels(self.headersOfconsumableDataTable)
	self.consumableDataTable.setStyleSheet(self.tableWidgetQSS)
	self.consumableDataTable.horizontalHeader().setStyleSheet(self.headerHorizontalQSS)
	self.consumableDataTable.setAlternatingRowColors(True)
	self.consumableDataTable.setShowGrid(False)
	layout.addWidget(self.consumableDataTable)

	# self.consumableDataTable.setEditTriggers(QAbstractItemView.NoEditTriggers)

	self.consumableDataTable.setColumnWidth(0, self.geometryWidth(0.09))
	self.consumableDataTable.setColumnWidth(1, self.geometryWidth(0.12))
	self.consumableDataTable.setColumnWidth(2, self.geometryWidth(0.09))
	self.consumableDataTable.setColumnWidth(3, self.geometryWidth(0.13))
	self.consumableDataTable.setColumnWidth(4, self.geometryWidth(0.16))
	self.consumableDataTable.setColumnWidth(5, self.geometryWidth(0.12))
	self.consumableDataTable.setColumnWidth(6, self.geometryWidth(0.1))

	def onClickingrefreshbutton_consu():
		queryone = '''
			SELECT
				sr_no,
				consumables,
				unit,
				totalconsumables_34trainset_1year,
				consumable_available_mmmocl,
				totalconsumables_34trainset_1month,
				id
			FROM
				reference
			WHERE
				deleted_at IS NULL					
					
		'''

		self.cursor.execute(queryone)
		refDataResult = self.cursor.fetchall()

		self.allIdsInBigTable = [tup[-1] for tup in refDataResult]

		def givingFunctionalityToButtonInBigTable(button, funct, bigTableRowData, filtered_data):
			button.clicked.connect(lambda:funct(bigTableRowData, filtered_data))

		# Below Function will be executed on clicking button in BIG Table.
		def onbuttonClickedInBigTable(bigTableRowData, filtered_data):

			from PySide6.QtWidgets import QApplication

			self.consumFormWindow = QWidget()
			self.consumFormWindow.move(400, 100)
			self.consumFormWindow.resize(500, 500)

			self.consumFormWindow.setWindowTitle(bigTableRowData[1])
			self.consumFormWindow.setWindowIcon(QIcon('Media/ramsify.png'))

			scrollArea = QScrollArea()
			scrollArea.setWidgetResizable(True)
			scrollArea.setStyleSheet(self.scrollAreaQSS)
			self.consumFormWindow.setLayout(QVBoxLayout())
			self.consumFormWindow.layout().addWidget(scrollArea)

			contentsWidget = QWidget()
			vboxLayout = QVBoxLayout()
			contentsWidget.setLayout(vboxLayout)
			scrollArea.setWidget(contentsWidget)
		
			self.consumFormDataTable = TableWidget()
			# self.consumFormDataTable.setMinimumHeight(self.geometryHeight(0.19))
		
			self.headersOfconsumFormDataTable  = ['Jobcard No', 'Date', 'Quantity', '']
			self.consumFormDataTable.setColumnCount(len(self.headersOfconsumFormDataTable))
				
			self.consumFormDataTable.setHorizontalHeaderLabels(self.headersOfconsumFormDataTable)
			self.consumFormDataTable.setStyleSheet(self.tableWidgetQSS)
			self.consumFormDataTable.horizontalHeader().setStyleSheet(self.headerHorizontalQSS)
			self.consumFormDataTable.setAlternatingRowColors(True)
			self.consumFormDataTable.setShowGrid(False)
			vboxLayout.addWidget(self.consumFormDataTable)
			self.consumFormDataTable.setEditTriggers(QAbstractItemView.NoEditTriggers)

			self.consumFormDataTable.setColumnWidth(0, self.geometryWidth(0.08))
			self.consumFormDataTable.setColumnWidth(1, self.geometryWidth(0.06))
			self.consumFormDataTable.setColumnWidth(2, self.geometryWidth(0.06))
			self.consumFormDataTable.setColumnWidth(3, self.geometryWidth(0.01))


			formLayout = QFormLayout()
			vboxLayout.addLayout(formLayout)

			self.createLineEditBox('jobcardLineEdit_Consum')
			self.createEmptyDateEditBox('date_Consum')
			self.createNumberLineEditBox('quantityLineEdit_Consum')

			formLayout.addRow('Jobcard: <font color="red">*</font>', self.jobcardLineEdit_Consum)
			formLayout.addRow('Date: <font color="red">*</font>', self.date_Consum)
			formLayout.addRow('Quantity: <font color="red">*</font>', self.quantityLineEdit_Consum)

			self.createPushButton('submitBtn_Consum', 'Submit', '', self.geometryWidth(0.035))
			self.createPushButton('updateBtn_Consum', 'Update', '', self.geometryWidth(0.035))
			self.createPushButton('cancelBtn_Consum', 'Cancel', '', self.geometryWidth(0.036))
			self.createPushButton('deleteBtn_Consum', 'Delete', '', self.geometryWidth(0.01))


			hBoxLayout = QHBoxLayout()
			hBoxLayout.addWidget(self.submitBtn_Consum)
			hBoxLayout.addWidget(self.updateBtn_Consum)
			hBoxLayout.addWidget(self.cancelBtn_Consum)
			vboxLayout.addLayout(hBoxLayout)


			allFieldsData = [self.jobcardLineEdit_Consum, self.date_Consum, self.quantityLineEdit_Consum]
		
		
			def setToolTip(wid, text):
				wid.setToolTip(text)
		
			def settingToolTipToLineEdits(wid):
				wid.textChanged.connect(lambda: setToolTip(wid, wid.text()))
		
			def settingToolTipToTextEdits(wid):
				wid.textChanged.connect(lambda: setToolTip(wid, wid.toPlainText()))
		
			for wid in allFieldsData:
				if isinstance(wid, QLineEdit):
					settingToolTipToLineEdits(wid)

				if isinstance(wid, QTextEdit):
					settingToolTipToTextEdits(wid)
			
			# consumable_id = bigTableRowData[-1]

			def givingFunctionalityToButtonInSmallTable(dabutton, fun, conuBemlData, addedRowIndex):
				dabutton.clicked.connect(lambda:fun(conuBemlData, addedRowIndex))

			# Below Function will be executed on clicking button in SMALL Table.
			def onclickingButtonInSmallTable(conuBemlData, tableRowIndex):

				self.submitBtn_Consum.setVisible(False)
				self.updateBtn_Consum.setVisible(True)
				self.cancelBtn_Consum.setVisible(True)

				self.updateBtn_Consum.setProperty('id', conuBemlData[-1])
				self.updateBtn_Consum.setProperty('row', tableRowIndex)

				self.jobcardLineEdit_Consum.setText(str(conuBemlData[0]))  # Set Jobcard

				if conuBemlData[1]:
					date_obj = conuBemlData[1]
					self.date_Consum.setDate(QDate(date_obj.year, date_obj.month, date_obj.day))  # Set Date
				else:
					self.date_Consum.setDate(QDate())
					self.date_Consum.lineEdit().setText(' ')
			
				if conuBemlData[2]:
					self.quantityLineEdit_Consum.setText(str(conuBemlData[2]))  # Set Quantity
				else:
					pass



			def addRowToSmallTable(rowData):
				self.consumFormDataTable.insertRow(self.consumFormDataTable.rowCount())
				addedRowIndex = self.consumFormDataTable.rowCount()-1
				for col, value in enumerate(rowData):
					if col == 0:
						button = QPushButton(str(value))
						givingFunctionalityToButtonInSmallTable(button, onclickingButtonInSmallTable, rowData, addedRowIndex)	
						button.setStyleSheet(self.tableButtonQSS)
						
						button.setCursor(Qt.PointingHandCursor)
						self.consumFormDataTable.setCellWidget(addedRowIndex, col, button)
	

					elif col == 3:  # Skip the 4th column
						continue
					else:
						
						value = str(rowData[col])

						item = QTableWidgetItem(value)
						item.setTextAlignment(Qt.AlignCenter)
						item.setToolTip(item.text())
						self.consumFormDataTable.setItem(addedRowIndex, col, item)



				button = QPushButton('')
				button = QPushButton('', icon=QIcon(deleteIconPath))
				button.setProperty('id', rowData[-1])
				button.clicked.connect(self.onClickingDeleteInSmallTable_consumable)
				self.consumFormDataTable.setCellWidget(addedRowIndex, col, button)




			for row, conuBemlData in enumerate(filtered_data):
				addRowToSmallTable(conuBemlData)


			self.consumFormDataTable.show()
			self.updateBtn_Consum.setVisible(False)
			self.cancelBtn_Consum.setVisible(False)



			def onClickingsubmitDataButton():
				mandatoryVerification_Consum = True
				mandatoryIndexesConsum = [0, 1, 2]
				consTableData = []
		
		
				for i, wid in enumerate(allFieldsData):
					if isinstance(wid, QLineEdit):
						if wid.text() == '':
							consTableData.append(None)
							if i in mandatoryIndexesConsum:
								mandatoryVerification_Consum = False
								wid.setProperty("error", True)
								wid.setStyleSheet(self.lineEditBoxQSS)
						else:
							if wid.text().isdigit():
								consTableData.append(int(wid.text()))
							else:
								consTableData.append(wid.text()) 	
		
							wid.setProperty("error", False)
							wid.setStyleSheet(self.lineEditBoxQSS)

					elif isinstance(wid, QDateEdit):
						if i in mandatoryIndexesConsum:
							if wid.lineEdit().text() == ' ':
								mandatoryVerification_Consum = False
								wid.setProperty("error", True)
								wid.setStyleSheet(self.dateEditBoxQSS)
								consTableData.append(None)
							else:
								qdate = wid.date()
								py_date = date(qdate.year(), qdate.month(), qdate.day())  # Convert QDate to Python date
								consTableData.append(py_date)
								wid.setProperty("error", False)
								wid.setStyleSheet(self.dateEditBoxQSS)
						else:
							if wid.lineEdit().text() == ' ':
								consTableData.append(None)
							else:
								qdate = wid.date()
								py_date = date(qdate.year(), qdate.month(), qdate.day())  # Convert QDate to Python date
								consTableData.append(py_date)


		
				consTableData.append(self.user_id)
				consumableid = bigTableRowData[-1]
				consTableData.append(consumableid)
		

				if not mandatoryVerification_Consum:
					print('Mandatory fields missing.')
		
				else:
		
					query = """
						INSERT INTO consumables_form_beml				
						(jobcard, revenuedate, quantity, user_id, consumable_id ) 
						VALUES (%s, %s, %s, %s, %s)
					"""

					self.cursor.execute(query, tuple(consTableData))
					self.mydb.commit()
					self.refreshButton_Cons.click()

					#Fetching the id of last Row in consumables_form_beml
					query2 = """
						SELECT id FROM consumables_form_beml
						ORDER BY id DESC LIMIT 1
					"""
					self.cursor.execute(query2)
					result = self.cursor.fetchone()

					addRowToSmallTable([consTableData[0], consTableData[1], consTableData[2], result[0]])
					

					self.jobcardLineEdit_Consum.clear()
					self.date_Consum.setDate(QDate())
					self.date_Consum.lineEdit().setText(' ')
					self.date_Consum.setProperty("error", False)
					self.date_Consum.setStyleSheet(self.dateEditBoxQSS)
					self.quantityLineEdit_Consum.clear()

					self.refreshButton_Cons.click()

			self.submitBtn_Consum.clicked.connect(onClickingsubmitDataButton)

			self.consumFormWindow.show()

			def onClickingUpdateFormData():

				mandatoryVerification_Consum = True
				mandatoryIndexesConsum = [0, 1, 2]
				clickedTableFormData = []
			
				for i, wid in enumerate(allFieldsData):
					if isinstance(wid, QLineEdit):
						if wid.text() == '':
							clickedTableFormData.append(None)
							if i in mandatoryIndexesConsum:
								mandatoryVerification_Consum = False
								wid.setProperty("error", True)
								wid.setStyleSheet(self.lineEditBoxQSS)
						else:
							if wid.text().isdigit():
								clickedTableFormData.append(int(wid.text()))
							else:
								clickedTableFormData.append(wid.text()) 	
		
							wid.setProperty("error", False)
							wid.setStyleSheet(self.lineEditBoxQSS)
		
					if isinstance(wid, QDateEdit):
						if i in mandatoryIndexesConsum:
							if wid.lineEdit().text() == ' ':
								mandatoryVerification_Consum = False
								wid.setProperty("error", True)
								wid.setStyleSheet(self.dateEditBoxQSS)
								clickedTableFormData.append(None)
							else:
								qdate = wid.date()
								py_date = date(qdate.year(), qdate.month(), qdate.day())  # Convert QDate to Python date
								clickedTableFormData.append(py_date)
								wid.setProperty("error", False)
								wid.setStyleSheet(self.dateEditBoxQSS)
						else:
							if wid.lineEdit().text() == ' ':
								clickedTableFormData.append(None)
							else:
								qdate = wid.date()
								py_date = date(qdate.year(), qdate.month(), qdate.day())  # Convert QDate to Python date
								clickedTableFormData.append(py_date)

		
				clickedTableFormData.append(self.user_id)
		
				if not mandatoryVerification_Consum:
					print('Mandatory fields missing...')
		
				else:

					idOfClickedButtonInSmallTable = self.updateBtn_Consum.property('id')
					clickedTableFormData.append(idOfClickedButtonInSmallTable)	
					
					update_queryone = """
						UPDATE consumables_form_beml
						SET							
							jobcard = %s,
							revenuedate = %s,
							quantity = %s,			
							user_id = %s
						WHERE id = %s
					"""
					
					self.cursor.execute(update_queryone, tuple(clickedTableFormData))
					self.mydb.commit()
					consUpdateMsgBox = QMessageBox()
					consUpdateMsgBox.setIcon(QMessageBox.Information) 
					consUpdateMsgBox.setText(f'Data Updated successfully.')
					consUpdateMsgBox.setWindowTitle("Message")
					consUpdateMsgBox.setWindowIcon(QIcon('Media/ramsify.png'))
					consUpdateMsgBox.setStandardButtons(QMessageBox.Ok)
					consUpdateMsgBox.exec_()


					currentRow = self.updateBtn_Consum.property('row')
					dbIdOfClickedRow = self.updateBtn_Consum.property('id')
					self.consumFormDataTable.cellWidget(currentRow, 0).setText(str(clickedTableFormData[0]))
					self.consumFormDataTable.setItem(currentRow, 1, QTableWidgetItem(clickedTableFormData[1].strftime("%d-%m-%Y")))
					self.consumFormDataTable.setItem(currentRow, 2, QTableWidgetItem(str(clickedTableFormData[2])))


					self.consumFormDataTable.cellWidget(currentRow, 0).clicked.connect(lambda: onclickingButtonInSmallTable(clickedTableFormData+[dbIdOfClickedRow], currentRow))

					self.cancelBtn_Consum.click()
					self.refreshButton_Cons.click()


			self.updateBtn_Consum.clicked.connect(onClickingUpdateFormData)



			def onClickingCancelFormData():
				for i, wid in enumerate(allFieldsData):
					if isinstance(wid, QLineEdit):
						wid.clear()
						wid.setProperty("error", False)
						wid.setStyleSheet(self.lineEditBoxQSS)

					elif isinstance(wid, QDateEdit):
						wid.setDate(QDate())
						wid.lineEdit().setText(' ')
						wid.setProperty("error", False)
						wid.setStyleSheet(self.dateEditBoxQSS)


				self.submitBtn_Consum.setVisible(True)
				self.updateBtn_Consum.setVisible(False)
				self.cancelBtn_Consum.setVisible(False)


			self.cancelBtn_Consum.clicked.connect(onClickingCancelFormData)


			
		self.consumableDataTable.setRowCount(0)
		
		for row, condata in enumerate(refDataResult):
			self.consumableDataTable.insertRow(self.consumableDataTable.rowCount())
	
			from_date = self.fromDateEditBox_Cons.date().toString("yyyy-MM-dd")
			to_date = self.toDateEditBox_Cons.date().toString("yyyy-MM-dd")

			queryone = '''
							SELECT
								jobcard,
								revenuedate,
								quantity,
								id
							FROM
								consumables_form_beml
							WHERE
								deleted_at IS NULL
								AND consumable_id = %s
								AND revenuedate BETWEEN %s AND %s
						'''

			self.cursor.execute(queryone, (condata[-1], from_date, to_date))
			filtered_data = self.cursor.fetchall()
			
			total = sum(row[2] for row in filtered_data)

			item = QTableWidgetItem(str(total))
			item.setTextAlignment(Qt.AlignCenter)
			tooltip_text = "\n".join([f"{entry[0]}, {entry[1]}, {entry[2]}" for entry in filtered_data])
			item.setToolTip(tooltip_text)
			item.setFlags(item.flags() & ~Qt.ItemIsEditable)
			self.consumableDataTable.setItem(row, 4, item)

			
			def refreshingTable():
				self.refreshButton_Cons.click()

			self.fromDateEditBox_Cons.dateChanged.connect(refreshingTable)
			self.toDateEditBox_Cons.dateChanged.connect(refreshingTable)

			if condata[4]:
				value = condata[4]
			else:
				value = 0

			item = QTableWidgetItem(str(value))
			item.setTextAlignment(Qt.AlignCenter)
			item.setToolTip(item.text())
			item.setFlags(item.flags() & ~Qt.ItemIsEditable)
			self.consumableDataTable.setItem(row, 5, item)

			if not condata[4] or not condata[5]:
				item = QTableWidgetItem(str(0))
			else:
				# consumable mmocl / totalconsumables for34 per month
				howManyMonthscovered = condata[4] / condata[5]
				formatted_value = f"{howManyMonthscovered:.2f}"	
				item = QTableWidgetItem(formatted_value)

			item.setTextAlignment(Qt.AlignCenter)
			item.setFlags(item.flags() & ~Qt.ItemIsEditable)
			self.consumableDataTable.setItem(row, 6, item)
		

			for col, value in enumerate(condata[:-3]):
				if col == 1:
					button = QPushButton(value)
					givingFunctionalityToButtonInBigTable(button, onbuttonClickedInBigTable, condata, filtered_data)				
					button.setStyleSheet(self.tableButtonQSS)
					button.setCursor(Qt.PointingHandCursor)
					self.consumableDataTable.setCellWidget(row, col, button)

				else:
					if value:
						item = QTableWidgetItem(str(value))
					else:
						item = QTableWidgetItem('')
					item.setTextAlignment(Qt.AlignCenter)
					item.setToolTip(item.text())
					item.setFlags(item.flags() & ~Qt.ItemIsEditable)
					self.consumableDataTable.setItem(row, col, item)

	self.refreshButton_Cons.clicked.connect(onClickingrefreshbutton_consu)


	def onClickingEditTableData():
		self.editButton_Cons.setVisible(False)
		self.saveButton_Cons.setVisible(True)
		self.editCancelButton_Cons.setVisible(True)

		editableColumn = self.consumableDataTable.columnCount() - 2



		for row in range(self.consumableDataTable.rowCount()):
			item = self.consumableDataTable.item(row, editableColumn)
			if item:
				item.setFlags(item.flags() | Qt.ItemIsEditable)
				item.setBackground(QBrush(QColor("#bdd7ee")))

	def onClickingEditCancelFormData():
		self.editButton_Cons.setVisible(True)
		self.saveButton_Cons.setVisible(False)
		self.editCancelButton_Cons.setVisible(False)

		editableColumn = self.consumableDataTable.columnCount() - 2

		for row in range(self.consumableDataTable.rowCount()):
			item = self.consumableDataTable.item(row, editableColumn)
			item.setFlags(item.flags() & ~Qt.ItemIsEditable)
			item.setBackground(QBrush(QColor('transparent')))


	def onClickingSaveMMOCLDataButton():
		allids = self.allIdsInBigTable
		mmmocltable_data = []
		editableColumn = self.consumableDataTable.columnCount() - 2
		for row in range(self.consumableDataTable.rowCount()):
			item = self.consumableDataTable.item(row, editableColumn)
			if item:
				mmmocltable_data.append(float(item.text()))
		
		if len(allids) != len(mmmocltable_data):
			print("Error: Mismatch between IDs and table data lengths!")
			return

		data_to_insert = list(zip(mmmocltable_data, allids))


		# update data into the 'reference' table
		query = """
					UPDATE reference
					SET							
						consumable_available_mmmocl = %s
					WHERE id = %s
				"""
		for i, item in enumerate(data_to_insert):
			self.cursor.execute(query, data_to_insert[i])

		self.mydb.commit()
		self.refreshButton_Cons.click()


		self.saveButton_Cons.setVisible(False)
		self.editCancelButton_Cons.setVisible(False)
		self.editButton_Cons.setVisible(True)


	self.saveButton_Cons.clicked.connect(onClickingSaveMMOCLDataButton)
	self.editCancelButton_Cons.clicked.connect(onClickingEditCancelFormData)
	self.editButton_Cons.clicked.connect(onClickingEditTableData)


	def onChangingSearchBar_consu():

		searchText = self.serachBarOfCons.text().lower()

		for row in range(self.consumableDataTable.rowCount()):
			self.consumableDataTable.setRowHidden(row, True)

			if self.consumableDataTable.cellWidget(row, 1) and (searchText in self.consumableDataTable.cellWidget(row, 1).text().lower()):
				self.consumableDataTable.setRowHidden(row, False)
				continue

			for col in range(self.consumableDataTable.columnCount()):
				if col != 1:
					item = self.consumableDataTable.item(row, col)
					if item is not None and searchText in item.text().lower():
						self.consumableDataTable.setRowHidden(row, False)
						break

	self.serachBarOfCons.textChanged.connect(onChangingSearchBar_consu)


	def onClickingDownloadBtn_ConsDT():
		file_path, _ = QFileDialog.getSaveFileName(self, "Save Excel File", "", "Excel Files (*.xlsx)")

		if file_path:

			wb = Workbook()
			ws = wb.active

			headers = []
			for col in range(self.consumableDataTable.columnCount()):
				if not self.consumableDataTable.isColumnHidden(col):
					header_item = self.consumableDataTable.horizontalHeaderItem(col)
					if header_item is not None:
						headers.append(header_item.text())

			ws.append(headers)
			row_index = 2
			for row in range(self.consumableDataTable.rowCount()):
				if not self.consumableDataTable.isRowHidden(row):
					for col in range(self.consumableDataTable.columnCount()):
						if col == 1:
							wid = self.consumableDataTable.cellWidget(row, col)
							if isinstance(wid, QPushButton):
								ws.cell(row=row_index, column=col + 1).value = wid.text()
					
						else:	
							item = self.consumableDataTable.item(row, col)
							if item is not None:
								ws.cell(row=row_index, column=col+1).value = item.text()

					row_index += 1 	

			wb.save(file_path)

			consDownloadedMsgBox = QMessageBox()
			consDownloadedMsgBox.setIcon(QMessageBox.Information) 
			consDownloadedMsgBox.setText(f'Data downloaded successfully')
			consDownloadedMsgBox.setWindowTitle("Message")
			consDownloadedMsgBox.setWindowIcon(QIcon('Media/ramsify.png'))
			consDownloadedMsgBox.setStandardButtons(QMessageBox.Ok)
			consDownloadedMsgBox.exec_()

	self.download_Cons.clicked.connect(onClickingDownloadBtn_ConsDT)
	

	def onClickingReport_consDt():
		consumablesData = []
		header_title = f'CONSUMABLES REPORT'

		# Add the header title as a paragraph
		consumablesData.append(header_title)

		##########################################################

		tableNamesList = [f'Consumables for {self.fromDateEditBox_Cons.date().toString('dd-MM-yyyy')} to {self.toDateEditBox_Cons.date().toString('dd-MM-yyyy')}']

		##########################################################

		table_data = []

		header_text = []
		for col in range(self.consumableDataTable.columnCount()):
			header_item = self.consumableDataTable.horizontalHeaderItem(col)
			if header_item:
				header_text.append(header_item.text())

		# Add the table to the consumablesData
		table_data.append(header_text)



		for row in range(self.consumableDataTable.rowCount()):
			row_data = []
			for col in range(self.consumableDataTable.columnCount()):
				if col == 1:
					button = self.consumableDataTable.cellWidget(row, col)
					if button:
						row_data.append(button.text())
					else:
						row_data.append('')
				else:
					item = self.consumableDataTable.item(row, col)
					if item:
						row_data.append(item.text())
					else:
						row_data.append('')

			table_data.append(row_data)



		# Add the caption as a paragraph
		consumablesData.append(table_data)

		# Generate the report
		# self.generate_pdf_report(selected_report_title, consumablesData, tableNamesList, 0, [])
		self.generate_pdf_report('', consumablesData, tableNamesList, 1, [])

	self.reportButton_Cons.clicked.connect(onClickingReport_consDt)

	onClickingrefreshbutton_consu()

def onClickingDeleteInSmallTable_consumable(self):
	button = self.sender()
	if button:
		index = self.consumFormDataTable.indexAt(button.pos())
		row = index.row()

		jcNumber = self.consumFormDataTable.cellWidget(row, 0).text()
		dataBaseId = button.property('id')

		confirmDeleteConsMsgBox = QMessageBox()
		confirmDeleteConsMsgBox.setIcon(QMessageBox.Question) 
		confirmDeleteConsMsgBox.setText(f"Are you sure you want to delete {jcNumber}")
		confirmDeleteConsMsgBox.setWindowTitle("Confirm")
		confirmDeleteConsMsgBox.setWindowIcon(QIcon('Media/ramsify.png'))
		confirmDeleteConsMsgBox.setStandardButtons(QMessageBox.Ok | QMessageBox.No)
		
		userResponse = confirmDeleteConsMsgBox.exec()

		if userResponse == QMessageBox.Ok:

			current_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
			update_queryone = """
								UPDATE consumables_form_beml
								SET																
									user_id = %s,
									deleted_at = %s
								WHERE id = %s
							"""
			self.cursor.execute(update_queryone, (self.user_id, current_time, dataBaseId))
			self.mydb.commit()
			
			self.consumFormDataTable.removeRow(row)

			consDeletedMsgBox = QMessageBox()
			consDeletedMsgBox.setIcon(QMessageBox.Information) 
			consDeletedMsgBox.setText(f'{jcNumber} Deleted successfully.')
			consDeletedMsgBox.setWindowTitle("Message")
			consDeletedMsgBox.setWindowIcon(QIcon('Media/ramsify.png'))
			consDeletedMsgBox.setStandardButtons(QMessageBox.Ok)
			consDeletedMsgBox.exec_()



			self.cancelBtn_Consum.click()
			self.refreshButton_Cons.click()

