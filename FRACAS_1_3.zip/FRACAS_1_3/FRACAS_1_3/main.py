from PySide6.QtWidgets import QVBoxLayout, QSpacerItem, QSizePolicy, QLabel, QProgressBar
from PySide6.QtCore import Qt, QSettings
from PySide6.QtGui import QIcon, QFont, QFontDatabase
from PySide6.QtWidgets import QApplication, QMainWindow, QPushButton
from PySide6.QtUiTools import loadUiType

import sys
import time

from loginForm import *

Ui_MainWindow, QMainWindowBase = loadUiType("uifile.ui")
class MainWindow(QMainWindow, Ui_MainWindow):

	from functions import (logErrors, readIniFile, connectDB, createCheckBoxes, createComboBox, createComboBox2, createDateTimeEditBox, createTextEditBox, createRadioButtons, createPushButton, browseFiles,
					createLayout, removeAttachment, openAttachment, createLineEditBox, createTableView, createListView, createDateEditBox, createTimeEditBox,
					create_folder_if_not_exists, logout, topItems, childrenOf, createSpinBox, mapImportedDataToWidgets, CustomSpinBox,
					generate_pdf_report, onClickingRemoveButn, createCheckableComboBox, FileAttachmentWidget, createAttachmentWidget, onClickingRemoveButn_OPM,
					createStackedBarChart, CustomValueAxis, showContextMenu, createPieChart, createLineChart, createBarChart, NumberLineEdit, createNumberLineEditBox, NumberLineEdit, createFloatLineEditBox,
					geometryWidth, geometryHeight, createEmptyDateEditBox)
	from sideMenu import (on_menu_button_clicked, onSideMenuTreeItemClicked, on_home_btn_clicked, on_settings_btn_clicked, sideTreeMenu, buttonsOnSideMenu, 
							onClickingConfigurationBtn)

	from configurationPage import configurationUI, onClickingRefresh_users
	from hideAndUnhide import hideOrUnhideFunction
	from menuBar import menuBarActions
	from tables import createTables
	from toolBar import toolBarFunction, onTriggeringSettingsAction, onTriggeringHelpAction
	from settings import settingsUI, onChangingFontCombobox, onChangingThemeCombobox

	from settingTheme import settingThemeFunction
	from QSSS import QSSValues

	from databaseData import databaseData
	from runningMileage import runningMileageUI
	from maintenance import maintenanceUI

	from maintenanceData import maintenanceDataUI
	from cmData import onButtonClicked_cmData
	from opmData import onButtonClicked_opmData
	# from scData import onButtonClicked_scData
	from home import homeUi, onClickingRefresh_home

	from dashboards.availabilityDashboard import availabilityUi, onClickingRefresh_availDash
	from dashboards.mdbfDashboard import mdbfUi, onClickingRefresh_MDBF
	from dashboards.trainSummary import trainSummaryUi
	from dashboards.patternFailure import patternFailureUi, onClickingRefresh_PF
	from dashboards.dashboardRunningMielage import dashboardRunningmileageUI, onClickingRefresh_RM
	from dashboards.systemsFailures import systemsFailuresUi, onClickingRefresh_SRF
	from dashboards.mttrDashboard import mttrDashboardUi, onClickingRefresh_MTTR
	from dashboards.mdbcfDashboard import mdbcfDashboardUi, onClickingRefresh_MDBCF


	from ncr import ncrUI
	from ncrform import ncrformUI
	from tandc import tandcDataUI
	from consumablesMain import consumablesMainTabDataUI
	from consumableData import onClickingDeleteInSmallTable_consumable
	from dlpSpares import dlpsparesDataUI

	from generateReports import generateReportFunction
	# from monthlyReport import generateMonthlyReport
	



	@logErrors
	def __init__(self):
		super(MainWindow,self).__init__()

		# pixmap = QPixmap("Media/Splashscreen11.png")
		# splashScreen = QSplashScreen(pixmap)
		# splashScreen.show()
		# start_time = time.time()
		font_id = QFontDatabase.addApplicationFont("Roboto-Regular.ttf")
		font_family = QFontDatabase.applicationFontFamilies(font_id)[0]
		custom_font = QFont(font_family)
		custom_font.setPointSize(int(0.006 * QApplication.primaryScreen().availableGeometry().width()))
		QApplication.setFont(custom_font)

		self.setupUi(self)
		screen = QApplication.primaryScreen()

		self.loadingWindow = QWidget()
		self.loadingWindow.setWindowTitle('RAMSify')
		self.loadingWindow.setWindowIcon(QIcon('Media/ramsify.png'))
		vLayoutForLoadingWindow = QVBoxLayout()
		self.loadingWindow.setLayout(vLayoutForLoadingWindow)
		statusLabel = QLabel()
 
		self.progress_bar = QProgressBar()
		self.progress_bar.setMinimum(0)
		self.progress_bar.setMaximum(100)
		self.progress_bar.setValue(0)
 
		vLayoutForLoadingWindow.addWidget(statusLabel)
		vLayoutForLoadingWindow.addWidget(self.progress_bar)
 
		self.loadingWindow.setFixedWidth(int(0.2 * QApplication.primaryScreen().availableGeometry().width()))
		self.loadingWindow.setFixedHeight(int(0.05 * QApplication.primaryScreen().availableGeometry().width()))
		self.loadingWindow.show()
 
		statusLabel.setText('Loading the basic setup')

		QApplication.processEvents()

		self.readIniFile()
		self.connectDB()
		self.databaseData()

		self.settings = QSettings("RAMSify", "BeAnalytic")
		self.QSSValues()
		
		self.setWindowTitle('RAMSify')
		self.setWindowIcon(QIcon('Media/ramsify.png'))
		
		self.crossButtons = {}
		self.checkedItemsOfBOMWindow = {}
		self.logoutButton.clicked.connect(self.logout)
		self.settings = QSettings("RAMSify", "BeAnalytic")


		self.toolBarFunction()
		self.createTables()
		self.sideTreeMenu()
		self.buttonsOnSideMenu()
		self.configurationUI()
		self.settingsUI()
		
		self.settingThemeFunction()

		statusLabel.setText('Loading all the forms')
		self.progress_bar.setValue(10)
		QApplication.processEvents()

		self.runningMileageUI()

		self.maintenanceUI()

		statusLabel.setText('Loading the data to tables')
		self.progress_bar.setValue(20)
		QApplication.processEvents()
		self.maintenanceDataUI()

		statusLabel.setText('Calculating Availability')
		self.progress_bar.setValue(30)
		QApplication.processEvents()
		self.availabilityUi()

		statusLabel.setText('Calculating MDBF')
		self.progress_bar.setValue(40)
		QApplication.processEvents()
		self.mdbfUi()

		statusLabel.setText('Calculating Train Summary')
		self.progress_bar.setValue(50)
		QApplication.processEvents()
		self.trainSummaryUi()

		statusLabel.setText('Calculating Patter Failures')
		self.progress_bar.setValue(50)
		QApplication.processEvents()
		self.patternFailureUi()

		statusLabel.setText('Calculating System Failures')
		self.progress_bar.setValue(60)
		QApplication.processEvents()
		self.systemsFailuresUi()

		
		statusLabel.setText('Calculating Running Mileages')
		self.progress_bar.setValue(70)
		QApplication.processEvents()
		self.dashboardRunningmileageUI()

		statusLabel.setText('Calculating MTTR')
		self.progress_bar.setValue(80)
		QApplication.processEvents()
		self.mttrDashboardUi()
		
		statusLabel.setText('Calculating MDBCF')
		self.progress_bar.setValue(90)
		QApplication.processEvents()
		self.mdbcfDashboardUi()

		statusLabel.setText('Creating Home Charts')
		self.progress_bar.setValue(95)
		QApplication.processEvents()
		self.menuBarActions()
		self.homeUi()

		self.ncrUI()
		self.ncrformUI()

		self.tandcDataUI()

		self.consumablesMainTabDataUI()
		self.dlpsparesDataUI()


		self.sideMenuSize = 0
		self.stackedWidget.setCurrentIndex(0)
		self.userNameButton.setText(self.userName)
		self.hideOrUnhideFunction()

		statusLabel.setText('Done')
		self.progress_bar.setValue(100)
		QApplication.processEvents()

		self.loadingWindow.close()
		self.showMaximized()

	def closeEvent(self, event):
		self.mydb.commit()
		self.cursor.close()
		self.mydb.close()
		event.accept()