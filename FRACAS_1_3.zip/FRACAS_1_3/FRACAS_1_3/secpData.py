from PySide6.QtWidgets import QTableWidgetItem, QSpacerItem, QSizePolicy, QMessageBox, QPushButton, QComboBox, QAbstractItemView, QLineEdit, QTextEdit, QCheckBox, QFileDialog, QScrollArea, QWidget, QLabel, QHBoxLayout, QVBoxLayout, QFormLayout, QHeaderView
from functions import TableWidget
from PySide6.QtCore import Qt
from PySide6.QtGui import QIcon, QColor
from openpyxl import Workbook
from datetime import date, datetime
from collections import defaultdict


def secpDataUI(self, layout):
	from PySide6.QtWidgets import QApplication, QLabel

	checkAllUserIconPath = self.currentTheme.get('oppositeColorCheckBoxIcon')
	unCheckAllUserIconPath = self.currentTheme.get('oppositeColorUnCheckBoxIcon')
	partiallyCheckedIconPath = self.currentTheme.get('oppositeColorPartiallyCheckedBoxIcon')
	deleteIconPath = self.currentTheme.get('whiteDeleteIcon')
	downloadIconPath = self.currentTheme.get('downloadIcon')

	self.createPushButton('selectAllSecpButton', '', unCheckAllUserIconPath, 30)
	self.createPushButton('deleteButton_secp', '', deleteIconPath, 35, 'Delete')
	self.createLineEditBox('serachBarOfSecp', 'Search..' )
	self.serachBarOfSecp.setClearButtonEnabled(True)
	self.serachBarOfSecp.setFixedWidth(self.geometryWidth(0.2))
	self.createPushButton('download_secp', '', downloadIconPath, 35, 'Download')

	refreshTableIconPath = self.currentTheme.get('refreshIcon')
	self.createPushButton('refreshButton_secp', '', refreshTableIconPath, 35, 'Refresh')
	self.createPushButton('newSecp_SECP', '+ New SECP', '', self.geometryWidth(0.055))
	
	self.secpHboxLayout = QHBoxLayout()
	self.secpHboxLayout.addWidget(self.selectAllSecpButton)
	self.secpHboxLayout.addWidget(self.deleteButton_secp)
	self.secpHboxLayout.addWidget(self.serachBarOfSecp)
	self.secpHboxLayout.addWidget(self.download_secp)
	self.secpHboxLayout.addWidget(self.refreshButton_secp)
	self.secpHboxLayout.addItem(QSpacerItem(1, 0, QSizePolicy.Expanding, QSizePolicy.Minimum))
	self.secpHboxLayout.addWidget(self.newSecp_SECP)
	layout.addLayout(self.secpHboxLayout)

	self.secpDataTable_SECP = TableWidget()
	self.headersOfSECPTable  = [' ', 'SECP No', 'Description', 'Approval Status', 'SW Ver Change'] + self.trainsetsList 
	self.secpDataTable_SECP.setColumnCount(len(self.headersOfSECPTable))
	self.secpDataTable_SECP.setHorizontalHeaderLabels(self.headersOfSECPTable)
	self.secpDataTable_SECP.setStyleSheet(self.tableWidgetQSS)
	self.secpDataTable_SECP.horizontalHeader().setStyleSheet(self.headerHorizontalQSS)
	self.secpDataTable_SECP.setAlternatingRowColors(True)
	self.secpDataTable_SECP.setShowGrid(False)
	layout.addWidget(self.secpDataTable_SECP)
	self.secpDataTable_SECP.setEditTriggers(QAbstractItemView.NoEditTriggers)

	self.selectAllSecpButton.setCheckable(True)

	self.secpDataTable_SECP.setColumnWidth(0, self.geometryWidth(0.03))
	self.secpDataTable_SECP.setColumnWidth(1, self.geometryWidth(0.10))
	self.secpDataTable_SECP.setColumnWidth(2, self.geometryWidth(0.09))
	self.secpDataTable_SECP.setColumnWidth(3, self.geometryWidth(0.09))
	self.secpDataTable_SECP.setColumnWidth(4, self.geometryWidth(0.09))

	

	def OnClickingNewSecpButton():
		self.newSecpWindow = QWidget()
		self.newSecpWindow.move(600, 200)
		self.newSecpWindow.resize(600, 400)
		self.newSecpWindow.setWindowTitle('New SECP')
		self.newSecpWindow.setWindowIcon(QIcon('Media/ramsify.png'))


		vboxLayout = QVBoxLayout()
		formLayout = QFormLayout()
		vboxLayout.addLayout(formLayout)

		self.newSecpWindow.setLayout(vboxLayout)

		self.createLineEditBox('secpLineEdit_SECP')
		self.createTextEditBox('description_SECP')
		self.createComboBox2(['Yes', 'No'],'approvalStatus_SECP')
		self.createLineEditBox('swVerChangeLineEdit_SECP')
		self.createCheckableComboBox(self.trainsetsList, 'factoryTrainComboBox_SECP')
		
		formLayout.addRow('SECP No: <font color="red">*</font>', self.secpLineEdit_SECP)
		formLayout.addRow('Description: <font color="red">*</font>', self.description_SECP)
		formLayout.addRow('Approval Status: ', self.approvalStatus_SECP)
		formLayout.addRow('SW Ver Change: <font color="red">*</font>', self.swVerChangeLineEdit_SECP)
		formLayout.addRow('Factory Trains: ', self.factoryTrainComboBox_SECP)

		self.createPushButton('submitBtn_SECP', 'Submit', '', self.geometryWidth(0.04))
		self.createPushButton('cancelBtn_SECP', 'Cancel', '', self.geometryWidth(0.04))
		# vboxLayout.addWidget(self.submitBtn_SECP, alignment = Qt.AlignCenter)

		hBoxLayout = QHBoxLayout()
		hBoxLayout.addWidget(self.submitBtn_SECP, alignment = Qt.AlignRight)
		hBoxLayout.addWidget(self.cancelBtn_SECP, alignment = Qt.AlignLeft)
		vboxLayout.addLayout(hBoxLayout)


		allFieldsData = [self.secpLineEdit_SECP, self.description_SECP, self.approvalStatus_SECP, self.swVerChangeLineEdit_SECP, self.factoryTrainComboBox_SECP]

			
		def onClickingSubmit_SECP():
			mandatoryVerification_SECP = True
			mandatoryIndexesSecp = [0, 1, 3]
			secpData = []

			for i, wid in enumerate(allFieldsData):
				if isinstance(wid, QLineEdit):
					if wid.text() == '':
						secpData.append(None)
						if i in mandatoryIndexesSecp:
							mandatoryVerification_SECP = False
							wid.setProperty("error", True)
							wid.setStyleSheet(self.lineEditBoxQSS)
					else:
						if wid.text().isdigit():
							secpData.append(int(wid.text()))
						else:
							secpData.append(wid.text())

						wid.setProperty("error", False)
						wid.setStyleSheet(self.lineEditBoxQSS)

				if isinstance(wid, QTextEdit):
					if wid.toPlainText() == '':
						secpData.append(None)
						if i in mandatoryIndexesSecp:
							mandatoryVerification_SECP = False
							wid.setProperty("error", True)
							wid.setStyleSheet(self.textEditBoxQSS)

					else:
						secpData.append(wid.toPlainText())
						wid.setProperty("error", False)
						wid.setStyleSheet(self.textEditBoxQSS)

				if isinstance(wid, QComboBox):
					if wid.isEnabled():
						if wid.currentText() == '':
							secpData.append(None)
							if i in mandatoryIndexesSecp:
								mandatoryVerification_SECP = False
								wid.setProperty("error", True)
								wid.setStyleSheet(self.comboBoxQSS)

						else:
							secpData.append(wid.currentText())
							wid.setProperty("error", False)
							wid.setStyleSheet(self.comboBoxQSS)
					else:
						secpData.append(None)


			if not mandatoryVerification_SECP:
				print('Mandatory fields missing.')

			else:
				query = '''
							SELECT sw_ver_change
							FROM secp
							WHERE secp_no = %s AND sw_ver_change = %s AND deleted_at IS NULL
						'''
				self.cursor.execute(query, (secpData[0], secpData[3]))
				resultSwVersions = self.cursor.fetchall()
				# allVersions = [sw_ver_change[0] for sw_ver_change in resultSwVersions]
				if len(resultSwVersions) > 0:
				# if secpData[3] in allVersions:
					QMessageBox.critical(self, "Duplicate Entry", "Duplicate secp number with swversions.")

				else:
					secpData.append(self.user_id)
					query = """
								INSERT INTO secp
								(secp_no, description, approval_status, sw_ver_change, factory_trains, user_id) 
								VALUES (%s, %s, %s, %s, %s, %s)
							""" 

					try:
						self.cursor.execute(query, tuple(secpData))
						self.mydb.commit()
						self.refreshButton_secp.click()

						secpSubmitMsgBox = QMessageBox()
						secpSubmitMsgBox.setIcon(QMessageBox.Information) 
						secpSubmitMsgBox.setText(f'Data Submitted successfully.')
						secpSubmitMsgBox.setWindowTitle("Message")
						secpSubmitMsgBox.setWindowIcon(QIcon('Media/ramsify.png'))
						secpSubmitMsgBox.setStandardButtons(QMessageBox.Ok)
						secpSubmitMsgBox.exec_()

						self.newSecpWindow.close()

					except Exception as e:
						QMessageBox.critical(self, "Database Error", f"An error occurred: {e}")		


		self.submitBtn_SECP.clicked.connect(onClickingSubmit_SECP)	

		self.newSecpWindow.show()

		def onClickingCancel_SECP():

			self.secpLineEdit_SECP.clear()
			self.description_SECP.clear()
			self.approvalStatus_SECP.setCurrentIndex(-1) 
			self.swVerChangeLineEdit_SECP.clear()
			self.factoryTrainComboBox_SECP.clearItems()

		self.cancelBtn_SECP.clicked.connect(onClickingCancel_SECP)

	self.newSecp_SECP.clicked.connect(OnClickingNewSecpButton)


	def onClickingrefreshbutton_secp():
		self.deleteButton_secp.hide()
		self.selectAllSecpButton.setIcon(QIcon(unCheckAllUserIconPath))
		self.selectAllSecpButton.setChecked(False)

		queryone = '''
						SELECT
							secp_no,
							description,
							approval_status,
							sw_ver_change,
							factory_trains
						FROM
							secp
						WHERE
							deleted_at IS NULL
					'''
		self.cursor.execute(queryone)
		secpDataResult = self.cursor.fetchall()

		def givingFunctionalityToButton(button, func, data):
			button.clicked.connect(lambda: func(data))


		def onbuttonClickedSecp(dataofsecp):
			from PySide6.QtWidgets import QApplication
			self.secpUpdateWindow = QWidget()
			self.secpUpdateWindow.move(400, 100)
			self.secpUpdateWindow.resize(500, 390)

			self.secpUpdateWindow.setWindowTitle(dataofsecp[0])
			self.secpUpdateWindow.setWindowIcon(QIcon('Media/ramsify.png'))

			scrollArea = QScrollArea()
			scrollArea.setWidgetResizable(True)
			scrollArea.setStyleSheet(self.scrollAreaQSS)
			self.secpUpdateWindow.setLayout(QVBoxLayout())
			self.secpUpdateWindow.layout().addWidget(scrollArea)

			contentsWidget = QWidget()
			vboxLayout = QVBoxLayout()
			contentsWidget.setLayout(vboxLayout)
			scrollArea.setWidget(contentsWidget)

			formLayout = QFormLayout()
			vboxLayout.addLayout(formLayout)

			self.createLineEditBox('secpLineEdit_SECP_')
			self.secpLineEdit_SECP_.setText(dataofsecp[0])

			self.createTextEditBox('description_SECP_')
			self.description_SECP_.setText(dataofsecp[1])
			self.description_SECP_.setToolTip(dataofsecp[1])

			self.createComboBox2(['Yes', 'No'],'approvalStatus_SECP_')
			self.approvalStatus_SECP_.setCurrentText(dataofsecp[2])

			self.createLineEditBox('swVerChangeLineEdit_SECP_')
			self.swVerChangeLineEdit_SECP_.setText(dataofsecp[3])
			self.swVerChangeLineEdit_SECP_.setToolTip(dataofsecp[3])


			self.createCheckableComboBox(self.trainsetsList, 'factoryTrainComboBox_SECP_')
			selected_trainsitems = [dataofsecp[4]]
			self.factoryTrainComboBox_SECP_.selectItems(str(selected_trainsitems))

			
			formLayout.addRow('SECP No: <font color="red">*</font>', self.secpLineEdit_SECP_)
			formLayout.addRow('Description: <font color="red">*</font>', self.description_SECP_)
			formLayout.addRow('Approval Status: ', self.approvalStatus_SECP_)
			formLayout.addRow('SW Ver Change: <font color="red">*</font>', self.swVerChangeLineEdit_SECP_)
			formLayout.addRow('Factory Trains: ', self.factoryTrainComboBox_SECP_)

			self.createPushButton('updateBtn_SECP', 'Update', '', self.geometryWidth(0.04))

			vboxLayout.addWidget(self.updateBtn_SECP, alignment = Qt.AlignCenter)

			allFieldsData_ = [self.secpLineEdit_SECP_, self.description_SECP_, self.approvalStatus_SECP_, self.swVerChangeLineEdit_SECP_, self.factoryTrainComboBox_SECP_]


			def setToolTip(wid, text):
				wid.setToolTip(text)

			def settingToolTipToLineEdits(wid):
				wid.textChanged.connect(lambda: setToolTip(wid, wid.text()))

			def settingToolTipToTextEdits(wid):
				wid.textChanged.connect(lambda: setToolTip(wid, wid.toPlainText()))

			for wid in allFieldsData_:
				if isinstance(wid, QLineEdit):
					settingToolTipToLineEdits(wid)

				if isinstance(wid, QTextEdit):
					settingToolTipToTextEdits(wid)


			def onClickingUpdateSecpDataButton():

				mandatoryVerification_SECP = True
				mandatoryIndexesSecp = [0, 1, 3]
				secpUpdateFormdata = []

				for i, wid in enumerate(allFieldsData_):
					if isinstance(wid, QLineEdit):
						if wid.text() == '':
							secpUpdateFormdata.append(None)
							if i in mandatoryIndexesSecp:
								mandatoryVerification_SECP = False
								wid.setProperty("error", True)
								wid.setStyleSheet(self.lineEditBoxQSS)
						else:
							secpUpdateFormdata.append(wid.text())
							wid.setProperty("error", False)
							wid.setStyleSheet(self.lineEditBoxQSS)

					if isinstance(wid, QTextEdit):
						if wid.toPlainText() == '':
							secpUpdateFormdata.append(None)
							if i in mandatoryIndexesSecp:
								mandatoryVerification_SECP = False
								wid.setProperty("error", True)
								wid.setStyleSheet(self.textEditBoxQSS)

						else:
							secpUpdateFormdata.append(wid.toPlainText())
							wid.setProperty("error", False)
							wid.setStyleSheet(self.textEditBoxQSS)

					if isinstance(wid, QComboBox):
						if wid.isEnabled():
							if wid.currentText() == '':
								secpUpdateFormdata.append(None)
								if i in mandatoryIndexesSecp:
									mandatoryVerification_SECP = False
									wid.setProperty("error", True)
									wid.setStyleSheet(self.comboBoxQSS)

							else:
								secpUpdateFormdata.append(wid.currentText())
								wid.setProperty("error", False)
								wid.setStyleSheet(self.comboBoxQSS)

						else:
							secpUpdateFormdata.append(None)

				
				if not mandatoryVerification_SECP:
					print('Mandatory fields missing.')

				else:
					query = '''
								SELECT sw_ver_change
								FROM secp
								WHERE secp_no = %s AND sw_ver_change = %s AND deleted_at IS NULL
							'''

					self.cursor.execute(query, (secpUpdateFormdata[0], secpUpdateFormdata[3]))
					resultVersions = self.cursor.fetchall()
					
					def updatingDatabase():

						secpUpdateFormdata.append(self.user_id)
						update_queryone = """
											UPDATE secp
											SET
												secp_no = %s,
												description = %s,
												approval_status = %s,
												sw_ver_change = %s,
												factory_trains = %s,
												user_id = %s
											WHERE secp_no = %s AND sw_ver_change = %s
										"""
						secpUpdateFormdata.append(dataofsecp[0])
						secpUpdateFormdata.append(dataofsecp[3])
						
						try:
							self.cursor.execute(update_queryone, tuple(secpUpdateFormdata))
							self.mydb.commit()
							self.refreshButton_secp.click()
							secpUpdateMsgBox = QMessageBox()
							secpUpdateMsgBox.setIcon(QMessageBox.Information) 
							secpUpdateMsgBox.setText(f'Data Updated successfully.')
							secpUpdateMsgBox.setWindowTitle("Message")
							secpUpdateMsgBox.setWindowIcon(QIcon('Media/ramsify.png'))
							secpUpdateMsgBox.setStandardButtons(QMessageBox.Ok)
							secpUpdateMsgBox.exec_()

							self.secpUpdateWindow.close()

						except Exception as e:
							# print(f"Error: {e}")
							QMessageBox.critical(self, "Database Error", f"An error occurred: {e}")

					if (secpUpdateFormdata[0] == dataofsecp[0]) and (secpUpdateFormdata[3] == dataofsecp[3]):
						if len(resultVersions) == 1:
							updatingDatabase()

					else:
						if len(resultVersions) == 0:
							updatingDatabase()
						else:
							QMessageBox.critical(self, "Duplicate Entry", "Duplicate Modification number with swverChange.")





			self.updateBtn_SECP.clicked.connect(onClickingUpdateSecpDataButton)


			self.secpUpdateWindow.show()


		self.secpDataTable_SECP.setRowCount(0)

		for rowIndex, rowData in enumerate(secpDataResult):
			self.secpDataTable_SECP.insertRow(self.secpDataTable_SECP.rowCount())
			factory_trains = rowData[4]


			secpCheckBoxWidget = QCheckBox('')
			secpCheckBoxWidget.setStyleSheet(self.checkBoxQSS)
			self.secpDataTable_SECP.setCellWidget(self.secpDataTable_SECP.rowCount()-1, 0, secpCheckBoxWidget)
			secpCheckBoxWidget.stateChanged.connect(onStateChangedOf_SECPCheckBox)
	
			for colIndex, seData in enumerate(rowData[:-1]):
				if colIndex == 0: 
					button = QPushButton(str(seData))
					givingFunctionalityToButton(button, onbuttonClickedSecp, rowData)
					button.setStyleSheet(self.tableButtonQSS)
					button.setCursor(Qt.PointingHandCursor)
					self.secpDataTable_SECP.setCellWidget(self.secpDataTable_SECP.rowCount()-1, 1, button)

				else:
					item = QTableWidgetItem(str(seData) if seData else '')
					item.setTextAlignment(Qt.AlignCenter)
					item.setToolTip(item.text())
					self.secpDataTable_SECP.setItem(self.secpDataTable_SECP.rowCount() - 1, colIndex + 1, item)

			
				
			query_opm = '''
							SELECT
								opm.trainset_id, trainsets.trainset, opm.work_start_at
							FROM
								other_preventive_maintenance AS opm

							JOIN
								trainsets ON opm.trainset_id = trainsets.id
							
							WHERE
								opm.t_c_no = %s AND
								opm.t_c_rev = %s AND
								opm.opm_type = 'SECP'
						'''
			# print(f"Executing query with t_c_no={rowData[0]}")
			self.cursor.execute(query_opm, (rowData[0], rowData[3]))
			opmDataResult = self.cursor.fetchall()


			# Create a dictionary for trainsets with their work_start_at dates
			opm_trainsets = {opmData[1]: opmData[2] for opmData in opmDataResult}


			for trainset in self.trainsetsList:
				trainset_col_index = self.headersOfSECPTable.index(trainset)  # Get the index of each trainset header

				if not factory_trains:
					factory_trains = []

				if trainset in factory_trains:  # Check if this trainset is in factory_trains
					item = QTableWidgetItem("Factory")
					item.setBackground(QColor(self.currentTheme.get('grayBGColor')))

				else:

					if trainset in opm_trainsets:
						item = QTableWidgetItem("Completed")
						item.setBackground(QColor(self.currentTheme.get('greenBGColor')))
						
						# Set tooltip with work_start_at date
						work_start_date = opm_trainsets[trainset]
						if work_start_date:  # Check if work_start_date is not None
							item.setToolTip(f"Date: {work_start_date}")

					
					else:
						item = QTableWidgetItem("Pending")
						item.setBackground(QColor(self.currentTheme.get('orangeBGColor')))
						item.setToolTip(' ')
				item.setTextAlignment(Qt.AlignCenter)
				self.secpDataTable_SECP.setItem(self.secpDataTable_SECP.rowCount() - 1, trainset_col_index, item)
		

	self.refreshButton_secp.clicked.connect(onClickingrefreshbutton_secp)




	def OnSearchBox_Secp_Button():

		searchText = self.serachBarOfSecp.text().lower()

		for row in range(self.secpDataTable_SECP.rowCount()):
			self.secpDataTable_SECP.setRowHidden(row, True)

			if self.secpDataTable_SECP.cellWidget(row, 1) and (searchText in self.secpDataTable_SECP.cellWidget(row, 1).text().lower()):
				self.secpDataTable_SECP.setRowHidden(row, False)
				continue

			for col in range(2, self.secpDataTable_SECP.columnCount()):
				item = self.secpDataTable_SECP.item(row, col)
				if item is not None and searchText in item.text().lower():
					self.secpDataTable_SECP.setRowHidden(row, False)
					break

	self.serachBarOfSecp.textChanged.connect(OnSearchBox_Secp_Button)


	def onClickingDownloadBtn_SECPDT():

		file_path, _ = QFileDialog.getSaveFileName(self, "Save Excel File", "", "Excel Files (*.xlsx)")

		if file_path:

			wb = Workbook()
			ws = wb.active

			headers = []
			for col in range(1, self.secpDataTable_SECP.columnCount()):
				if not self.secpDataTable_SECP.isColumnHidden(col):
					header_item = self.secpDataTable_SECP.horizontalHeaderItem(col)
					if header_item is not None:
						headers.append(header_item.text())

			ws.append(headers)

			row_index = 2
			for row in range(self.secpDataTable_SECP.rowCount()):
				if not self.secpDataTable_SECP.isRowHidden(row):
					# ws.cell(row=row_index, column=1).value = self.secpDataTable_SECP.cellWidget(row, 0).text()
					for col in range(1, self.secpDataTable_SECP.columnCount()):
						if col == 1:
							wid = self.secpDataTable_SECP.cellWidget(row, col)
							if isinstance(wid, QPushButton):
								ws.cell(row=row_index, column=col).value = wid.text()
						else:	
							item = self.secpDataTable_SECP.item(row, col)
							if item is not None:
								ws.cell(row=row_index, column=col).value = item.text()

					row_index += 1

			wb.save(file_path)

			secpDownloadedMsgBox = QMessageBox()
			secpDownloadedMsgBox.setIcon(QMessageBox.Information) 
			secpDownloadedMsgBox.setText(f'Data downloaded successfully')
			secpDownloadedMsgBox.setWindowTitle("Message")
			secpDownloadedMsgBox.setWindowIcon(QIcon('Media/ramsify.png'))
			secpDownloadedMsgBox.setStandardButtons(QMessageBox.Ok)
			secpDownloadedMsgBox.exec_()

	self.download_secp.clicked.connect(onClickingDownloadBtn_SECPDT)

	def onClicking_SelectAll_SECPDT(checked):
		if checked:
			self.selectAllSecpButton.setIcon(QIcon(checkAllUserIconPath))

			for i in range(self.secpDataTable_SECP.rowCount()):
				if not self.secpDataTable_SECP.isRowHidden(i):
					if isinstance(self.secpDataTable_SECP.cellWidget(i,0), QCheckBox):
						self.secpDataTable_SECP.cellWidget(i,0).setCheckState(Qt.Checked)
		
		else:
			self.selectAllSecpButton.setIcon(QIcon(unCheckAllUserIconPath))

			for i in range(self.secpDataTable_SECP.rowCount()):
				if not self.secpDataTable_SECP.isRowHidden(i):
					if isinstance(self.secpDataTable_SECP.cellWidget(i,0), QCheckBox):
						self.secpDataTable_SECP.cellWidget(i,0).setCheckState(Qt.Unchecked)

	self.selectAllSecpButton.toggled.connect(onClicking_SelectAll_SECPDT)


	def onStateChangedOf_SECPCheckBox():
		all_checked = True
		all_unchecked = True

		for i in range(self.secpDataTable_SECP.rowCount()):
			if not self.secpDataTable_SECP.isRowHidden(i):
				if isinstance(self.secpDataTable_SECP.cellWidget(i,0), QCheckBox):
					if self.secpDataTable_SECP.cellWidget(i,0).isChecked():
						all_unchecked = False
					else:
						all_checked = False

		if all_checked or all_unchecked:
			some_checked = False
		else:
			some_checked = True


		if all_checked:
			self.deleteButton_secp.show()
			self.selectAllSecpButton.setIcon(QIcon(checkAllUserIconPath))
			self.selectAllSecpButton.setChecked(True)
			

		if all_unchecked:
			self.deleteButton_secp.hide()
			self.selectAllSecpButton.setIcon(QIcon(unCheckAllUserIconPath))
			self.selectAllSecpButton.setChecked(False)

		if some_checked:
			self.deleteButton_secp.show()
			self.selectAllSecpButton.setIcon(QIcon(partiallyCheckedIconPath))




	def onClicking_Delete_SECPDT():
			
		selectedSecpnoIndices_ = []
		selectedSecpnos = []
		selectedSwverChange = []
		numberOfSelectedSecpnos = 0

		for i in range(self.secpDataTable_SECP.rowCount()):
			if not self.secpDataTable_SECP.isRowHidden(i):
				if isinstance(self.secpDataTable_SECP.cellWidget(i,0), QCheckBox):
					if self.secpDataTable_SECP.cellWidget(i,0).checkState() == Qt.Checked:
						selectedSecpnoIndices_.append(i)

						secpnoButton = self.secpDataTable_SECP.cellWidget(i, 1)
						if secpnoButton:
							selectedSecpnos.append(secpnoButton.text())
							numberOfSelectedSecpnos += 1

						swverchange = self.secpDataTable_SECP.item(i, 4).text()
						selectedSwverChange.append(swverchange)
		
	
		if selectedSecpnos:

			confirmDeleteSECPMsgBox = QMessageBox()
			confirmDeleteSECPMsgBox.setIcon(QMessageBox.Question) 
			confirmDeleteSECPMsgBox.setText(f"Are you sure you want to delete {numberOfSelectedSecpnos} SECP(s)?")
			confirmDeleteSECPMsgBox.setWindowTitle("Confirm")
			confirmDeleteSECPMsgBox.setWindowIcon(QIcon('Media/ramsify.png'))
			confirmDeleteSECPMsgBox.setStandardButtons(QMessageBox.Ok | QMessageBox.No)
			
			userResponse = confirmDeleteSECPMsgBox.exec()

			if userResponse == QMessageBox.Ok:
				current_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
				for ind in sorted(selectedSecpnoIndices_, reverse=True):
					secpnoToDelete = selectedSecpnos[selectedSecpnoIndices_.index(ind)]
					swverChangeToDelete = selectedSwverChange[selectedSecpnoIndices_.index(ind)]
					sql = "UPDATE secp SET deleted_at = %s, user_id = %s WHERE secp_no = %s AND sw_ver_change = %s"
					values = (current_time, self.user_id, secpnoToDelete, swverChangeToDelete)
					self.cursor.execute(sql, values)
					self.mydb.commit()
					self.secpDataTable_SECP.removeRow(ind)

				secpDeleteSuccessMsgBox = QMessageBox()
				secpDeleteSuccessMsgBox.setIcon(QMessageBox.Information) 
				secpDeleteSuccessMsgBox.setText(f'{numberOfSelectedSecpnos} SECP(s) deleted successfully.')
				secpDeleteSuccessMsgBox.setWindowTitle("Message")
				secpDeleteSuccessMsgBox.setWindowIcon(QIcon('Media/ramsify.png'))
				secpDeleteSuccessMsgBox.setStandardButtons(QMessageBox.Ok)
				secpDeleteSuccessMsgBox.exec()
			
				self.deleteButton_secp.hide()
				self.selectAllSecpButton.setIcon(QIcon(unCheckAllUserIconPath))
			
			else:
				pass


	self.deleteButton_secp.clicked.connect(onClicking_Delete_SECPDT)

	onClickingrefreshbutton_secp()