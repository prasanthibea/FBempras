from PySide6.QtWidgets import QApplication, QWidget, QVBoxLayout, QHBoxLayout, QCheckBox, QListWidget, QListWidgetItem, QMessageBox, QSpacerItem
from PySide6.QtCore import *
from PySide6.QtGui import QIcon, QFont
from QSSS import *
from functions import *

from dateutil.relativedelta import relativedelta


from reports.trainSummaryReport import trainSummaryReportUi
from reports.runningMileageReport import runningMileageReportUi
from reports.availabilityReport import availabilityReportUi
from reports.mttrReport import mttrReportUi
from reports.mdbfReport import mdbfReportUi
from reports.mdbcfReport import mdbcfReportUi
from reports.systemFailuresReport import systemFailuresReportUi
from reports.patternFailureReport import patternFailureReportUi
from reports.monthwiseSummaryReport import monthwiseSummaryReportUi

	
def generateReportFunction(self):

	reportsWindowWidth = int(0.3* QApplication.primaryScreen().availableGeometry().width())
	reportsWindowHeight = int(0.45 * QApplication.primaryScreen().availableGeometry().height())

	self.reportsWindow = QWidget()
	self.reportsWindow.setWindowTitle("Reports")
	self.reportsWindow.setWindowIcon(QIcon('Media/ramsify.png'))
	self.reportsWindow.setStyleSheet(self.widgetQSS)
	self.reportsWindow.setFixedWidth(reportsWindowWidth)
	self.reportsWindow.setFixedHeight(reportsWindowHeight)


	self.mainVerticalLayoutOfReportsWindow = QVBoxLayout()



###########################################################################################################################################


	## Add the year and month selection comboboxes:

	self.layoutForFilters_Reports = QHBoxLayout()

	self.yearFormLayout_Reports = QFormLayout()
	self.monthFormLayout_Reports = QFormLayout()

	currentDate = datetime.now()
	currentYear = currentDate.year
	currentMonth = currentDate.month

	# previousMonthDate = currentDate - relativedelta(months=1)
	# previousMonth = previousMonthDate.strftime('%b')

	listOfYears = [str(num) for num in range(self.startingYear,currentYear+1)]

	self.createComboBox(listOfYears, 'yearSelectionCombobox_Reports') 
	self.yearSelectionCombobox_Reports.setFixedWidth(int(0.1 * QApplication.primaryScreen().availableGeometry().width()))

	self.createComboBox([], 'monthSelectionCombobox_Reports')
	self.monthSelectionCombobox_Reports.setFixedWidth(int(0.1 * QApplication.primaryScreen().availableGeometry().width()))
	# self.monthSelectionCombobox_Reports.setEnabled(False)

	monthsList = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12']

	def onChangingYearCombobox():
		self.monthSelectionCombobox_Reports.clear()
		
		if self.yearSelectionCombobox_Reports.currentIndex() == 0:
			if len(listOfYears) == 1:
				self.monthSelectionCombobox_Reports.addItems([str(num) for num in range(self.startingMonth,currentMonth)])

			if len(listOfYears) > 1:
				self.monthSelectionCombobox_Reports.addItems([str(num) for num in range(self.startingMonth,13)])
		
		elif self.yearSelectionCombobox_Reports.currentIndex() == (len(listOfYears)-1):
			self.monthSelectionCombobox_Reports.addItems([str(num) for num in range(1, currentMonth)])
			
		else:
			self.monthSelectionCombobox_Reports.addItems(monthsList)


	self.yearSelectionCombobox_Reports.currentIndexChanged.connect(onChangingYearCombobox)

	self.yearFormLayout_Reports.addRow(QLabel('Year:'), self.yearSelectionCombobox_Reports)
	self.yearFormLayout_Reports.setAlignment(Qt.AlignRight)

	self.monthFormLayout_Reports.addRow(QLabel('Month:'), self.monthSelectionCombobox_Reports)
	self.monthFormLayout_Reports.setAlignment(Qt.AlignLeft)


	self.layoutForFilters_Reports.addLayout(self.yearFormLayout_Reports)
	self.layoutForFilters_Reports.addLayout(self.monthFormLayout_Reports)


	self.mainVerticalLayoutOfReportsWindow.addLayout(self.layoutForFilters_Reports)


###########################################################################################################################################


	## List widgets with report names.
	
	listOfReportsName = ['Train Summary', 'Running Mileage', 'Availability', 'MTTR', 'MDBF', 'MDBCF', 'System Relevant & Service Failures', 'Pattern Failure', 'Monthly Summary']

	self.reportsListWidget = QListWidget()
	self.reportsListWidget.setStyleSheet(self.listWidgetQSS)

	self.reportsListWidget.addItems(listOfReportsName)
	self.reportsListWidget.setCurrentRow(0)


	self.mainVerticalLayoutOfReportsWindow.addWidget(self.reportsListWidget)


	layoutForSubmitAndCancelBtnOFReportsWindow = QHBoxLayout()
	self.createPushButton('submitBtnOfReportWindow', 'Submit', width=int(0.050 * QApplication.primaryScreen().availableGeometry().width()))
	self.submitBtnOfReportWindow.setFixedHeight(30)

	self.createPushButton('cancelBtnOfReportWindow', 'Cancel', width=int(0.050 * QApplication.primaryScreen().availableGeometry().width()))
	self.cancelBtnOfReportWindow.setFixedHeight(30)


	self.cancelBtnOfReportWindow.clicked.connect(lambda: self.reportsWindow.close())
	
	layoutForSubmitAndCancelBtnOFReportsWindow.addWidget(self.submitBtnOfReportWindow, alignment = Qt.AlignRight)
	layoutForSubmitAndCancelBtnOFReportsWindow.addWidget(self.cancelBtnOfReportWindow, alignment = Qt.AlignLeft)

	self.mainVerticalLayoutOfReportsWindow.addLayout(layoutForSubmitAndCancelBtnOFReportsWindow)





	### Function to get the selected report:
	def getSelectedReport():

		# selected_year = int(self.yearSelectionCombobox_Reports.currentText())
		# selected_month = int(self.monthSelectionCombobox_Reports.currentText())

		selected_year_ = self.yearSelectionCombobox_Reports.currentText()
		selected_month_ = self.monthSelectionCombobox_Reports.currentText()

		if selected_year_:
			selected_year = int(self.yearSelectionCombobox_Reports.currentText())

			self.yearSelectionCombobox_Reports.setProperty("error", False)
			self.yearSelectionCombobox_Reports.setStyleSheet(self.comboBoxQSS)
			
			if selected_month_:
				selected_month = int(self.monthSelectionCombobox_Reports.currentText())

				self.monthSelectionCombobox_Reports.setProperty("error", False)
				self.monthSelectionCombobox_Reports.setStyleSheet(self.comboBoxQSS)

				## Get the selected list widget item:
				selectedReportIndex = self.reportsListWidget.currentRow()
				selectedReportName = self.reportsListWidget.currentItem().text()

				if selectedReportIndex is not None:


					if selectedReportIndex == 0:
						trainSummaryReportUi(self, selected_month, selected_year, selectedReportName)

					elif selectedReportIndex == 1:
						runningMileageReportUi(self, selected_month, selected_year, selectedReportName)

					elif selectedReportIndex == 2:
						availabilityReportUi(self, selected_month, selected_year, selectedReportName )

					elif selectedReportIndex == 3:
						mttrReportUi(self, selected_month, selected_year, selectedReportName)

					elif selectedReportIndex == 4:
						mdbfReportUi(self, selected_month, selected_year, selectedReportName)

					elif selectedReportIndex == 5:
						mdbcfReportUi(self, selected_month, selected_year, selectedReportName)

					elif selectedReportIndex == 6:
						systemFailuresReportUi(self, selected_month, selected_year, selectedReportName)

					elif selectedReportIndex == 7:
						patternFailureReportUi(self, selected_month, selected_year, selectedReportName)

					elif selectedReportIndex == 8:
						monthwiseSummaryReportUi(self, selected_year, selected_month)

					# elif selectedReportIndex == 8:
					# 	print(selected_month, selected_year)
						# totalReport(self, selected_month, selected_year)



					# reportMsgBox = QMessageBox()
					# reportMsgBox.setIcon(QMessageBox.Information) 
					# reportMsgBox.setText(f'{selectedReportName} Report Generated Successfully')
					# reportMsgBox.setWindowTitle("Message")
					# reportMsgBox.setWindowIcon(QIcon('Media/ramsify.png'))
					# reportMsgBox.setStandardButtons(QMessageBox.Ok)
					# reportMsgBox.exec()

			else:
				self.monthSelectionCombobox_Reports.setProperty("error", True)
				self.monthSelectionCombobox_Reports.setStyleSheet(self.comboBoxQSS)

		else:
			self.yearSelectionCombobox_Reports.setProperty("error", True)
			self.yearSelectionCombobox_Reports.setStyleSheet(self.comboBoxQSS)

			

	self.submitBtnOfReportWindow.clicked.connect(getSelectedReport)


	self.reportsWindow.setLayout(self.mainVerticalLayoutOfReportsWindow)
	self.reportsWindow.show()