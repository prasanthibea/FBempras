from datetime import datetime, timedelta
from dateutil.relativedelta import relativedelta
import calendar

from PySide6.QtWidgets import QApplication
from PySide6.QtCore import Qt
from functions import createPieChart

def systemFailuresReportUi(self, month, year, selected_report_title):

	# six_months_ago = datetime(year, month, 1) - relativedelta(months=5)

	# six_months_agoDate = six_months_ago.date()
	# fromDateMonthString = six_months_agoDate.strftime('%b - %Y')
	# allItems = []
	# for index in range(self.fromCombobox_SRF.count()):
	# 	item_text = self.fromCombobox_SRF.itemText(index)
	# 	allItems.append(item_text)
	

	# if fromDateMonthString in allItems:
	# 	self.fromCombobox_SRF.setCurrentText(fromDateMonthString)
	# else:
	# 	self.fromCombobox_SRF.setCurrentIndex(0)


	# month_string = calendar.month_abbr[int(month)]
	date_object = datetime(year, month, 1)
	toMonthString = date_object.strftime('%b - %Y')

	self.fromCombobox_SRF.setCurrentText(toMonthString)
	self.toCombobox_SRF.setCurrentText(toMonthString)


	system_failures_data = []

	report_title = f'SYSTEM RELEVANT & SERVICE FAILURES FOR {toMonthString.upper()}'

	system_failures_data.append(report_title)


	##########################################################

	tableNamesList = ['RELEVANT & SERVICE FAILURES']

	##########################################################


	relevantFailureTableData = []

	header_text = ['Systems', 'Relevant Failures', 'Service Failures']
	# for col in range(self.tableForRelevantFailuresCount.columnCount()):
	# 	header_item = self.tableForRelevantFailuresCount.horizontalHeaderItem(col)
	# 	if header_item:
	# 		header_text.append(header_item.text())

	# Add headers to the table_data
	relevantFailureTableData.append(header_text)


	# Fetch data
	for row in range(self.tableForRelevantFailuresCount.rowCount()):
		row_data = []
		for col in range(self.tableForRelevantFailuresCount.columnCount()-1):
			if not self.tableForRelevantFailuresCount.isColumnHidden(col):
				item = self.tableForRelevantFailuresCount.item(row, col)
				if item:
					row_data.append(item.text())
				else:
					row_data.append('')

		for col in range(1,self.tableForServiceFailuresCount.columnCount()-1):
			if not self.tableForServiceFailuresCount.isColumnHidden(col):
				item = self.tableForServiceFailuresCount.item(row, col)
				if item:
					row_data.append(item.text())
				else:
					row_data.append('')
		
		relevantFailureTableData.append(row_data)
		# print(relevantFailureTableData)
	# totalRelevantFailures = 0
	# totalServiceFailures = 0
	# for lis in relevantFailureTableData[1:]:
	# 	totalRelevantFailures += int(lis[1])
	# 	totalServiceFailures += int(lis[2])

	# totalRow = ['TOTAL FAILURES']
	# totalRow.append(str(totalRelevantFailures))
	# totalRow.append(str(totalServiceFailures))

	# relevantFailureTableData.append(totalRow)
	system_failures_data.append(relevantFailureTableData)


	

	##########################################################

	# serviceFailureTableData = []

	# header_text = []
	# for col in range(self.tableForServiceFailuresCount.columnCount()):
	# 	header_item = self.tableForServiceFailuresCount.horizontalHeaderItem(col)
	# 	if header_item:
	# 		header_text.append(header_item.text())

	# # Add headers to the table_data
	# serviceFailureTableData.append(header_text)


	# # Fetch data
	# for row in range(self.tableForServiceFailuresCount.rowCount()):
	# 	row_data = []
	# 	for col in range(self.tableForServiceFailuresCount.columnCount()):
	# 		item = self.tableForServiceFailuresCount.item(row, col)

	# 		if item:
	# 			row_data.append(item.text())
	# 		else:
	# 			row_data.append('')
		
	# 	serviceFailureTableData.append(row_data)


	# system_failures_data.append(serviceFailureTableData)

	
	##########################################################


	##########################################################

	failure_charts_list = []

	# Constructing the dictionary directly with these counts
	failureResultDict = {
		'Relevant Failures': int(relevantFailureTableData[-1][1]),
		'Service Failures': int(relevantFailureTableData[-1][2]),
	}


	mttrResultChartView = self.createPieChart(failureResultDict, f'Total Relevant And Service Failures For {toMonthString}')
	mttrResultChartView.setFixedHeight(525)
	mttrResultChartView.setFixedWidth(int(0.4 * QApplication.primaryScreen().availableGeometry().width()))

	failures_chart_image = mttrResultChartView.grab().toImage()
	failure_charts_list.append(failures_chart_image)


	##########################################################

	

	# Generate the report
	self.generate_pdf_report(selected_report_title, system_failures_data , tableNamesList, 0, failure_charts_list)
	# self.generate_pdf_report(selected_report_title, system_failures_data , tableNamesList, 0)
	self.clearAllFiltersButton_SRF.click()