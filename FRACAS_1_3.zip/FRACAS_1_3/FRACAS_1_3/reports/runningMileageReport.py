from reportlab.pdfgen import canvas
from datetime import datetime, timedelta, date
from dateutil.relativedelta import relativedelta
import calendar
from functions import createStackedBarChart, createBarChart
from PySide6.QtWidgets import QApplication

def runningMileageReportUi(self, month, year,selectedReportName):

	# Calculate the year and month six months before
	six_months_ago = datetime(year, month, 1) - relativedelta(months=5)

	six_months_agoDate = six_months_ago.date()
	fromDateMonthString = six_months_agoDate.strftime('%b - %Y')
	allItems = []
	for index in range(self.fromCombobox_RMDash.count()):
		item_text = self.fromCombobox_RMDash.itemText(index)
		allItems.append(item_text)
	

	if fromDateMonthString in allItems:
		self.fromCombobox_RMDash.setCurrentText(fromDateMonthString)
	else:
		self.fromCombobox_RMDash.setCurrentIndex(0)


	# month_string = calendar.month_abbr[int(month)]
	date_object = datetime(year, month, 1)
	toMonthString = date_object.strftime('%b - %Y')

	self.toCombobox_RMDash.setCurrentText(toMonthString)














	## Create a main list which holds RM report data:
	running_mileage_data = []

	## Report title
	report_title = f'RUNNING MILEAGE REPORT FOR {toMonthString.upper()}'

	running_mileage_data.append(report_title)

	##########################################################

	tableNamesList = ['Monthly Running Mileage', 'Accumulated Running Mileage', 'Average Running Mileage']
	for line_name in self.uniqueLines:
		tableNamesList.append(f'Running Mileage for {line_name}')
	##########################################################


	## Fetch RM table data from RM table:
	monthlyRunningMileageTableData = []

	header_text = []
	for col in range(self.dashboardRmMonthlyTable.columnCount()):
		if not self.dashboardRmMonthlyTable.isColumnHidden(col):
			header_item = self.dashboardRmMonthlyTable.horizontalHeaderItem(col)
			if header_item:
				header_text.append(header_item.text())

	# Add headers to the table_data
	monthlyRunningMileageTableData.append(header_text)


	# Fetch data
	for row in range(self.dashboardRmMonthlyTable.rowCount()):
		row_data = []
		for col in range(self.dashboardRmMonthlyTable.columnCount()):
			if not self.dashboardRmMonthlyTable.isColumnHidden(col):
				item = self.dashboardRmMonthlyTable.item(row, col)

				if item:
					row_data.append(item.text())
				else:
					row_data.append('')
		
		monthlyRunningMileageTableData.append(row_data)

	# # Add the table to the mttr_data
	running_mileage_data.append(monthlyRunningMileageTableData)


	##########################################################################################################


	## Fetch RM table data from RM table:
	accumulatedRunningMileageTableData = []

	header_text = []
	for col in range(self.dashboardRmAccumulatedTable.columnCount()):
		if not self.dashboardRmAccumulatedTable.isColumnHidden(col):
			header_item = self.dashboardRmAccumulatedTable.horizontalHeaderItem(col)
			if header_item:
				header_text.append(header_item.text())

	# Add headers to the table_data
	accumulatedRunningMileageTableData.append(header_text)


	# Fetch data
	for row in range(self.dashboardRmAccumulatedTable.rowCount()):
		row_data = []
		for col in range(self.dashboardRmAccumulatedTable.columnCount()):
			if not self.dashboardRmAccumulatedTable.isColumnHidden(col):
				item = self.dashboardRmAccumulatedTable.item(row, col)

				if item:
					row_data.append(item.text())
				else:
					row_data.append('')
		
		accumulatedRunningMileageTableData.append(row_data)


	# # Add the table to the mttr_data
	running_mileage_data.append(accumulatedRunningMileageTableData)




	##########################################################################################################


	## Fetch RM table data from RM table:
	averageRunningMileageTableData = []

	header_text = []
	for col in range(self.dashboardRmAvgTable.columnCount()):
		if not self.dashboardRmAvgTable.isColumnHidden(col):
			header_item = self.dashboardRmAvgTable.horizontalHeaderItem(col)
			if header_item:
				header_text.append(header_item.text())

	# Add headers to the table_data
	averageRunningMileageTableData.append(header_text)


	# Fetch data
	for row in range(self.dashboardRmAvgTable.rowCount()):
		row_data = []
		for col in range(self.dashboardRmAvgTable.columnCount()):
			if not self.dashboardRmAvgTable.isColumnHidden(col):
				item = self.dashboardRmAvgTable.item(row, col)

				if item:
					row_data.append(item.text())
				else:
					row_data.append('')
		
		averageRunningMileageTableData.append(row_data)

	# # Add the table to the mttr_data



	running_mileage_data.append(averageRunningMileageTableData)


	##########################################################################################################

	for tab in self.listOfLinesTablesInRMDash:
		## Fetch RM table data from RM table:
		runningMileageTableData = []

		header_text = []
		for col in range(tab.columnCount()):
			if not tab.isColumnHidden(col):
				header_item = tab.horizontalHeaderItem(col)
				if header_item:
					header_text.append(header_item.text())

		# Add headers to the table_data
		runningMileageTableData.append(header_text)


		# Fetch data
		for row in range(tab.rowCount()):
			row_data = []
			for col in range(tab.columnCount()):
				if not tab.isColumnHidden(col):
					item = tab.item(row, col)

					if item:
						row_data.append(item.text())
					else:
						row_data.append('')
			
			runningMileageTableData.append(row_data)


		# # Add the table to the mttr_data
		running_mileage_data.append(runningMileageTableData)


	##########################################################################################################


	# ## Fetch RM table data from RM table:
	# runningMileageTableData_Line2B = []

	# header_text = []
	# for col in range(self.listOfLinesTablesInRMDash[1].columnCount()):
	# 	header_item = self.listOfLinesTablesInRMDash[1].horizontalHeaderItem(col)
	# 	if header_item:
	# 		header_text.append(header_item.text())

	# # Add headers to the table_data
	# runningMileageTableData_Line2B.append(header_text)


	# # Fetch data
	# for row in range(self.listOfLinesTablesInRMDash[1].rowCount()):
	# 	row_data = []
	# 	for col in range(self.listOfLinesTablesInRMDash[1].columnCount()):
	# 		item = self.listOfLinesTablesInRMDash[1].item(row, col)

	# 		if item:
	# 			row_data.append(item.text())
	# 		else:
	# 			row_data.append('')
		
	# 	runningMileageTableData_Line2B.append(row_data)


	# # # Add the table to the mttr_data
	# running_mileage_data.append(runningMileageTableData_Line2B)


	###################################################################################################

	running_mileage_charts_list = []

	### Chart for monthly total running mileage:

	xlabelsForAccumulatedRunningMileage_SBC = []

	for col in range(1, self.dashboardRmMonthlyTable.columnCount()):
		if not self.dashboardRmMonthlyTable.isColumnHidden(col):
			header_item = self.dashboardRmMonthlyTable.horizontalHeaderItem(col)
			if header_item and header_item.text() is not None:
				xlabelsForAccumulatedRunningMileage_SBC.append(header_item.text())



	runningMileageDataList_SBC = []

	for row in range(self.dashboardRmMonthlyTable.rowCount()):
		row_data = []
		for col in range(1, self.dashboardRmMonthlyTable.columnCount()):
			if not self.dashboardRmMonthlyTable.isColumnHidden(col):
				item = self.dashboardRmMonthlyTable.item(row, col)

				if item:
					row_data.append(int(item.text()))
				else:
					row_data.append(0)
		
		runningMileageDataList_SBC.append(row_data)



	title = "Monthly Running Mileage"
	x_label = "Months"
	y_label = "Mileage (KM)"

	accumulatedRMChartView = createStackedBarChart(self, xlabelsForAccumulatedRunningMileage_SBC, runningMileageDataList_SBC,  title, x_label, y_label, self.uniqueLines)
	accumulatedRMChartView.setFixedHeight(525)
	accumulatedRMChartView.setFixedWidth(int(0.4 * QApplication.primaryScreen().availableGeometry().width()))

	monthly_rm_chart_image = accumulatedRMChartView.grab().toImage()
	running_mileage_charts_list.append(monthly_rm_chart_image)
	
	###################################################################################################


	###################################################################################################

	### Chart for monthly average running mileage:
	
	xlabelsForAverageRunningMileage_BC = []

	for col in range(1, self.dashboardRmAvgTable.columnCount()):
		if not self.dashboardRmAvgTable.isColumnHidden(col):
			header_item = self.dashboardRmAvgTable.horizontalHeaderItem(col)
			if header_item and header_item.text() is not None:
				xlabelsForAverageRunningMileage_BC.append(header_item.text())



	averageRunningMileageDataList_BC = []

	for row in range(self.dashboardRmAvgTable.rowCount()):
		row_data = []
		for col in range(1, self.dashboardRmAvgTable.columnCount()):
			if not self.dashboardRmAvgTable.isColumnHidden(col):
				item = self.dashboardRmAvgTable.item(row, col)

				if item:
					row_data.append(float(item.text()))
				else:
					row_data.append(0)
		
		averageRunningMileageDataList_BC.append(row_data)


	title_average_rm = "Monthly Average Running Mileage"
	x_label_average_rm = "Months"
	y_label_average_rm = "Average Mileage (KM)"

	averageRMChartView = createBarChart(self, xlabelsForAverageRunningMileage_BC, averageRunningMileageDataList_BC,  title_average_rm, x_label_average_rm, y_label_average_rm, ['Average Running Mileage'])
	averageRMChartView.setFixedHeight(525)
	averageRMChartView.setFixedWidth(int(0.4 * QApplication.primaryScreen().availableGeometry().width()))


	average_rm_chart_image = averageRMChartView.grab().toImage()
	running_mileage_charts_list.append(average_rm_chart_image)
	
	###################################################################################################



	


	self.generate_pdf_report(selectedReportName, running_mileage_data, tableNamesList, 0, running_mileage_charts_list)
	self.clearAllFiltersButton_RMDash.click()