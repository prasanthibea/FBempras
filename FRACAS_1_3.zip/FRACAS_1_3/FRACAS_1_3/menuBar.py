from configuration import *
from functions import *
from QSSS import *

def menuBarActions(self):
	def showRunTimesWindow():

		#def printSpinboxValues():
		#	for i in range(runTimeFormLayout.rowCount()):
		#		item = runTimeFormLayout.itemAt(i, QFormLayout.FieldRole)
		#		if isinstance(item.widget(), QSpinBox):
		#			print(item.widget().value())

		self.runTimesWindow = QWidget()
		self.runTimesWindow.setWindowTitle('Coach Run Time Window')
		self.runTimesWindow.setWindowIcon(QIcon('Media/ramsify.png'))
		self.runTimesWindow.setStyleSheet(self.widgetQSS)
		
		mainVerticalLayout = QVBoxLayout()

		scroll_area = QScrollArea()
		scroll_area.setWidgetResizable(True)

		mainVerticalLayout.addWidget(scroll_area)

		formLayoutWidget = QWidget()
		runTimeFormLayout = QFormLayout()
		formLayoutWidget.setLayout(runTimeFormLayout)


		scroll_area.setWidget(formLayoutWidget)
		self.runTimesWindow.setGeometry(530,130,500,700)

		updateButtonInShowRunTimesWindow = QPushButton('Update')
		updateButtonInShowRunTimesWindow.setFixedWidth(100)
		updateButtonInShowRunTimesWindow.setFixedHeight(30)
		updateButtonInShowRunTimesWindow.setStyleSheet(self.pushbuttonQSS)
		mainVerticalLayout.addWidget(updateButtonInShowRunTimesWindow, alignment= Qt.AlignRight)



		
		query = 'SELECT coach_name, runtime FROM coach_runtimes'
		self.cursor.execute(query)
		results = self.cursor.fetchall()
		

		coaches = []
		for (coach,coachRuntime) in results:
			spinBox = QSpinBox()
			spinBox.setMaximum(2147483646)
			spinBox.setValue(coachRuntime)
			spinBox.setFixedWidth(150)
			spinBox.setStyleSheet(self.spinBoxQSS)

			label = QLabel(coach + ': ')

			runTimeFormLayout.addRow(label, spinBox)
			coaches.append(coach)

		self.runTimesWindow.setLayout(mainVerticalLayout)
		self.runTimesWindow.show()

		def updateRunTimes():
			

			for i in range(len(coaches)):
				item = runTimeFormLayout.itemAt(i, QFormLayout.FieldRole)
				if isinstance(item.widget(), QSpinBox):
					value = item.widget().value()

				updateQuery = "UPDATE coach_runtimes SET runtime = {} WHERE coach_name = '{}'".format(value,coaches[i])
				self.cursor.execute(updateQuery)

			self.mydb.commit()
			
			self.runTimesWindow.close()


		updateButtonInShowRunTimesWindow.clicked.connect(updateRunTimes)
		

	#self.actionRun_Times.triggered.connect(showRunTimesWindow)
	
