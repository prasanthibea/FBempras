from PySide6.QtCore import QUrl
from PySide6.QtGui import QIcon
from PySide6.QtWebEngineWidgets import QWebEngineView

def helpUi(self):
	# self.helpButton.clicked.connect(self.helpFunction)
	self.actionhelp.triggered.connect(self.helpFunction)

	
def helpFunction(self):

	self.webview = QWebEngineView()
	self.webview.setWindowTitle('Help')
	self.webview.setWindowIcon(QIcon('Media/question.png'))
	file_path = "help/index.html"
	self.webview.load(QUrl.fromLocalFile(file_path))
	self.webview.show()
