# This is base Font size
mediumFont = 12


# All levels should be written in small letters
level_0 = 'sw-admin'
level_1 = 'admin'
level_2 = ''
level_3 = ''
level_4 = ''