from PySide6.QtWidgets import QTableWidgetItem, QSpacerItem, QSizePolicy, QMessageBox, QDateEdit, QTextEdit, QComboBox, QCheckBox, QPushButton, QFileDialog, QAbstractItemView, QLineEdit, QWidget, QLabel, QHBoxLayout, QVBoxLayout, QFormLayout, QHeaderView
from functions import TableWidget
from PySide6.QtCore import Qt, QDate, QTime, QDateTime
from PySide6.QtGui import QIcon, QFont
from openpyxl import Workbook
from datetime import date, datetime

def eirDataUI(self, layout):
	from PySide6.QtWidgets import QApplication, QLabel

	checkAllUserIconPath = self.currentTheme.get('oppositeColorCheckBoxIcon')
	unCheckAllUserIconPath = self.currentTheme.get('oppositeColorUnCheckBoxIcon')
	partiallyCheckedIconPath = self.currentTheme.get('oppositeColorPartiallyCheckedBoxIcon')
	deleteIconPath = self.currentTheme.get('whiteDeleteIcon')
	downloadIconPath = self.currentTheme.get('downloadIcon')
	refreshTableIconPath = self.currentTheme.get('refreshIcon')

	self.createPushButton('selectAllEirButton', '', unCheckAllUserIconPath, 30)
	self.selectAllEirButton.setCheckable(True)
	self.createPushButton('deleteButton_Eir', '', deleteIconPath, 35, 'Delete')
	self.createLineEditBox('serachBarOfEirTable', 'Search...' )
	self.serachBarOfEirTable.setClearButtonEnabled(True)
	self.serachBarOfEirTable.setFixedWidth(self.geometryWidth(0.2))
	self.createPushButton('download_Eir', '', downloadIconPath, 35, 'Download')
	self.createPushButton('refreshButton_Eir', '', refreshTableIconPath, 35, 'Refresh')
	self.createPushButton('newEir_EIR', '+ New EIR No', '', self.geometryWidth(0.059))

	

	self.eirHboxLayout = QHBoxLayout()
	self.eirHboxLayout.addWidget(self.selectAllEirButton)
	self.eirHboxLayout.addWidget(self.deleteButton_Eir)
	self.eirHboxLayout.addWidget(self.serachBarOfEirTable)
	self.eirHboxLayout.addWidget(self.download_Eir)
	self.eirHboxLayout.addWidget(self.refreshButton_Eir)
	self.eirHboxLayout.addItem(QSpacerItem(1, 0, QSizePolicy.Expanding, QSizePolicy.Minimum))
	self.eirHboxLayout.addWidget(self.newEir_EIR)
	layout.addLayout(self.eirHboxLayout)

	statuses = ["Closed", "Submitted for Closure",  "Under Monitoring", "In Progress", "Not Issued"]
	
	self.eirSummaryTable_EIR = TableWidget()
	self.headersOfSummayEIRTable  = ['Total EIRs'] + statuses
	self.eirSummaryTable_EIR.setColumnCount(len(self.headersOfSummayEIRTable))
	self.eirSummaryTable_EIR.setRowCount(2)
	self.eirSummaryTable_EIR.setHorizontalHeaderLabels(self.headersOfSummayEIRTable)
	self.eirSummaryTable_EIR.setStyleSheet(self.tableWidgetQSS)
	self.eirSummaryTable_EIR.horizontalHeader().setStyleSheet(self.headerHorizontalQSS)
	self.eirSummaryTable_EIR.setAlternatingRowColors(True)
	self.eirSummaryTable_EIR.setShowGrid(False)
	self.eirSummaryTable_EIR.setEditTriggers(QAbstractItemView.NoEditTriggers)

	

	lineWiseStatusDict = {status: 1 for status in statuses}
	self.totalStatusChartView = self.createPieChart(lineWiseStatusDict, 'EIR Summary')
	self.totalStatusChartView.setFixedHeight(525)
	self.totalStatusChartView.setFixedWidth(self.geometryWidth(0.45))


	self.dataTable_EIR = TableWidget()
	self.headersOfDataEIRTable  = ['', 'EIR No', 'ECR No', 'System', 'Subject', 'Repercussion', 'Action Taken', 'Status', 'PDC', 'Resp', 'Vendor', 'Latest Submission date', "DMRC's Reply Letter Reference Number/DMRC Reply Date", 'Remarks']
	self.dataTable_EIR.setColumnCount(len(self.headersOfDataEIRTable))
	self.dataTable_EIR.setHorizontalHeaderLabels(self.headersOfDataEIRTable)
	self.dataTable_EIR.setStyleSheet(self.tableWidgetQSS)
	self.dataTable_EIR.horizontalHeader().setStyleSheet(self.headerHorizontalQSS)
	self.dataTable_EIR.setAlternatingRowColors(True)
	self.dataTable_EIR.setShowGrid(False)
	self.dataTable_EIR.setEditTriggers(QAbstractItemView.NoEditTriggers)
	self.dataTable_EIR.setMinimumHeight(self.geometryHeight(0.68))


	layout.addWidget(self.dataTable_EIR)

	EIRSummaryLabel = QLabel('EIR Summary')
	EIRSummaryLabel.setStyleSheet("font-size: 18px;")
	layout.addWidget(EIRSummaryLabel)
	layout.addWidget(self.eirSummaryTable_EIR)
	layout.addWidget(self.totalStatusChartView, alignment = Qt.AlignCenter)

	self.eirSummaryTable_EIR.setColumnWidth(0, self.geometryWidth(0.06))
	self.eirSummaryTable_EIR.setColumnWidth(1, self.geometryWidth(0.05))
	self.eirSummaryTable_EIR.setColumnWidth(2, self.geometryWidth(0.1))
	self.eirSummaryTable_EIR.setColumnWidth(3, self.geometryWidth(0.08))
	self.eirSummaryTable_EIR.setColumnWidth(4, self.geometryWidth(0.06))
	self.eirSummaryTable_EIR.setColumnWidth(5, self.geometryWidth(0.06))
	
	self.eirSummaryTable_EIR.setMinimumHeight(self.geometryHeight(0.15))



	self.dataTable_EIR.setColumnWidth(0, self.geometryWidth(0.04))
	self.dataTable_EIR.setColumnWidth(1, self.geometryWidth(0.06))
	self.dataTable_EIR.setColumnWidth(2, self.geometryWidth(0.09))
	self.dataTable_EIR.setColumnWidth(3, self.geometryWidth(0.09))
	self.dataTable_EIR.setColumnWidth(4, self.geometryWidth(0.12))
	self.dataTable_EIR.setColumnWidth(5, self.geometryWidth(0.14))
	self.dataTable_EIR.setColumnWidth(6, self.geometryWidth(0.10))
	self.dataTable_EIR.setColumnWidth(7, self.geometryWidth(0.10))
	self.dataTable_EIR.setColumnWidth(8, self.geometryWidth(0.10))
	self.dataTable_EIR.setColumnWidth(9, self.geometryWidth(0.10))
	self.dataTable_EIR.setColumnWidth(10, self.geometryWidth(0.13))
	self.dataTable_EIR.setColumnWidth(11, self.geometryWidth(0.12))
	self.dataTable_EIR.setColumnWidth(12, self.geometryWidth(0.24))
	self.dataTable_EIR.setColumnWidth(13, self.geometryWidth(0.1))



	def OnClickingEirNoButton():
		self.eirWindow = QWidget()
		self.eirWindow.move(600, 200)
		self.eirWindow.resize(800, 400)
		self.eirWindow.setWindowTitle('EIR Number')
		self.eirWindow.setWindowIcon(QIcon('Media/ramsify.png'))


		vboxLayout = QVBoxLayout()
		formLayout = QFormLayout()
		vboxLayout.addLayout(formLayout)

		self.eirWindow.setLayout(vboxLayout)

		self.createNumberLineEditBox('eirNumber_EIR')
		self.createNumberLineEditBox('ecrNumber_EIR')
		self.createComboBox2(self.BOMSystemDictionary.keys(), 'systemComboBox_EIR')
		self.createLineEditBox('subject_EIR')
		self.createLineEditBox('repercussion_EIR')
		self.createTextEditBox('actionTaken_EIR')
		self.createComboBox2(statuses, 'status_EIR')

		self.createEmptyDateEditBox('datePdc_EIR')
		
		self.createLineEditBox('resp_EIR')
		self.createLineEditBox('vendor_EIR')

		self.createEmptyDateEditBox('latetSubmissionDate_EIR')
		
		self.createLineEditBox('dmrcsReplyletterReferenceNumber_EIR')
		self.createTextEditBox('remarks_EIR')
			

		formLayout.addRow('EIR No: <font color="red">*</font>', self.eirNumber_EIR)
		formLayout.addRow('ECR No: ', self.ecrNumber_EIR)
		formLayout.addRow('System: <font color="red">*</font>', self.systemComboBox_EIR)
		formLayout.addRow('Subject: <font color="red">*</font>', self.subject_EIR)
		formLayout.addRow('Repercussion: ', self.repercussion_EIR)
		formLayout.addRow('Action Taken: <font color="red">*</font>', self.actionTaken_EIR)
		formLayout.addRow('Status: <font color="red">*</font>', self.status_EIR)
		formLayout.addRow('PDC:', self.datePdc_EIR)
		formLayout.addRow('Resp:', self.resp_EIR)
		formLayout.addRow('Vendor:', self.vendor_EIR)
		formLayout.addRow('Latest Submission date:', self.latetSubmissionDate_EIR)
		formLayout.addRow("DMRC's Reply Letter Reference Number/ DMRC Reply Date:", self.dmrcsReplyletterReferenceNumber_EIR)
		formLayout.addRow('Remarks:', self.remarks_EIR)
		
		self.createPushButton('submitBtn_EIR', 'Submit', '', self.geometryWidth(0.04))
		self.createPushButton('cancelBtn_EIR', 'Cancel', '', self.geometryWidth(0.04))
		# vboxLayout.addWidget(self.submitBtn_EIR, alignment = Qt.AlignCenter)

		hBoxLayout = QHBoxLayout()
		hBoxLayout.addWidget(self.submitBtn_EIR, alignment = Qt.AlignRight)
		hBoxLayout.addWidget(self.cancelBtn_EIR, alignment = Qt.AlignLeft)
		vboxLayout.addLayout(hBoxLayout)


		formFields_EIR = [self.eirNumber_EIR, self.ecrNumber_EIR, self.systemComboBox_EIR, self.subject_EIR, self.repercussion_EIR, self.actionTaken_EIR, self.status_EIR, 
						self.datePdc_EIR, self.resp_EIR, self.vendor_EIR, self.latetSubmissionDate_EIR, self.dmrcsReplyletterReferenceNumber_EIR, self.remarks_EIR]

			
		def onClickingSubmit_EIR():
			mandatoryVerification_EIR = True
			mandatoryIndexesEir = [0, 2, 3, 5, 6]
			formFieldsData_EIR = []

			for i, wid in enumerate(formFields_EIR):
				if isinstance(wid, QLineEdit):
					if wid.text() == '':
						formFieldsData_EIR.append(None)
						if i in mandatoryIndexesEir:
							mandatoryVerification_EIR = False
							wid.setProperty("error", True)
							wid.setStyleSheet(self.lineEditBoxQSS)
					else:
						if wid.text().isdigit():
							formFieldsData_EIR.append(int(wid.text()))
						else:
							formFieldsData_EIR.append(wid.text()) 	

						wid.setProperty("error", False)
						wid.setStyleSheet(self.lineEditBoxQSS)

				if isinstance(wid, QTextEdit):
					if wid.toPlainText() == '':
						formFieldsData_EIR.append(None)
						if i in mandatoryIndexesEir:
							mandatoryVerification_EIR = False
							wid.setProperty("error", True)
							wid.setStyleSheet(self.textEditBoxQSS)		

					else:
						formFieldsData_EIR.append(wid.toPlainText())	
						wid.setProperty("error", False)
						wid.setStyleSheet(self.textEditBoxQSS)

				if isinstance(wid, QComboBox):
					if wid.isEnabled():
						if wid.currentText() == '':
							formFieldsData_EIR.append(None)
							if i in mandatoryIndexesEir:
								mandatoryVerification_EIR = False
								wid.setProperty("error", True)
								wid.setStyleSheet(self.comboBoxQSS)

						else:
							formFieldsData_EIR.append(wid.currentText())
							wid.setProperty("error", False)
							wid.setStyleSheet(self.comboBoxQSS)
					else:
						formFieldsData_EIR.append(None)

				elif isinstance(wid, QDateEdit):
					if i in mandatoryIndexesEir:
						if wid.lineEdit().text() == ' ':
							mandatoryVerification_EIR = False
							wid.setProperty("error", True)
							wid.setStyleSheet(self.dateEditBoxQSS)
							formFieldsData_EIR.append(None)
						else:
							qdate = wid.date()
							py_date = date(qdate.year(), qdate.month(), qdate.day())  # Convert QDate to Python date
							formFieldsData_EIR.append(py_date)
							wid.setProperty("error", False)
							wid.setStyleSheet(self.dateEditBoxQSS)
					else:
						if wid.lineEdit().text() == ' ':
							formFieldsData_EIR.append(None)
						else:
							qdate = wid.date()
							py_date = date(qdate.year(), qdate.month(), qdate.day())  # Convert QDate to Python date
							formFieldsData_EIR.append(py_date)
				

			if not mandatoryVerification_EIR:
				print('Mandatory fields missing.')

			else:
			
				formFieldsData_EIR.append(self.user_id)

				query = """
					INSERT INTO eir				
					(eir_no, ecr_number, system_eir, subject, repercussion, action_taken, status, pdc, resp, vendor, latest_submission_date,
					dmrcsreplyletter_referenceno_or_dmrcreply_date, remarks, user_id) 
					VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
				""" 

				try:
					self.cursor.execute(query, tuple(formFieldsData_EIR))
					self.mydb.commit()
					self.refreshButton_Eir.click()

					eirSubmitMsgBox = QMessageBox()
					eirSubmitMsgBox.setIcon(QMessageBox.Information) 
					eirSubmitMsgBox.setText(f'Data Submitted successfully.')
					eirSubmitMsgBox.setWindowTitle("Message")
					eirSubmitMsgBox.setWindowIcon(QIcon('Media/ramsify.png'))
					eirSubmitMsgBox.setStandardButtons(QMessageBox.Ok)
					eirSubmitMsgBox.exec_()

					self.eirWindow.close()

				except Exception as e:
					QMessageBox.critical(self, "Database Error", f"An error occurred: {e}")		

		self.submitBtn_EIR.clicked.connect(onClickingSubmit_EIR)

		self.eirWindow.show()


		def onClickingCancelButton_EIR():
			self.eirNumber_EIR.clear()
			self.ecrNumber_EIR.clear()
			self.systemComboBox_EIR.setCurrentIndex(-1)
			self.subject_EIR.clear()
			self.repercussion_EIR.clear()
			self.actionTaken_EIR.clear()
			self.status_EIR.setCurrentIndex(-1)
			self.datePdc_EIR.setDate(QDate())
			self.datePdc_EIR.lineEdit().setText(' ')
			self.resp_EIR.clear()
			self.vendor_EIR.clear()
			self.latetSubmissionDate_EIR.setDate(QDate())
			self.latetSubmissionDate_EIR.lineEdit().setText(' ')
			self.dmrcsReplyletterReferenceNumber_EIR.clear()
			self.remarks_EIR.clear()

		self.cancelBtn_EIR.clicked.connect(onClickingCancelButton_EIR)


	self.newEir_EIR.clicked.connect(OnClickingEirNoButton)

	def onClickingrefreshbutton_eir():
		self.deleteButton_Eir.hide()
		self.selectAllEirButton.setIcon(QIcon(unCheckAllUserIconPath))
		self.selectAllEirButton.setChecked(False)

		queryone = '''
						SELECT
							eir_no ,
							ecr_number,
							system_eir,
							subject,
							repercussion,
							action_taken,
							status,
							pdc,
							resp,
							vendor, 
							latest_submission_date,
							dmrcsreplyletter_referenceno_or_dmrcreply_date, 
							remarks,
							id

						FROM
							eir

						WHERE deleted_at IS NULL 
								
					'''
		self.cursor.execute(queryone)
		eirDataResult = self.cursor.fetchall()
		

		def givingFunctionalityToButton(button, func, data):
			button.clicked.connect(lambda: func(data))

		def onbuttonClickedEir(dataOfEir):
			self.eirUpdateWindow = QWidget()
			self.eirUpdateWindow.move(400, 100)
			self.eirUpdateWindow.resize(700, 800)

			self.eirUpdateWindow.setWindowTitle(str(dataOfEir[0]))
			self.eirUpdateWindow.setWindowIcon(QIcon('Media/ramsify.png'))

			vboxLayout = QVBoxLayout()
			formLayout = QFormLayout()
			vboxLayout.addLayout(formLayout)

			self.eirUpdateWindow.setLayout(vboxLayout)

			self.createNumberLineEditBox('eirNumber_EIR_')
			if dataOfEir[0]:
				self.eirNumber_EIR_.setText(str(dataOfEir[0]))
				self.eirNumber_EIR_.setToolTip(str(dataOfEir[0]))
			else:
				pass

			self.createNumberLineEditBox('ecrNumber_EIR_')
			if dataOfEir[1]:
				self.ecrNumber_EIR_.setText(str(dataOfEir[1]))
				self.ecrNumber_EIR_.setToolTip(str(dataOfEir[1]))
			else:
				pass

			self.createComboBox2(self.BOMSystemDictionary.keys(), 'systemComboBox_EIR_')
			self.systemComboBox_EIR_.setCurrentText(dataOfEir[2])

			self.createLineEditBox('subject_EIR_')
			self.subject_EIR_.setText(dataOfEir[3])
			self.subject_EIR_.setToolTip(dataOfEir[3])

			self.createLineEditBox('repercussion_EIR_')
			self.repercussion_EIR_.setText(dataOfEir[4])
			self.repercussion_EIR_.setToolTip(dataOfEir[4])

			self.createTextEditBox('actionTaken_EIR_')
			self.actionTaken_EIR_.setText(dataOfEir[5])
			self.actionTaken_EIR_.setToolTip(dataOfEir[5])


			self.createComboBox2(statuses, 'status_EIR_')
			self.status_EIR_.setCurrentText(dataOfEir[6])
			
			self.createEmptyDateEditBox('datePdc_EIR_')
			if dataOfEir[7]:
				self.datePdc_EIR_.setDate(QDate(dataOfEir[7].year, dataOfEir[7].month, dataOfEir[7].day))
			else:
				self.datePdc_EIR_.setDate(QDate())
			
			self.createLineEditBox('resp_EIR_')
			self.resp_EIR_.setText(dataOfEir[8])
			self.resp_EIR_.setToolTip(dataOfEir[8])

			self.createLineEditBox('vendor_EIR_')
			self.vendor_EIR_.setText(dataOfEir[9])
			self.vendor_EIR_.setToolTip(dataOfEir[9])

			self.createEmptyDateEditBox('latetSubmissionDate_EIR_')
			if dataOfEir[7]:
				self.latetSubmissionDate_EIR_.setDate(QDate(dataOfEir[10].year, dataOfEir[10].month, dataOfEir[10].day))
			else:
				self.latetSubmissionDate_EIR_.setDate(QDate())
			
			
			self.createLineEditBox('dmrcsReplyletterReferenceNumber_EIR_')
			self.dmrcsReplyletterReferenceNumber_EIR_.setText(dataOfEir[11])
			self.dmrcsReplyletterReferenceNumber_EIR_.setToolTip(dataOfEir[11])

			self.createTextEditBox('remarks_EIR_')
			self.remarks_EIR_.setText(dataOfEir[12])
			self.remarks_EIR_.setToolTip(dataOfEir[12])

			formLayout.addRow('EIR No: <font color="red">*</font>', self.eirNumber_EIR_)
			formLayout.addRow('ECR No: ', self.ecrNumber_EIR_)
			formLayout.addRow('System: <font color="red">*</font>', self.systemComboBox_EIR_)
			formLayout.addRow('Subject: <font color="red">*</font>', self.subject_EIR_)
			formLayout.addRow('Repercussion: ', self.repercussion_EIR_)
			formLayout.addRow('Action Taken: <font color="red">*</font>', self.actionTaken_EIR_)
			formLayout.addRow('Status: <font color="red">*</font>', self.status_EIR_)
			formLayout.addRow('PDC:', self.datePdc_EIR_)
			formLayout.addRow('Resp:', self.resp_EIR_)
			formLayout.addRow('Vendor:', self.vendor_EIR_)
			formLayout.addRow('Latest Submission date:', self.latetSubmissionDate_EIR_)
			formLayout.addRow("DMRC's Reply Letter Reference Number/ DMRC Reply date:", self.dmrcsReplyletterReferenceNumber_EIR_)
			formLayout.addRow('Remarks:', self.remarks_EIR_)
		

			self.createPushButton('updateBtn_EIR', 'Update', '', self.geometryWidth(0.04))

			vboxLayout.addWidget(self.updateBtn_EIR, alignment = Qt.AlignCenter)
			

			self.eirUpdateWindow.show()

			allFieldsDataEIR_ = [self.eirNumber_EIR_, self.ecrNumber_EIR_, self.systemComboBox_EIR_, self.subject_EIR_, self.repercussion_EIR_, self.actionTaken_EIR_, self.status_EIR_,
								 self.datePdc_EIR_, self.resp_EIR_, self.vendor_EIR_, self.latetSubmissionDate_EIR_, self.dmrcsReplyletterReferenceNumber_EIR_, self.remarks_EIR_]


			def setToolTip(wid, text):
				wid.setToolTip(text)

			def settingToolTipToLineEdits(wid):
				wid.textChanged.connect(lambda: setToolTip(wid, wid.text()))

			def settingToolTipToTextEdits(wid):
				wid.textChanged.connect(lambda: setToolTip(wid, wid.toPlainText()))
			
			for wid in allFieldsDataEIR_:
				if isinstance(wid, QLineEdit):
					settingToolTipToLineEdits(wid)

				if isinstance(wid, QTextEdit):
					settingToolTipToTextEdits(wid)


			def onClickingupdateEir():
				mandatoryVerification_EIR = True
				mandatoryIndexesEir = [0, 2, 3, 5, 6]
				dataOfUpdateFormEir = []

				for i, wid in enumerate(allFieldsDataEIR_):
					if isinstance(wid, QLineEdit):
						if wid.text() == '':
							dataOfUpdateFormEir.append(None)
							if i in mandatoryIndexesEir:
								mandatoryVerification_EIR = False
								wid.setProperty("error", True)
								wid.setStyleSheet(self.lineEditBoxQSS)
						else:
							if wid.text().isdigit():
								dataOfUpdateFormEir.append(int(wid.text()))
							else:
								dataOfUpdateFormEir.append(wid.text()) 	

							wid.setProperty("error", False)
							wid.setStyleSheet(self.lineEditBoxQSS)

					if isinstance(wid, QTextEdit):
						if wid.toPlainText() == '':
							dataOfUpdateFormEir.append(None)
							if i in mandatoryIndexesEir:
								mandatoryVerification_EIR = False
								wid.setProperty("error", True)
								wid.setStyleSheet(self.textEditBoxQSS)		

						else:
							dataOfUpdateFormEir.append(wid.toPlainText())	
							wid.setProperty("error", False)
							wid.setStyleSheet(self.textEditBoxQSS)

					if isinstance(wid, QComboBox):
						if wid.isEnabled():
							if wid.currentText() == '':
								dataOfUpdateFormEir.append(None)
								if i in mandatoryIndexesEir:
									mandatoryVerification_EIR = False
									wid.setProperty("error", True)
									wid.setStyleSheet(self.comboBoxQSS)

							else:
								dataOfUpdateFormEir.append(wid.currentText())
								wid.setProperty("error", False)
								wid.setStyleSheet(self.comboBoxQSS)

						else:
							dataOfUpdateFormEir.append(None)

					elif isinstance(wid, QDateEdit):
						if i in mandatoryIndexesEir:
							if wid.lineEdit().text() == ' ':
								mandatoryVerification_EIR = False
								wid.setProperty("error", True)
								wid.setStyleSheet(self.dateEditBoxQSS)
								dataOfUpdateFormEir.append(None)
							else:
								qdate = wid.date()
								py_date = date(qdate.year(), qdate.month(), qdate.day())  # Convert QDate to Python date
								dataOfUpdateFormEir.append(py_date)
								wid.setProperty("error", False)
								wid.setStyleSheet(self.dateEditBoxQSS)
						else:
							if wid.lineEdit().text() == ' ':
								dataOfUpdateFormEir.append(None)
							else:
								qdate = wid.date()
								py_date = date(qdate.year(), qdate.month(), qdate.day())  # Convert QDate to Python date
								dataOfUpdateFormEir.append(py_date)
					

				if not mandatoryVerification_EIR:
					pass

				else:
					
					dataOfUpdateFormEir.append(self.user_id)						
					
					update_queryone = """
										UPDATE eir
										SET
											eir_no = %s,
											ecr_number = %s,
											system_eir = %s,
											subject = %s,
											repercussion = %s,
											action_taken = %s,
											status = %s,
											pdc = %s,
											resp = %s,
											vendor = %s, 
											latest_submission_date = %s,
											dmrcsreplyletter_referenceno_or_dmrcreply_date = %s,
											remarks = %s,
											user_id = %s
										WHERE id = %s
									"""
					idNum = dataOfEir[13]		
					dataOfUpdateFormEir.append(idNum)

					
					try:
						self.cursor.execute(update_queryone, tuple(dataOfUpdateFormEir))
						self.mydb.commit()
						self.refreshButton_Eir.click()

						eirUpdateMsgBox = QMessageBox()
						eirUpdateMsgBox.setIcon(QMessageBox.Information) 
						eirUpdateMsgBox.setText(f'Data Updated successfully.')
						eirUpdateMsgBox.setWindowTitle("Message")
						eirUpdateMsgBox.setWindowIcon(QIcon('Media/ramsify.png'))
						eirUpdateMsgBox.setStandardButtons(QMessageBox.Ok)
						eirUpdateMsgBox.exec_()

						self.eirUpdateWindow.close()
					
					except Exception as e:
						print(f"Error executing update: {e}")				

			self.updateBtn_EIR.clicked.connect(onClickingupdateEir)
		
		self.dataTable_EIR.setRowCount(0)
	
		for rowIndex, rowData in enumerate(eirDataResult):
			self.dataTable_EIR.insertRow(self.dataTable_EIR.rowCount())

			eirCheckBoxWidget = QCheckBox('')
			eirCheckBoxWidget.setStyleSheet(self.checkBoxQSS)
			self.dataTable_EIR.setCellWidget(self.dataTable_EIR.rowCount()-1, 0, eirCheckBoxWidget)
			eirCheckBoxWidget.stateChanged.connect(onStateChangedOf_EIRCheckBox)

			for colIndex, erData in enumerate(rowData[:-1]):
				if colIndex == 0: 
					button = QPushButton(str(erData))
					givingFunctionalityToButton(button, onbuttonClickedEir, rowData)
					button.setStyleSheet(self.tableButtonQSS)
					button.setCursor(Qt.PointingHandCursor)
					self.dataTable_EIR.setCellWidget(self.dataTable_EIR.rowCount()-1, 1, button)

				else: 
					if erData is not None:
						item = QTableWidgetItem(str(erData))
					else:
						item = QTableWidgetItem('')
					item.setTextAlignment(Qt.AlignCenter)
					item.setToolTip(item.text())
					self.dataTable_EIR.setItem(self.dataTable_EIR.rowCount()-1, colIndex + 1, item)


		totalEIRs = self.dataTable_EIR.rowCount()
		self.eirSummaryTable_EIR.setItem(0, 0, QTableWidgetItem(str(totalEIRs)))

		statusCounts = []

		if totalEIRs == 0:
			self.eirSummaryTable_EIR.setItem(1, 0, QTableWidgetItem('0.00%'))

			for col, status in enumerate(statuses, start=1):
				self.eirSummaryTable_EIR.setItem(0, col, QTableWidgetItem(str(0)))
				self.eirSummaryTable_EIR.setItem(1, col, QTableWidgetItem('0.00%'))

			self.totalStatusChartView.hide()

		else:
			self.eirSummaryTable_EIR.setItem(1, 0, QTableWidgetItem('100%'))

			for col, status in enumerate(statuses, start=1):
				currentStatusCount = len([row[6] for row in eirDataResult if row[6] == status])
				statusCounts.append(currentStatusCount)
				self.eirSummaryTable_EIR.setItem(0, col, QTableWidgetItem(str(currentStatusCount)))

				percentage = (currentStatusCount / totalEIRs) * 100
				self.eirSummaryTable_EIR.setItem(1, col, QTableWidgetItem(f"{percentage:.2f}%"))


			pie_Series = self.totalStatusChartView.chart().series()[0]
			for i, slic in enumerate(pie_Series.slices()):
				slic.setValue(statusCounts[i])
				slic.setLabel(f'{statuses[i]} ({statusCounts[i]})')
			
			self.totalStatusChartView.show()


	self.refreshButton_Eir.clicked.connect(onClickingrefreshbutton_eir)



	def onSearchBox_Eir_Button():
		searchText = self.serachBarOfEirTable.text().lower()

		for row in range(self.dataTable_EIR.rowCount()):
			self.dataTable_EIR.setRowHidden(row, True)

			if self.dataTable_EIR.cellWidget(row, 1) and (searchText in self.dataTable_EIR.cellWidget(row, 1).text().lower()):
				self.dataTable_EIR.setRowHidden(row, False)
				continue

			for col in range(2, self.dataTable_EIR.columnCount()):
				item = self.dataTable_EIR.item(row, col)
				if item is not None and searchText in item.text().lower():
					self.dataTable_EIR.setRowHidden(row, False)
					break

	self.serachBarOfEirTable.textChanged.connect(onSearchBox_Eir_Button)

	def onClickingDownloadBtn_EIRDT():

		file_path, _ = QFileDialog.getSaveFileName(self, "Save Excel File", "", "Excel Files (*.xlsx)")
		if file_path:
			wb = Workbook()
			ws = wb.active

			headers = []
			for col in range(1, self.dataTable_EIR.columnCount()):
				if not self.dataTable_EIR.isColumnHidden(col):
					header_item = self.dataTable_EIR.horizontalHeaderItem(col)
					if header_item is not None:
						headers.append(header_item.text())

			ws.append(headers)

			row_index = 2
			for row in range(self.dataTable_EIR.rowCount()):
				if not self.dataTable_EIR.isRowHidden(row):
					for col in range(1, self.dataTable_EIR.columnCount()):
						if col == 1:
							wid = self.dataTable_EIR.cellWidget(row, col)
							if isinstance(wid, QPushButton):
								ws.cell(row=row_index, column=col).value = wid.text()
						else:	
							item = self.dataTable_EIR.item(row, col)
							if item is not None:
								ws.cell(row=row_index, column=col).value = item.text()

					row_index += 1

			wb.save(file_path)

			eirDownloadedMsgBox = QMessageBox()
			eirDownloadedMsgBox.setIcon(QMessageBox.Information) 
			eirDownloadedMsgBox.setText(f'Data downloaded successfully')
			eirDownloadedMsgBox.setWindowTitle("Message")
			eirDownloadedMsgBox.setWindowIcon(QIcon('Media/ramsify.png'))
			eirDownloadedMsgBox.setStandardButtons(QMessageBox.Ok)
			eirDownloadedMsgBox.exec_()

	self.download_Eir.clicked.connect(onClickingDownloadBtn_EIRDT)

	def onClicking_SelectAll_EIRDT(checked):
		if checked:
			self.selectAllEirButton.setIcon(QIcon(checkAllUserIconPath))

			for i in range(self.dataTable_EIR.rowCount()):
				if not self.dataTable_EIR.isRowHidden(i):
					if isinstance(self.dataTable_EIR.cellWidget(i,0), QCheckBox):
						self.dataTable_EIR.cellWidget(i,0).setCheckState(Qt.Checked)
		
		else:
			self.selectAllEirButton.setIcon(QIcon(unCheckAllUserIconPath))

			for i in range(self.dataTable_EIR.rowCount()):
				if not self.dataTable_EIR.isRowHidden(i):
					if isinstance(self.dataTable_EIR.cellWidget(i,0), QCheckBox):
						self.dataTable_EIR.cellWidget(i,0).setCheckState(Qt.Unchecked)
	
	self.selectAllEirButton.toggled.connect(onClicking_SelectAll_EIRDT)


	def onStateChangedOf_EIRCheckBox():
		all_checked = True
		all_unchecked = True

		for i in range(self.dataTable_EIR.rowCount()):
			if not self.dataTable_EIR.isRowHidden(i):
				if isinstance(self.dataTable_EIR.cellWidget(i,0), QCheckBox):
					if self.dataTable_EIR.cellWidget(i,0).isChecked():
						all_unchecked = False
					else:
						all_checked = False

		if all_checked or all_unchecked:
			some_checked = False
		else:
			some_checked = True


		if all_checked:
			self.deleteButton_Eir.show()
			self.selectAllEirButton.setIcon(QIcon(checkAllUserIconPath))
			self.selectAllEirButton.setChecked(True)
			

		if all_unchecked:
			self.deleteButton_Eir.hide()
			self.selectAllEirButton.setIcon(QIcon(unCheckAllUserIconPath))
			self.selectAllEirButton.setChecked(False)

		if some_checked:
			self.deleteButton_Eir.show()
			self.selectAllEirButton.setIcon(QIcon(partiallyCheckedIconPath))


	def onClicking_Delete_EIRDT():
			
		selectedEirnoIndices_ = []
		selectedEirnos = []

		numberOfSelectedEirnos = 0

		for i in range(self.dataTable_EIR.rowCount()):
			if not self.dataTable_EIR.isRowHidden(i):
				if isinstance(self.dataTable_EIR.cellWidget(i,0), QCheckBox):
					if self.dataTable_EIR.cellWidget(i,0).checkState() == Qt.Checked:
						selectedEirnoIndices_.append(i)

						eirnoButton = self.dataTable_EIR.cellWidget(i, 1)
						if eirnoButton:
							selectedEirnos.append(eirnoButton.text())
							numberOfSelectedEirnos += 1
		

		if selectedEirnos:

			confirmDeleteEIRMsgBox = QMessageBox()
			confirmDeleteEIRMsgBox.setIcon(QMessageBox.Question) 
			confirmDeleteEIRMsgBox.setText(f"Are you sure you want to delete {numberOfSelectedEirnos} EIR(s)?")
			confirmDeleteEIRMsgBox.setWindowTitle("Confirm")
			confirmDeleteEIRMsgBox.setWindowIcon(QIcon('Media/ramsify.png'))
			confirmDeleteEIRMsgBox.setStandardButtons(QMessageBox.Ok | QMessageBox.No)
			
			userResponse = confirmDeleteEIRMsgBox.exec()

			if userResponse == QMessageBox.Ok:
				current_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
				for ind in sorted(selectedEirnoIndices_, reverse=True):
					eirnoToDelete = selectedEirnos[selectedEirnoIndices_.index(ind)]
					sql = "UPDATE eir SET deleted_at = %s, user_id = %s WHERE eir_no = %s"
					values = (current_time, self.user_id, eirnoToDelete )
					self.cursor.execute(sql, values)
					self.mydb.commit()
					self.dataTable_EIR.removeRow(ind)

				eirDeleteSuccessMsgBox = QMessageBox()
				eirDeleteSuccessMsgBox.setIcon(QMessageBox.Information) 
				eirDeleteSuccessMsgBox.setText(f'{numberOfSelectedEirnos} EIRs deleted successfully.')
				eirDeleteSuccessMsgBox.setWindowTitle("Message")
				eirDeleteSuccessMsgBox.setWindowIcon(QIcon('Media/ramsify.png'))
				eirDeleteSuccessMsgBox.setStandardButtons(QMessageBox.Ok)
				eirDeleteSuccessMsgBox.exec()
				self.refreshButton_Eir.click()
				self.deleteButton_Eir.hide()
				self.selectAllEirButton.setIcon(QIcon(unCheckAllUserIconPath))
			
			else:
				pass

	self.deleteButton_Eir.clicked.connect(onClicking_Delete_EIRDT)
	
	onClickingrefreshbutton_eir()