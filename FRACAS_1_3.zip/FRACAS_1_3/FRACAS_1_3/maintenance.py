from configuration import *
from PySide6.QtWidgets import QTabWidget, QWidget, QVBoxLayout, QLabel, QSizePolicy, QScrollArea, QFormLayout

from correctiveMaintenance import CMUI
from preventiveMaintenance import OPMUI
from serviceChecks import SCUI
from functions import logErrors

# @logErrors
def maintenanceUI(self):
	from PySide6.QtWidgets import QApplication

	layoutForTypeOfMaintenance = QFormLayout()
	 
	self.createComboBox(['Corrective Maintenance', 'Other Preventive Maintenance', 'Service Check'], 'typeOfMaintenanceCombobox')
	layoutForTypeOfMaintenance.addRow('Type of Maintenance:', self.typeOfMaintenanceCombobox)
	self.mainVerticalLayout_Maintenance.addLayout(layoutForTypeOfMaintenance)

	# Create three tabs
	self.CMTabWidget = QWidget()
	self.OPMTabWidget = QWidget()
	self.SCTabWidget = QWidget()

	self.mainVerticalLayout_Maintenance.addWidget(self.CMTabWidget)
	self.mainVerticalLayout_Maintenance.addWidget(self.OPMTabWidget)
	self.mainVerticalLayout_Maintenance.addWidget(self.SCTabWidget)


	CMUI(self,self.CMTabWidget)
	OPMUI(self,self.OPMTabWidget)
	SCUI(self,self.SCTabWidget)

	self.CMTabWidget.setVisible(False)
	self.OPMTabWidget.setVisible(False)
	self.SCTabWidget.setVisible(False)

	def onChangingTypeOfMaintenance(index):
		if index == 0:
			self.CMTabWidget.setVisible(True)
			self.OPMTabWidget.setVisible(False)
			self.SCTabWidget.setVisible(False)

		if index == 1:
			self.CMTabWidget.setVisible(False)
			self.OPMTabWidget.setVisible(True)
			self.SCTabWidget.setVisible(False)

		if index == 2:
			self.CMTabWidget.setVisible(False)
			self.OPMTabWidget.setVisible(False)
			self.SCTabWidget.setVisible(True)

	self.typeOfMaintenanceCombobox.currentIndexChanged.connect(onChangingTypeOfMaintenance)