from PySide6.QtWidgets import QTableWidgetItem, QPushButton, QWidget, QHBoxLayout, QVBoxLayout, QCheckBox, QGridLayout, QScrollArea , QAbstractItemView, QMessageBox, QFormLayout, QFileDialog, QHeaderView, QLabel, QComboBox, QDateEdit, QTimeEdit, QTextEdit, QSizePolicy, QSpacerItem, QLineEdit, QDialog, QDialogButtonBox
from functions import TableWidget
from datetime import datetime, timedelta
from dateutil.relativedelta import relativedelta
from PySide6.QtCore import Qt, QDateTime, QDate, QTime
from PySide6.QtGui import QIcon, QIntValidator
import time
from openpyxl import Workbook
import os
import shutil

def serviceFailuresUI(self, mainLayout):
	from PySide6.QtWidgets import QApplication
	self.layoutForFilters_sfDataTable = QHBoxLayout()

	self.createLineEditBox('serachBarOfSFDataTable', 'Search..' )
	self.serachBarOfSFDataTable.setClearButtonEnabled(True)
	self.serachBarOfSFDataTable.setFixedWidth(int(0.2 * QApplication.primaryScreen().availableGeometry().width()))


	self.fromFormLayout_SFDT = QFormLayout()
	self.toFormLayout_SFDT = QFormLayout()
	
	start_date = datetime(self.startingYear, self.startingMonth, 1).date()
	#print('start_date', start_date)

	self.createDateEditBox('fromDateEditBox_SFDT')
	self.fromDateEditBox_SFDT.setMinimumDate(QDate(self.startingYear, self.startingMonth, 1))
	# self.fromDateEditBox_SFDT.setDate(start_date)

	self.createDateEditBox('toDateEditBox_SFDT')
	self.toDateEditBox_SFDT.setMinimumDate(QDate(self.startingYear, self.startingMonth, 1))
	# self.toDateEditBox_SFDT.setDate(QDate.currentDate())

	self.fromFormLayout_SFDT.addRow(QLabel('From: '), self.fromDateEditBox_SFDT)
	self.toFormLayout_SFDT.addRow(QLabel('To: '), self.toDateEditBox_SFDT)


	clearFilterIconPath = self.currentTheme.get('clearTableFilterIcon')
	downloadIconPath = self.currentTheme.get('downloadIcon')


	deleteIconPath = self.currentTheme.get('whiteDeleteIcon')
	darkCheckBoxIconPath = self.currentTheme.get('darkCheckBoxIcon')
	darkUnCheckBoxIconPath = self.currentTheme.get('darkUnCheckBoxIcon')


	checkAllUserIconPath = self.currentTheme.get('oppositeColorCheckBoxIcon')
	unCheckAllUserIconPath = self.currentTheme.get('oppositeColorUnCheckBoxIcon')
	partiallyCheckedIconPath = self.currentTheme.get('oppositeColorPartiallyCheckedBoxIcon')

	customFilterIconPath = self.currentTheme.get('customFilterIcon')


	self.createPushButton('selectAllSFdataButton', '', unCheckAllUserIconPath, 30)
	self.createPushButton('deleteButton_SFDT', '', deleteIconPath, 35, 'Delete')
	self.createPushButton('customFilterButton_SFDT', '', customFilterIconPath, 35, 'Custom Filter')
	self.createPushButton('clearAllFiltersButton_SFDT', '', clearFilterIconPath, 35, 'Clear Filters')
	self.createPushButton('download_SFDT', '', downloadIconPath, 35, 'Download')
	self.createPushButton('apply_SFDT', 'Apply', '', 80)


	self.layoutForFilters_sfDataTable.addWidget(self.selectAllSFdataButton)
	self.layoutForFilters_sfDataTable.addWidget(self.deleteButton_SFDT)
	self.layoutForFilters_sfDataTable.addWidget(self.customFilterButton_SFDT)

	self.layoutForFilters_sfDataTable.addItem(QSpacerItem(1, 0, QSizePolicy.Expanding, QSizePolicy.Minimum))
	self.layoutForFilters_sfDataTable.addWidget(self.serachBarOfSFDataTable)
	self.layoutForFilters_sfDataTable.addLayout(self.fromFormLayout_SFDT)
	self.layoutForFilters_sfDataTable.addLayout(self.toFormLayout_SFDT)
	self.layoutForFilters_sfDataTable.addWidget(self.apply_SFDT)
	self.layoutForFilters_sfDataTable.addWidget(self.clearAllFiltersButton_SFDT)
	self.layoutForFilters_sfDataTable.addWidget(self.download_SFDT)


	mainLayout.addLayout(self.layoutForFilters_sfDataTable)




	self.sfDataTable = TableWidget()
	headers = ['', "Id", "Date & Time", 'Depot', "Train", "Car No", 'JC No', 'Issued to', 'ML/Depot', 'Location', "System", "Sub-System", 'Other Sub-System', 'Fault Details', 'Failure Type', 'Service Failure Effect', 'Consider for Relevant Fails', 'Action Taken At Mainline', 'Action Taken At Depot', 'Failure Category', 'Responsibility', 'Equipment', 'Component', 'Lowest Level Component', 'NCR', 'Is Component Replaced', 'Replaced Component', 'Verification', 'Work Start At', 'Work End At', 'Down Time', 'Overlapped IDs']
	self.sfDataTable.setColumnCount(len(headers))
	self.sfDataTable.setHorizontalHeaderLabels(headers)
	self.sfDataTable.setStyleSheet(self.tableWidgetQSS)
	self.sfDataTable.horizontalHeader().setStyleSheet(self.headerHorizontalQSS)
	# self.sfDataTable.verticalHeader().setStyleSheet(self.headerVerticalQSS)
	self.sfDataTable.setAlternatingRowColors(True)
	self.sfDataTable.setShowGrid(False)
	mainLayout.addWidget(self.sfDataTable)
	self.sfDataTable.setEditTriggers(QAbstractItemView.NoEditTriggers)
	
	self.sfDataTable.setColumnWidth(0, int(0.01 * QApplication.primaryScreen().availableGeometry().width()))
	self.sfDataTable.setColumnWidth(1, int(0.1 * QApplication.primaryScreen().availableGeometry().width()))
	self.sfDataTable.setColumnWidth(2, int(0.07 * QApplication.primaryScreen().availableGeometry().width()))
	self.sfDataTable.setColumnWidth(3, int(0.035 * QApplication.primaryScreen().availableGeometry().width()))
	self.sfDataTable.setColumnWidth(4, int(0.035 * QApplication.primaryScreen().availableGeometry().width()))
	self.sfDataTable.setColumnWidth(5, int(0.04 * QApplication.primaryScreen().availableGeometry().width()))
	self.sfDataTable.setColumnWidth(6, int(0.05 * QApplication.primaryScreen().availableGeometry().width()))
	self.sfDataTable.setColumnWidth(7, int(0.08 * QApplication.primaryScreen().availableGeometry().width()))
	self.sfDataTable.setColumnWidth(8, int(0.06 * QApplication.primaryScreen().availableGeometry().width()))
	self.sfDataTable.setColumnWidth(9, int(0.07 * QApplication.primaryScreen().availableGeometry().width()))
	self.sfDataTable.setColumnWidth(10, int(0.15 * QApplication.primaryScreen().availableGeometry().width()))
	self.sfDataTable.setColumnWidth(11, int(0.15 * QApplication.primaryScreen().availableGeometry().width()))
	self.sfDataTable.setColumnWidth(12, int(0.12 * QApplication.primaryScreen().availableGeometry().width()))
	self.sfDataTable.setColumnWidth(13, int(0.12 * QApplication.primaryScreen().availableGeometry().width()))
	self.sfDataTable.setColumnWidth(14, int(0.08 * QApplication.primaryScreen().availableGeometry().width()))
	self.sfDataTable.setColumnWidth(15, int(0.11 * QApplication.primaryScreen().availableGeometry().width()))
	self.sfDataTable.setColumnWidth(16, int(0.12 * QApplication.primaryScreen().availableGeometry().width()))
	self.sfDataTable.setColumnWidth(17, int(0.12 * QApplication.primaryScreen().availableGeometry().width()))
	self.sfDataTable.setColumnWidth(18, int(0.12 * QApplication.primaryScreen().availableGeometry().width()))
	self.sfDataTable.setColumnWidth(19, int(0.09 * QApplication.primaryScreen().availableGeometry().width()))
	self.sfDataTable.setColumnWidth(20, int(0.1 * QApplication.primaryScreen().availableGeometry().width()))
	self.sfDataTable.setColumnWidth(21, int(0.1 * QApplication.primaryScreen().availableGeometry().width()))
	self.sfDataTable.setColumnWidth(22, int(0.1 * QApplication.primaryScreen().availableGeometry().width()))
	self.sfDataTable.setColumnWidth(23, int(0.14 * QApplication.primaryScreen().availableGeometry().width()))
	self.sfDataTable.setColumnWidth(24, int(0.08 * QApplication.primaryScreen().availableGeometry().width()))
	self.sfDataTable.setColumnWidth(25, int(0.12 * QApplication.primaryScreen().availableGeometry().width()))
	self.sfDataTable.setColumnWidth(26, int(0.11 * QApplication.primaryScreen().availableGeometry().width()))
	self.sfDataTable.setColumnWidth(27, int(0.08 * QApplication.primaryScreen().availableGeometry().width()))
	self.sfDataTable.setColumnWidth(28, int(0.08 * QApplication.primaryScreen().availableGeometry().width()))
	self.sfDataTable.setColumnWidth(29, int(0.13 * QApplication.primaryScreen().availableGeometry().width()))
	# self.sfDataTable.setColumnWidth(26, int(0.13 * QApplication.primaryScreen().availableGeometry().width()))
	# self.sfDataTable.setColumnWidth(27, int(0.13 * QApplication.primaryScreen().availableGeometry().width()))
	# self.sfDataTable.setColumnWidth(28, int(0.13 * QApplication.primaryScreen().availableGeometry().width()))

	

	self.sfDataTable.setMinimumHeight(int(0.74 * QApplication.primaryScreen().availableGeometry().height()))

	self.selectAllSFdataButton.setVisible(True)
	self.selectAllSFdataButton.setCheckable(True)
	self.selectAllSFdataButton.setFixedHeight(26)

	self.deleteButton_SFDT.setVisible(False)


	def on_searchBox_filter_sf_data_table():

		searchText = self.serachBarOfSFDataTable.text().lower()

		for row in range(self.sfDataTable.rowCount()):
			self.sfDataTable.setRowHidden(row, True)

			if searchText in self.sfDataTable.cellWidget(row, 1).text().lower():
				self.sfDataTable.setRowHidden(row, False)

			for col in range(1,self.sfDataTable.columnCount()):
				item = self.sfDataTable.item(row, col)
				if item is not None and searchText in item.text().lower():
					self.sfDataTable.setRowHidden(row, False)
					break

	self.serachBarOfSFDataTable.textChanged.connect(on_searchBox_filter_sf_data_table)


	def OnClickingcustomFilterButton_SFDT():

		self.customFilterWidget_SFDT = QWidget()
		customFiltertWindowWidth_SFDT = int(0.365* QApplication.primaryScreen().availableGeometry().width())
		customFiltertWindowHeight_SFDT = int(0.6 * QApplication.primaryScreen().availableGeometry().height())

		self.customFilterWidget_SFDT.setWindowTitle("Custom Filter for CM")
		self.customFilterWidget_SFDT.setWindowIcon(QIcon('Media/ramsify.png'))
		self.customFilterWidget_SFDT.setStyleSheet(self.widgetQSS)
		self.customFilterWidget_SFDT.resize(customFiltertWindowWidth_SFDT, customFiltertWindowHeight_SFDT)


		layoutToAddScrollArea_SFDT = QVBoxLayout()
		self.customFilterWidget_SFDT.setLayout(layoutToAddScrollArea_SFDT)
		self.ScrollAreaForCustomFilters_SFDT = QScrollArea()
		self.ScrollAreaForCustomFilters_SFDT.setWidgetResizable(True)
		layoutToAddScrollArea_SFDT.addWidget(self.ScrollAreaForCustomFilters_SFDT)
		self.ScrollAreaForCustomFilters_SFDT.setStyleSheet(self.scrollAreaQSS)
		widgetToPutInScrollArea_SFDT = QWidget()
		mainLayoutOfCustomFilterWidget_SFDT = QVBoxLayout()
		gridLayoutOfCustomFilterWidget_SFDT = QGridLayout()
		LayoutForApplyButttonFilterWidget_SFDT = QHBoxLayout()
		widgetToPutInScrollArea_SFDT.setLayout(mainLayoutOfCustomFilterWidget_SFDT)
		self.ScrollAreaForCustomFilters_SFDT.setWidget(widgetToPutInScrollArea_SFDT)

		mainLayoutOfCustomFilterWidget_SFDT.addLayout(gridLayoutOfCustomFilterWidget_SFDT)
		mainLayoutOfCustomFilterWidget_SFDT.addLayout(LayoutForApplyButttonFilterWidget_SFDT)


		lablesForCustomFilters_SFDT = ['Event Date', 'Depot', "Train", "Car No", 'Jobcard No', 'Issued to', 'ML/Depot', 'Location', 
						 "System", "Sub System", 'Other Sub-System', 'Fault Details', 'Failure Type', 'Service Failure Effect', 'Consider for Relevant Fails', 'Action Taken At Mainline', 
						 'Action Taken At Depot', 'Failure Category', 'Failure Responsibility', 'Equipment', 'Component', 'Lowest Level Component',
						 'NCR no', 'Is Component Replaced?', 'Replaced Component', 'Verification', 'Work Start Date', 'Work End Date', 'Down Time(Minutes)']

		

		indicesOfComboboxes_SFDT = [1,2,3,6,8,9,12,13,14,17,18,23,25]
		indicesOfDateEdits_SFDT = [0,26,27]
		indicesOfLineEdits_SFDT = [4,5,7,10,11,15,16,19,20,21,22,24]
		indicesOfSpinBox_SFDT = [28]

		indicesOfMandatoryFields_SFDTFilter = [0, 1, 2, 8, 9, 11, 12, 14, 16, 18, 25, 26, 27]


		conditionsForDateEdit = ['Equals To', 'Not Equals To', 'Greater-than or Equals to', 'Less-than or Equals to']
		conditionsForCombobox = ['Equals To', 'Not Equals To']
		conditionsForLineEdits = ['Equals To', 'Not Equals To', 'Contains', 'Does not Contains']
		conditionsForSpinBox = ['Equals To', 'Not Equals To', 'Greater-than or Equals to', 'Less-than or Equals to']

		for i, stri in enumerate(lablesForCustomFilters_SFDT):
			if i in indicesOfMandatoryFields_SFDTFilter:
				gridLayoutOfCustomFilterWidget_SFDT.addWidget(QLabel(stri+'<font color="red">*</font>'), i, 0)
			else:
				gridLayoutOfCustomFilterWidget_SFDT.addWidget(QLabel(stri), i, 0)


		for ind in indicesOfDateEdits_SFDT:
			self.createComboBox(conditionsForDateEdit, 'conditionComboboxForDE_SFDT')
			self.conditionComboboxForDE_SFDT.setFixedWidth(int(0.1* QApplication.primaryScreen().availableGeometry().width()))
			gridLayoutOfCustomFilterWidget_SFDT.addWidget(self.conditionComboboxForDE_SFDT, ind, 1)


			self.createDateEditBox('customFilterDateEdit_SFDT')
			gridLayoutOfCustomFilterWidget_SFDT.addWidget(self.customFilterDateEdit_SFDT, ind, 2)


		comboBoxOptions_SFDT = {
							1: self.depotsList,
							2: self.trainsetsList,
							3: self.carsList,
							6: ['M/L', 'Depot'],
							8: list(self.BOMSystemDictionary.keys()),
							9: [],
							12: ['Relevant Failure', 'Service Failure', 'Non Relevant Failure'],
							13: ['Pre-departure Withdrawal', 'Withdrawal', '3 min delay', 'Deboarding'],
							14: ['Yes', 'No'],
							17: ['External', 'Maintenance', 'Material', 'NFF', 'Operation', 'Software', 'Workmanship', 'Others'],
							18: ['BEML', 'MMMOCL', 'Others'],
							23: ['Yes', 'No'],
							25: ['Yes', 'No']
							}
		for ind in indicesOfComboboxes_SFDT:
			self.createComboBox(conditionsForCombobox, 'conditionComboboxForCB_SFDT')
			self.conditionComboboxForCB_SFDT.setFixedWidth(int(0.1* QApplication.primaryScreen().availableGeometry().width()))
			gridLayoutOfCustomFilterWidget_SFDT.addWidget(self.conditionComboboxForCB_SFDT, ind, 1)

			self.createComboBox(comboBoxOptions_SFDT[ind], 'customFilterCombobox_SFDT')
			gridLayoutOfCustomFilterWidget_SFDT.addWidget(self.customFilterCombobox_SFDT, ind, 2)


			if ind == 1:
				self.depotComboboxInCustomFilter_SFDT = self.customFilterCombobox_SFDT
			if ind == 2:
				self.trainComboboxInCustomFilter_SFDT = self.customFilterCombobox_SFDT

				def onChanginDepotCustomFilter_SFDT():
					if self.depotComboboxInCustomFilter_SFDT.currentIndex() != -1:
						self.trainComboboxInCustomFilter_SFDT.setEnabled(True)
						self.trainComboboxInCustomFilter_SFDT.clear()
						self.trainComboboxInCustomFilter_SFDT.addItems(self.depotTrainDictionary[self.depotComboboxInCustomFilter_SFDT.currentText()])
				self.depotComboboxInCustomFilter_SFDT.currentIndexChanged.connect(onChanginDepotCustomFilter_SFDT)

				self.trainComboboxInCustomFilter_SFDT.setEnabled(False)


			if ind == 8:
				self.systemComboboxInCustomFilter_SFDT = self.customFilterCombobox_SFDT
			if ind == 9:
				self.subSystemComboboxInCustomFilter_SFDT = self.customFilterCombobox_SFDT

				def onChanginSystemCustomFilter_SFDT():
					if self.systemComboboxInCustomFilter_SFDT.currentIndex() != -1:
						self.subSystemComboboxInCustomFilter_SFDT.setEnabled(True)
						self.subSystemComboboxInCustomFilter_SFDT.clear()
						self.subSystemComboboxInCustomFilter_SFDT.addItems(self.BOMSystemDictionary[self.systemComboboxInCustomFilter_SFDT.currentText()])
				self.systemComboboxInCustomFilter_SFDT.currentIndexChanged.connect(onChanginSystemCustomFilter_SFDT)

				self.subSystemComboboxInCustomFilter_SFDT.setEnabled(False)


		for ind in indicesOfLineEdits_SFDT:
			self.createComboBox(conditionsForLineEdits, 'conditionComboboxForLE_SFDT')
			self.conditionComboboxForLE_SFDT.setFixedWidth(int(0.1* QApplication.primaryScreen().availableGeometry().width()))
			gridLayoutOfCustomFilterWidget_SFDT.addWidget(self.conditionComboboxForLE_SFDT, ind, 1)

			self.createLineEditBox('customFilterLineEdit_SFDT')
			gridLayoutOfCustomFilterWidget_SFDT.addWidget(self.customFilterLineEdit_SFDT, ind, 2)

		

		for ind in indicesOfSpinBox_SFDT:
			self.createComboBox(conditionsForSpinBox, 'conditionComboboxForSB_SFDT')
			self.conditionComboboxForSB_SFDT.setFixedWidth(int(0.1* QApplication.primaryScreen().availableGeometry().width()))
			gridLayoutOfCustomFilterWidget_SFDT.addWidget(self.conditionComboboxForSB_SFDT, ind, 1)

			self.createLineEditBox('customFilterSpinBoxEdit_SFDT')
			validator = QIntValidator(0, 2147483647)
			self.customFilterSpinBoxEdit_SFDT.setValidator(validator)
			gridLayoutOfCustomFilterWidget_SFDT.addWidget(self.customFilterSpinBoxEdit_SFDT, ind, 2)


		# Create apply and cancel buttons
		self.createPushButton('applyCustomFilterBtn_SFDT', 'Apply', '', width=int(0.050 * QApplication.primaryScreen().availableGeometry().width()))
		self.applyCustomFilterBtn_SFDT.setFixedHeight(30)

		self.createPushButton('cancelCustomFilterBtn_SFDT', 'Cancel', '',width=int(0.050 * QApplication.primaryScreen().availableGeometry().width()))
		self.cancelCustomFilterBtn_SFDT.setFixedHeight(30)
		
		LayoutForApplyButttonFilterWidget_SFDT.addWidget(self.applyCustomFilterBtn_SFDT, alignment = Qt.AlignRight)
		LayoutForApplyButttonFilterWidget_SFDT.addWidget(self.cancelCustomFilterBtn_SFDT, alignment = Qt.AlignLeft)


		def onClickingApplyCustomFilter_SFDT():
			customFilterValid_SFDT = True
			selectedIndicesInCustomFilter_SFDT = []

			for r in range(gridLayoutOfCustomFilterWidget_SFDT.rowCount()):
				if r not in indicesOfDateEdits_SFDT:
					conditionBoxSelected = False
					fieldBoxSelected = False

					if gridLayoutOfCustomFilterWidget_SFDT.itemAtPosition(r, 1).widget().currentIndex() != -1:
						conditionBoxSelected = True

					if r in indicesOfComboboxes_SFDT:
						if gridLayoutOfCustomFilterWidget_SFDT.itemAtPosition(r, 2).widget().currentIndex() != -1:
							fieldBoxSelected = True


					elif r in indicesOfLineEdits_SFDT:
						if gridLayoutOfCustomFilterWidget_SFDT.itemAtPosition(r, 2).widget().text() != '':
							fieldBoxSelected = True

					elif r in indicesOfSpinBox_SFDT:
						if gridLayoutOfCustomFilterWidget_SFDT.itemAtPosition(r, 2).widget().text() != '':
							fieldBoxSelected = True



					if conditionBoxSelected ^ fieldBoxSelected:
						if conditionBoxSelected:
							if r in indicesOfComboboxes_SFDT:
								gridLayoutOfCustomFilterWidget_SFDT.itemAtPosition(r, 1).widget().setProperty('error', False)
								gridLayoutOfCustomFilterWidget_SFDT.itemAtPosition(r, 1).widget().setStyleSheet(self.comboBoxQSS)

								if r in indicesOfMandatoryFields_SFDTFilter:
									gridLayoutOfCustomFilterWidget_SFDT.itemAtPosition(r, 2).widget().setProperty('error', True)
									gridLayoutOfCustomFilterWidget_SFDT.itemAtPosition(r, 2).widget().setStyleSheet(self.comboBoxQSS)
									customFilterValid_SFDT = False
								else:
									selectedIndicesInCustomFilter_SFDT.append(r)


							if r in indicesOfLineEdits_SFDT:
								gridLayoutOfCustomFilterWidget_SFDT.itemAtPosition(r, 1).widget().setProperty('error', False)
								gridLayoutOfCustomFilterWidget_SFDT.itemAtPosition(r, 1).widget().setStyleSheet(self.comboBoxQSS)

								if r in indicesOfMandatoryFields_SFDTFilter:
									gridLayoutOfCustomFilterWidget_SFDT.itemAtPosition(r, 2).widget().setProperty('error', True)
									gridLayoutOfCustomFilterWidget_SFDT.itemAtPosition(r, 2).widget().setStyleSheet(self.lineEditBoxQSS)
									customFilterValid_SFDT = False
								else:
									selectedIndicesInCustomFilter_SFDT.append(r)

							if r in indicesOfSpinBox_SFDT:
								gridLayoutOfCustomFilterWidget_SFDT.itemAtPosition(r, 1).widget().setProperty('error', False)
								gridLayoutOfCustomFilterWidget_SFDT.itemAtPosition(r, 1).widget().setStyleSheet(self.comboBoxQSS)

								if r in indicesOfMandatoryFields_SFDTFilter:
									gridLayoutOfCustomFilterWidget_SFDT.itemAtPosition(r, 2).widget().setProperty('error', True)
									gridLayoutOfCustomFilterWidget_SFDT.itemAtPosition(r, 2).widget().setStyleSheet(self.lineEditBoxQSS)
									customFilterValid_SFDT = False
								else:
									selectedIndicesInCustomFilter_SFDT.append(r)

						if fieldBoxSelected:
							gridLayoutOfCustomFilterWidget_SFDT.itemAtPosition(r, 2).widget().setProperty('error', False)
							if r in indicesOfComboboxes_SFDT:
								gridLayoutOfCustomFilterWidget_SFDT.itemAtPosition(r, 2).widget().setStyleSheet(self.comboBoxQSS)
							elif r in indicesOfLineEdits_SFDT:
								gridLayoutOfCustomFilterWidget_SFDT.itemAtPosition(r, 2).widget().setStyleSheet(self.lineEditBoxQSS)
							elif r in indicesOfSpinBox_SFDT:
								gridLayoutOfCustomFilterWidget_SFDT.itemAtPosition(r, 2).widget().setStyleSheet(self.lineEditBoxQSS)


							gridLayoutOfCustomFilterWidget_SFDT.itemAtPosition(r, 1).widget().setProperty('error', True)
							gridLayoutOfCustomFilterWidget_SFDT.itemAtPosition(r, 1).widget().setStyleSheet(self.comboBoxQSS)
							customFilterValid_SFDT = False

					else:
						gridLayoutOfCustomFilterWidget_SFDT.itemAtPosition(r, 1).widget().setProperty('error', False)
						gridLayoutOfCustomFilterWidget_SFDT.itemAtPosition(r, 1).widget().setStyleSheet(self.comboBoxQSS)

						if r in indicesOfComboboxes_SFDT:
							gridLayoutOfCustomFilterWidget_SFDT.itemAtPosition(r, 2).widget().setProperty('error', False)
							gridLayoutOfCustomFilterWidget_SFDT.itemAtPosition(r, 2).widget().setStyleSheet(self.comboBoxQSS)

						if r in indicesOfLineEdits_SFDT:
							gridLayoutOfCustomFilterWidget_SFDT.itemAtPosition(r, 2).widget().setProperty('error', False)
							gridLayoutOfCustomFilterWidget_SFDT.itemAtPosition(r, 2).widget().setStyleSheet(self.lineEditBoxQSS)

						if r in indicesOfSpinBox_SFDT:
							gridLayoutOfCustomFilterWidget_SFDT.itemAtPosition(r, 2).widget().setProperty('error', False)
							gridLayoutOfCustomFilterWidget_SFDT.itemAtPosition(r, 2).widget().setStyleSheet(self.lineEditBoxQSS)

					if conditionBoxSelected and fieldBoxSelected:
						if r not in selectedIndicesInCustomFilter_SFDT:
							selectedIndicesInCustomFilter_SFDT.append(r)
				else:
					if gridLayoutOfCustomFilterWidget_SFDT.itemAtPosition(r, 1).widget().currentIndex() != -1:
						if r not in selectedIndicesInCustomFilter_SFDT:
							selectedIndicesInCustomFilter_SFDT.append(r)


			if customFilterValid_SFDT:
				for row in range(self.sfDataTable.rowCount()):
					self.sfDataTable.setRowHidden(row, False)
				


				for r in selectedIndicesInCustomFilter_SFDT:
					for row in range(self.sfDataTable.rowCount()):
						if not self.sfDataTable.isRowHidden(row):
							conditionWidget = gridLayoutOfCustomFilterWidget_SFDT.itemAtPosition(r, 1).widget()
							fieldWidget = gridLayoutOfCustomFilterWidget_SFDT.itemAtPosition(r, 2).widget()

							if r in indicesOfComboboxes_SFDT:
								if conditionWidget.currentIndex() == 0:
									if fieldWidget.currentIndex() != -1:
										if fieldWidget.currentText() != self.sfDataTable.item(row, r+2).text():
											self.sfDataTable.setRowHidden(row, True)
									else:
										if '' != self.sfDataTable.item(row, r+2).text():
											self.sfDataTable.setRowHidden(row, True)

								elif conditionWidget.currentIndex() == 1:
									if fieldWidget.currentIndex() != -1:
										if fieldWidget.currentText() == self.sfDataTable.item(row, r+2).text():
											self.sfDataTable.setRowHidden(row, True)
									else:
										if '' == self.sfDataTable.item(row, r+2).text():
											self.sfDataTable.setRowHidden(row, True)


							if r in indicesOfLineEdits_SFDT:
								if conditionWidget.currentIndex() == 0:
									if fieldWidget.text().lower() != self.sfDataTable.item(row, r+2).text().lower():
										self.sfDataTable.setRowHidden(row, True)

								elif conditionWidget.currentIndex() == 1:
									if fieldWidget.text().lower() == self.sfDataTable.item(row, r+2).text().lower():
										self.sfDataTable.setRowHidden(row, True)

								elif conditionWidget.currentIndex() == 2:
									if not fieldWidget.text().lower() in self.sfDataTable.item(row, r+2).text().lower():
										self.sfDataTable.setRowHidden(row, True)

								elif conditionWidget.currentIndex() == 2:
									if fieldWidget.text().lower() in self.sfDataTable.item(row, r+2).text().lower():
										self.sfDataTable.setRowHidden(row, True)


							if r in indicesOfSpinBox_SFDT:
								if conditionWidget.currentIndex() == 0:
									if int(fieldWidget.text()) != int(self.sfDataTable.item(row, r+2).text()):
										self.sfDataTable.setRowHidden(row, True)

								elif conditionWidget.currentIndex() == 1:
									if int(fieldWidget.text()) == int(self.sfDataTable.item(row, r+2).text()):
										self.sfDataTable.setRowHidden(row, True)

								elif conditionWidget.currentIndex() == 2:
									if int(fieldWidget.text()) > int(self.sfDataTable.item(row, r+2).text()):
										self.sfDataTable.setRowHidden(row, True)

								elif conditionWidget.currentIndex() == 3:
									if int(fieldWidget.text()) < int(self.sfDataTable.item(row, r+2).text()):
										self.sfDataTable.setRowHidden(row, True)



							if r in indicesOfDateEdits_SFDT:

								stringDateFromTable = self.sfDataTable.item(row, r+2).text().split(' ')[0]

								qdateFromTable = QDate.fromString(stringDateFromTable, "yyyy-MM-dd")

								if conditionWidget.currentIndex() == 0:
									if fieldWidget.date() != qdateFromTable:
										self.sfDataTable.setRowHidden(row, True)

								elif conditionWidget.currentIndex() == 1:
									if fieldWidget.date() == qdateFromTable:
										self.sfDataTable.setRowHidden(row, True)

								elif conditionWidget.currentIndex() == 2:
									if fieldWidget.date() > qdateFromTable:
										self.sfDataTable.setRowHidden(row, True)

								elif conditionWidget.currentIndex() == 3:
									if fieldWidget.date() < qdateFromTable:
										self.sfDataTable.setRowHidden(row, True)


		self.applyCustomFilterBtn_SFDT.clicked.connect(onClickingApplyCustomFilter_SFDT)

		def onClickingCancelCustomFilter_SFDT():
			for r in range(gridLayoutOfCustomFilterWidget_SFDT.rowCount()):
				gridLayoutOfCustomFilterWidget_SFDT.itemAtPosition(r, 1).widget().setCurrentIndex(-1)
				gridLayoutOfCustomFilterWidget_SFDT.itemAtPosition(r, 1).widget().setProperty('error', False)
				gridLayoutOfCustomFilterWidget_SFDT.itemAtPosition(r, 1).widget().setStyleSheet(self.comboBoxQSS)

				if r in indicesOfComboboxes_SFDT:
					gridLayoutOfCustomFilterWidget_SFDT.itemAtPosition(r, 2).widget().setCurrentIndex(-1)
					if r in [2, 9]:
						gridLayoutOfCustomFilterWidget_SFDT.itemAtPosition(r, 2).widget().setEnabled(False)
					gridLayoutOfCustomFilterWidget_SFDT.itemAtPosition(r, 2).widget().setProperty('error', False)
					gridLayoutOfCustomFilterWidget_SFDT.itemAtPosition(r, 2).widget().setStyleSheet(self.comboBoxQSS)

				if r in indicesOfLineEdits_SFDT:
					gridLayoutOfCustomFilterWidget_SFDT.itemAtPosition(r, 2).widget().clear()
					gridLayoutOfCustomFilterWidget_SFDT.itemAtPosition(r, 2).widget().setProperty('error', False)
					gridLayoutOfCustomFilterWidget_SFDT.itemAtPosition(r, 2).widget().setStyleSheet(self.lineEditBoxQSS)

				if r in indicesOfSpinBox_SFDT:
					gridLayoutOfCustomFilterWidget_SFDT.itemAtPosition(r, 2).widget().clear()
					gridLayoutOfCustomFilterWidget_SFDT.itemAtPosition(r, 2).widget().setProperty('error', False)
					gridLayoutOfCustomFilterWidget_SFDT.itemAtPosition(r, 2).widget().setStyleSheet(self.lineEditBoxQSS)

				if r in indicesOfDateEdits_SFDT:
					gridLayoutOfCustomFilterWidget_SFDT.itemAtPosition(r, 2).widget().setDate(gridLayoutOfCustomFilterWidget_SFDT.itemAtPosition(r, 2).widget().minimumDate())





		self.cancelCustomFilterBtn_SFDT.clicked.connect(onClickingCancelCustomFilter_SFDT)

		self.customFilterWidget_SFDT.show()

	self.customFilterButton_SFDT.clicked.connect(OnClickingcustomFilterButton_SFDT)



	def onclicking_delete_SFDT():
			
		selectedCMIndices_ = []
		selectedCMIds = []

		numberOfSelectedCMIds = 0

		for i in range(self.sfDataTable.rowCount()):
			if not self.sfDataTable.isRowHidden(i):
				if isinstance(self.sfDataTable.cellWidget(i,0), QCheckBox):
					if self.sfDataTable.cellWidget(i,0).checkState() == Qt.Checked:
						selectedCMIndices_.append(i)

						CMIdButton = self.sfDataTable.cellWidget(i, 1)
						if CMIdButton:
							# selectedCMIds = CMIdButton.text()
							selectedCMIds.append(CMIdButton.text())
							numberOfSelectedCMIds += 1
		

		if selectedCMIds:

			confirmDeleteCMMsgBox = QMessageBox()
			confirmDeleteCMMsgBox.setIcon(QMessageBox.Question) 
			# confirmDeleteCMMsgBox.setText(f'Are sure you want to delete the selected CM data')
			confirmDeleteCMMsgBox.setText(f"Are you sure you want to delete {numberOfSelectedCMIds} CMs?")
			confirmDeleteCMMsgBox.setWindowTitle("Confirm")
			confirmDeleteCMMsgBox.setWindowIcon(QIcon('Media/ramsify.png'))
			confirmDeleteCMMsgBox.setStandardButtons(QMessageBox.Ok | QMessageBox.No)
			
			userResponse = confirmDeleteCMMsgBox.exec()

			if userResponse == QMessageBox.Ok:
				for ind in sorted(selectedCMIndices_, reverse=True):
					cmIdToDelete = selectedCMIds[selectedCMIndices_.index(ind)]
					sql = "DELETE FROM corrective_maintenance WHERE cm_id = %s"
					values = (cmIdToDelete,)
					self.cursor.execute(sql, values)
					self.mydb.commit()
					self.sfDataTable.removeRow(ind)

				cmDeleteSuccessMsgBox = QMessageBox()
				cmDeleteSuccessMsgBox.setIcon(QMessageBox.Information) 
				cmDeleteSuccessMsgBox.setText(f'{numberOfSelectedCMIds} CMs deleted successfully.')
				cmDeleteSuccessMsgBox.setWindowTitle("Message")
				cmDeleteSuccessMsgBox.setWindowIcon(QIcon('Media/ramsify.png'))
				cmDeleteSuccessMsgBox.setStandardButtons(QMessageBox.Ok)
				cmDeleteSuccessMsgBox.exec()
			
				self.deleteButton_SFDT.hide()
				self.selectAllSFdataButton.setIcon(QIcon(unCheckAllUserIconPath))
			
			else:
				pass



	self.deleteButton_SFDT.clicked.connect(onclicking_delete_SFDT)





	def onclicking_selectall_SFDT(checked):
		if checked:
			self.selectAllSFdataButton.setIcon(QIcon(checkAllUserIconPath))

			for i in range(self.sfDataTable.rowCount()):
				if not self.sfDataTable.isRowHidden(i):
					if isinstance(self.sfDataTable.cellWidget(i,0), QCheckBox):
						self.sfDataTable.cellWidget(i,0).setCheckState(Qt.Checked)
		
		else:
			self.selectAllSFdataButton.setIcon(QIcon(unCheckAllUserIconPath))

			for i in range(self.sfDataTable.rowCount()):
				if not self.sfDataTable.isRowHidden(i):
					if isinstance(self.sfDataTable.cellWidget(i,0), QCheckBox):
						self.sfDataTable.cellWidget(i,0).setCheckState(Qt.Unchecked)

	
	self.selectAllSFdataButton.toggled.connect(onclicking_selectall_SFDT)

		

	def onClickingApplyBtn_SFDT():
		self.sfDataTable.clearContents()
		self.sfDataTable.setRowCount(0)


		query1 = '''SELECT
		corrective_maintenance.cm_id,
		corrective_maintenance.event_datetime,
		corrective_maintenance.depot,
		trainsets.trainset,
		corrective_maintenance.car_no,
		corrective_maintenance.jobcard_no,
		corrective_maintenance.issued_to,
		corrective_maintenance.ml_depot,
		corrective_maintenance.location,
		bom_sys.equipment,
		bom_sub.equipment,
		corrective_maintenance.other_subsystem,
		corrective_maintenance.fault_details,
		corrective_maintenance.failure_type,
		corrective_maintenance.service_failure_effect,
		corrective_maintenance.consider_for_relevant_fails,
		corrective_maintenance.action_taken_at_mainline,
		corrective_maintenance.action_taken_at_depot,
		corrective_maintenance.failure_category,
		corrective_maintenance.failure_responsibility,
		corrective_maintenance.equipment,
		corrective_maintenance.component,
		corrective_maintenance.lowest_level_component,
		corrective_maintenance.ncr_no,
		corrective_maintenance.component_replaced,
		corrective_maintenance.replaced_component,
		corrective_maintenance.verification,
		corrective_maintenance.work_start_at,
		corrective_maintenance.work_end_at,
		corrective_maintenance.down_time,
		corrective_maintenance.trainset_id
		FROM
			corrective_maintenance
		LEFT JOIN
			trainsets ON corrective_maintenance.trainset_id = trainsets.id
		LEFT JOIN
			bom bom_sys ON corrective_maintenance.system_id = bom_sys.id
		LEFT JOIN
			bom bom_sub ON corrective_maintenance.subsystem_id = bom_sub.id
		WHERE
			corrective_maintenance.failure_type = 'Service Failure'
			AND corrective_maintenance.work_start_at BETWEEN %s AND %s
		ORDER BY work_start_at
		'''


		from_date = self.fromDateEditBox_SFDT.date().toString("yyyy-MM-dd")

		to_date_ = self.toDateEditBox_SFDT.date()
		to_date_ = to_date_.addDays(1)
		to_date = to_date_.toString("yyyy-MM-dd")

		self.cursor.execute(query1, (from_date, to_date))
		CMDataResult = self.cursor.fetchall()
		self.sfDataTable.setRowCount(len(CMDataResult))



		









		
		
		# dataToFindOverlappIds_CM = [((row[12], row[13]), row[0], row[15]) for row in CMDataResult]
		# self.totalDataToFindOverlapIds += dataToFindOverlappIds_CM

		def connect_button_clicked(button, on_clicked_function, rowNum):
			button.clicked.connect(lambda : on_clicked_function(self, button.text(), rowNum))




		


		current_date = datetime.now()

		# Calculate the start of the current month
		start_of_current_month = datetime(current_date.year, current_date.month, 1)

		# Calculate the start of the previous month
		start_of_previous_month = start_of_current_month - relativedelta(months=1)

		# Calculate the end of the current month
		end_of_current_month = start_of_current_month + relativedelta(months=1, days=-1)

		# Calculate the end of the previous month
		end_of_previous_month = start_of_current_month + relativedelta(days=-1)


		def onStateChangedOf_CMCheckBox():
			all_checked = True
			all_unchecked = True

			for i in range(self.sfDataTable.rowCount()):
				if not self.sfDataTable.isRowHidden(i):
					if isinstance(self.sfDataTable.cellWidget(i,0), QCheckBox):
						if self.sfDataTable.cellWidget(i,0).isChecked():
							all_unchecked = False
						else:
							all_checked = False

			if all_checked or all_unchecked:
				some_checked = False
			else:
				some_checked = True


			if all_checked:
				self.deleteButton_SFDT.show()
				self.selectAllSFdataButton.setIcon(QIcon(checkAllUserIconPath))
				self.selectAllSFdataButton.setChecked(True)

			if all_unchecked:
				self.deleteButton_SFDT.hide()
				self.selectAllSFdataButton.setIcon(QIcon(unCheckAllUserIconPath))

			if some_checked:
				self.deleteButton_SFDT.show()
				self.selectAllSFdataButton.setIcon(QIcon(partiallyCheckedIconPath))



		for row, rowData in enumerate(CMDataResult):
			work_start_date = rowData[-4]
			if start_of_previous_month <= work_start_date <= end_of_current_month:
				cmCheckBoxWidget = QCheckBox('')
				cmCheckBoxWidget.setStyleSheet(self.checkBoxQSS)
				self.sfDataTable.setCellWidget(row, 0, cmCheckBoxWidget)
				cmCheckBoxWidget.stateChanged.connect(onStateChangedOf_CMCheckBox)

			for col, value in enumerate(rowData[:-1]):
				if isinstance(value, datetime):
					value = value.strftime('%Y-%m-%d %H:%M')

				if col == 0:
					button = QPushButton(str(value))
					connect_button_clicked(button, onButtonClicked_cmData, row)

					button.setStyleSheet("QPushButton { text-decoration: none; }"
						"QPushButton:hover { text-decoration: underline; }")
					button.setCursor(Qt.PointingHandCursor)
					self.sfDataTable.setCellWidget(row, col+1, button)
				else:
					if value != None:
						item = QTableWidgetItem(str(value))
					else:
						item = QTableWidgetItem('')
					item.setFlags(item.flags() & ~Qt.ItemIsEditable)
					item.setTextAlignment(Qt.AlignCenter)
					item.setToolTip(item.text())
					self.sfDataTable.setItem(row, col+1, item)

		self.sfDataTable.setColumnHidden(self.sfDataTable.columnCount()-1, True)

		on_searchBox_filter_sf_data_table()

	self.apply_SFDT.clicked.connect(onClickingApplyBtn_SFDT)

	# Function to clear the filter:
	def onClickingClearBtnOf_SFDT():
		current_date = datetime.now()

		date1 = datetime(self.startingYear, self.startingMonth, 1)
		date2 = datetime(current_date.year, current_date.month, 1)

		# Calculate the difference in months
		difference_in_months = (date2.year - date1.year) * 12 + date2.month - date1.month

		if difference_in_months <= 3:
			self.fromDateEditBox_SFDT.setDate(start_date)

		else:
			six_months_before = current_date - relativedelta(months = 3)
			sixMonthsBeforeDate = (datetime(six_months_before.date().year, six_months_before.date().month, 1)).date()

			self.fromDateEditBox_SFDT.setDate(sixMonthsBeforeDate)
		
		self.toDateEditBox_SFDT.setDate(QDate.currentDate())
		
		self.serachBarOfSFDataTable.clear()
		onClickingApplyBtn_SFDT()

	self.clearAllFiltersButton_SFDT.clicked.connect(onClickingClearBtnOf_SFDT)

	def onClickingDownloadBtnOf_SFDT():

		file_path, _ = QFileDialog.getSaveFileName(self, "Save Excel File", "", "Excel Files (*.xlsx)")

		if file_path:

			wb = Workbook()
			ws = wb.active

			headers = []
			for col in range(1, self.sfDataTable.columnCount()):
				if not self.sfDataTable.isColumnHidden(col):
					header_item = self.sfDataTable.horizontalHeaderItem(col)
					if header_item is not None:
						headers.append(header_item.text())


			ws.append(headers)

			row_index = 2
			for row in range(self.sfDataTable.rowCount()):
				if not self.sfDataTable.isRowHidden(row):
					# ws.cell(row=row_index, column=1).value = self.sfDataTable.cellWidget(row, 0).text()
					for col in range(1, self.sfDataTable.columnCount()):
						if col == 1:
							wid = self.sfDataTable.cellWidget(row, col)
							if isinstance(wid, QPushButton):
								ws.cell(row=row_index, column=col).value = wid.text()
						else:	
							item = self.sfDataTable.item(row, col)
							if item is not None:
								ws.cell(row=row_index, column=col).value = item.text()

					row_index += 1

			wb.save(file_path)

			cmDownloadedMsgBox = QMessageBox()
			cmDownloadedMsgBox.setIcon(QMessageBox.Information) 
			cmDownloadedMsgBox.setText(f'Data downloaded successfully')
			cmDownloadedMsgBox.setWindowTitle("Message")
			cmDownloadedMsgBox.setWindowIcon(QIcon('Media/ramsify.png'))
			cmDownloadedMsgBox.setStandardButtons(QMessageBox.Ok)
			cmDownloadedMsgBox.exec_()

	self.download_SFDT.clicked.connect(onClickingDownloadBtnOf_SFDT)


	onClickingClearBtnOf_SFDT()

def onButtonClicked_cmData(self, cmId, rowNum):
	from PySide6.QtWidgets import QApplication

	self.cmWindow = QWidget()
	self.cmWindow.move(400, 100)
	self.cmWindow.setWindowTitle(cmId)
	self.cmWindow.setWindowIcon(QIcon('Media/ramsify.png'))
	hLayout = QHBoxLayout()
	vLayout = QVBoxLayout()
	self.cmWindow.setLayout(vLayout)
	vLayout.addLayout(hLayout)

	formLayout1 =QFormLayout()
	formLayout2 =QFormLayout()

	hLayout.addLayout(formLayout1)
	hLayout.addLayout(formLayout2)

	query = '''SELECT
		corrective_maintenance.cm_id,
		corrective_maintenance.event_datetime,
		corrective_maintenance.depot,
		trainsets.trainset,
		corrective_maintenance.car_no,
		corrective_maintenance.jobcard_no,
		corrective_maintenance.issued_to,
		corrective_maintenance.ml_depot,
		corrective_maintenance.location,
		bom_sys.equipment,
		bom_sub.equipment,
		corrective_maintenance.fault_details,
		corrective_maintenance.failure_type,
		corrective_maintenance.service_failure_effect,
		corrective_maintenance.action_taken_at_mainline,
		corrective_maintenance.action_taken_at_depot,
		corrective_maintenance.failure_category,
		corrective_maintenance.failure_responsibility,
		corrective_maintenance.equipment,
		corrective_maintenance.component,
		corrective_maintenance.lowest_level_component,
		corrective_maintenance.ncr_no,
		corrective_maintenance.component_replaced,
		corrective_maintenance.verification,
		corrective_maintenance.work_start_at,
		corrective_maintenance.work_end_at,
		corrective_maintenance.down_time,
		corrective_maintenance.other_subsystem,
		corrective_maintenance.consider_for_relevant_fails,
		corrective_maintenance.attachments,
		corrective_maintenance.replaced_component
	FROM
		corrective_maintenance
	LEFT JOIN
		trainsets ON corrective_maintenance.trainset_id = trainsets.id
	LEFT JOIN
		bom bom_sys ON corrective_maintenance.system_id = bom_sys.id
	LEFT JOIN
		bom bom_sub ON corrective_maintenance.subsystem_id = bom_sub.id
		WHERE cm_id = "{}"

	'''.format(cmId)

	self.cursor.execute(query)
	row = self.cursor.fetchone()

	selected_year, selected_month = row[24].year, row[24].month
	current_date_ = datetime.now()
	currentMonthStartingDate = datetime(current_date_.year, current_date_.month, 1)
	previous_month = currentMonthStartingDate - timedelta(days=1)
	six_months_ago = current_date_ - relativedelta(months=6)
	six_months_ago = six_months_ago.replace(day=1)

	if (selected_year == previous_month.year and selected_month == previous_month.month) or (selected_year == current_date_.year and selected_month == current_date_.month):
		prevMonth = True
	else:
		prevMonth = False

	if ((self.userName == 'Ravikumar') and (self.editableOptionMaxDate > datetime.now().date())):
		prevMonth = True

	if self.userRole == 0:
		prevMonth = True

	if (self.userRole == 1) and (six_months_ago <= row[24] <= current_date_):
		prevMonth = True



	self.createDateEditBox('eventDate_CMTab_')
	self.eventDate_CMTab_.setDate(row[1].date())

	self.createTimeEditBox('eventTime_CMTab_')
	self.eventTime_CMTab_.setTime(row[1].time())

	self.createComboBox(self.depotsList, 'depotComboBox_CMTab_')
	self.createComboBox([], 'trainComboBox_CMTab_')

	def onChangingDepotCombobox_():
		self.trainComboBox_CMTab_.setEnabled(True)
		self.trainComboBox_CMTab_.clear()
		self.trainComboBox_CMTab_.addItems(self.depotTrainDictionary[self.depotComboBox_CMTab_.currentText()])
	self.depotComboBox_CMTab_.currentIndexChanged.connect(lambda: onChangingDepotCombobox_())
	
	self.depotComboBox_CMTab_.setCurrentText(row[2])
	self.trainComboBox_CMTab_.setCurrentText(row[3])


	self.createComboBox(self.carsList, 'carComboBox_CMTab_')
	self.carComboBox_CMTab_.setCurrentText(row[4])

	self.createLineEditBox('jobcardNo_CMTab_')

	self.createLineEditBox('issuedTo_CMTab_')

	self.createComboBox(['M/L', 'Depot'], 'reapairAt_CMTab_')
	self.reapairAt_CMTab_.setCurrentText(row[7])

	self.createLineEditBox('locationLineEdit_CMTab_')

	self.createComboBox(self.BOMSystemDictionary.keys(), 'systemComboBox_CMTab_')
	self.createComboBox([], 'subsystemComboBox_CMTab_')

	def onSystemComboboxChanged_():
		self.subsystemComboBox_CMTab_.setEnabled(True)
		self.subsystemComboBox_CMTab_.clear()
		self.subsystemComboBox_CMTab_.addItems(self.BOMSystemDictionary[self.systemComboBox_CMTab_.currentText()])		
	self.systemComboBox_CMTab_.currentIndexChanged.connect(lambda: onSystemComboboxChanged_())

	self.systemComboBox_CMTab_.setCurrentText(row[9])
	self.subsystemComboBox_CMTab_.setCurrentText(row[10])

	


	self.createLineEditBox('otherSubSystemLineEdit_CMTab_')
	# def onChangingOtherSubSysLE(text):
	# 	self.otherSubSystemLineEdit_CMTab_.setToolTip(text)
	# self.otherSubSystemLineEdit_CMTab_.textChanged.connect(onChangingOtherSubSysLE)
	

	if self.subsystemComboBox_CMTab_.currentText() != 'Others':
		self.otherSubSystemLineEdit_CMTab_.setEnabled(False)

	def onSubSystemComboboxChanged_():
		if self.subsystemComboBox_CMTab_.currentText() == 'Others':
			self.otherSubSystemLineEdit_CMTab_.setEnabled(True)
		else:
			self.otherSubSystemLineEdit_CMTab_.clear()
			self.otherSubSystemLineEdit_CMTab_.setEnabled(False)
	self.subsystemComboBox_CMTab_.currentIndexChanged.connect(lambda: onSubSystemComboboxChanged_())



	self.createTextEditBox('faultDetails_CMTab_')
	

	self.createComboBox(['Relevant Failure', 'Service Failure', 'Non Relevant Failure'], 'failureType__CMTab_')
	self.createComboBox([], 'serviceFailureEffect_CMTab_')

	def onFailureTypeComboboxChanged_():
		if self.failureType__CMTab_.currentIndex() == 1:
			self.serviceFailureEffect_CMTab_.setEnabled(True)
			self.serviceFailureEffect_CMTab_.addItems(['Pre-departure Withdrawal', 'Withdrawal', '3 min delay', 'Deboarding'])
		else:
			self.serviceFailureEffect_CMTab_.setEnabled(False)
			self.serviceFailureEffect_CMTab_.clear()
	self.failureType__CMTab_.currentIndexChanged.connect(lambda: onFailureTypeComboboxChanged_())
	self.failureType__CMTab_.setCurrentText(row[12])
	self.serviceFailureEffect_CMTab_.setCurrentText(row[13])


	self.createComboBox(['Yes', 'No'], 'considerForRelavantFails__CMTab_')
	self.considerForRelavantFails__CMTab_.setCurrentText(row[28])


	self.createAttachmentWidget('mianAttachment_CM_')
	self.mianAttachment_CM_.fileListWidget.setMinimumHeight(140)


	import ast

	# attachedItemsList = ast.literal_eval(row[16])
	attachedItemsList = ast.literal_eval(row[29]) if row[29] is not None else []
	# print(attachedItemsList)
	# print(type(attachedItemsList))
	if len(attachedItemsList) > 0:
		for attachment in attachedItemsList:
			self.mianAttachment_CM_.fileListWidget.addItem(attachment)
			self.mianAttachment_CM_.fileListWidget.setVisible(True)
			self.mianAttachment_CM_.removeButton.setEnabled(True)


	self.createTextEditBox('actionTakenAtMainline_CM_')

	self.createTextEditBox('actionTakenAtDepot_CM_')


	self.createComboBox(['External', 'Maintenance', 'Material', 'NFF', 'Operation', 'Software', 'Workmanship', 'Others'], 'failureCategory_CMTab_')
	self.failureCategory_CMTab_.setCurrentText(row[16])

	self.createComboBox(['BEML', 'MMMOCL', 'Others'], 'failureResponsibility_CMTab_')
	self.failureResponsibility_CMTab_.setCurrentText(row[17])

	self.createLineEditBox('equipmentLineEdit_CMTab_')

	self.createLineEditBox('componentLineEdit_CMTab_')

	self.createLineEditBox('lowestLevelLineEdit_CMTab_')

	self.createLineEditBox('NCR_CM_')

	self.createComboBox(['Yes', 'No'], 'componentReplaced_CM_')
	self.componentReplaced_CM_.setCurrentText(row[22])


	self.createLineEditBox('replacedComponentLineEdit_CM_')
	# def onChangingReplacedCompLE(text):
	# 	self.replacedComponentLineEdit_CM_.setToolTip(text)
	# self.replacedComponentLineEdit_CM_.textChanged.connect(onChangingReplacedCompLE)


	if self.componentReplaced_CM_.currentText() != 'Yes':
		self.replacedComponentLineEdit_CM_.setEnabled(False)

	def onIsComponentReplacedComboboxChanged_():
		if self.componentReplaced_CM_.currentText() == 'Yes':
			self.replacedComponentLineEdit_CM_.setEnabled(True)
		else:
			self.replacedComponentLineEdit_CM_.clear()
			self.replacedComponentLineEdit_CM_.setEnabled(False)
	self.componentReplaced_CM_.currentIndexChanged.connect(lambda: onIsComponentReplacedComboboxChanged_())


	self.createComboBox(['Yes', 'No'], 'verification__CMTab_')
	self.verification__CMTab_.setCurrentText(row[23])

	self.createDateEditBox('workStartDate_CMTab_')
	self.workStartDate_CMTab_.setDate(row[24].date())

	self.createTimeEditBox('workStartTime_CMTab_')
	self.workStartTime_CMTab_.setTime(row[24].time())

	self.createDateEditBox('workEndDate_CMTab_')
	self.workEndDate_CMTab_.setDate(row[25].date())

	self.createTimeEditBox('workEndTime_CMTab_')
	self.workEndTime_CMTab_.setTime(row[25].time())

	self.downTimeLabel_CMTab_ = QLabel('Down Time(Minutes):')
	self.downTime_CMTab_ = QLabel(str(row[26]))

	listOfWidgets_CM_ = [self.eventDate_CMTab_, self.eventTime_CMTab_, self.depotComboBox_CMTab_, self.trainComboBox_CMTab_, self.carComboBox_CMTab_, self.jobcardNo_CMTab_,
						self.issuedTo_CMTab_, self.reapairAt_CMTab_, self.locationLineEdit_CMTab_, self.systemComboBox_CMTab_, self.subsystemComboBox_CMTab_,
						self.faultDetails_CMTab_, self.failureType__CMTab_, self.serviceFailureEffect_CMTab_, self.actionTakenAtMainline_CM_, self.actionTakenAtDepot_CM_,
						self.failureCategory_CMTab_, self.failureResponsibility_CMTab_, self.equipmentLineEdit_CMTab_, self.componentLineEdit_CMTab_, self.lowestLevelLineEdit_CMTab_,
						self.NCR_CM_, self.componentReplaced_CM_, self.verification__CMTab_, self.workStartDate_CMTab_, self.workStartTime_CMTab_,
						self.workEndDate_CMTab_, self.workEndTime_CMTab_, self.downTime_CMTab_, self.otherSubSystemLineEdit_CMTab_, self.considerForRelavantFails__CMTab_,
						self.mianAttachment_CM_, self.replacedComponentLineEdit_CM_]

	if not prevMonth:
		for wid in listOfWidgets_CM_:
			wid.setEnabled(False)
	
	self.cmWindow.show()


	def setToolTip(wid, text):
		wid.setToolTip(text)

	def settingToolTipp(wid):
		wid.textChanged.connect(lambda: setToolTip(wid, wid.text()))

	for wid in listOfWidgets_CM_:
		if isinstance(wid, QLineEdit):
			settingToolTipp(wid)



	def setToolTip(wid, text):
		wid.setToolTip(text)

	def settingToolTipp(wid):
		wid.textChanged.connect(lambda: setToolTip(wid, wid.toPlainText()))

	for wid in listOfWidgets_CM_:
		if isinstance(wid, QTextEdit):
			settingToolTipp(wid)
			

	self.otherSubSystemLineEdit_CMTab_.setText(row[27])
	self.jobcardNo_CMTab_.setText(row[5])
	self.issuedTo_CMTab_.setText(row[6])
	self.locationLineEdit_CMTab_.setText(row[8])
	self.equipmentLineEdit_CMTab_.setText(row[18])
	self.componentLineEdit_CMTab_.setText(row[19])
	self.lowestLevelLineEdit_CMTab_.setText(row[20])
	self.NCR_CM_.setText(row[21])
	self.replacedComponentLineEdit_CM_.setText(row[30])


	

	self.faultDetails_CMTab_.setText(row[11])
	self.actionTakenAtMainline_CM_.setText(row[14])
	self.actionTakenAtDepot_CM_.setText(row[15])
	

	def onWorkDateTimeChanged_():
		workStartDate_ = self.workStartDate_CMTab_.date().toPython()
		workStartTime_ = self.workStartTime_CMTab_.time().toPython().replace(second=0, microsecond=0)
		workEndDate_ = self.workEndDate_CMTab_.date().toPython()
		workEndTime_ = self.workEndTime_CMTab_.time().toPython().replace(second=0, microsecond=0)

		startDateTime_ = datetime.combine(workStartDate_, workStartTime_)
		endDateTime_ = datetime.combine(workEndDate_, workEndTime_)

		timeDifference_ = endDateTime_ - startDateTime_
		minutesDifference_ = timeDifference_.total_seconds() / 60

		if endDateTime_ < startDateTime_:
			self.workEndDate_CMTab_.setDate(self.workStartDate_CMTab_.date())
			self.workEndTime_CMTab_.setTime(self.workStartTime_CMTab_.time())

			endDateTime_ = datetime.combine(workStartDate_, workStartTime_)
			timeDifference_ = endDateTime_ - startDateTime_
			minutesDifference_ = timeDifference_.total_seconds() / 60

		self.downTime_CMTab_.setText(str(int(minutesDifference_)))

	self.workStartDate_CMTab_.dateChanged.connect(onWorkDateTimeChanged_)
	self.workStartTime_CMTab_.timeChanged.connect(onWorkDateTimeChanged_)
	self.workEndDate_CMTab_.dateChanged.connect(onWorkDateTimeChanged_)
	self.workEndTime_CMTab_.timeChanged.connect(onWorkDateTimeChanged_)

	hLayoutForEventDateTime_CMTab_ = QHBoxLayout()
	hLayoutForEventDateTime_CMTab_.addWidget(self.eventDate_CMTab_)
	hLayoutForEventDateTime_CMTab_.addWidget(self.eventTime_CMTab_)

	hLayoutForWorkStartAt_CMTab_ = QHBoxLayout()
	hLayoutForWorkStartAt_CMTab_.addWidget(self.workStartDate_CMTab_)
	hLayoutForWorkStartAt_CMTab_.addWidget(self.workStartTime_CMTab_)

	hLayoutForWorkEndAt_CMTab_ = QHBoxLayout()
	hLayoutForWorkEndAt_CMTab_.addWidget(self.workEndDate_CMTab_)
	hLayoutForWorkEndAt_CMTab_.addWidget(self.workEndTime_CMTab_)


	idLabel = QLabel('Id:')
	cmIdLabel = QLabel(cmId)
	idLabel.setFixedHeight(25)
	cmIdLabel.setFixedHeight(25)
	formLayout1.addRow(idLabel, cmIdLabel)
	formLayout1.setAlignment(cmIdLabel, Qt.AlignTop)
	formLayout1.setAlignment(cmIdLabel, Qt.AlignTop)
	formLayout1.addRow('Event Date & Time:<font color="red">*</font>', hLayoutForEventDateTime_CMTab_)
	formLayout1.addRow('Depot:<font color="red">*</font>', self.depotComboBox_CMTab_)
	formLayout1.addRow('Trainset:<font color="red">*</font>', self.trainComboBox_CMTab_)
	formLayout1.addRow('Car No:', self.carComboBox_CMTab_)
	formLayout1.addRow('Jobcard No:', self.jobcardNo_CMTab_)
	formLayout1.addRow('Issued To:', self.issuedTo_CMTab_)
	formLayout1.addRow('ML/Depot:', self.reapairAt_CMTab_)
	formLayout1.addRow('Location:', self.locationLineEdit_CMTab_)
	formLayout1.addRow('System:<font color="red">*</font>', self.systemComboBox_CMTab_)
	# formLayout1.addRow('Sub-System:<font color="red">*</font>', self.subsystemComboBox_CMTab_)
	hLayoutForSubSystem_CM_ = QHBoxLayout()
	hLayoutForSubSystem_CM_.addWidget(self.subsystemComboBox_CMTab_)
	hLayoutForSubSystem_CM_.addWidget(self.otherSubSystemLineEdit_CMTab_)
	formLayout1.addRow('Sub-System:<font color="red">*</font>', hLayoutForSubSystem_CM_)
	formLayout1.addRow('Fault Details:<font color="red">*</font>', self.faultDetails_CMTab_)
	formLayout1.addRow('Failure Type:<font color="red">*</font>', self.failureType__CMTab_)
	formLayout1.addRow('Service Failure Effect:', self.serviceFailureEffect_CMTab_)
	formLayout1.addRow('Consider for Relevant Fails?:<font color="red">*</font>', self.considerForRelavantFails__CMTab_)
	formLayout1.addRow('Attachments:', self.mianAttachment_CM_)
	formLayout2.addRow('Action Taken At Mainline:', self.actionTakenAtMainline_CM_)
	formLayout2.addRow('Action Taken At Depot:<font color="red">*</font>', self.actionTakenAtDepot_CM_)
	formLayout2.addRow('Failure Category:', self.failureCategory_CMTab_)
	formLayout2.addRow('Failure Responsibility:<font color="red">*</font>', self.failureResponsibility_CMTab_)
	formLayout2.addRow('Equipment:', self.equipmentLineEdit_CMTab_)
	formLayout2.addRow('Component:', self.componentLineEdit_CMTab_)
	formLayout2.addRow('Lowest Level Component:', self.lowestLevelLineEdit_CMTab_)

	formLayout2.addRow('NCR no:', self.NCR_CM_)
	# formLayout2.addRow('Is Component Replaced?:', self.componentReplaced_CM_)
	hLayoutForReplacedComponent_CM_ = QHBoxLayout()
	hLayoutForReplacedComponent_CM_.addWidget(self.componentReplaced_CM_)
	hLayoutForReplacedComponent_CM_.addWidget(self.replacedComponentLineEdit_CM_)
	formLayout2.addRow('Is Component Replaced?:', hLayoutForReplacedComponent_CM_)

	formLayout2.addRow('Verification:<font color="red">*</font>', self.verification__CMTab_)
	formLayout2.addRow('Work Start At:<font color="red">*</font>', hLayoutForWorkStartAt_CMTab_)
	formLayout2.addRow('Work End At:<font color="red">*</font>', hLayoutForWorkEndAt_CMTab_)

	formLayout2.addRow(self.downTimeLabel_CMTab_, self.downTime_CMTab_)
	formLayout2.setAlignment(self.downTime_CMTab_, Qt.AlignTop)
	formLayout2.setAlignment(self.downTimeLabel_CMTab_, Qt.AlignTop)

	
	if prevMonth:
		def onClickingUpdate_CMData():

			mandatoryVerification_CMData = True
			mandatoryIndexes_CMData = [0, 1, 2, 3, 9, 10, 11, 12, 15, 17, 23, 24, 25, 26, 27, 30]

			row_ = []

			for i, wid in enumerate(listOfWidgets_CM_):
				if i == 31:
					row_.append(None)

				if isinstance(wid, QDateEdit):
					if isinstance(listOfWidgets_CM_[i+1], QTimeEdit):
						datetime_ = QDateTime(wid.date(), listOfWidgets_CM_[i+1].time())
						row_.append(datetime_.toPython())

				elif isinstance(wid, QComboBox):
					if wid.isEnabled():
						if wid.currentText() == '':
							row_.append(None)

							if i in mandatoryIndexes_CMData:
								mandatoryVerification_CMData = False
								wid.setProperty("error", True)
								wid.setStyleSheet(self.comboBoxQSS)

						else:
							if i == 9:
								query = "SELECT id FROM bom WHERE equipment = %s AND parent_id = 0"
								self.cursor.execute(query, (wid.currentText(),))
								result = self.cursor.fetchone()
								row_.append(result[0])
								wid.setProperty("error", False)
								wid.setStyleSheet(self.comboBoxQSS)
							elif i == 10:
								query = "SELECT id FROM bom WHERE parent_id = (SELECT id FROM bom WHERE equipment = %s AND parent_id = 0) AND equipment = %s"
								self.cursor.execute(query, (listOfWidgets_CM_[9].currentText(), wid.currentText()))
								result = self.cursor.fetchone()
								row_.append(result[0])
								wid.setProperty("error", False)
								wid.setStyleSheet(self.comboBoxQSS)

							else:
								row_.append(wid.currentText())
								wid.setProperty("error", False)
								wid.setStyleSheet(self.comboBoxQSS)
					else:
						row_.append(None)

				elif isinstance(wid, QLineEdit):
					if wid.text() == '':
						row_.append(None)
						if i in mandatoryIndexes_CMData:
							mandatoryVerification_CMData = False
							wid.setProperty("error", True)
							wid.setStyleSheet(self.lineEditBoxQSS)

					else:
						row_.append(wid.text())

				elif isinstance(wid, QTextEdit):
					if wid.toPlainText() == '':
						row_.append(None)
						if i in mandatoryIndexes_CMData:
							mandatoryVerification_CMData = False
							wid.setProperty("error", True)
							wid.setStyleSheet(self.textEditBoxQSS)
					else:
						row_.append(wid.toPlainText())
						wid.setProperty("error", False)
						wid.setStyleSheet(self.textEditBoxQSS)

				elif isinstance(wid, QLabel):
					row_.append(int(wid.text()))

			if not mandatoryVerification_CMData:
				pass

			else:
				row_.append(self.user_id)
				row_.append(cmId)




				selected_files = [self.mianAttachment_CM_.fileListWidget.item(i).text() for i in range(self.mianAttachment_CM_.fileListWidget.count())]

				vall = 0
				allFileNames = []
				for file in selected_files:
					if '/' in file:
						dest_folder = "C:\\ProgramData\\RAMSify\\Attachments"
						file_name = os.path.basename(file)
						
						fVal = str(vall)
						if len(str(vall)) == 1:
							fVal = '00'+str(vall)
						elif len(str(vall)) == 2:
							fVal = '0'+str(vall)
						else:
							fVal = str(vall)


						base_name, file_extension = os.path.splitext(file_name)
						new_filename = f"{base_name}_{datetime.now().strftime('%Y%m%d%H%M%S')}{fVal}{file_extension}"
						allFileNames.append(new_filename)
						dest_file = os.path.join(dest_folder, new_filename)
						shutil.copy(file, dest_file)

					else:
						allFileNames.append(file)


				attachmentsString = str(allFileNames)

				row_[28] = attachmentsString





				update_query = """
					UPDATE corrective_maintenance
					SET
						event_datetime = %s,
						depot = %s,
						trainset_id = (SELECT id FROM trainsets WHERE trainset = %s),
						car_no = %s,
						jobcard_no = %s,
						issued_to = %s,
						ml_depot = %s,
						location = %s,
						system_id = %s,
						subsystem_id = %s,
						fault_details = %s,
						failure_type = %s,
						service_failure_effect = %s,
						action_taken_at_mainline = %s,
						action_taken_at_depot = %s,
						failure_category = %s,
						failure_responsibility = %s,
						equipment = %s,
						component = %s,
						lowest_level_component = %s,
						ncr_no = %s,
						component_replaced = %s,
						verification = %s,
						work_start_at = %s,
						work_end_at = %s,
						down_time = %s,
						other_subsystem = %s,
						consider_for_relevant_fails = %s,
						attachments = %s,
						replaced_component = %s,
						user_id = %s
					WHERE cm_id = %s
				"""


				self.cursor.execute(update_query, tuple(row_))
				self.mydb.commit()
						
				dataOfTableRowToUpdate = row_[0:8] + [self.systemComboBox_CMTab_.currentText(), self.subsystemComboBox_CMTab_.currentText()] + [row_[26]] + row_[10:13] + [row_[27]] + row_[13:22] + [row_[29]] + row_[22:]

				for c in range(1, self.sfDataTable.columnCount()-1):
					if dataOfTableRowToUpdate[c-1] != None:
						item = QTableWidgetItem(str(dataOfTableRowToUpdate[c-1]))
						item.setTextAlignment(Qt.AlignCenter)
						item.setToolTip(item.text())
						self.sfDataTable.setItem(rowNum, c+1, item)
					else:
						item = QTableWidgetItem('')
						item.setTextAlignment(Qt.AlignCenter)
						self.sfDataTable.setItem(rowNum, c+1, item)

				cmUpdateMsgBox = QMessageBox()
				cmUpdateMsgBox.setIcon(QMessageBox.Information) 
				cmUpdateMsgBox.setText(f'Data Updated successfully.\nID:{cmId}')
				cmUpdateMsgBox.setWindowTitle("Message")
				cmUpdateMsgBox.setWindowIcon(QIcon('Media/ramsify.png'))
				cmUpdateMsgBox.setStandardButtons(QMessageBox.Ok)
				cmUpdateMsgBox.exec_()

				self.cmWindow.close()


		self.createPushButton('updateBtn_cmData', 'Update',  width=int(0.075 * QApplication.primaryScreen().availableGeometry().width()))
		self.updateBtn_cmData.clicked.connect(onClickingUpdate_CMData)
		hLayoutForSubmitCancel = QHBoxLayout()
		vLayout.addLayout(hLayoutForSubmitCancel)
		hLayoutForSubmitCancel.addWidget(self.updateBtn_cmData, alignment=Qt.AlignCenter)