import uuid
import wmi

mac_address = '-'.join(['{:02x}'.format((uuid.getnode() >> ele) & 0xFF) for ele in range(0, 8 * 6, 8)][::-1])
mac_address = mac_address.replace(':', '-')
print(mac_address.lower())

w = wmi.WMI()
cpu_serial = w.Win32_Processor()[0].ProcessorId.strip()
print(cpu_serial.lower())