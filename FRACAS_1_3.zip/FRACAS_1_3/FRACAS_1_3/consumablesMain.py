from PySide6.QtWidgets import QScrollArea, QTabWidget, QVBoxLayout, QLabel, QComboBox, QToolBox, QWidget, QFormLayout, QDateEdit, QTimeEdit, QTextEdit, QPushButton, QSizePolicy, QHBoxLayout, QSpacerItem, QLineEdit, QDialog, QDialogButtonBox, QTableWidgetItem
# import sys
# import os

def consumablesMainTabDataUI(self):
	from PySide6.QtWidgets import QApplication

	from consumableData import consumableDataUI
	from referenceData import referenceDataUI

	self.consumablesDataTabWidget = QTabWidget()
	self.consumablesDataTabWidget.setStyleSheet(self.tabWidgetQSS)
	self.consumablesDataTabWidget.setMinimumHeight(self.geometryHeight(0.81))


	self.mainVerticalLayout_Consumables.addWidget(self.consumablesDataTabWidget)

	consumablesScroll = QScrollArea()
	referenceScroll = QScrollArea()

	self.consumablesDataTabWidget.addTab(consumablesScroll, 'Consumables')
	self.consumablesDataTabWidget.addTab(referenceScroll, 'Reference')

	# consumablesTabWidget = QWidget()
	# referenceTabWidget = QWidget()


	self.consumablesDataWidget = QWidget()
	self.referenceDataWidget = QWidget()

	consumablesDataMainLayout = QVBoxLayout(self.consumablesDataWidget)
	referenceDataMainLayout = QVBoxLayout(self.referenceDataWidget)


	self.consumablesDataWidget.setLayout(consumablesDataMainLayout)
	self.referenceDataWidget.setLayout(referenceDataMainLayout)

	consumablesScroll.setWidgetResizable(True)
	referenceScroll.setWidgetResizable(True)

	consumablesScroll.setWidget(self.consumablesDataWidget)
	referenceScroll.setWidget(self.referenceDataWidget)

	consumableDataUI(self, consumablesDataMainLayout)
	referenceDataUI(self, referenceDataMainLayout)