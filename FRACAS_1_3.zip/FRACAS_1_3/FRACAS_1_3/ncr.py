from PySide6.QtWidgets import QLabel, QWidget, QVBoxLayout, QTextEdit, QSpacerItem, QDialog, QMessageBox, QSizePolicy, QFileDialog, QHBoxLayout, QCheckBox, QScrollBar, QScrollArea, QTabWidget,QTableWidget, QTableWidgetItem, QAbstractItemView, QFormLayout, QLineEdit, QDateEdit, QComboBox, QGridLayout, QPushButton, QSpinBox
from functions import TableWidget
from PySide6.QtCore import Qt,QDate
from PySide6.QtGui import QIcon
from openpyxl import Workbook
from datetime import date, datetime
import shutil
import os
def ncrUI(self):
	from PySide6.QtWidgets import QApplication

	self.vboxlayout =QVBoxLayout()
	self.mainVerticalLayout_Ncr.addLayout(self.vboxlayout)

	self.ncrhboxlayout = QHBoxLayout()

	checkAllUserIconPath = self.currentTheme.get('oppositeColorCheckBoxIcon')
	unCheckAllUserIconPath = self.currentTheme.get('oppositeColorUnCheckBoxIcon')
	partiallyCheckedIconPath = self.currentTheme.get('oppositeColorPartiallyCheckedBoxIcon')

	deleteIconPath = self.currentTheme.get('whiteDeleteIcon')
	downloadIconPath = self.currentTheme.get('downloadIcon')
	refreshTableIconPath = self.currentTheme.get('refreshIcon')

	self.createPushButton('selectAllNcrButton', '', unCheckAllUserIconPath, 30)
	self.createPushButton('deleteButton_Ncr', '', deleteIconPath, 35, 'Delete')
	self.createLineEditBox('serachBarOfNcrTable', 'Search...' )
	self.serachBarOfNcrTable.setClearButtonEnabled(True)
	self.serachBarOfNcrTable.setFixedWidth(self.geometryWidth(0.2))
	self.createPushButton('download_Ncr', '', downloadIconPath, 35, 'Download')
	self.createPushButton('refreshButton_ncr', '', refreshTableIconPath, 35, 'Refresh')
	self.createPushButton('newncr_NCR', '+ New NCR', '', self.geometryWidth(0.054))


	self.ncrhboxlayout.addWidget(self.selectAllNcrButton)
	self.ncrhboxlayout.addWidget(self.deleteButton_Ncr)
	self.ncrhboxlayout.addWidget(self.serachBarOfNcrTable)
	self.ncrhboxlayout.addWidget(self.download_Ncr)
	self.ncrhboxlayout.addWidget(self.refreshButton_ncr)
	self.ncrhboxlayout.addItem(QSpacerItem(1, 0, QSizePolicy.Expanding, QSizePolicy.Minimum))
	self.ncrhboxlayout.addWidget(self.newncr_NCR)
	self.vboxlayout.addLayout(self.ncrhboxlayout)

	self.ncrDataTable_NCR = TableWidget()

	self.headersOfNCRTable  = ['', 'Report No', 'Project', 'Product', 'Quantity', 'Supplier', 'Detection' ,'Place', 'Stored at', 'Severity',
						'Distribution to', 'Trainset', 'Car', 'Assy dwg no', 'Rev', 'Part No','Assy Serial No', 'Part Serial No', 'B/L No', 'Invoice no', 'Responsible party', 
						'Material status', 'Description of non-conform', 'Attached documents (if any)', 'Date', 'Team', 'Issued by',
						'Reviewed by', 'Approved by', 'Cause of nonconformity', 'Attached documents (if any)', 'A.Correction/corrective action result', 
						'B.Action Plan:', 'Attached documents (if any)', 'Date', 'Action by', 'Issued by', 'Reviewed by', 'Approved by', 
						'Decision', 'Repair procedure', 'Name', 'Date', 'Sign', 'Name', 'Date', 'Sign', 'Approval Scope', 'Entity',
						'Position', 'Name', 'Date', 'Sign', 'Signed NCR']

	self.ncrDataTable_NCR.setColumnCount(len(self.headersOfNCRTable))
	self.ncrDataTable_NCR.setHorizontalHeaderLabels(self.headersOfNCRTable)
	self.ncrDataTable_NCR.setStyleSheet(self.tableWidgetQSS)
	self.ncrDataTable_NCR.horizontalHeader().setStyleSheet(self.headerHorizontalQSS)
	self.ncrDataTable_NCR.setAlternatingRowColors(True)
	self.ncrDataTable_NCR.setShowGrid(False)
	self.vboxlayout.addWidget(self.ncrDataTable_NCR)

	self.ncrDataTable_NCR.setEditTriggers(QAbstractItemView.NoEditTriggers)
	self.ncrDataTable_NCR.setColumnWidth(0, self.geometryWidth(0.01))
	self.ncrDataTable_NCR.setColumnWidth(1, self.geometryWidth(0.14))
	self.ncrDataTable_NCR.setColumnWidth(2, self.geometryWidth(0.07))
	self.ncrDataTable_NCR.setColumnWidth(3, self.geometryWidth(0.07))
	self.ncrDataTable_NCR.setColumnWidth(4, self.geometryWidth(0.1))
	self.ncrDataTable_NCR.setColumnWidth(5, self.geometryWidth(0.08))
	self.ncrDataTable_NCR.setColumnWidth(6, self.geometryWidth(0.08))
	self.ncrDataTable_NCR.setColumnWidth(7, self.geometryWidth(0.07))
	self.ncrDataTable_NCR.setColumnWidth(8, self.geometryWidth(0.07))
	self.ncrDataTable_NCR.setColumnWidth(9, self.geometryWidth(0.07))
	self.ncrDataTable_NCR.setColumnWidth(10, self.geometryWidth(0.07))
	self.ncrDataTable_NCR.setColumnWidth(11, self.geometryWidth(0.07))
	self.ncrDataTable_NCR.setColumnWidth(12, self.geometryWidth(0.07))
	self.ncrDataTable_NCR.setColumnWidth(13, self.geometryWidth(0.07))
	self.ncrDataTable_NCR.setColumnWidth(14, self.geometryWidth(0.1))
	self.ncrDataTable_NCR.setColumnWidth(15, self.geometryWidth(0.14))
	self.ncrDataTable_NCR.setColumnWidth(16, self.geometryWidth(0.12))
	self.ncrDataTable_NCR.setColumnWidth(17, self.geometryWidth(0.12))
	self.ncrDataTable_NCR.setColumnWidth(18, self.geometryWidth(0.09))
	self.ncrDataTable_NCR.setColumnWidth(19, self.geometryWidth(0.11))
	self.ncrDataTable_NCR.setColumnWidth(20, self.geometryWidth(0.1))
	self.ncrDataTable_NCR.setColumnWidth(21, self.geometryWidth(0.1))
	self.ncrDataTable_NCR.setColumnWidth(22, self.geometryWidth(0.15))
	self.ncrDataTable_NCR.setColumnWidth(23, self.geometryWidth(0.14))
	self.ncrDataTable_NCR.setColumnWidth(24, self.geometryWidth(0.1))
	self.ncrDataTable_NCR.setColumnWidth(25, self.geometryWidth(0.07))
	self.ncrDataTable_NCR.setColumnWidth(26, self.geometryWidth(0.07))
	self.ncrDataTable_NCR.setColumnWidth(27, self.geometryWidth(0.07))
	self.ncrDataTable_NCR.setColumnWidth(28, self.geometryWidth(0.14))
	self.ncrDataTable_NCR.setColumnWidth(29, self.geometryWidth(0.15))
	self.ncrDataTable_NCR.setColumnWidth(30, self.geometryWidth(0.14))
	self.ncrDataTable_NCR.setColumnWidth(31, self.geometryWidth(0.16))
	self.ncrDataTable_NCR.setColumnWidth(32, self.geometryWidth(0.14))
	self.ncrDataTable_NCR.setColumnWidth(33, self.geometryWidth(0.14))
	self.ncrDataTable_NCR.setColumnWidth(34, self.geometryWidth(0.1))
	self.ncrDataTable_NCR.setColumnWidth(35, self.geometryWidth(0.08))
	self.ncrDataTable_NCR.setColumnWidth(36, self.geometryWidth(0.08))
	self.ncrDataTable_NCR.setColumnWidth(37, self.geometryWidth(0.08))
	self.ncrDataTable_NCR.setColumnWidth(38, self.geometryWidth(0.08))
	self.ncrDataTable_NCR.setColumnWidth(39, self.geometryWidth(0.08))
	self.ncrDataTable_NCR.setColumnWidth(40, self.geometryWidth(0.08))
	self.ncrDataTable_NCR.setColumnWidth(41, self.geometryWidth(0.08))
	self.ncrDataTable_NCR.setColumnWidth(42, self.geometryWidth(0.08))
	self.ncrDataTable_NCR.setColumnWidth(43, self.geometryWidth(0.1))
	self.ncrDataTable_NCR.setColumnWidth(44, self.geometryWidth(0.08))
	self.ncrDataTable_NCR.setColumnWidth(45, self.geometryWidth(0.08))
	self.ncrDataTable_NCR.setColumnWidth(46, self.geometryWidth(0.08))
	self.ncrDataTable_NCR.setColumnWidth(47, self.geometryWidth(0.08))
	self.ncrDataTable_NCR.setColumnWidth(48, self.geometryWidth(0.08))
	self.ncrDataTable_NCR.setColumnWidth(49, self.geometryWidth(0.08))
	self.ncrDataTable_NCR.setColumnWidth(50, self.geometryWidth(0.08))
	self.ncrDataTable_NCR.setColumnWidth(51, self.geometryWidth(0.08))
	self.ncrDataTable_NCR.setColumnWidth(52, self.geometryWidth(0.08))
	self.ncrDataTable_NCR.setColumnWidth(53, self.geometryWidth(0.1))

	
	self.ncrDataTable_NCR.setFixedHeight(self.geometryHeight(0.78))

	self.selectAllNcrButton.setCheckable(True)
	self.selectAllNcrButton.setFixedHeight(26)
	self.selectAllNcrButton.setChecked(False)
	

	def onStateChangedOf_NCRCheckBox():
		all_checked = True
		all_unchecked = True

		for i in range(self.ncrDataTable_NCR.rowCount()):
			if not self.ncrDataTable_NCR.isRowHidden(i):
				if isinstance(self.ncrDataTable_NCR.cellWidget(i,0), QCheckBox):
					if self.ncrDataTable_NCR.cellWidget(i,0).isChecked():
						all_unchecked = False
					else:
						all_checked = False

		if all_checked or all_unchecked:
			some_checked = False
		else:
			some_checked = True


		if all_checked:
			self.deleteButton_Ncr.show()
			self.selectAllNcrButton.setIcon(QIcon(checkAllUserIconPath))
			self.selectAllNcrButton.setChecked(True)
			

		if all_unchecked:
			self.deleteButton_Ncr.hide()
			self.selectAllNcrButton.setIcon(QIcon(unCheckAllUserIconPath))
			self.selectAllNcrButton.setChecked(False)

		if some_checked:
			self.deleteButton_Ncr.show()
			self.selectAllNcrButton.setIcon(QIcon(partiallyCheckedIconPath))


	def onClicking_Refreshbutton_Ncr():
		self.deleteButton_Ncr.setVisible(False)
		self.selectAllNcrButton.setIcon(QIcon(unCheckAllUserIconPath))

		query = '''SELECT
						report_no,
						project,
						product,
						quantity,
						supplier,
						detection,
						place,
						stored_at,
						severity,
						distribution_to,
						trainset,
						car,
						assy_dwg_no,
						rev,
						part_no,
						assy_serial_no,
						part_serial_no,
						bl_no,
						invoice_no,
						responsible_party,
						material_status,
						description_of_nonconform,
						attachments_one,
						attachments_one_date,
						attachments_one_team,
						attachments_one_issued_by,
						attachments_one_reviewed_by,
						attachments_one_approved_by,
						cause_of_nonconformity,
						attached_documents_two,
						correction_corrective_action_result,
						action_plan,
						attachments_three,
						attachments_three_date,
						attachments_three_action_by,
						attachments_three_issued_by,
						attachments_three_reviewed_by,
						attachments_three_approved_by,
						decision,
						repair_procedure,
						correction_name,
						correction_date,
						correction_sign,
						correctiveaction_name,
						correctiveaction_date,
						correctiveaction_sign,
						approval_scope,
						approvedby_entity,
						approvedby_position,
						approvedby_name,
						approvedby_date,
						approvedby_sign,
						signed_ncr
					FROM
						ncr
					WHERE
						deleted_at IS NULL
				'''
		self.cursor.execute(query)
		ncrDataResult = self.cursor.fetchall()


		def givingFunctionalityToButton(button, func, data):
			button.clicked.connect(lambda: func(data))


		def onbuttonClickedNcr(dataOfNcr):
			from PySide6.QtWidgets import QApplication
			# print(dataOfNcr)

			self.ncrWindow = QWidget()
			self.ncrWindow.move(400, 90)
			self.ncrWindow.resize(1100, 900)

			self.ncrWindow.setWindowTitle(dataOfNcr[0])
			self.ncrWindow.setWindowIcon(QIcon('Media/ramsify.png'))

			scrollArea = QScrollArea()
			scrollArea.setWidgetResizable(True)
			scrollArea.setStyleSheet(self.scrollAreaQSS)
			self.ncrWindow.setLayout(QVBoxLayout())
			self.ncrWindow.layout().addWidget(scrollArea)

			contentsWidget = QWidget()
			vboxLayout = QVBoxLayout()
			contentsWidget.setLayout(vboxLayout)
			scrollArea.setWidget(contentsWidget)

			hboxLayout = QHBoxLayout()			
			vboxLayout.addLayout(hboxLayout)

			formLayout1 =QFormLayout()
			formLayout2 =QFormLayout()
			

			hboxLayout.addLayout(formLayout1)
			spacer_item = QSpacerItem(self.geometryWidth(0.01), 5, QSizePolicy.Fixed, QSizePolicy.Minimum)
			hboxLayout.addItem(spacer_item)
			hboxLayout.addLayout(formLayout2)

			self.ckdmndl_NCR_ = QPushButton()
			self.ckdmndl_NCR_.setFixedWidth(37)
			self.ckdmndl_NCR_.setFixedHeight(25)
			self.ckdmndl_NCR_.setStyleSheet('border-radius: 2px; background:white; border: 1px solid grey;padding: 2px;')

			self.current_ncr_ = QLabel()
			self.reportno_ = QLabel('NCR-BEML MRS1-T&C-')

			ncr_string = dataOfNcr[0]
			last_part = ncr_string.split('-')[-2].strip()
			result0 = f"{last_part}"
			
			last_part = ncr_string.split('-')[-1].strip()
			result1 = f"-{last_part}"

			self.ckdmndl_NCR_.setText(result0)
			self.current_ncr_.setText(result1)	

			ckmandlhboxlayout_NCR_ = QHBoxLayout()
			ckmandlhboxlayout_NCR_.addWidget(self.reportno_, alignment = Qt.AlignRight )
			ckmandlhboxlayout_NCR_.addWidget(self.ckdmndl_NCR_, alignment = Qt.AlignLeft )
			ckmandlhboxlayout_NCR_.addWidget(self.current_ncr_,alignment = Qt.AlignLeft)
			ckmandlhboxlayout_NCR_.addItem(QSpacerItem(1, 0, QSizePolicy.Expanding, QSizePolicy.Minimum))


			self.createLineEditBox('projectLineEdit_NCR_')
			self.projectLineEdit_NCR_.setText(dataOfNcr[1])
			self.projectLineEdit_NCR_.setToolTip(dataOfNcr[1])

			self.createLineEditBox('productLineEdit_NCR_')
			self.productLineEdit_NCR_.setText(dataOfNcr[2])
			self.productLineEdit_NCR_.setToolTip(dataOfNcr[2])

			self.createNumberLineEditBox('quantityLineEdit_NCR_')
			if dataOfNcr[3]:
				self.quantityLineEdit_NCR_.setText(str(dataOfNcr[3]))
				self.quantityLineEdit_NCR_.setToolTip(str(dataOfNcr[3]))
			else:
				pass
			

			self.createLineEditBox('supplierLineEdit_NCR_')
			self.supplierLineEdit_NCR_.setText(dataOfNcr[4])
			self.supplierLineEdit_NCR_.setToolTip(dataOfNcr[4])

			self.createLineEditBox('detectionLineEdit_NCR_')
			self.detectionLineEdit_NCR_.setText(dataOfNcr[5])
			self.detectionLineEdit_NCR_.setToolTip(dataOfNcr[5])

			self.createComboBox2(['CKD', 'Mandala'], 'placeComboBox_NCR_')
			self.placeComboBox_NCR_.setCurrentText(dataOfNcr[6])

			self.createLineEditBox('storedLineEdit_NCR_')
			self.storedLineEdit_NCR_.setText(dataOfNcr[7])
			self.storedLineEdit_NCR_.setToolTip(dataOfNcr[7])

			self.createComboBox2(['Major', 'Minor'],'severityComboBox_NCR_')
			self.severityComboBox_NCR_.setCurrentText(dataOfNcr[8])
			

			self.createLineEditBox('distributiontoLineEdit_NCR_')
			self.distributiontoLineEdit_NCR_.setText(dataOfNcr[9])
			self.distributiontoLineEdit_NCR_.setToolTip(dataOfNcr[9])

			self.createCheckableComboBox(self.trainsetsList, 'trainComboBox_NCR_')
			selectedTrains = [dataOfNcr[10]]
			self.trainComboBox_NCR_.selectItems(str(selectedTrains))
			
			self.createCheckableComboBox(self.carsList, 'carComboBox_NCR_')
			selectedCars = [dataOfNcr[11]]
			self.carComboBox_NCR_.selectItems(str(selectedCars))
			
			self.createLineEditBox('assydwgnoLineEdit_NCR_')
			self.assydwgnoLineEdit_NCR_.setText(dataOfNcr[12])
			self.assydwgnoLineEdit_NCR_.setToolTip(dataOfNcr[12])

			self.createNumberLineEditBox('revLineEdit_NCR_')
			if dataOfNcr[13] is not None:
				self.revLineEdit_NCR_.setText(str(int(dataOfNcr[13])))
				self.revLineEdit_NCR_.setToolTip((str(int(dataOfNcr[13]))))


			self.createLineEditBox('partnoLineEdit_NCR_')
			self.partnoLineEdit_NCR_.setText(dataOfNcr[14])
			self.partnoLineEdit_NCR_.setToolTip(dataOfNcr[14])

			self.createLineEditBox('assysnoLineEdit_NCR_')
			self.assysnoLineEdit_NCR_.setText(dataOfNcr[15])
			self.assysnoLineEdit_NCR_.setToolTip(dataOfNcr[15])

			self.createLineEditBox('partserialnoLineEdit_NCR_')
			self.partserialnoLineEdit_NCR_.setText(dataOfNcr[16])
			self.partserialnoLineEdit_NCR_.setToolTip(dataOfNcr[16])

			self.createLineEditBox('blnoLineEdit_NCR_')
			self.blnoLineEdit_NCR_.setText(dataOfNcr[17])
			self.blnoLineEdit_NCR_.setToolTip(dataOfNcr[17])

			self.createLineEditBox('invoicenoLineEdit_NCR_')
			self.invoicenoLineEdit_NCR_.setText(dataOfNcr[18])
			self.invoicenoLineEdit_NCR_.setToolTip(dataOfNcr[18])

			self.createLineEditBox('responsiblepartyLineEdit_NCR_')
			self.responsiblepartyLineEdit_NCR_.setText(dataOfNcr[19])
			self.responsiblepartyLineEdit_NCR_.setToolTip(dataOfNcr[19])

			self.createComboBox2(['Before Installation', 'Installed', 'Disassembled', 'Before receiving'], 'materialstatusComboBox_NCR_')
			self.materialstatusComboBox_NCR_.setCurrentText(dataOfNcr[20])
			
			self.createTextEditBox('descriptionOfNonConform_NCR_')
			self.descriptionOfNonConform_NCR_.setText(dataOfNcr[21])
			self.descriptionOfNonConform_NCR_.setToolTip(dataOfNcr[21])
			
			self.createAttachmentWidget('attachedDocuments1_NCR_')
			self.attachedDocuments1_NCR_.fileListWidget.setMinimumHeight(140)

			import ast

			attachedItemsListone = ast.literal_eval(dataOfNcr[22]) if dataOfNcr[22] is not None else []
			if len(attachedItemsListone) > 0:
				for attachment in attachedItemsListone:
					self.attachedDocuments1_NCR_.fileListWidget.addItem(attachment)
					self.attachedDocuments1_NCR_.fileListWidget.setVisible(True)
					self.attachedDocuments1_NCR_.removeButton.setEnabled(True)

			self.createEmptyDateEditBox('date_NCR_')
			self.date_NCR_.setDate(QDate(dataOfNcr[23].year, dataOfNcr[23].month, dataOfNcr[23].day))
			
			self.createLineEditBox('teamLineEdit_NCR_')
			self.teamLineEdit_NCR_.setText(dataOfNcr[24])
			self.teamLineEdit_NCR_.setToolTip(dataOfNcr[24])

			self.createLineEditBox('issuedbyLineEdit_NCR_')
			self.issuedbyLineEdit_NCR_.setText(dataOfNcr[25])
			self.issuedbyLineEdit_NCR_.setToolTip(dataOfNcr[25])

			self.createLineEditBox('reviewedbyLineEdit_NCR_')
			self.reviewedbyLineEdit_NCR_.setText(dataOfNcr[26])
			self.reviewedbyLineEdit_NCR_.setToolTip(dataOfNcr[26])

			self.createLineEditBox('approvedbyLineEdit_NCR_')
			self.approvedbyLineEdit_NCR_.setText(dataOfNcr[27])
			self.approvedbyLineEdit_NCR_.setToolTip(dataOfNcr[27])

			self.createTextEditBox('causeofnonconformity_NCR_')
			self.causeofnonconformity_NCR_.setText(dataOfNcr[28])
			self.causeofnonconformity_NCR_.setToolTip(dataOfNcr[28])

			self.createAttachmentWidget('attacheddocuments2_NCR_')
			self.attacheddocuments2_NCR_.fileListWidget.setMinimumHeight(140)

			attachedItemsListtwo = ast.literal_eval(dataOfNcr[29]) if dataOfNcr[29] is not None else []
			if len(attachedItemsListtwo) > 0:
				for attachment in attachedItemsListtwo:
					self.attacheddocuments2_NCR_.fileListWidget.addItem(attachment)
					self.attacheddocuments2_NCR_.fileListWidget.setVisible(True)
					self.attacheddocuments2_NCR_.removeButton.setEnabled(True)


			self.createTextEditBox('correctionOrCorrectiveActionLineEdit_NCR_')
			self.correctionOrCorrectiveActionLineEdit_NCR_.setText(dataOfNcr[30])
			self.correctionOrCorrectiveActionLineEdit_NCR_.setToolTip(dataOfNcr[30])

			self.createTextEditBox('actionPlan_NCR_')
			self.actionPlan_NCR_.setText(dataOfNcr[31])
			self.actionPlan_NCR_.setToolTip(dataOfNcr[31])

			self.createAttachmentWidget('attacheddocuments3_NCR_')
			self.attacheddocuments3_NCR_.fileListWidget.setMinimumHeight(140)

			attachedItemsListthree = ast.literal_eval(dataOfNcr[32]) if dataOfNcr[32] is not None else []
			if len(attachedItemsListthree) > 0:
				for attachment in attachedItemsListthree:
					self.attacheddocuments3_NCR_.fileListWidget.addItem(attachment)
					self.attacheddocuments3_NCR_.fileListWidget.setVisible(True)
					self.attacheddocuments3_NCR_.removeButton.setEnabled(True)

			self.createEmptyDateEditBox('date1_NCR_')
			if dataOfNcr[33]:
				self.date1_NCR_.setDate(QDate(dataOfNcr[33].year, dataOfNcr[33].month, dataOfNcr[33].day))
			else:
				self.date1_NCR_.setDate(QDate())

			
			self.createLineEditBox('actionbyLineEdit_NCR_')
			self.actionbyLineEdit_NCR_.setText(dataOfNcr[34])
			self.actionbyLineEdit_NCR_.setToolTip(dataOfNcr[34])

			self.createLineEditBox('issuedby1LineEdit_NCR_')
			self.issuedby1LineEdit_NCR_.setText(dataOfNcr[35])
			self.issuedby1LineEdit_NCR_.setToolTip(dataOfNcr[35])

			self.createLineEditBox('reviewedby1LineEdit_NCR_')
			self.reviewedby1LineEdit_NCR_.setText(dataOfNcr[36])
			self.reviewedby1LineEdit_NCR_.setToolTip(dataOfNcr[36])

			self.createLineEditBox('approvedby1LineEdit_NCR_')
			self.approvedby1LineEdit_NCR_.setText(dataOfNcr[37])
			self.approvedby1LineEdit_NCR_.setToolTip(dataOfNcr[37])

			self.createComboBox2(['Claim', 'Holding', 'Use as is', 'Rework', 'Waiver', 'Scrap', 'Repair'], 'decisionComboBox_NCR_')
			self.decisionComboBox_NCR_.setCurrentText(dataOfNcr[38])

			self.createComboBox2(['Yes', 'No'], 'repairprocedureComboBox_NCR_')
			self.repairprocedureComboBox_NCR_.setCurrentText(dataOfNcr[39])

			self.createLineEditBox('name1LineEdit_NCR_')
			self.name1LineEdit_NCR_.setText(dataOfNcr[40])
			self.name1LineEdit_NCR_.setToolTip(dataOfNcr[40])

			self.createEmptyDateEditBox('date2_NCR_')
			if dataOfNcr[41]:
				self.date2_NCR_.setDate(QDate(dataOfNcr[41].year, dataOfNcr[41].month, dataOfNcr[41].day))				
			else:
				self.date2_NCR_.setDate(QDate())


			self.createLineEditBox('sign1LineEdit_NCR_')
			self.sign1LineEdit_NCR_.setText(dataOfNcr[42])
			self.sign1LineEdit_NCR_.setToolTip(dataOfNcr[42])

			self.createLineEditBox('name2LineEdit_NCR_')
			self.name2LineEdit_NCR_.setText(dataOfNcr[43])
			self.name2LineEdit_NCR_.setToolTip(dataOfNcr[43])

			self.createEmptyDateEditBox('date3_NCR_')
			if dataOfNcr[44]:
				self.date3_NCR_.setDate(QDate(dataOfNcr[44].year, dataOfNcr[44].month, dataOfNcr[44].day))
			else:
				self.date3_NCR_.setDate(QDate())

			self.createLineEditBox('sign2LineEdit_NCR_')
			self.sign2LineEdit_NCR_.setText(dataOfNcr[45])
			self.sign2LineEdit_NCR_.setToolTip(dataOfNcr[45])

			self.createComboBox2(['Internal', 'Customer'], 'approvalscopComboBox_NCR_')   
			self.approvalscopComboBox_NCR_.setCurrentText(dataOfNcr[46])
	 	
			self.createLineEditBox('entityLineEdit_NCR_')
			self.entityLineEdit_NCR_.setText(dataOfNcr[47])
			self.entityLineEdit_NCR_.setToolTip(dataOfNcr[47])

			self.createLineEditBox('positionLineEdit_NCR_')
			self.positionLineEdit_NCR_.setText(dataOfNcr[48])
			self.positionLineEdit_NCR_.setToolTip(dataOfNcr[48])

			self.createLineEditBox('name3LineEdit_NCR_')
			self.name3LineEdit_NCR_.setText(dataOfNcr[49])
			self.name3LineEdit_NCR_.setToolTip(dataOfNcr[49])

			self.createEmptyDateEditBox('date4_NCR_')
			if dataOfNcr[50]:
				self.date4_NCR_.setDate(QDate(dataOfNcr[50].year, dataOfNcr[50].month, dataOfNcr[50].day))
			else:
				self.date4_NCR_.setDate(QDate())

			self.createLineEditBox('sign3LineEdit_NCR_')
			self.sign3LineEdit_NCR_.setText(dataOfNcr[51])
			self.sign3LineEdit_NCR_.setToolTip(dataOfNcr[51])

			self.createAttachmentWidget('attacheddocuments4_NCR_')
			self.attacheddocuments4_NCR_.fileListWidget.setMinimumHeight(140)
		

			attachedItemsListfour = ast.literal_eval(dataOfNcr[52]) if dataOfNcr[52] is not None else []
			if len(attachedItemsListfour) > 0:
				for attachment in attachedItemsListfour:
					self.attacheddocuments4_NCR_.fileListWidget.addItem(attachment)
					self.attacheddocuments4_NCR_.fileListWidget.setVisible(True)
					self.attacheddocuments4_NCR_.removeButton.setEnabled(True)

			

			formLayout1.addRow('Report No: <font color="red">*</font>', ckmandlhboxlayout_NCR_)
			formLayout1.addRow('Project:', self.projectLineEdit_NCR_)

			formLayout1.addRow('Product:', self.productLineEdit_NCR_)
			formLayout1.addRow('Quantity: <font color="red">*</font>', self.quantityLineEdit_NCR_)
			
			formLayout1.addRow('Supplier: <font color="red">*</font>', self.supplierLineEdit_NCR_)
			formLayout1.addRow('Detection: <font color="red">*</font>', self.detectionLineEdit_NCR_)
			formLayout1.addRow('Place:', self.placeComboBox_NCR_)
			formLayout1.addRow('Stored at:', self.storedLineEdit_NCR_)	
			formLayout1.addRow('Severity:', self.severityComboBox_NCR_)
			formLayout1.addRow('Distribution to: <font color="red">*</font>', self.distributiontoLineEdit_NCR_)
			formLayout1.addRow('Trainset: <font color="red">*</font>', self.trainComboBox_NCR_)
			formLayout1.addRow('Car:', self.carComboBox_NCR_)

			formLayout1.addRow('Assy dwg no:', self.assydwgnoLineEdit_NCR_)
			formLayout1.addRow('Rev:', self.revLineEdit_NCR_)
			formLayout1.addRow('Part No:', self.partnoLineEdit_NCR_)

			formLayout1.addRow('Assy Serial No:', self.assysnoLineEdit_NCR_)
			formLayout1.addRow('Part Serial No:', self.partserialnoLineEdit_NCR_)


			formLayout1.addRow('B/L No:', self.blnoLineEdit_NCR_)
			formLayout1.addRow('Invoice no:', self.invoicenoLineEdit_NCR_)
			formLayout1.addRow('Responsible party: <font color="red">*</font>', self.responsiblepartyLineEdit_NCR_)
			formLayout1.addRow('Material status:', self.materialstatusComboBox_NCR_)

			formLayout1.addRow('Description of non-conform: <font color="red">*</font>', self.descriptionOfNonConform_NCR_)
			formLayout1.addRow('Attached documents (if any):', self.attachedDocuments1_NCR_)

			formLayout1.addRow('Date: <font color="red">*</font>' , self.date_NCR_)
			formLayout1.addRow('Team :', self.teamLineEdit_NCR_)
			formLayout1.addRow('Issued by: <font color="red">*</font>', self.issuedbyLineEdit_NCR_)
			formLayout1.addRow('Reviewed by: <font color="red">*</font>', self.reviewedbyLineEdit_NCR_)
			formLayout1.addRow('Approved by: <font color="red">*</font>', self.approvedbyLineEdit_NCR_)
			formLayout1.addRow('Cause of nonconformity: ', self.causeofnonconformity_NCR_)


			formLayout2.addRow('Attached documents (if any):', self.attacheddocuments2_NCR_)
			formLayout2.addRow('A. Correction/corrective action result: <font color="red">*</font>', self.correctionOrCorrectiveActionLineEdit_NCR_)
			formLayout2.addRow('B. Action Plan: ', self.actionPlan_NCR_)
			formLayout2.addRow('Attached documents (if any):', self.attacheddocuments3_NCR_)
			formLayout2.addRow('Date: ' , self.date1_NCR_)
			formLayout2.addRow('Action by:', self.actionbyLineEdit_NCR_)
			formLayout2.addRow('Issued by:', self.issuedby1LineEdit_NCR_)
			formLayout2.addRow('Reviewed by:', self.reviewedby1LineEdit_NCR_)
			formLayout2.addRow('Approved by:', self.approvedby1LineEdit_NCR_)
			formLayout2.addRow('Decision :', self.decisionComboBox_NCR_)
			formLayout2.addRow('Repair procedure:', self.repairprocedureComboBox_NCR_)
			formLayout2.addRow(QLabel('Verification on correction:	'))
			formLayout2.addRow('            Name:', self.name1LineEdit_NCR_)
			formLayout2.addRow('            Date:' , self.date2_NCR_)
			formLayout2.addRow('            Sign:', self.sign1LineEdit_NCR_)
			formLayout2.addRow(QLabel('Verification on corrective action:	'))
			formLayout2.addRow('            Name:', self.name2LineEdit_NCR_)
			formLayout2.addRow('            Date: ' , self.date3_NCR_)
			formLayout2.addRow('            Sign:', self.sign2LineEdit_NCR_)
			formLayout2.addRow('Approval Scope:', self.approvalscopComboBox_NCR_)

			formLayout2.addRow('Entity:', self.entityLineEdit_NCR_)
			formLayout2.addRow('Position:', self.positionLineEdit_NCR_)
			formLayout2.addRow('Name:', self.name3LineEdit_NCR_)
			formLayout2.addRow('Date:', self.date4_NCR_)
			formLayout2.addRow('Sign:', self.sign3LineEdit_NCR_)
			formLayout2.addRow('Signed NCR:', self.attacheddocuments4_NCR_)


			def toggleLabelText_():
				currentText_ = self.ckdmndl_NCR_.text()
				if currentText_ == 'CKD':
					self.ckdmndl_NCR_.setText('Mandala')		
					self.ckdmndl_NCR_.setFixedWidth(65)	
				else:
					self.ckdmndl_NCR_.setText('CKD')
					self.ckdmndl_NCR_.setFixedWidth(37)	
			self.ckdmndl_NCR_.clicked.connect(toggleLabelText_)


			self.createPushButton('updateBtn_NCR', 'Update', '', self.geometryWidth(0.04))

			vboxLayout.addWidget(self.updateBtn_NCR, alignment = Qt.AlignCenter)
			

			self.ncrWindow.show()


			allFields_ = [self.reportno_, self.projectLineEdit_NCR_, self.productLineEdit_NCR_, self.quantityLineEdit_NCR_, self.supplierLineEdit_NCR_,
						self.detectionLineEdit_NCR_, self.placeComboBox_NCR_, self.storedLineEdit_NCR_, self.severityComboBox_NCR_,self.distributiontoLineEdit_NCR_,
						self.trainComboBox_NCR_, self.carComboBox_NCR_, self.assydwgnoLineEdit_NCR_, self.revLineEdit_NCR_, self.partnoLineEdit_NCR_,
						self.assysnoLineEdit_NCR_, self.partserialnoLineEdit_NCR_, self.blnoLineEdit_NCR_, self.invoicenoLineEdit_NCR_, self.responsiblepartyLineEdit_NCR_,
						self.materialstatusComboBox_NCR_, self.descriptionOfNonConform_NCR_, self.attachedDocuments1_NCR_, self.date_NCR_, self.teamLineEdit_NCR_, 
						self.issuedbyLineEdit_NCR_, self.reviewedbyLineEdit_NCR_, self.approvedbyLineEdit_NCR_, self.causeofnonconformity_NCR_, 
						self.attacheddocuments2_NCR_, self.correctionOrCorrectiveActionLineEdit_NCR_, self.actionPlan_NCR_, self.attacheddocuments3_NCR_, 
						self.date1_NCR_, self.actionbyLineEdit_NCR_, self.issuedby1LineEdit_NCR_, self.reviewedby1LineEdit_NCR_, self.approvedby1LineEdit_NCR_, 
						self.decisionComboBox_NCR_, self.repairprocedureComboBox_NCR_, self.name1LineEdit_NCR_, self.date2_NCR_, self.sign1LineEdit_NCR_, 
						self.name2LineEdit_NCR_, self.date3_NCR_, self.sign2LineEdit_NCR_, self.approvalscopComboBox_NCR_, self.entityLineEdit_NCR_, 
						self.positionLineEdit_NCR_, self.name3LineEdit_NCR_, self.date4_NCR_, self.sign3LineEdit_NCR_, self.attacheddocuments4_NCR_]


			def setToolTip(wid, text):
				wid.setToolTip(text)

			def settingToolTipps(wid):
				wid.textChanged.connect(lambda: setToolTip(wid, wid.text()))

			for wid in allFields_:
				if isinstance(wid, QLineEdit):
					settingToolTipps(wid)


			def settingToolTipp(wid):
				wid.textChanged.connect(lambda: setToolTip(wid, wid.toPlainText()))

			for wid in allFields_:
				if isinstance(wid, QTextEdit):
					settingToolTipp(wid)
			
			def onClickingupdateNcr():
				mandatoryVerification_NCR = True
				mandatoryIndexesNcr = [0, 3, 4, 5, 9, 10, 19, 21, 23, 25, 26, 27, 30]
			
				ncrFormData_ =[]

				for i, wid in enumerate(allFields_):
					if i ==0:
						ReportNo = f'{self.reportno_.text()}{self.ckdmndl_NCR_.text()}{self.current_ncr_.text()}'
						ncrFormData_.append(ReportNo)

					else:	
						if isinstance(wid, QComboBox):
							if wid.isEnabled():
								if wid.currentText() == '':
									ncrFormData_.append(None)
									if i in mandatoryIndexesNcr:
										mandatoryVerification_NCR = False
										wid.setProperty("error", True)
										wid.setStyleSheet(self.comboBoxQSS)

								else:
									ncrFormData_.append(wid.currentText())
									wid.setProperty("error", False)
									wid.setStyleSheet(self.comboBoxQSS)
							else:
								ncrFormData_.append(None)


						elif isinstance(wid, QLineEdit):
							
							if wid.text() == '':
								ncrFormData_.append(None)
								if i in mandatoryIndexesNcr:
									mandatoryVerification_NCR = False
									wid.setProperty("error", True)
									wid.setStyleSheet(self.lineEditBoxQSS)
							else:
								if wid.text().isdigit():
									ncrFormData_.append(int(wid.text()))
									
								else:
									ncrFormData_.append(wid.text())
									
								wid.setProperty("error", False)
								wid.setStyleSheet(self.lineEditBoxQSS)


						elif isinstance(wid, QTextEdit):
							if wid.isEnabled():
								text_value = wid.toPlainText().strip()
								if text_value == '':
									ncrFormData_.append(None)
									if i in mandatoryIndexesNcr:
										mandatoryVerification_NCR = False
										wid.setProperty("error", True)
										wid.setStyleSheet(self.textEditBoxQSS)		

								else:
									ncrFormData_.append(text_value)
									wid.setProperty("error", False)
									wid.setStyleSheet(self.textEditBoxQSS)

							else:
								ncrFormData_.append(None)


						elif isinstance(wid, QDateEdit):
							if i in mandatoryIndexesNcr:
								if wid.lineEdit().text() == ' ':
									mandatoryVerification_NCR = False
									wid.setProperty("error", True)
									wid.setStyleSheet(self.dateEditBoxQSS)
									ncrFormData_.append(None)
								else:
									qdate = wid.date()
									py_date = date(qdate.year(), qdate.month(), qdate.day())  # Convert QDate to Python date
									ncrFormData_.append(py_date)
									wid.setProperty("error", False)
									wid.setStyleSheet(self.dateEditBoxQSS)
							else:
								if wid.lineEdit().text() == ' ':
									ncrFormData_.append(None)
								else:
									qdate = wid.date()
									py_date = date(qdate.year(), qdate.month(), qdate.day())  # Convert QDate to Python date
									ncrFormData_.append(py_date)


				if not mandatoryVerification_NCR:
					pass

				else:

					dest_folder = "C:\\ProgramData\\RAMSify\\Attachments"
					selected_files1_ = [self.attachedDocuments1_NCR_.fileListWidget.item(i).text() for i in range(self.attachedDocuments1_NCR_.fileListWidget.count())]
					selected_files2_ = [self.attacheddocuments2_NCR_.fileListWidget.item(i).text() for i in range(self.attacheddocuments2_NCR_.fileListWidget.count())]
					selected_files3_ = [self.attacheddocuments3_NCR_.fileListWidget.item(i).text() for i in range(self.attacheddocuments3_NCR_.fileListWidget.count())]		
					selected_files4_ = [self.attacheddocuments4_NCR_.fileListWidget.item(i).text() for i in range(self.attacheddocuments4_NCR_.fileListWidget.count())]		


					vall = 0
					allFileNamesOne = []
					for file in selected_files1_:
						if '/' in file:
							dest_folder = "C:\\ProgramData\\RAMSify\\Attachments"
							file_name = os.path.basename(file)
							
							fVal = str(vall)
							if len(str(vall)) == 1:
								fVal = '00'+str(vall)
							elif len(str(vall)) == 2:
								fVal = '0'+str(vall)
							else:
								fVal = str(vall)

							vall += 1

							base_name, file_extension = os.path.splitext(file_name)
							new_filename = f"{base_name}_{datetime.now().strftime('%Y%m%d%H%M%S')}{fVal}{file_extension}"
							allFileNamesOne.append(new_filename)
							dest_file = os.path.join(dest_folder, new_filename)
							shutil.copy(file, dest_file)

						else:
							allFileNamesOne.append(file)

					if allFileNamesOne:
						ncrFormData_.insert(22, str(allFileNamesOne))
					else:
						ncrFormData_.insert(22, None) 

							
					allFileNamesTwo = []
					for file in selected_files2_:
						if '/' in file:
							dest_folder = "C:\\ProgramData\\RAMSify\\Attachments"
							file_name = os.path.basename(file)
							
							fVal = str(vall)
							if len(str(vall)) == 1:
								fVal = '00'+str(vall)
							elif len(str(vall)) == 2:
								fVal = '0'+str(vall)
							else:
								fVal = str(vall)

							vall += 1
								
							base_name, file_extension = os.path.splitext(file_name)
							new_filename = f"{base_name}_{datetime.now().strftime('%Y%m%d%H%M%S')}{fVal}{file_extension}"
							allFileNamesTwo.append(new_filename)
							dest_file = os.path.join(dest_folder, new_filename)
							shutil.copy(file, dest_file)

						else:
							allFileNamesTwo.append(file)

			
					if allFileNamesTwo:
						ncrFormData_.insert(29, str(allFileNamesTwo))
					else:
						ncrFormData_.insert(29, None) 

					
					allFileNamesThree = []
					for file in selected_files3_:
						if '/' in file:
							dest_folder = "C:\\ProgramData\\RAMSify\\Attachments"
							file_name = os.path.basename(file)
							
							fVal = str(vall)
							if len(str(vall)) == 1:
								fVal = '00'+str(vall)
							elif len(str(vall)) == 2:
								fVal = '0'+str(vall)
							else:
								fVal = str(vall)

							vall += 1
								
							base_name, file_extension = os.path.splitext(file_name)
							new_filename = f"{base_name}_{datetime.now().strftime('%Y%m%d%H%M%S')}{fVal}{file_extension}"
							allFileNamesThree.append(new_filename)
							dest_file = os.path.join(dest_folder, new_filename)
							shutil.copy(file, dest_file)

						else:
							allFileNamesThree.append(file)


					if allFileNamesThree:
						ncrFormData_.insert(32, str(allFileNamesThree))
					else:
						ncrFormData_.insert(32, None) 


					allFileNamesfour = []
					for file in selected_files4_:
						if '/' in file:
							dest_folder = "C:\\ProgramData\\RAMSify\\Attachments"
							file_name = os.path.basename(file)
							
							fVal = str(vall)
							if len(str(vall)) == 1:
								fVal = '00'+str(vall)
							elif len(str(vall)) == 2:
								fVal = '0'+str(vall)
							else:
								fVal = str(vall)

							vall += 1
								
							base_name, file_extension = os.path.splitext(file_name)
							new_filename = f"{base_name}_{datetime.now().strftime('%Y%m%d%H%M%S')}{fVal}{file_extension}"
							allFileNamesfour.append(new_filename)
							dest_file = os.path.join(dest_folder, new_filename)
							shutil.copy(file, dest_file)

						else:
							allFileNamesfour.append(file)

					if allFileNamesfour:
						ncrFormData_.insert(52, str(allFileNamesfour))
					else:
						ncrFormData_.insert(52, None)
					
					ncrFormData_.append(self.user_id)
				
						
				
					update_queryone = """
						UPDATE ncr
						SET
							report_no = %s,
							project = %s,
							product = %s,
							quantity = %s,
							supplier = %s,
							detection = %s,
							place = %s,
							stored_at = %s,
							severity = %s,
							distribution_to = %s,
							trainset = %s,
							car = %s,
							assy_dwg_no = %s,
							rev = %s,
							part_no = %s,
							assy_serial_no = %s,
							part_serial_no = %s,
							bl_no = %s,
							invoice_no = %s,
							responsible_party = %s,
							material_status = %s,
							description_of_nonconform = %s,
							attachments_one = %s,
							attachments_one_date = %s,
							attachments_one_team = %s,
							attachments_one_issued_by = %s,
							attachments_one_reviewed_by = %s,
							attachments_one_approved_by = %s,
							cause_of_nonconformity = %s,
							attached_documents_two = %s,
							correction_corrective_action_result = %s,
							action_plan = %s,
							attachments_three = %s,
							attachments_three_date = %s,
							attachments_three_action_by = %s,
							attachments_three_issued_by = %s,
							attachments_three_reviewed_by = %s,
							attachments_three_approved_by = %s,
							decision = %s,
							repair_procedure = %s,
							correction_name = %s,
							correction_date = %s,
							correction_sign = %s,
							correctiveaction_name = %s,
							correctiveaction_date = %s,
							correctiveaction_sign = %s,
							approval_scope = %s,
							approvedby_entity = %s,
							approvedby_position = %s,
							approvedby_name = %s,
							approvedby_date = %s,
							approvedby_sign = %s,
							signed_ncr = %s,
							user_id = %s
						WHERE report_no = %s
					"""
					reportnum = dataOfNcr[0]		
					ncrFormData_.append(reportnum)

					try:
						self.cursor.execute(update_queryone, tuple(ncrFormData_))
						self.mydb.commit()
						self.refreshButton_ncr.click()
						
						ncrUpdateMsgBox = QMessageBox()
						ncrUpdateMsgBox.setIcon(QMessageBox.Information) 
						ncrUpdateMsgBox.setText(f'Data Updated successfully.')
						ncrUpdateMsgBox.setWindowTitle("Message")
						ncrUpdateMsgBox.setWindowIcon(QIcon('Media/ramsify.png'))
						ncrUpdateMsgBox.setStandardButtons(QMessageBox.Ok)
						ncrUpdateMsgBox.exec_()

						self.ncrWindow.close()
					
					except Exception as e:
						ncrUpdateErrorMsgBox = QMessageBox()
						ncrUpdateErrorMsgBox.setIcon(QMessageBox.Information) 
						ncrUpdateErrorMsgBox.setText(f"Error executing update: {e}")
						ncrUpdateErrorMsgBox.setWindowTitle("Error")
						ncrUpdateErrorMsgBox.setWindowIcon(QIcon('Media/ramsify.png'))
						ncrUpdateErrorMsgBox.setStandardButtons(QMessageBox.Ok)
						ncrUpdateErrorMsgBox.exec_()
					
					

			self.updateBtn_NCR.clicked.connect(onClickingupdateNcr)


		self.ncrDataTable_NCR.setRowCount(0)
	
		for rowIndex, rowData in enumerate(ncrDataResult):
			self.ncrDataTable_NCR.insertRow(self.ncrDataTable_NCR.rowCount()) 

			ncrCheckBoxWidget = QCheckBox('')
			ncrCheckBoxWidget.setStyleSheet(self.checkBoxQSS)
			self.ncrDataTable_NCR.setCellWidget(rowIndex, 0, ncrCheckBoxWidget)
			ncrCheckBoxWidget.stateChanged.connect(onStateChangedOf_NCRCheckBox)

			for colIndex, fData in enumerate(rowData):
				if colIndex == 0:
					button = QPushButton(str(fData))
					givingFunctionalityToButton(button, onbuttonClickedNcr, rowData)				
					button.setStyleSheet(self.tableButtonQSS)
					button.setCursor(Qt.PointingHandCursor)
					self.ncrDataTable_NCR.setCellWidget(rowIndex, colIndex+1, button)

				else: 
					if fData:
						item = QTableWidgetItem(str(fData))
					else:
						item = QTableWidgetItem('')
					item.setFlags(item.flags() & ~Qt.ItemIsEditable) 
					item.setTextAlignment(Qt.AlignCenter)
					item.setToolTip(item.text())
					self.ncrDataTable_NCR.setItem(rowIndex, colIndex+1, item)
				
	self.refreshButton_ncr.clicked.connect(onClicking_Refreshbutton_Ncr)
	

	def onChangingSearchBar_NCR():
		searchText = self.serachBarOfNcrTable.text().lower()

		for row in range(self.ncrDataTable_NCR.rowCount()):
			self.ncrDataTable_NCR.setRowHidden(row, True)

			if self.ncrDataTable_NCR.cellWidget(row, 1) and (searchText in self.ncrDataTable_NCR.cellWidget(row, 1).text().lower()):
				# print(self.ncrDataTable_NCR.cellWidget(row, 1).text().lower())
				self.ncrDataTable_NCR.setRowHidden(row, False)
				continue

			for col in range(2, self.ncrDataTable_NCR.columnCount()):
				item = self.ncrDataTable_NCR.item(row, col)
				if item is not None and searchText in item.text().lower():
					self.ncrDataTable_NCR.setRowHidden(row, False)
					break

	self.serachBarOfNcrTable.textChanged.connect(onChangingSearchBar_NCR)


	def onclicking_selectall_NCRDT(checked):
		if checked:
			self.selectAllNcrButton.setIcon(QIcon(checkAllUserIconPath))

			for i in range(self.ncrDataTable_NCR.rowCount()):
				if not self.ncrDataTable_NCR.isRowHidden(i):
					if isinstance(self.ncrDataTable_NCR.cellWidget(i,0), QCheckBox):
						self.ncrDataTable_NCR.cellWidget(i,0).setCheckState(Qt.Checked)
		
		else:
			self.selectAllNcrButton.setIcon(QIcon(unCheckAllUserIconPath))

			for i in range(self.ncrDataTable_NCR.rowCount()):
				if not self.ncrDataTable_NCR.isRowHidden(i):
					if isinstance(self.ncrDataTable_NCR.cellWidget(i,0), QCheckBox):
						self.ncrDataTable_NCR.cellWidget(i,0).setCheckState(Qt.Unchecked)
	
	self.selectAllNcrButton.toggled.connect(onclicking_selectall_NCRDT)

			
	def onclicking_delete_NCRDT():
			
		selectedReportnoIndices_ = []
		selectedReportnos = []
		numberOfSelectedReportnos = 0

		for i in range(self.ncrDataTable_NCR.rowCount()):
			if not self.ncrDataTable_NCR.isRowHidden(i):
				if isinstance(self.ncrDataTable_NCR.cellWidget(i,0), QCheckBox):
					if self.ncrDataTable_NCR.cellWidget(i,0).checkState() == Qt.Checked:
						selectedReportnoIndices_.append(i)
						ReportnoButton = self.ncrDataTable_NCR.cellWidget(i, 1)
						if ReportnoButton:
							selectedReportnos.append(ReportnoButton.text())
							numberOfSelectedReportnos += 1
		

		if selectedReportnos:
			confirmDeleteNCRMsgBox = QMessageBox()
			confirmDeleteNCRMsgBox.setIcon(QMessageBox.Question) 
			confirmDeleteNCRMsgBox.setText(f"Are you sure you want to delete {numberOfSelectedReportnos} NCR(s)?")
			confirmDeleteNCRMsgBox.setWindowTitle("Confirm")
			confirmDeleteNCRMsgBox.setWindowIcon(QIcon('Media/ramsify.png'))
			confirmDeleteNCRMsgBox.setStandardButtons(QMessageBox.Ok | QMessageBox.No)
			
			userResponse = confirmDeleteNCRMsgBox.exec()

			if userResponse == QMessageBox.Ok:
				current_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
				for ind in sorted(selectedReportnoIndices_, reverse=True):
					reportnoToDelete = selectedReportnos[selectedReportnoIndices_.index(ind)]
					sql = "UPDATE ncr SET deleted_at = %s, user_id = %s WHERE report_no = %s"
					values = (current_time, self.user_id, reportnoToDelete)
					self.cursor.execute(sql, values)
					self.mydb.commit()
					self.ncrDataTable_NCR.removeRow(ind)

				ncrDeleteSuccessMsgBox = QMessageBox()
				ncrDeleteSuccessMsgBox.setIcon(QMessageBox.Information) 
				ncrDeleteSuccessMsgBox.setText(f'{numberOfSelectedReportnos} NCR(s) deleted successfully.')
				ncrDeleteSuccessMsgBox.setWindowTitle("Message")
				ncrDeleteSuccessMsgBox.setWindowIcon(QIcon('Media/ramsify.png'))
				ncrDeleteSuccessMsgBox.setStandardButtons(QMessageBox.Ok)
				ncrDeleteSuccessMsgBox.exec()
			
				self.deleteButton_Ncr.hide()
				self.selectAllNcrButton.setIcon(QIcon(unCheckAllUserIconPath))
			
			else:
				pass

	self.deleteButton_Ncr.clicked.connect(onclicking_delete_NCRDT)


	def onClickingDownloadBtn_NCRDT():

		file_path, _ = QFileDialog.getSaveFileName(self, "Save Excel File", "", "Excel Files (*.xlsx)")

		if file_path:

			wb = Workbook()
			ws = wb.active

			headers = []
			for col in range(1, self.ncrDataTable_NCR.columnCount()):
				if not self.ncrDataTable_NCR.isColumnHidden(col):
					header_item = self.ncrDataTable_NCR.horizontalHeaderItem(col)
					if header_item:
						headers.append(header_item.text())
					else:
						headers.append('')


			ws.append(headers)

			row_index = 2
			for row in range(self.ncrDataTable_NCR.rowCount()):
				if not self.ncrDataTable_NCR.isRowHidden(row):
					for col in range(1, self.ncrDataTable_NCR.columnCount()):
						if col == 1:
							wid = self.ncrDataTable_NCR.cellWidget(row, col)
							if isinstance(wid, QPushButton):
								ws.cell(row=row_index, column=col).value = wid.text()
						else:	
							item = self.ncrDataTable_NCR.item(row, col)
							if item is not None:
								ws.cell(row=row_index, column=col).value = item.text()

					row_index += 1

			wb.save(file_path)

			ncrDownloadedMsgBox = QMessageBox()
			ncrDownloadedMsgBox.setIcon(QMessageBox.Information) 
			ncrDownloadedMsgBox.setText(f'Data downloaded successfully')
			ncrDownloadedMsgBox.setWindowTitle("Message")
			ncrDownloadedMsgBox.setWindowIcon(QIcon('Media/ramsify.png'))
			ncrDownloadedMsgBox.setStandardButtons(QMessageBox.Ok)
			ncrDownloadedMsgBox.exec_()

	self.download_Ncr.clicked.connect(onClickingDownloadBtn_NCRDT)


	def onClickingNewncr():
		self.currentNCRIndex = 15
		self.stackedWidget.setCurrentIndex(15)
	
	self.newncr_NCR.clicked.connect(onClickingNewncr)


	onClicking_Refreshbutton_Ncr()