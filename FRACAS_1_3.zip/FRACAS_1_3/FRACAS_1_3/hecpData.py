from PySide6.QtWidgets import QTableWidgetItem, QSpacerItem, QSizePolicy, QMessageBox, QPushButton, QFileDialog, QCheckBox, QTextEdit, QScrollArea, QComboBox, QAbstractItemView, QLineEdit, QWidget, QLabel, QHBoxLayout, QVBoxLayout, QFormLayout, QHeaderView
from functions import TableWidget
from PySide6.QtCore import Qt
from PySide6.QtGui import QIcon, QColor
from openpyxl import Workbook
from datetime import date, datetime
from collections import defaultdict

def hecpDataUI(self, layout):
	from PySide6.QtWidgets import QApplication, QLabel

	checkAllUserIconPath = self.currentTheme.get('oppositeColorCheckBoxIcon')
	unCheckAllUserIconPath = self.currentTheme.get('oppositeColorUnCheckBoxIcon')
	partiallyCheckedIconPath = self.currentTheme.get('oppositeColorPartiallyCheckedBoxIcon')
	deleteIconPath = self.currentTheme.get('whiteDeleteIcon')
	downloadIconPath = self.currentTheme.get('downloadIcon')
	refreshTableIconPath = self.currentTheme.get('refreshIcon')

	self.createPushButton('selectAllHecpButton', '', unCheckAllUserIconPath, 30)
	self.createPushButton('deleteButton_hecp', '', deleteIconPath, 35, 'Delete')
	self.createLineEditBox('serachBarOfHecp', 'Search...' )
	self.serachBarOfHecp.setClearButtonEnabled(True)
	self.serachBarOfHecp.setFixedWidth(self.geometryWidth(0.2))
	self.createPushButton('download_hecp', '', downloadIconPath, 35, 'Download')

	self.createPushButton('refreshButton_hecp', '', refreshTableIconPath, 35, 'Refresh')
	self.createPushButton('newHecp_HECP', '+ New HECP', '', self.geometryWidth(0.055))

	self.hecpHboxLayout = QHBoxLayout()
	self.hecpHboxLayout.addWidget(self.selectAllHecpButton)
	self.hecpHboxLayout.addWidget(self.deleteButton_hecp)
	self.hecpHboxLayout.addWidget(self.serachBarOfHecp)
	self.hecpHboxLayout.addWidget(self.download_hecp)
	self.hecpHboxLayout.addWidget(self.refreshButton_hecp)
	self.hecpHboxLayout.addItem(QSpacerItem(1, 0, QSizePolicy.Expanding, QSizePolicy.Minimum))
	self.hecpHboxLayout.addWidget(self.newHecp_HECP)
	layout.addLayout(self.hecpHboxLayout)


	self.dataTable_HECP = TableWidget()
	self.headersOfHECPTable  = [' ','HECP No', 'Rev', 'Description', 'Car'] + self.trainsetsList 
	self.dataTable_HECP.setColumnCount(len(self.headersOfHECPTable))
	self.dataTable_HECP.setHorizontalHeaderLabels(self.headersOfHECPTable)
	self.dataTable_HECP.setStyleSheet(self.tableWidgetQSS)
	self.dataTable_HECP.horizontalHeader().setStyleSheet(self.headerHorizontalQSS)
	self.dataTable_HECP.setAlternatingRowColors(True)
	self.dataTable_HECP.setShowGrid(False)
	layout.addWidget(self.dataTable_HECP)

	self.dataTable_HECP.setEditTriggers(QAbstractItemView.NoEditTriggers)
	
	self.selectAllHecpButton.setCheckable(True)

	self.dataTable_HECP.setColumnWidth(0, self.geometryWidth(0.03))
	self.dataTable_HECP.setColumnWidth(1, self.geometryWidth(0.12))
	self.dataTable_HECP.setColumnWidth(2, self.geometryWidth(0.05))
	self.dataTable_HECP.setColumnWidth(3, self.geometryWidth(0.10))

	def OnClickingNewHecpButton():
		self.newHecpWindow = QWidget()
		self.newHecpWindow.move(600, 200)
		self.newHecpWindow.resize(600, 400)
		self.newHecpWindow.setWindowTitle('New HECP')
		self.newHecpWindow.setWindowIcon(QIcon('Media/ramsify.png'))

		vboxLayout = QVBoxLayout()
		formLayout = QFormLayout()
		vboxLayout.addLayout(formLayout)

		self.newHecpWindow.setLayout(vboxLayout)

		self.createLineEditBox('hecpLineEdit_HECP')
		self.createNumberLineEditBox('revLineEdit_HECP')
		self.createTextEditBox('description_HECP')
		self.createCheckableComboBox(self.carsList, 'carComboBox_HECP')
		self.createCheckableComboBox(self.trainsetsList, 'factoryTrainComboBox_HECP')
		
		formLayout.addRow('HECP No: <font color="red">*</font>', self.hecpLineEdit_HECP)
		formLayout.addRow('Rev: <font color="red">*</font>', self.revLineEdit_HECP)
		formLayout.addRow('Description: <font color="red">*</font>', self.description_HECP)
		formLayout.addRow('Cars: <font color="red">*</font>', self.carComboBox_HECP)
		formLayout.addRow('Factory Trains: ', self.factoryTrainComboBox_HECP)

		self.createPushButton('submitBtn_HECP', 'Submit', '', self.geometryWidth(0.04))
		self.createPushButton('cancelBtn_HECP', 'Cancel', '', self.geometryWidth(0.04))


		vboxLayout.addWidget(self.submitBtn_HECP, alignment = Qt.AlignCenter)
		
		hBoxLayout = QHBoxLayout()
		hBoxLayout.addWidget(self.submitBtn_HECP, alignment = Qt.AlignRight)
		hBoxLayout.addWidget(self.cancelBtn_HECP, alignment = Qt.AlignLeft)
		vboxLayout.addLayout(hBoxLayout)
			
		allFieldsData = [self.hecpLineEdit_HECP, self.revLineEdit_HECP, self.description_HECP, self.carComboBox_HECP, self.factoryTrainComboBox_HECP]

		def onClickingSubmit_HECP():
			mandatoryVerification_HECP = True
			mandatoryIndexesHecp = [0, 1, 2, 3]
			hecpData = []

			for i, wid in enumerate(allFieldsData):
				if isinstance(wid, QLineEdit):
					if wid.text() == '':
						hecpData.append(None)
						if i in mandatoryIndexesHecp:
							mandatoryVerification_HECP = False
							wid.setProperty("error", True)
							wid.setStyleSheet(self.lineEditBoxQSS)
					else:
						if wid.text().isdigit():
							hecpData.append(int(wid.text()))
						else:
							hecpData.append(wid.text())

						wid.setProperty("error", False)
						wid.setStyleSheet(self.lineEditBoxQSS)

				if isinstance(wid, QTextEdit):
					if wid.toPlainText() == '':
						hecpData.append(None)
						if i in mandatoryIndexesHecp:
							mandatoryVerification_HECP = False
							wid.setProperty("error", True)
							wid.setStyleSheet(self.textEditBoxQSS)

					else:
						hecpData.append(wid.toPlainText())
						wid.setProperty("error", False)
						wid.setStyleSheet(self.textEditBoxQSS)

				if isinstance(wid, QComboBox):
					if wid.isEnabled():
						if wid.currentText() == '':
							hecpData.append(None)
							if i in mandatoryIndexesHecp:
								mandatoryVerification_HECP = False
								wid.setProperty("error", True)
								wid.setStyleSheet(self.comboBoxQSS)

						else:
							hecpData.append(wid.currentText())
							wid.setProperty("error", False)
							wid.setStyleSheet(self.comboBoxQSS)
					else:
						hecpData.append(None)


			if not mandatoryVerification_HECP:
				print('Mandatory fields missing.')

			else:
				query = '''
							SELECT rev
							FROM hecp
							WHERE hecp_no = %s AND rev = %s AND deleted_at IS NULL
						'''

				self.cursor.execute(query, (hecpData[0], hecpData[1]))
				resultRev = self.cursor.fetchall()
				
				# allRevs = [rev[0] for rev in resultRev]
				if len(resultRev) > 0:
				# if hecpData[1] in allRevs:
					QMessageBox.critical(self, "Duplicate Entry", "Duplicate hecp number with revision.")
				
				else:

					hecpData.append(self.user_id)

					query = """
								INSERT INTO hecp				
								(hecp_no, rev, description, car, factory_trains, user_id)
								VALUES (%s, %s, %s, %s, %s, %s)
							""" 

					try:
						self.cursor.execute(query, tuple(hecpData))
						self.mydb.commit()
						self.refreshButton_hecp.click()
						hecpSubmitMsgBox = QMessageBox()
						hecpSubmitMsgBox.setIcon(QMessageBox.Information) 
						hecpSubmitMsgBox.setText(f'Data Submitted successfully.')
						hecpSubmitMsgBox.setWindowTitle("Message")
						hecpSubmitMsgBox.setWindowIcon(QIcon('Media/ramsify.png'))
						hecpSubmitMsgBox.setStandardButtons(QMessageBox.Ok)
						hecpSubmitMsgBox.exec_()

						self.newHecpWindow.close()

					except Exception as e:
						QMessageBox.critical(self, "Database Error", f"An error occurred: {e}")


		self.submitBtn_HECP.clicked.connect(onClickingSubmit_HECP)

		self.newHecpWindow.show()

		def onClickingcancel_HECP():
			print('sdssssssssssf')

			self.hecpLineEdit_HECP.clear()
			self.revLineEdit_HECP.clear()
			self.description_HECP.clear()
			self.carComboBox_HECP.clearItems()
			self.factoryTrainComboBox_HECP.clearItems()

		self.cancelBtn_HECP.clicked.connect(onClickingcancel_HECP)

	self.newHecp_HECP.clicked.connect(OnClickingNewHecpButton)




	def onClickingRefreshButton_hecp():
		self.deleteButton_hecp.hide()
		self.selectAllHecpButton.setIcon(QIcon(unCheckAllUserIconPath))
		self.selectAllHecpButton.setChecked(False)

		queryone = '''
					SELECT
						hecp_no,
						rev,
						description,
						car,
						factory_trains

					FROM
						hecp

					WHERE
						deleted_at IS NULL
					'''

		self.cursor.execute(queryone)
		hecpDataResultWithCombinedCars = self.cursor.fetchall()

		# Process the results to split 'car' field by ', '
		hecpDataResult = []

		for row in hecpDataResultWithCombinedCars:
			hecp_no, rev, description, car, factory_trains = row
			
			# Split the 'car' field if it contains multiple values separated by ', '
			car_split = list(car.split(', ')) if car else []
			
			# Append the processed row with the split car values
			hecpDataResult.append((hecp_no, rev, description, car_split, factory_trains))

		
		def givingFunctionalityToButton(hecc, functi, dataa):
			hecc.clicked.connect(lambda: functi(dataa))


		def onbuttonClickedHecp(dataOfHecp):
			from PySide6.QtWidgets import QApplication

			self.hecpUpdateWindow = QWidget()
			self.hecpUpdateWindow.move(400, 100)
			self.hecpUpdateWindow.resize(500, 390)

			self.hecpUpdateWindow.setWindowTitle(dataOfHecp[0])
			self.hecpUpdateWindow.setWindowIcon(QIcon('Media/ramsify.png'))

			scrollArea = QScrollArea()
			scrollArea.setWidgetResizable(True)
			scrollArea.setStyleSheet(self.scrollAreaQSS)
			self.hecpUpdateWindow.setLayout(QVBoxLayout())
			self.hecpUpdateWindow.layout().addWidget(scrollArea)

			contentsWidget = QWidget()
			vboxLayout = QVBoxLayout()
			contentsWidget.setLayout(vboxLayout)
			scrollArea.setWidget(contentsWidget)

			formLayout = QFormLayout()
			vboxLayout.addLayout(formLayout)

			self.createLineEditBox('hecpLineEdit_HECP_')
			self.hecpLineEdit_HECP_.setText(dataOfHecp[0])

			self.createNumberLineEditBox('revLineEdit_HECP_')
			self.revLineEdit_HECP_.setText(str(dataOfHecp[1]))
			self.revLineEdit_HECP_.setToolTip(str(dataOfHecp[1]))

			self.createTextEditBox('description_HECP_')
			self.description_HECP_.setText(dataOfHecp[2])
			self.description_HECP_.setToolTip(dataOfHecp[2])

			self.createCheckableComboBox(self.carsList, 'carComboBox_HECP_')
			selected_caritems = [dataOfHecp[3]]
			self.carComboBox_HECP_.selectItems(str(selected_caritems))
			
			self.createCheckableComboBox(self.trainsetsList, 'factoryTrainComboBox_HECP_')
			selected_trainsitems = [dataOfHecp[4]]
			self.factoryTrainComboBox_HECP_.selectItems(str(selected_trainsitems))
			
			
			formLayout.addRow('HECP No: <font color="red">*</font>', self.hecpLineEdit_HECP_)
			formLayout.addRow('Rev: <font color="red">*</font>', self.revLineEdit_HECP_)
			formLayout.addRow('Description: <font color="red">*</font>', self.description_HECP_)
			formLayout.addRow('Cars: <font color="red">*</font>', self.carComboBox_HECP_)
			formLayout.addRow('Factory Trains: ', self.factoryTrainComboBox_HECP_)

			self.createPushButton('updateBtn_HECP', 'Update', '', self.geometryWidth(0.04))

			vboxLayout.addWidget(self.updateBtn_HECP, alignment = Qt.AlignCenter)

			allFieldsData_ = [self.hecpLineEdit_HECP_, self.revLineEdit_HECP_, self.description_HECP_, self.carComboBox_HECP_, self.factoryTrainComboBox_HECP_]


			def setToolTip(wid, text):
				wid.setToolTip(text)

			def settingToolTipToLineEdits(wid):
				wid.textChanged.connect(lambda: setToolTip(wid, wid.text()))


			def settingToolTipToTextEdits(wid):
				wid.textChanged.connect(lambda: setToolTip(wid, wid.toPlainText()))

			for wid in allFieldsData_:
				if isinstance(wid, QLineEdit):
					settingToolTipToLineEdits(wid)

				if isinstance(wid, QTextEdit):
					settingToolTipToTextEdits(wid)


			def onClickingUpdateHecpDataButton():
				mandatoryVerification_HECP = True
				mandatoryIndexesHecp = [0, 1, 2, 3]
				hecpUpdateData = []

				for i, wid in enumerate(allFieldsData_):
					if isinstance(wid, QLineEdit):
						if wid.text() == '':
							hecpUpdateData.append(None)
							if i in mandatoryIndexesHecp:
								mandatoryVerification_HECP = False
								wid.setProperty("error", True)
								wid.setStyleSheet(self.lineEditBoxQSS)
						else:
							if wid.text().isdigit():
								hecpUpdateData.append(int(wid.text()))
							else:
								hecpUpdateData.append(wid.text())

							wid.setProperty("error", False)
							wid.setStyleSheet(self.lineEditBoxQSS)

					if isinstance(wid, QTextEdit):
						if wid.toPlainText() == '':
							hecpUpdateData.append(None)
							if i in mandatoryIndexesHecp:
								mandatoryVerification_HECP = False
								wid.setProperty("error", True)
								wid.setStyleSheet(self.textEditBoxQSS)
						else:
							hecpUpdateData.append(wid.toPlainText())
							wid.setProperty("error", False)
							wid.setStyleSheet(self.textEditBoxQSS)

					if isinstance(wid, QComboBox):
						if wid.isEnabled():
							if wid.currentText() == '':
								hecpUpdateData.append(None)
								if i in mandatoryIndexesHecp:
									mandatoryVerification_HECP = False
									wid.setProperty("error", True)
									wid.setStyleSheet(self.comboBoxQSS)

							else:
								hecpUpdateData.append(wid.currentText())
								wid.setProperty("error", False)
								wid.setStyleSheet(self.comboBoxQSS)
						else:
							hecpUpdateData.append(None)


				

				if not mandatoryVerification_HECP:
					print('Mandatory fields missing.')

				else:

					query = '''
								SELECT rev
								FROM hecp
								WHERE hecp_no = %s AND rev = %s AND deleted_at IS NULL
							'''

					self.cursor.execute(query, (hecpUpdateData[0], hecpUpdateData[1]))
					resultRevs = self.cursor.fetchall()

					def updatingDatabase():
					
						hecpUpdateData.append(self.user_id)						
						update_queryone = """
											UPDATE hecp
											SET
												hecp_no = %s,
												rev = %s,
												description = %s,
												car = %s,
												factory_trains = %s,
												user_id = %s
											WHERE hecp_no = %s AND rev = %s
										"""
						hecpUpdateData.append(dataOfHecp[0])
						hecpUpdateData.append(dataOfHecp[1])
						
					

						try:
							self.cursor.execute(update_queryone, tuple(hecpUpdateData))
							self.mydb.commit()
							self.refreshButton_hecp.click()
							hecpUpdateMsgBox = QMessageBox()
							hecpUpdateMsgBox.setIcon(QMessageBox.Information) 
							hecpUpdateMsgBox.setText(f'Data Updated successfully.')
							hecpUpdateMsgBox.setWindowTitle("Message")
							hecpUpdateMsgBox.setWindowIcon(QIcon('Media/ramsify.png'))
							hecpUpdateMsgBox.setStandardButtons(QMessageBox.Ok)
							hecpUpdateMsgBox.exec_()

							self.hecpUpdateWindow.close()

						except Exception as e:
							QMessageBox.critical(self, "Database Error", f"An error occurred: {e}")


					if (hecpUpdateData[0] == dataOfHecp[0]) and (hecpUpdateData[1] == dataOfHecp[1]):
						if len(resultRevs) == 1:
							updatingDatabase()

					else:
						if len(resultRevs) == 0:
							updatingDatabase()
						else:
							QMessageBox.critical(self, "Duplicate Entry", "Duplicate hecpNo number with revision.")

			


			self.updateBtn_HECP.clicked.connect(onClickingUpdateHecpDataButton)

			self.hecpUpdateWindow.show()

		self.dataTable_HECP.setRowCount(0)
		

		for rowIndex, rowData in enumerate(hecpDataResult):
			self.dataTable_HECP.insertRow(self.dataTable_HECP.rowCount())
			factory_trains = rowData[4]

			hecpCheckBoxWidget = QCheckBox('')
			hecpCheckBoxWidget.setStyleSheet(self.checkBoxQSS)
			self.dataTable_HECP.setCellWidget(self.dataTable_HECP.rowCount()-1, 0, hecpCheckBoxWidget)
			hecpCheckBoxWidget.stateChanged.connect(onStateChangedOf_HECPCheckBox)

			for colIndex, hecData in enumerate(rowData[:-1]):
				if colIndex == 0: 
					button = QPushButton(str(hecData))
					givingFunctionalityToButton(button, onbuttonClickedHecp, rowData)
					button.setStyleSheet(self.tableButtonQSS)
					button.setCursor(Qt.PointingHandCursor)
					self.dataTable_HECP.setCellWidget(self.dataTable_HECP.rowCount()-1, 1, button)

				else:
					item = QTableWidgetItem(str(hecData) if hecData else '')
					item.setTextAlignment(Qt.AlignCenter)
					item.setToolTip(item.text())
					self.dataTable_HECP.setItem(self.dataTable_HECP.rowCount() - 1, colIndex + 1, item)
			

			query_opm = '''
							SELECT
								opm.car_number, trainsets.trainset, opm.work_start_at
							FROM
								other_preventive_maintenance AS opm

							JOIN
								trainsets ON opm.trainset_id = trainsets.id
							
							WHERE
								opm.t_c_no = %s AND
								opm.t_c_rev = %s AND
								opm.opm_type = 'HECP'
						'''
			self.cursor.execute(query_opm, (rowData[0], rowData[1]))
			opmDataResult = self.cursor.fetchall()

			desired_Cars = rowData[3]

			# Grouping by trainset
			grouped_By_Trainset = defaultdict(list)
			trainset_Work_Start_Date = defaultdict(dict)  # Store start dates for completed cars

			for car, trainset, work_start_date in opmDataResult:
				grouped_By_Trainset[trainset].append(car)
				trainset_Work_Start_Date[trainset][car] = work_start_date  # Save start date per car

			for trainset in self.trainsetsList:
				trainset_col_index = self.headersOfHECPTable.index(trainset)  # Get the index of each trainset header
				
				if not factory_trains:
					factory_trains = []

				if trainset in factory_trains:  # Check if this trainset is in factory_trains
					item = QTableWidgetItem("Factory")				
					item.setBackground(QColor(self.currentTheme.get('grayBGColor')))
				else:
					if trainset in grouped_By_Trainset.keys():
						if set(desired_Cars).issubset(set(grouped_By_Trainset[trainset])):
							item = QTableWidgetItem("Completed")
							item.setBackground(QColor(self.currentTheme.get('greenBGColor')))
						else:
							item = QTableWidgetItem("Pending")
							item.setBackground(QColor(self.currentTheme.get('orangeBGColor')))

					else:
						item = QTableWidgetItem("Pending")
						item.setBackground(QColor(self.currentTheme.get('orangeBGColor')))


					toolTipText = ''
					for car in desired_Cars:
						toolTipText += f"{car}:    {trainset_Work_Start_Date.get(trainset, {}).get(car, '')}\n"
					item.setToolTip(toolTipText)


				item.setTextAlignment(Qt.AlignCenter)
				self.dataTable_HECP.setItem(self.dataTable_HECP.rowCount() - 1, trainset_col_index, item)
		
	self.refreshButton_hecp.clicked.connect(onClickingRefreshButton_hecp)




	def onSearchbox_Hecp_Button():

		searchText = self.serachBarOfHecp.text().lower()

		for row in range(self.dataTable_HECP.rowCount()):
			self.dataTable_HECP.setRowHidden(row, True)

			if self.dataTable_HECP.cellWidget(row, 1) and (searchText in self.dataTable_HECP.cellWidget(row, 1).text().lower()):
				self.dataTable_HECP.setRowHidden(row, False)
				continue

			for col in range(2, self.dataTable_HECP.columnCount()):
				item = self.dataTable_HECP.item(row, col)
				if item is not None and searchText in item.text().lower():
					self.dataTable_HECP.setRowHidden(row, False)
					break

	self.serachBarOfHecp.textChanged.connect(onSearchbox_Hecp_Button)


	def onClickingDownloadBtn_HECPDT():

		file_path, _ = QFileDialog.getSaveFileName(self, "Save Excel File", "", "Excel Files (*.xlsx)")

		if file_path:

			wb = Workbook()
			ws = wb.active

			headers = []
			for col in range(1, self.dataTable_HECP.columnCount()):
				if not self.dataTable_HECP.isColumnHidden(col):
					header_item = self.dataTable_HECP.horizontalHeaderItem(col)
					if header_item is not None:
						headers.append(header_item.text())

			ws.append(headers)

			row_index = 2
			for row in range(self.dataTable_HECP.rowCount()):
				if not self.dataTable_HECP.isRowHidden(row):
					# ws.cell(row=row_index, column=1).value = self.dataTable_HECP.cellWidget(row, 0).text()
					for col in range(1, self.dataTable_HECP.columnCount()):
						if col == 1:
							wid = self.dataTable_HECP.cellWidget(row, col)
							if isinstance(wid, QPushButton):
								ws.cell(row=row_index, column=col).value = wid.text()
						else:	
							item = self.dataTable_HECP.item(row, col)
							if item is not None:
								ws.cell(row=row_index, column=col).value = item.text()

					row_index += 1

			wb.save(file_path)

			hecpDownloadedMsgBox = QMessageBox()
			hecpDownloadedMsgBox.setIcon(QMessageBox.Information) 
			hecpDownloadedMsgBox.setText(f'Data downloaded successfully')
			hecpDownloadedMsgBox.setWindowTitle("Message")
			hecpDownloadedMsgBox.setWindowIcon(QIcon('Media/ramsify.png'))
			hecpDownloadedMsgBox.setStandardButtons(QMessageBox.Ok)
			hecpDownloadedMsgBox.exec_()

	self.download_hecp.clicked.connect(onClickingDownloadBtn_HECPDT)


	def onClicking_Selectall_HECPDT(checked):
		if checked:
			self.selectAllHecpButton.setIcon(QIcon(checkAllUserIconPath))

			for i in range(self.dataTable_HECP.rowCount()):
				if not self.dataTable_HECP.isRowHidden(i):
					if isinstance(self.dataTable_HECP.cellWidget(i,0), QCheckBox):
						self.dataTable_HECP.cellWidget(i,0).setCheckState(Qt.Checked)
		
		else:
			self.selectAllHecpButton.setIcon(QIcon(unCheckAllUserIconPath))

			for i in range(self.dataTable_HECP.rowCount()):
				if not self.dataTable_HECP.isRowHidden(i):
					if isinstance(self.dataTable_HECP.cellWidget(i,0), QCheckBox):
						self.dataTable_HECP.cellWidget(i,0).setCheckState(Qt.Unchecked)

	
	self.selectAllHecpButton.toggled.connect(onClicking_Selectall_HECPDT)


	def onStateChangedOf_HECPCheckBox():
		all_checked = True
		all_unchecked = True

		for i in range(self.dataTable_HECP.rowCount()):
			if not self.dataTable_HECP.isRowHidden(i):
				if isinstance(self.dataTable_HECP.cellWidget(i,0), QCheckBox):
					if self.dataTable_HECP.cellWidget(i,0).isChecked():
						all_unchecked = False
					else:
						all_checked = False

		if all_checked or all_unchecked:
			some_checked = False
		else:
			some_checked = True


		if all_checked:
			self.deleteButton_hecp.show()
			self.selectAllHecpButton.setIcon(QIcon(checkAllUserIconPath))
			self.selectAllHecpButton.setChecked(True)
			

		if all_unchecked:
			self.deleteButton_hecp.hide()
			self.selectAllHecpButton.setIcon(QIcon(unCheckAllUserIconPath))
			self.selectAllHecpButton.setChecked(False)

		if some_checked:
			self.deleteButton_hecp.show()
			self.selectAllHecpButton.setIcon(QIcon(partiallyCheckedIconPath))




	def onClicking_Delete_HECPDT():
			
		selectedHecpnoIndices_ = []
		selectedHecpnos = []
		selectedRevs = []
		numberOfSelectedHecpnos = 0

		for i in range(self.dataTable_HECP.rowCount()):
			if not self.dataTable_HECP.isRowHidden(i):
				if isinstance(self.dataTable_HECP.cellWidget(i,0), QCheckBox):
					if self.dataTable_HECP.cellWidget(i,0).checkState() == Qt.Checked:
						selectedHecpnoIndices_.append(i)

						hecpnoButton = self.dataTable_HECP.cellWidget(i, 1)
						if hecpnoButton:
							selectedHecpnos.append(hecpnoButton.text())
							numberOfSelectedHecpnos += 1

						rev = self.dataTable_HECP.item(i, 2).text()
						selectedRevs.append(int(rev))
		
		

		if selectedHecpnos:

			confirmDeleteHECPMsgBox = QMessageBox()
			confirmDeleteHECPMsgBox.setIcon(QMessageBox.Question) 
			confirmDeleteHECPMsgBox.setText(f"Are you sure you want to delete {numberOfSelectedHecpnos} HECP(s)?")
			confirmDeleteHECPMsgBox.setWindowTitle("Confirm")
			confirmDeleteHECPMsgBox.setWindowIcon(QIcon('Media/ramsify.png'))
			confirmDeleteHECPMsgBox.setStandardButtons(QMessageBox.Ok | QMessageBox.No)
			
			userResponse = confirmDeleteHECPMsgBox.exec()

			if userResponse == QMessageBox.Ok:
				current_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
				for ind in sorted(selectedHecpnoIndices_, reverse=True):
					hecpnoToDelete = selectedHecpnos[selectedHecpnoIndices_.index(ind)]
					revOfHecpNoToDelete = selectedRevs[selectedHecpnoIndices_.index(ind)]
					sql = "UPDATE hecp SET deleted_at = %s, user_id = %s WHERE hecp_no = %s AND rev = %s"
					values = (current_time, self.user_id, hecpnoToDelete, revOfHecpNoToDelete)
					self.cursor.execute(sql, values)
					self.mydb.commit()
					self.dataTable_HECP.removeRow(ind)
					
				hecpDeleteSuccessMsgBox = QMessageBox()
				hecpDeleteSuccessMsgBox.setIcon(QMessageBox.Information) 
				hecpDeleteSuccessMsgBox.setText(f'{numberOfSelectedHecpnos} HECPSs deleted successfully.')
				hecpDeleteSuccessMsgBox.setWindowTitle("Message")
				hecpDeleteSuccessMsgBox.setWindowIcon(QIcon('Media/ramsify.png'))
				hecpDeleteSuccessMsgBox.setStandardButtons(QMessageBox.Ok)
				hecpDeleteSuccessMsgBox.exec()
			
				self.deleteButton_hecp.hide()
				self.selectAllHecpButton.setIcon(QIcon(unCheckAllUserIconPath))
			
			else:
				pass


	self.deleteButton_hecp.clicked.connect(onClicking_Delete_HECPDT)


	onClickingRefreshButton_hecp()