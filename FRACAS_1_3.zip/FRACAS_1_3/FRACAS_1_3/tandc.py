from PySide6.QtWidgets import QScrollArea, QTabWidget, QVBoxLayout, QLabel, QComboBox, QToolBox, QWidget, QFormLayout, QDateEdit, QTimeEdit, QTextEdit, QPushButton, QSizePolicy, QHBoxLayout, QSpacerItem, QLineEdit, QDialog, QDialogButtonBox, QTableWidgetItem
import sys
import os

def tandcDataUI(self):
	from PySide6.QtWidgets import QApplication
	# sys.path.append(os.path.dirname(os.path.abspath(__file__)))
	# sys.path.append(os.path.dirname(__file__))
	
	from vccModi import vccModDataUI
	from hecpData import hecpDataUI
	from secpData import secpDataUI
	from rsoiData import rsoiDataUI
	from eirData import eirDataUI

	self.tandcDataTabWidget_TC = QTabWidget()
	self.tandcDataTabWidget_TC.setStyleSheet(self.tabWidgetQSS)
	self.tandcDataTabWidget_TC.setFixedHeight(self.geometryHeight(0.817))

	self.mainVerticalLayout_Tnc.addWidget(self.tandcDataTabWidget_TC)

	vccScroll = QScrollArea()
	hecpScroll = QScrollArea()
	secpScroll = QScrollArea()
	rsoiScroll = QScrollArea()
	eirScroll = QScrollArea()


	self.tandcDataTabWidget_TC.addTab(vccScroll, 'VCC Mod')
	self.tandcDataTabWidget_TC.addTab(hecpScroll, 'HECP')
	self.tandcDataTabWidget_TC.addTab(secpScroll, 'SECP')
	self.tandcDataTabWidget_TC.addTab(rsoiScroll, 'RSOI')
	self.tandcDataTabWidget_TC.addTab(eirScroll, 'EIR')

	
	self.vccDataWidget = QWidget()
	self.hecpDataWidget = QWidget()
	self.secpDataWidget = QWidget()
	self.eirDataWidget = QWidget()
	self.rsoiDataWidget = QWidget()


	vccDataMainLayout = QVBoxLayout(self.vccDataWidget)
	hecpDataMainLayout = QVBoxLayout(self.hecpDataWidget)
	secpDataMainLayout = QVBoxLayout(self.secpDataWidget)
	rsoiDataMainLayout = QVBoxLayout(self.rsoiDataWidget)
	eirDataMainLayout = QVBoxLayout(self.eirDataWidget)

	self.vccDataWidget.setLayout(vccDataMainLayout)
	self.hecpDataWidget.setLayout(hecpDataMainLayout)
	self.secpDataWidget.setLayout(secpDataMainLayout)
	self.rsoiDataWidget.setLayout(rsoiDataMainLayout)
	self.eirDataWidget.setLayout(eirDataMainLayout)

	vccScroll.setWidget(self.vccDataWidget)
	hecpScroll.setWidget(self.hecpDataWidget)
	secpScroll.setWidget(self.secpDataWidget)
	rsoiScroll.setWidget(self.rsoiDataWidget)
	eirScroll.setWidget(self.eirDataWidget)

	vccScroll.setWidgetResizable(True)
	hecpScroll.setWidgetResizable(True)
	secpScroll.setWidgetResizable(True)
	rsoiScroll.setWidgetResizable(True)
	eirScroll.setWidgetResizable(True)

	vccModDataUI(self, vccDataMainLayout)
	hecpDataUI(self, hecpDataMainLayout)
	secpDataUI(self, secpDataMainLayout)
	rsoiDataUI(self, rsoiDataMainLayout)
	eirDataUI(self, eirDataMainLayout)