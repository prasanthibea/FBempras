from functions import *
from QSSS import *

from PySide6.QtWidgets import QScrollArea
import hashlib
import numpy as np
import pandas as pd

# from qtwidgets import PasswordEdit
from configuration import *

import shutil



def configurationUI(self):
	layoutForButtons1 = QHBoxLayout()

	darkCheckBoxIconPath = self.currentTheme.get('darkCheckBoxIcon')
	darkUnCheckBoxIconPath = self.currentTheme.get('darkUnCheckBoxIcon')

	checkAllUserIconPath = self.currentTheme.get('oppositeColorCheckBoxIcon')
	unCheckAllUserIconPath = self.currentTheme.get('oppositeColorUnCheckBoxIcon')
	partiallyCheckedIconPath = self.currentTheme.get('oppositeColorPartiallyCheckedBoxIcon')

	manageUserIconPath = self.currentTheme.get('manageUserIcon')
	addUserIconPath = self.currentTheme.get('addUserIcon')
	deleteUserIconPath = self.currentTheme.get('deleteUserIcon')
	enableUserIconPath = self.currentTheme.get('enableUserIcon')
	disableUserIconPath = self.currentTheme.get('disableUserIcon')


	exportAddUserTemplatePath = self.currentTheme.get('exportTemplateIcon')
	importUsersFromTemplatePath = self.currentTheme.get('importDataIcon')

	self.createPushButton('userManagementBtn', '', manageUserIconPath, 30)
	self.userManagementBtn.setToolTip('Manage User')
	layoutForButtons1.addWidget(self.userManagementBtn, alignment = Qt.AlignLeft)

	self.createPushButton('BOMEditButton', 'BOM')
	layoutForButtons1.addWidget(self.BOMEditButton, alignment = Qt.AlignLeft)

	self.createPushButton('trainsetEditButton', 'Trainset')
	layoutForButtons1.addWidget(self.trainsetEditButton, alignment = Qt.AlignLeft)


	###############################################################################

	self.createPushButton('dbBackupButton', 'Backup')
	layoutForButtons1.addWidget(self.dbBackupButton, alignment = Qt.AlignLeft)


	#################################################################################


	layoutForButtons1.addItem(QSpacerItem(100, 0, QSizePolicy.Expanding, QSizePolicy.Minimum))


	def onclickingUserManagementBtn():
		self.stackedWidgetInConfigurationPage.setCurrentIndex(0)

	def onClickingBOMBtn():
		self.stackedWidgetInConfigurationPage.setCurrentIndex(1)

	def onClickingTrainsetBtn():
		self.stackedWidgetInConfigurationPage.setCurrentIndex(2)


	#################################################################################
	
	def onClickingdbBackupBtn():
		folder_path = QFileDialog.getExistingDirectory(self, "Select Folder", "/")
		if folder_path:
			
			backup_folder_path = os.path.join(folder_path, f"backup_{datetime.now().strftime('%Y%m%d%H%M%S')}")   		
			os.makedirs(backup_folder_path, exist_ok=True)
						
			attachments_folder_path = os.path.join(backup_folder_path, 'Attachments')
			shutil.copytree('C:/ProgramData/RAMSify/Attachments', attachments_folder_path)
	
			backup_file = os.path.join(backup_folder_path, f"backup_{datetime.now().strftime('%Y%m%d%H%M%S')}.sql")
			
			user = self.config.get('Database', 'user')
			password = self.config.get('Database', 'password')
			database = self.config.get('Database', 'database')

			command = f"mysqldump --defaults-file=dbData.cnf {database} > {backup_file}"
			subprocess.run(command, shell=True)

	self.dbBackupButton.clicked.connect(onClickingdbBackupBtn)

	#################################################################################

	self.userManagementBtn.clicked.connect(onclickingUserManagementBtn)
	self.BOMEditButton.clicked.connect(onClickingBOMBtn)
	self.trainsetEditButton.clicked.connect(onClickingTrainsetBtn)

	self.mainVerticalLayout_Configuration.addLayout(layoutForButtons1)

	self.stackedWidgetInConfigurationPage = QStackedWidget()
	self.mainVerticalLayout_Configuration.addWidget(self.stackedWidgetInConfigurationPage)

	#self.stackedWidgetInConfigurationPage.addWidget(QLabel(''))

	manageUsersWidget = QWidget()
	layoutForManageUsersWidget = QVBoxLayout()
	manageUsersWidget.setLayout(layoutForManageUsersWidget)
	self.stackedWidgetInConfigurationPage.addWidget(manageUsersWidget)


	manageBOMWidget = QWidget()
	layoutForManageBOMWidget = QVBoxLayout()
	manageBOMWidget.setLayout(layoutForManageBOMWidget)

	manageTrainsetWidget = QWidget()
	layoutForManageTrainsetWidget = QVBoxLayout()
	manageTrainsetWidget.setLayout(layoutForManageTrainsetWidget)

	layoutForButtonsOfUsersTable = QHBoxLayout()
	layoutForManageUsersWidget.addLayout(layoutForButtonsOfUsersTable)

	self.createPushButton('selectAllButtonInUsersTable', '', unCheckAllUserIconPath, 30)
	self.selectAllButtonInUsersTable.setToolTip('Select all user')

	self.createPushButton('addUserButtonInUsersTable', '', addUserIconPath, 30)
	self.addUserButtonInUsersTable.setToolTip('Add new user')

	self.createPushButton('resetPasswordButtonInUsersTable', 'Reset Password', '', 130)
	self.resetPasswordButtonInUsersTable.setToolTip('Reset user password')

	self.createPushButton('editRoleButtonInUsersTable', 'Edit Role')
	self.editRoleButtonInUsersTable.setToolTip('Edit user role')
	self.editRoleButtonInUsersTable.hide()

	self.createPushButton('disableButtonInUsersTable', '', disableUserIconPath, 30)
	self.disableButtonInUsersTable.setToolTip('Disable user')

	self.createPushButton('EnableButtonInUsersTable', '', enableUserIconPath, 30)
	self.EnableButtonInUsersTable.setToolTip('Enable user')

	self.createPushButton('deleteUserButtonInUsersTable', '', deleteUserIconPath, 30)
	self.deleteUserButtonInUsersTable.setToolTip('Delete user')


	self.createComboBox(['Enabled Users', 'Disabled Users'], 'comboboxForEnabledAndDisabledUsers')
	self.comboboxForEnabledAndDisabledUsers.setCurrentIndex(0)

	refreshTableIconPath = self.currentTheme.get('refreshIcon')
	self.createPushButton('refreshButton_users','', refreshTableIconPath, 35, 'Refresh')
	
	

	

	self.createPushButton('refreshButton_ManageUsers', '', 'Media/refresh.png', 30)

	def onStateChangedOfCheckBox():
		all_checked = True
		all_unchecked = True

		for i in range(userTable_configPage.rowCount()):
			if not userTable_configPage.isRowHidden(i):
				if isinstance(userTable_configPage.cellWidget(i,0), QCheckBox):
					if userTable_configPage.cellWidget(i,0).isChecked():
						all_unchecked = False
					else:
						all_checked = False

		if all_checked or all_unchecked:
			some_checked = False
		else:
			some_checked = True
		

		if self.comboboxForEnabledAndDisabledUsers.currentText() == 'Enabled Users':

			
			if all_checked:
				self.disableButtonInUsersTable.show()
				# self.editRoleButtonInUsersTable.show()
				self.resetPasswordButtonInUsersTable.show()
				self.deleteUserButtonInUsersTable.show()

				#self.selectAllButtonInUsersTable.setIcon(QIcon('Media/checkbox.png'))
				self.selectAllButtonInUsersTable.setIcon(QIcon(checkAllUserIconPath))
				self.selectAllButtonInUsersTable.setChecked(True)

			if all_unchecked:
				self.disableButtonInUsersTable.hide()
				self.editRoleButtonInUsersTable.hide()
				self.resetPasswordButtonInUsersTable.hide()
				self.deleteUserButtonInUsersTable.hide()

				#self.selectAllButtonInUsersTable.setIcon(QIcon('Media/unchecked.png'))
				self.selectAllButtonInUsersTable.setIcon(QIcon(unCheckAllUserIconPath))
				self.selectAllButtonInUsersTable.setChecked(False)

			if some_checked:
				self.disableButtonInUsersTable.show()
				# self.editRoleButtonInUsersTable.show()
				self.resetPasswordButtonInUsersTable.show()
				self.deleteUserButtonInUsersTable.show()

				#self.selectAllButtonInUsersTable.setIcon(QIcon('Media/partialCheckbox.png'))
				self.selectAllButtonInUsersTable.setIcon(QIcon(partiallyCheckedIconPath))
		
		else:
			if all_checked:
				self.disableButtonInUsersTable.hide()
				self.EnableButtonInUsersTable.show()
				# self.editRoleButtonInUsersTable.hide()
				self.resetPasswordButtonInUsersTable.hide()
				self.deleteUserButtonInUsersTable.show()

				#self.selectAllButtonInUsersTable.setIcon(QIcon('Media/checkbox.png'))
				self.selectAllButtonInUsersTable.setIcon(QIcon(checkAllUserIconPath))
				self.selectAllButtonInUsersTable.setChecked(True)

			if all_unchecked:
				self.disableButtonInUsersTable.hide()
				# self.editRoleButtonInUsersTable.hide()
				self.resetPasswordButtonInUsersTable.hide()
				self.deleteUserButtonInUsersTable.hide()
				self.EnableButtonInUsersTable.hide()

				#self.selectAllButtonInUsersTable.setIcon(QIcon('Media/unchecked.png'))
				self.selectAllButtonInUsersTable.setIcon(QIcon(unCheckAllUserIconPath))
				self.selectAllButtonInUsersTable.setChecked(False)

			if some_checked:
				self.disableButtonInUsersTable.hide()
				self.EnableButtonInUsersTable.show()
				# self.editRoleButtonInUsersTable.hide()
				self.resetPasswordButtonInUsersTable.hide()
				self.deleteUserButtonInUsersTable.show()

				#self.selectAllButtonInUsersTable.setIcon(QIcon('Media/partialCheckbox.png'))
				self.selectAllButtonInUsersTable.setIcon(QIcon(partiallyCheckedIconPath))







			# showButtons = 0
			# for i in range(userTable_configPage.rowCount()):
			# 	if not userTable_configPage.isRowHidden(i):
			# 		if isinstance(userTable_configPage.cellWidget(i,0), QCheckBox):
			# 			if userTable_configPage.cellWidget(i,0).checkState() == Qt.Checked:
			# 				showButtons = 1
			# 				break

			# if showButtons == 1:
			# 	self.disableButtonInUsersTable.hide()
			# 	self.EnableButtonInUsersTable.show()
			# 	self.editRoleButtonInUsersTable.hide()
			# 	self.resetPasswordButtonInUsersTable.hide()
			# 	self.deleteUserButtonInUsersTable.show()

			# else:
			# 	self.selectAllButtonInUsersTable.setChecked(False)

			# 	self.disableButtonInUsersTable.hide()
			# 	self.editRoleButtonInUsersTable.hide()
			# 	self.resetPasswordButtonInUsersTable.hide()
			# 	self.deleteUserButtonInUsersTable.hide()
			# 	self.EnableButtonInUsersTable.hide()


			# allChecked = 1
			# for i in range(userTable_configPage.rowCount()):
			# 	if not userTable_configPage.isRowHidden(i):
			# 		if isinstance(userTable_configPage.cellWidget(i,0), QCheckBox):
			# 			if userTable_configPage.cellWidget(i,0).checkState() == Qt.Unchecked:
			# 				allChecked = 0
			# 				break

			# if allChecked == 1:
			# 	self.selectAllButtonInUsersTable.setChecked(True)
			# else:
			# 	pass


	def onChangingComboboxOfEnabledAndDisabled():
		if self.comboboxForEnabledAndDisabledUsers.currentText() == 'Enabled Users':

			for i in range(userTable_configPage.rowCount()):
				if userTable_configPage.item(i,4) != None:
					if userTable_configPage.item(i,4).text() == 'Enabled':
						userTable_configPage.setRowHidden(i, False)
					else:
						userTable_configPage.setRowHidden(i, True)
				else:
					userTable_configPage.setRowHidden(i, True)

			self.addUserButtonInUsersTable.show()
			self.disableButtonInUsersTable.hide()
			# self.editRoleButtonInUsersTable.hide()
			self.resetPasswordButtonInUsersTable.hide()
			self.EnableButtonInUsersTable.hide()

		else:
			for i in range(userTable_configPage.rowCount()):
				if userTable_configPage.item(i,4) != None:
					if userTable_configPage.item(i,4).text() == 'Disabled':
						userTable_configPage.setRowHidden(i, False)
					else:
						userTable_configPage.setRowHidden(i, True)
				else:
					userTable_configPage.setRowHidden(i, True)

			self.addUserButtonInUsersTable.hide()
			self.disableButtonInUsersTable.hide()
			# self.editRoleButtonInUsersTable.hide()
			self.resetPasswordButtonInUsersTable.hide()
			self.EnableButtonInUsersTable.hide()

		onStateChangedOfCheckBox()

	self.comboboxForEnabledAndDisabledUsers.currentIndexChanged.connect(onChangingComboboxOfEnabledAndDisabled)
	


	self.selectAllButtonInUsersTable.setCheckable(True)
	self.selectAllButtonInUsersTable.setFixedHeight(28)

	def onclickingselectallUsersBtn(checked):
		if checked:
			#self.selectAllButtonInUsersTable.setIcon(QIcon('Media/checkbox.png'))
			self.selectAllButtonInUsersTable.setIcon(QIcon(checkAllUserIconPath))

			for i in range(userTable_configPage.rowCount()):
				if not userTable_configPage.isRowHidden(i):
					if isinstance(userTable_configPage.cellWidget(i,0), QCheckBox):
						userTable_configPage.cellWidget(i,0).setCheckState(Qt.Checked)
		else:
			#self.selectAllButtonInUsersTable.setIcon(QIcon('Media/unchecked.png'))
			self.selectAllButtonInUsersTable.setIcon(QIcon(unCheckAllUserIconPath))

			for i in range(userTable_configPage.rowCount()):
				if not userTable_configPage.isRowHidden(i):
					if isinstance(userTable_configPage.cellWidget(i,0), QCheckBox):
						userTable_configPage.cellWidget(i,0).setCheckState(Qt.Unchecked)


	self.selectAllButtonInUsersTable.toggled.connect(onclickingselectallUsersBtn)

	layoutForButtonsOfUsersTable.addWidget(self.selectAllButtonInUsersTable, alignment = Qt.AlignLeft)
	layoutForButtonsOfUsersTable.addWidget(self.addUserButtonInUsersTable, alignment = Qt.AlignLeft)
	layoutForButtonsOfUsersTable.addWidget(self.EnableButtonInUsersTable, alignment = Qt.AlignLeft)
	layoutForButtonsOfUsersTable.addWidget(self.disableButtonInUsersTable, alignment = Qt.AlignLeft)
	layoutForButtonsOfUsersTable.addWidget(self.deleteUserButtonInUsersTable, alignment = Qt.AlignLeft)
	layoutForButtonsOfUsersTable.addWidget(self.editRoleButtonInUsersTable, alignment = Qt.AlignLeft)
	layoutForButtonsOfUsersTable.addWidget(self.resetPasswordButtonInUsersTable, alignment = Qt.AlignLeft)
	layoutForButtonsOfUsersTable.addItem(QSpacerItem(100, 0, QSizePolicy.Expanding, QSizePolicy.Minimum))
	
	layoutForButtonsOfUsersTable.addWidget(self.comboboxForEnabledAndDisabledUsers, alignment = Qt.AlignRight)
	layoutForButtonsOfUsersTable.addWidget(self.refreshButton_ManageUsers, alignment = Qt.AlignRight)
	layoutForButtonsOfUsersTable.addWidget(self.refreshButton_users, alignment = Qt.AlignRight)

	self.refreshButton_users.clicked.connect(lambda: self.onClickingRefresh_users(self.mainVerticalLayout_Configuration))



	self.disableButtonInUsersTable.hide()
	self.editRoleButtonInUsersTable.hide()
	self.resetPasswordButtonInUsersTable.hide()
	self.deleteUserButtonInUsersTable.hide()
	self.EnableButtonInUsersTable.hide()

	self.cursor.execute('SELECT username, email, role, status FROM users')
	usersData = self.cursor.fetchall()
	numberOfUsers = len(usersData)

	headersOfUsersTable = ['', 'User Name', 'Email', 'Role', 'Status']

	userTable_configPage = TableWidget(0, 5, actions=["Copy"])
	layoutForManageUsersWidget.addWidget(userTable_configPage)
	userTable_configPage.setStyleSheet(self.tableWidgetQSS)
	userTable_configPage.horizontalHeader().setStyleSheet(self.headerHorizontalQSS)
	userTable_configPage.verticalHeader().setStyleSheet(self.headerHorizontalQSS)
	userTable_configPage.verticalHeader().setVisible(False)
	userTable_configPage.setAlternatingRowColors(True)
	userTable_configPage.setShowGrid(False)
	userTable_configPage.resizeRowsToContents()
	userTable_configPage.setMinimumHeight(720)
	userTable_configPage.setColumnWidth(0,25)
	userTable_configPage.setColumnWidth(1,150)
	userTable_configPage.setColumnWidth(2,250)
	userTable_configPage.setColumnWidth(3,210)
	userTable_configPage.setColumnWidth(4,250)
	userTable_configPage.setCornerButtonEnabled(False)
	userTable_configPage.setHorizontalHeaderLabels(headersOfUsersTable)


	layoutForSaveAndCancelButtons_ManageUsers = QHBoxLayout()
	self.createPushButton('saveButton_ManageUsers', 'Save')
	self.createPushButton('cancelButton_ManageUsers', 'Cancel')
	
	self.saveButton_ManageUsers.hide()
	self.cancelButton_ManageUsers.hide()

	layoutForSaveAndCancelButtons_ManageUsers.addWidget(self.saveButton_ManageUsers, alignment = Qt.AlignRight)
	layoutForSaveAndCancelButtons_ManageUsers.addWidget(self.cancelButton_ManageUsers, alignment = Qt.AlignLeft)

	layoutForManageUsersWidget.addLayout(layoutForSaveAndCancelButtons_ManageUsers)

	for i in range(numberOfUsers):
		if not usersData[i][2] == 0:
			if not usersData[i][1] == 'admin@gmail.com':
				checkBox = QCheckBox('')
				checkBox.setIcon(QIcon(darkUnCheckBoxIconPath))
				checkBox.stateChanged.connect(onStateChangedOfCheckBox)
				checkBox.setStyleSheet(self.checkBoxQSS)
				userTable_configPage.insertRow(userTable_configPage.rowCount())
				userTable_configPage.setCellWidget(userTable_configPage.rowCount()-1, 0, checkBox)
				for j in range(len(usersData[i])):
					

					if j==2:
						if usersData[i][j] == 1:
							tableItem = QTableWidgetItem('Admin')
						if usersData[i][j] == 2:
							tableItem = QTableWidgetItem('Manager')
						if usersData[i][j] == 3:
							tableItem = QTableWidgetItem('Engineer')

					elif j==3:
						if usersData[i][j] == 1:
							tableItem = QTableWidgetItem('Enabled')
						elif usersData[i][j] == 0:
							tableItem = QTableWidgetItem('Disabled')
							
					else:
						tableItem = QTableWidgetItem(str(usersData[i][j]))


					tableItem.setFlags(tableItem.flags() & ~Qt.ItemIsEditable)
					tableItem.setTextAlignment(Qt.AlignCenter)
					userTable_configPage.setItem(userTable_configPage.rowCount()-1, j+1, tableItem)

	onChangingComboboxOfEnabledAndDisabled()


	def onclickingAddUserButton():

		self.addusersWindow = QWidget()
		self.addusersWindow.setWindowTitle('Add Users Window')
		self.addusersWindow.setWindowIcon(QIcon('Media/ramsify.png'))
		self.addusersWindow.resize(750,600)
		self.addusersWindow.setStyleSheet('background: #ffffff')
		
		addUsersLayout = QVBoxLayout()


		scrollArea = QScrollArea()
		scrollArea.setWidgetResizable(True)
		addUsersGridLayout = QGridLayout()

		# templateButton_addUsers = QPushButton()
		# templateButton_addUsers.setToolTip('Export template')
		# templateButton_addUsers.setIcon(QIcon(exportAddUserTemplatePath))
		#templateButton_addUsers.setFixedWidth(35)

		# importButton_addUsers = QPushButton()
		# importButton_addUsers.setToolTip('Import users')
		# #importButton_addUsers.setFixedWidth(35)
		# importButton_addUsers.setIcon(QIcon(importUsersFromTemplatePath))
		
		headersOfAddUsers = ['User Name', 'Email', 'Initial Password', 'Role', 'Status', '']

		for i in range(len(headersOfAddUsers)):
			label = QLabel(headersOfAddUsers[i])
			# label.setFont(self.labelsAndPushBtnsFont)
			label.setStyleSheet("color: Black;")
			addUsersGridLayout.addWidget(label, 0, i, alignment = Qt.AlignCenter)

		addUsersGridLayout.addItem(QSpacerItem(0, 10, QSizePolicy.Fixed, QSizePolicy.Expanding), addUsersGridLayout.rowCount(), 0)
		
		def addRow(i):
			item = addUsersGridLayout.itemAtPosition(addUsersGridLayout.rowCount()-1, 0)
			addUsersGridLayout.removeItem(item)

			userNameLineEdit = QLineEdit()
			userNameLineEdit.setStyleSheet(self.lineEditBoxQSS)
			addUsersGridLayout.addWidget(userNameLineEdit, i, 0, alignment = Qt.AlignTop)

			emailLineEdit = QLineEdit()
			emailLineEdit.setStyleSheet(self.lineEditBoxQSS)
			addUsersGridLayout.addWidget(emailLineEdit, i, 1, alignment = Qt.AlignTop)

			passwordLineEdit = QLineEdit()
			passwordLineEdit.setStyleSheet(self.lineEditBoxQSS)
			addUsersGridLayout.addWidget(passwordLineEdit, i, 2, alignment = Qt.AlignTop)

			roleCombobox = QComboBox()
			roleCombobox.setFixedHeight(23)
			print(self.userRole)
			roleCombobox.addItems(self.userRolesList[self.userRole:])
			roleCombobox.setStyleSheet(self.comboBoxQSS)
			roleCombobox.setCurrentIndex(-1)
			addUsersGridLayout.addWidget(roleCombobox, i, 3, alignment = Qt.AlignTop)

			statusCombobox = QComboBox()
			statusCombobox.setFixedHeight(23)
			statusCombobox.addItems(['Disabled', 'Enabled'])
			statusCombobox.setStyleSheet(self.comboBoxQSS)
			statusCombobox.setCurrentIndex(-1)
			addUsersGridLayout.addWidget(statusCombobox, i, 4, alignment = Qt.AlignTop)

			minusButton = QPushButton()
			minusButton.setIcon(QIcon('Media/minus.png'))
			#minusButton.setToolTip('Remove user')
			minusButton.setStyleSheet(self.pushbuttonQSS)
			minusButton.setFixedHeight(22)
			minusButton.setFixedWidth(30)
			addUsersGridLayout.addWidget(minusButton, i, 5, alignment = Qt.AlignTop)

			addUsersGridLayout.addItem(QSpacerItem(0, 10, QSizePolicy.Fixed, QSizePolicy.Expanding), addUsersGridLayout.rowCount(), 0)

			def onclickingMinusButton():
				
				index = addUsersGridLayout.getItemPosition(addUsersGridLayout.indexOf(minusButton))
				for i in range(addUsersGridLayout.columnCount()):
					widget = addUsersGridLayout.itemAtPosition(index[0], i).widget()
					addUsersGridLayout.removeWidget(widget)
					widget.deleteLater()

			minusButton.clicked.connect(onclickingMinusButton)
		
		addRow(1)

		

		layoutForButtons_addUsers = QHBoxLayout()
		addUsersLayout.addLayout(layoutForButtons_addUsers)

		plusButton = QPushButton()
		plusButton.setIcon(QIcon('Media/plus.png'))
		plusButton.setToolTip('Add user')
		plusButton.setStyleSheet(self.pushbuttonQSS)
		plusButton.setFixedWidth(29)
		plusButton.setFixedHeight(25)
		layoutForButtons_addUsers.addWidget(plusButton)
		plusButton.clicked.connect(lambda: addRow(addUsersGridLayout.rowCount()-1))


		
		# templateButton_addUsers.setStyleSheet(self.pushbuttonQSS)
		# templateButton_addUsers.setFixedWidth(35)
		# templateButton_addUsers.setFixedHeight(25)
		# layoutForButtons_addUsers.addWidget(templateButton_addUsers)
		


		
		# importButton_addUsers.setStyleSheet(self.pushbuttonQSS)
		# importButton_addUsers.setFixedWidth(35)
		# importButton_addUsers.setFixedHeight(25)
		# layoutForButtons_addUsers.addWidget(importButton_addUsers)
		#layoutForButtons_addUsers.addItem(QSpacerItem())
		

		layoutForButtons_addUsers.addItem(QSpacerItem(1, 1, QSizePolicy.Expanding, QSizePolicy.Fixed))

		gridWidget = QWidget()
		gridWidget.setLayout(addUsersGridLayout)
		scrollArea.setWidget(gridWidget)
		addUsersLayout.addWidget(scrollArea)


		layoutForSaveAndCancelButtons_addUsersWindow = QHBoxLayout()
		addUsersLayout.addLayout(layoutForSaveAndCancelButtons_addUsersWindow)

		saveButton_AddUsersWindow = QPushButton('Save')
		saveButton_AddUsersWindow.setToolTip('Save data')

		cancelButton_AddUsersWindow = QPushButton('Cancel')
		cancelButton_AddUsersWindow.setToolTip('Cancel')

		saveButton_AddUsersWindow.setStyleSheet(self.pushbuttonQSS)
		cancelButton_AddUsersWindow.setStyleSheet(self.pushbuttonQSS)

		saveButton_AddUsersWindow.setFixedHeight(30)
		cancelButton_AddUsersWindow.setFixedHeight(30)

		saveButton_AddUsersWindow.setFixedWidth(75)
		cancelButton_AddUsersWindow.setFixedWidth(75)


		layoutForSaveAndCancelButtons_addUsersWindow.addWidget(saveButton_AddUsersWindow, alignment = Qt.AlignRight)
		layoutForSaveAndCancelButtons_addUsersWindow.addWidget(cancelButton_AddUsersWindow, alignment = Qt.AlignLeft)

		cancelButton_AddUsersWindow.clicked.connect(lambda: self.addusersWindow.close())


		def onClickingSaveButton_addUsersWindow():
			for i in range(addUsersGridLayout.rowCount()-2):

				if addUsersGridLayout.itemAtPosition(i+1,0) != None:
					valid = 1
					newUserData = []
					for j in range(addUsersGridLayout.columnCount()-1):
						if addUsersGridLayout.itemAtPosition(i+1,j) != None:
							widget = addUsersGridLayout.itemAtPosition(i+1,j).widget()
							if isinstance(widget, QLineEdit):
								newUserData.append(widget.text())
								if widget.text() == '':
									valid = 0

							elif isinstance(widget, QComboBox):
								newUserData.append(widget.currentIndex())
								if widget.currentIndex() == -1:
									valid = 0



					if valid == 1:

						newUserPassword = newUserData[2]

						# Create a SHA-256 hash object
						hash_object = hashlib.sha256()

						# Convert the text to bytes and update the hash object
						hash_object.update(newUserPassword.encode('utf-8'))

						# Get the hashed value as a hexadecimal string
						hashed_newPassword = hash_object.hexdigest()

						newUserData[2] = hashed_newPassword

						getemailsQuery = 'SELECT email FROM users'
						self.cursor.execute(getemailsQuery)
						emails = self.cursor.fetchall()
						emailsList = [tup[0] for tup in emails]

						if not newUserData[1] in emailsList:
							insert_query = "INSERT INTO users (username, email, password, role, status, admin_password) VALUES (%s, %s, %s, %s, %s, %s)"
							values = tuple([newUserData[0], newUserData[1], newUserData[2], newUserData[3] + self.userRole, newUserData[4]] + [1])

							# try:
							self.cursor.execute(insert_query, values)
							self.mydb.commit()
						else:
							messageBox = QMessageBox()
							messageBox.setIcon(QMessageBox.Information)
							messageBox.setText(f'"{newUserData[1]}" already exists.')
							messageBox.setWindowTitle("Message")
							messageBox.setWindowIcon(QIcon('Media/ramsify.png'))
							messageBox.setStandardButtons(QMessageBox.Ok)
							messageBox.exec_()


						messageBox = QMessageBox()
						messageBox.setIcon(QMessageBox.Information)
						messageBox.setText('Users Added Successfully')
						messageBox.setWindowTitle("Message")
						messageBox.setWindowIcon(QIcon('Media/ramsify.png'))
						messageBox.setStandardButtons(QMessageBox.Ok)
						messageBox.exec_()

						self.addusersWindow.close()

						# except mysql.connector.Error as err:
						# 	messageBox = QMessageBox()
						# 	messageBox.setIcon(QMessageBox.Information)
						# 	messageBox.setText(f"{newUserData[1]} already exists")
						# 	messageBox.setWindowTitle("Message")
						# 	messageBox.setWindowIcon(QIcon('Media/ramsify.png'))
						# 	messageBox.setStandardButtons(QMessageBox.Ok)
						# 	messageBox.exec_()


						# 	self.mydb.rollback()
					else:
						messageBox = QMessageBox()
						messageBox.setIcon(QMessageBox.Information)
						messageBox.setText('Please Enter All Fields')
						messageBox.setWindowTitle("Message")
						messageBox.setWindowIcon(QIcon('Media/ramsify.png'))
						messageBox.setStandardButtons(QMessageBox.Ok)
						messageBox.exec_()



		saveButton_AddUsersWindow.clicked.connect(onClickingSaveButton_addUsersWindow)



		# def exportUserTemplate():
		# 	# Get the file path for saving the Excel file
		# 	file_path, _ = QFileDialog.getSaveFileName(None, "Save Excel File", "", "Excel Files (*.xlsx)")

		# 	if file_path:

		# 		headersData = []

		# 		for col in range(addUsersGridLayout.columnCount()):
		# 			label = addUsersGridLayout.itemAtPosition(0, col).widget().text()
		# 			headersData.append(label)

		# 		# Create a Pandas DataFrame from the table data
		# 		df = pd.DataFrame([headersData])

		# 		# Save the DataFrame to an Excel file
		# 		df.to_excel(file_path, index=False, header=False)

		# 		# Show success message
		# 		msg = QMessageBox()
		# 		msg.setIcon(QMessageBox.Information)
		# 		msg.setText("Exported Successfully")
		# 		msg.setWindowTitle("Message")
		# 		msg.setWindowIcon(QIcon('Media/ramsify.png'))
		# 		msg.exec_()

		# templateButton_addUsers.clicked.connect(exportUserTemplate)

		# def importUserFromTemplate(): 
		# 	# Get the file path to fetch the data from the excel file:
		# 	file_path, _ = QFileDialog.getOpenFileName(None, "Select Excel File", "", "Excel Files (*.xlsx)")

		# 	if file_path:
		# 		# Read the excel file into pandas dataframe
		# 		df = pd.read_excel(file_path)

		# 		widgetRowCount = -1
		# 		for row in range(addUsersGridLayout.rowCount()):
		# 			if addUsersGridLayout.itemAtPosition(row,0) != None:
		# 				if addUsersGridLayout.itemAtPosition(row,0).widget():
		# 					widgetRowCount += 1


		# 		diff = df.shape[0] - widgetRowCount

		# 		def deleteRows(n):
		# 			if addUsersGridLayout.itemAtPosition(n,6) != None:
		# 				if isinstance(addUsersGridLayout.itemAtPosition(n,6).widget(), QPushButton):
		# 					addUsersGridLayout.itemAtPosition(n,6).widget().click()
		# 			else:
		# 				deleteRows(n+1)

		# 		if diff > 0:
		# 			for i in range(diff):
		# 				plusButton.click()
		# 		elif diff < 0:
		# 			for i in range(0-diff+1):
		# 				deleteRows(i)


		# 		def addingUsers(row, column):
		# 			if addUsersGridLayout.itemAtPosition(row, column) != None:
		# 				if isinstance(addUsersGridLayout.itemAtPosition(row, column).widget(), QLineEdit):
		# 					addUsersGridLayout.itemAtPosition(row, column).widget().setText(str(value))

		# 				elif isinstance(addUsersGridLayout.itemAtPosition(row, column).widget(), QComboBox):

		# 					if value == 'disabled':
		# 						addUsersGridLayout.itemAtPosition(row, column).widget().setCurrentText(str(value))
		# 					else:
		# 						addUsersGridLayout.itemAtPosition(row, column).widget().setCurrentText('enabled')


		# 		validRows = []
		# 		for row in range(addUsersGridLayout.rowCount()):
		# 			if addUsersGridLayout.itemAtPosition(row, 0) != None:
		# 				if isinstance(addUsersGridLayout.itemAtPosition(row, 0).widget(), QLineEdit):
		# 					validRows.append(row)


		# 		for row in range(df.shape[0]):
		# 			for column in range(df.shape[1]):
		# 				value = df.iloc[row, column]
		# 				addingUsers(validRows[row], column)


		# importButton_addUsers.clicked.connect(importUserFromTemplate)


		self.addusersWindow.setLayout(addUsersLayout)
		self.addusersWindow.show()


	def onclickingDisableButton():
		
		selectedUsersIndices = []
		for i in range(userTable_configPage.rowCount()):
			if not userTable_configPage.isRowHidden(i):
				if isinstance(userTable_configPage.cellWidget(i,0), QCheckBox):
					if userTable_configPage.cellWidget(i,0).checkState() == Qt.Checked:
						selectedUsersIndices.append(i)

		for i in range(len(selectedUsersIndices)):
			mail = userTable_configPage.item(selectedUsersIndices[i],2).text()

			sql = "UPDATE users SET status = %s WHERE email = %s"
			values = (0, mail)


			self.cursor.execute(sql, values)
			self.mydb.commit()

			tableItem = QTableWidgetItem('Disabled')
			tableItem.setFlags(tableItem.flags() & ~Qt.ItemIsEditable)
			tableItem.setTextAlignment(Qt.AlignCenter)
			userTable_configPage.setItem(selectedUsersIndices[i], 4, tableItem)
			userTable_configPage.setRowHidden(selectedUsersIndices[i], True)

			userTable_configPage.cellWidget(selectedUsersIndices[i],0).setCheckState(Qt.Unchecked)


	def onclickingEnableButton():
		selectedUsersIndices = []
		for i in range(userTable_configPage.rowCount()):
			if not userTable_configPage.isRowHidden(i):
				if isinstance(userTable_configPage.cellWidget(i,0), QCheckBox):
					if userTable_configPage.cellWidget(i,0).checkState() == Qt.Checked:
						selectedUsersIndices.append(i)

		for i in range(len(selectedUsersIndices)):
			mail = userTable_configPage.item(selectedUsersIndices[i],2).text()

			sql = "UPDATE users SET status = %s WHERE email = %s"
			values = (1, mail)


			self.cursor.execute(sql, values)
			self.mydb.commit()

			tableItem = QTableWidgetItem('Enabled')
			tableItem.setFlags(tableItem.flags() & ~Qt.ItemIsEditable)
			tableItem.setTextAlignment(Qt.AlignCenter)
			userTable_configPage.setItem(selectedUsersIndices[i], 4, tableItem)
			userTable_configPage.setRowHidden(selectedUsersIndices[i], True)

			userTable_configPage.cellWidget(selectedUsersIndices[i],0).setCheckState(Qt.Unchecked)


	def onclickingDeleteUserButton():
		selectedUsersIndices_ = []
		for i in range(userTable_configPage.rowCount()):
			if not userTable_configPage.isRowHidden(i):
				if isinstance(userTable_configPage.cellWidget(i,0), QCheckBox):
					if userTable_configPage.cellWidget(i,0).checkState() == Qt.Checked:
						selectedUsersIndices_.append(i)

		selectedUsersIndices = sorted(selectedUsersIndices_, reverse=True)

		for i in range(len(selectedUsersIndices)):
			mail = userTable_configPage.item(selectedUsersIndices[i],2).text()

			sql = "DELETE FROM users WHERE email = %s"
			values = (mail,)

			self.cursor.execute(sql, values)
			self.mydb.commit()

			userTable_configPage.removeRow(selectedUsersIndices[i])


		onStateChangedOfCheckBox()


	def onclickingResetPasswordButton():

		ResetPasswordDialog = QDialog()
		ResetPasswordDialog.setStyleSheet(self.widgetQSS)
		ResetPasswordDialog.setWindowIcon(QIcon('Media/ramsify.png'))
		ResetPasswordDialog.setWindowTitle("Reset Password")

		label = QLabel("Enter new password:")
		# label.setFont(self.labelsAndPushBtnsFont)
		#resetPasswordLineEdit = QLineEdit()
		resetPasswordLineEdit = QLineEdit()
		# resetPasswordLineEdit.setEchoMode(QLineEdit.Password)
		resetPasswordLineEdit.setEchoMode(QLineEdit.Password)
		resetPasswordLineEdit.setStyleSheet(self.lineEditBoxQSS)
		# resetPasswordLineEdit.setFont(self.labelsAndPushBtnsFont)

		def reset_clicked():
			password_= resetPasswordLineEdit.text()

			selectedUsersIndices = []
			for i in range(userTable_configPage.rowCount()):
				if not userTable_configPage.isRowHidden(i):
					if isinstance(userTable_configPage.cellWidget(i,0), QCheckBox):
						if userTable_configPage.cellWidget(i,0).checkState() == Qt.Checked:
							selectedUsersIndices.append(i)


			for i in range(len(selectedUsersIndices)):
				mail = userTable_configPage.item(selectedUsersIndices[i],2).text()

				hash_object = hashlib.sha256()

				# Convert the text to bytes and update the hash object
				hash_object.update(password_.encode('utf-8'))

				# Get the hashed value as a hexadecimal string
				hashed_Pass = hash_object.hexdigest()


				sql = "UPDATE users SET admin_password = 1, password = %s WHERE email = %s"
				values = (hashed_Pass,mail)


				self.cursor.execute(sql, values)
				self.mydb.commit()

				userTable_configPage.cellWidget(selectedUsersIndices[i],0).setCheckState(Qt.Unchecked)


			ResetPasswordDialog.accept()

		reset_button = QPushButton("Reset")
		reset_button.setStyleSheet(self.pushbuttonQSS)
		reset_button.setFixedWidth(75)
		reset_button.setFixedHeight(25)
		# reset_button.setFont(self.labelsAndPushBtnsFont)
		reset_button.clicked.connect(reset_clicked)


		def cancel_clicked():
			ResetPasswordDialog.reject()

		cancel_button = QPushButton("Cancel")
		cancel_button.setStyleSheet(self.pushbuttonQSS)
		cancel_button.setFixedWidth(75)
		cancel_button.setFixedHeight(25)
		# cancel_button.setFont(self.labelsAndPushBtnsFont)
		cancel_button.clicked.connect(cancel_clicked)

		layoutInResetPasswordWindow = QVBoxLayout()
		layoutInResetPasswordWindow.addWidget(label)
		layoutInResetPasswordWindow.addWidget(resetPasswordLineEdit)
		#layoutInResetPasswordWindow.addWidget(reset_button)
		#layoutInResetPasswordWindow.addWidget(cancel_button)

		hboxlayoutForResetAndCancelPasswordButtons = QHBoxLayout()
		hboxlayoutForResetAndCancelPasswordButtons.addWidget(reset_button)
		hboxlayoutForResetAndCancelPasswordButtons.addWidget(cancel_button)
		hboxlayoutForResetAndCancelPasswordButtons.setAlignment(Qt.AlignCenter)
		layoutInResetPasswordWindow.addLayout(hboxlayoutForResetAndCancelPasswordButtons)
		
		ResetPasswordDialog.setLayout(layoutInResetPasswordWindow)
		
		ResetPasswordDialog.setWindowFlags(ResetPasswordDialog.windowFlags() & ~Qt.WindowContextHelpButtonHint)
		ResetPasswordDialog.setModal(True)


		ResetPasswordDialog.show()



	#def onClickingSaveButton_ManageUsers():
	#	if len(addedUserRowsIndices) != 0:
	#		for i in range(len(addedUserRowsIndices)):
	#			if userTable_configPage.item(addedUserRowsIndices[i], 1) != None and userTable_configPage.item(addedUserRowsIndices[i], 2) != None and userTable_configPage.item(addedUserRowsIndices[i], 3) != None and userTable_configPage.item(addedUserRowsIndices[i], 4) != None:
	#				userName = userTable_configPage.item(addedUserRowsIndices[i], 1)
	#				email = userTable_configPage.item(addedUserRowsIndices[i], 2)


	def onClickingRefreshButton_ManageUsers():

		self.comboboxForEnabledAndDisabledUsers.setCurrentText('Enabled Users')	
		userTable_configPage.clearContents()
		self.cursor.execute('SELECT username, email, role, subsystems, status, created_at, updated_at FROM users')
		usersData = self.cursor.fetchall()
		numberOfUsers = len(usersData)
		
		userTable_configPage.setRowCount(numberOfUsers)
		for i in range(numberOfUsers):
			checkBox = QCheckBox('')
			checkBox.stateChanged.connect(onStateChangedOfCheckBox)
			checkBox.setStyleSheet(self.checkBoxQSS)
			userTable_configPage.setCellWidget(i, 0, checkBox)
			for j in range(len(usersData[i])):
				tableItem = QTableWidgetItem(str(usersData[i][j]))
				tableItem.setFlags(tableItem.flags() & ~Qt.ItemIsEditable)
				tableItem.setTextAlignment(Qt.AlignCenter)
				userTable_configPage.setItem(i, j+1, tableItem)
																			

		for i in range(userTable_configPage.rowCount()):
			if userTable_configPage.item(i,1) != None:
				#if userTable_configPage.item(i,1).text() == 'admin':
				if userTable_configPage.item(i,1).text().lower() == level_1:
					rowIndex = userTable_configPage.row(userTable_configPage.item(i,1))
					userTable_configPage.removeRow(rowIndex)

		for i in range(userTable_configPage.rowCount()):
			if userTable_configPage.item(i,1) != None:			
				if userTable_configPage.item(i,1).text().lower() == level_0:
					rowIndex = userTable_configPage.row(userTable_configPage.item(i,1))
					userTable_configPage.removeRow(rowIndex)


		for i in range(userTable_configPage.rowCount()):
			if userTable_configPage.item(i,5) != None:
				if userTable_configPage.item(i,5).text() == 'Enabled':
					userTable_configPage.setRowHidden(i, False)
				else:
					userTable_configPage.setRowHidden(i, True)






	def onclickingEditRoleButton():
		selectedUsersIndices = []
		for i in range(userTable_configPage.rowCount()):
			if not userTable_configPage.isRowHidden(i):
				if isinstance(userTable_configPage.cellWidget(i,0), QCheckBox):
					if userTable_configPage.cellWidget(i,0).checkState() == Qt.Checked:
						selectedUsersIndices.append(i)


		for i in range(len(selectedUsersIndices)):
			item = userTable_configPage.item(selectedUsersIndices[i], 3)
			item.setFlags(item.flags() | Qt.ItemIsEditable)

		self.saveButton_ManageUsers.show()
		self.cancelButton_ManageUsers.show()


		def onClickingSaveButton_ManageUsers():
			for i in range(len(selectedUsersIndices)):
				mail = userTable_configPage.item(selectedUsersIndices[i],2).text()
				item = userTable_configPage.item(selectedUsersIndices[i], 3)
				item.setFlags(item.flags() & ~Qt.ItemIsEditable)

				sql = "UPDATE users SET role = %s WHERE email = %s"
				values = (item.text(),mail)

				userTable_configPage.cellWidget(selectedUsersIndices[i],0).setCheckState(Qt.Unchecked)

				self.cursor.execute(sql, values)
				self.mydb.commit()
																								 

			self.saveButton_ManageUsers.hide()
			self.cancelButton_ManageUsers.hide()

		def onClickingCancelButton_ManageUsers():
			onClickingRefreshButton_ManageUsers()

		self.saveButton_ManageUsers.clicked.connect(onClickingSaveButton_ManageUsers)
		self.cancelButton_ManageUsers.clicked.connect(onClickingCancelButton_ManageUsers)


	self.refreshButton_ManageUsers.hide()

	self.refreshButton_ManageUsers.clicked.connect(onClickingRefreshButton_ManageUsers)	
	#self.saveButton_ManageUsers.clicked.connect(onClickingSaveButton_ManageUsers)
	self.addUserButtonInUsersTable.clicked.connect(onclickingAddUserButton)
	self.deleteUserButtonInUsersTable.clicked.connect(onclickingDeleteUserButton)
	self.EnableButtonInUsersTable.clicked.connect(onclickingEnableButton)
	self.disableButtonInUsersTable.clicked.connect(onclickingDisableButton)
	self.resetPasswordButtonInUsersTable.clicked.connect(onclickingResetPasswordButton)
	self.editRoleButtonInUsersTable.clicked.connect(onclickingEditRoleButton)


	
	self.stackedWidgetInConfigurationPage.addWidget(manageBOMWidget)
	self.stackedWidgetInConfigurationPage.addWidget(manageTrainsetWidget)



########### Manage BOM
	


	layoutForButtons_manageBOM = QHBoxLayout()
	self.createPushButton('templateButton_manageBOM', 'Template')
	self.createPushButton('importButton_manageBOM', 'Import')
	layoutForButtons_manageBOM.addWidget(self.templateButton_manageBOM, alignment = Qt.AlignRight)
	layoutForButtons_manageBOM.addWidget(self.importButton_manageBOM, alignment = Qt.AlignLeft)

	layoutForManageBOMWidget.addLayout(layoutForButtons_manageBOM)




	def onClickingTemplate_manageBOM():

		file_path, _ = QFileDialog.getSaveFileName(None, "Save Excel File", "", "Excel Files (*.xlsx)")

		if file_path:
			# query = 'SELECT * FROM bom'
			query = 'SELECT id, parent_id, equipment, dm1, t2, m3, m4, t5, dm6, quantity, mdbcf_target, mttr_target, item_mdbcf FROM bom'
			self.cursor.execute(query)
			BOM = self.cursor.fetchall()
			df = pd.DataFrame(BOM)

			# query_headers = "SHOW COLUMNS FROM bom"
			# self.cursor.execute(query_headers)
			headers = ['id', 'parent_id', 'equipment', 'dm1', 't2', 'm3', 'm4', 't5', 'dm6', 'quantity', 'mdbcf_target', 'mttr_target', 'item_mdbcf']

			df.columns = headers
			df.to_excel(file_path, index=False, header=True)

			# Show success message
			msg = QMessageBox()
			msg.setIcon(QMessageBox.Information)
			msg.setText("Exported Successfully")
			msg.setWindowTitle("Message")
			msg.setWindowIcon(QIcon('Media/ramsify.png'))
			msg.exec_()

	self.templateButton_manageBOM.clicked.connect(onClickingTemplate_manageBOM)


	def onClickingImport_manageBOM():
		# Get the file path for selecting the Excel file
		file_path, _ = QFileDialog.getOpenFileName(None, "Select Excel File", "", "Excel Files (*.xlsx)")

		if file_path:
			# Specify the table name
			table_name = 'bom'

			# Read the Excel file into a Pandas DataFrame
			df = pd.read_excel(file_path)
			df = df.map(lambda x: x.strip() if isinstance(x, str) else x)

			# Drop the empty column
			df = df.dropna(axis=1, how='all')

			# Replace 'nan' values with None
			df = df.replace({np.nan: None})

			# Convert DataFrame to list of tuples
			data = [tuple(row) for row in df.values]
			

			# Generate placeholders for the query
			placeholders = ', '.join(['%s'] * len(df.columns))
			

			# Delete all the data in table
			self.cursor.execute("DELETE FROM bom")
			self.cursor.execute("ALTER TABLE bom AUTO_INCREMENT = 1")

			# Generate the INSERT query
			column_names = ['id', 'parent_id', 'equipment', 'dm1', 't2', 'm3', 'm4', 't5', 'dm6', 'quantity', 'mdbcf_target', 'mttr_target', 'item_mdbcf']
			query = f"INSERT INTO {table_name} ({', '.join(column_names)}) VALUES ({placeholders})"

			self.cursor.executemany(query, data)
			self.mydb.commit()

			msg = QMessageBox()
			msg.setIcon(QMessageBox.Information)
			msg.setText("Data Imported Successfully")
			msg.setWindowTitle("Message")
			msg.setWindowIcon(QIcon('Media/ramsify.png'))
			msg.exec_()

	self.importButton_manageBOM.clicked.connect(onClickingImport_manageBOM)




########### Manage Trainsets


	layoutForButtons_manageTrainset = QHBoxLayout()
	self.createPushButton('templateButton_manageTrainset', 'Template')
	self.createPushButton('importButton_manageTrainset', 'Import')
	layoutForButtons_manageTrainset.addWidget(self.templateButton_manageTrainset, alignment = Qt.AlignRight)
	layoutForButtons_manageTrainset.addWidget(self.importButton_manageTrainset, alignment = Qt.AlignLeft)

	layoutForManageTrainsetWidget.addLayout(layoutForButtons_manageTrainset)




	def onClickingTemplate_manageTrainset():

		file_path, _ = QFileDialog.getSaveFileName(None, "Save Excel File", "", "Excel Files (*.xlsx)")

		if file_path:

			query = 'SELECT trainset, line, depot, hand_over, revenue_date, stabilization, end_of_12m_revenue, end_of_18m_revenue, warranty FROM trainsets'
			self.cursor.execute(query)
			BOM = self.cursor.fetchall()
			df = pd.DataFrame(BOM)

			headers = ['trainset', 'line', 'depot', 'hand_over', 'revenue_date', 'stabilization', 'end_of_12m_revenue', 'end_of_18m_revenue', 'warranty']

			df.columns = headers
			df.to_excel(file_path, index=False, header=True)

			# Show success message
			msg = QMessageBox()
			msg.setIcon(QMessageBox.Information)
			msg.setText("Exported Successfully")
			msg.setWindowTitle("Message")
			msg.setWindowIcon(QIcon('Media/ramsify.png'))
			msg.exec_()

	self.templateButton_manageTrainset.clicked.connect(onClickingTemplate_manageTrainset)


	def onClickingImport_manageTrainset():
		# Get the file path for selecting the Excel file
		file_path, _ = QFileDialog.getOpenFileName(None, "Select Excel File", "", "Excel Files (*.xlsx)")

		if file_path:
			# Specify the table name
			table_name = 'trainsets'

			# Read the Excel file into a Pandas DataFrame
			df = pd.read_excel(file_path)
			df = df.map(lambda x: x.strip() if isinstance(x, str) else x)

			# Drop the empty column
			df = df.dropna(axis=1, how='all')

			# Convert the 'Target_MTBF' column to nullable float type
			#df['Target_MTBF'] = df['Target_MTBF'].astype('Float64')

			# Replace 'nan' values with None
			df = df.replace({np.nan: None})

			# Convert DataFrame to list of tuples
			data = [tuple(row) for row in df.values]

			# Generate placeholders for the query
			placeholders = ', '.join(['%s'] * len(df.columns))

			# Delete all the data in table
			self.cursor.execute("DELETE FROM trainsets")
			self.cursor.execute("ALTER TABLE trainsets AUTO_INCREMENT = 1")

			# Generate the INSERT query
			column_names = ['trainset', 'line', 'depot', 'hand_over', 'revenue_date', 'stabilization', 'end_of_12m_revenue', 'end_of_18m_revenue', 'warranty']
			query = f"INSERT INTO {table_name} ({', '.join(column_names)}) VALUES ({placeholders})"

			self.cursor.executemany(query, data)
			self.mydb.commit()

			msg = QMessageBox()
			msg.setIcon(QMessageBox.Information)
			msg.setText("Data Imported Successfully")
			msg.setWindowTitle("Message")
			msg.setWindowIcon(QIcon('Media/ramsify.png'))
			msg.exec_()


			# Generate the INSERT query
			# query = f"INSERT INTO {table_name} VALUES ({placeholders})"

			# self.cursor.executemany(query, data)
			# self.mydb.commit()

	self.importButton_manageTrainset.clicked.connect(onClickingImport_manageTrainset)


def deleteItems_users(layout):
	if layout:
		while layout.count():
			item = layout.takeAt(0)
			widget = item.widget()
			if widget:
				widget.setParent(None)
			else:
				deleteItems_users(item.layout())

def onClickingRefresh_users(self, layout):
	deleteItems_users(layout)
	self.configurationUI()
	
	if self.userRole == 0:
		self.BOMEditButton.show()
		self.trainsetEditButton.show()
	else:
		self.BOMEditButton.hide()
		self.trainsetEditButton.hide()