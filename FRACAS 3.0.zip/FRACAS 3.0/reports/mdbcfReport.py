from datetime import datetime, timedelta
from dateutil.relativedelta import relativedelta
import calendar

from PySide6.QtWidgets import QApplication
from functions import createPieChart

def mdbcfReportUi(self, month, year, selected_report_title):
	# six_months_ago = datetime(year, month, 1) - relativedelta(months=5)

	# six_months_agoDate = six_months_ago.date()
	# fromDateMonthString = six_months_agoDate.strftime('%b - %Y')
	# allItems = []
	# for index in range(self.fromCombobox_MDBCF.count()):
	# 	item_text = self.fromCombobox_MDBCF.itemText(index)
	# 	allItems.append(item_text)
	

	# if fromDateMonthString in allItems:
	# 	self.fromCombobox_MDBCF.setCurrentText(fromDateMonthString)
	# else:
	# 	self.fromCombobox_MDBCF.setCurrentIndex(0)


	# month_string = calendar.month_abbr[int(month)]
	date_object = datetime(year, month, 1)
	toMonthString = date_object.strftime('%b - %Y')

	self.fromCombobox_MDBCF.setCurrentText(toMonthString)
	self.toCombobox_MDBCF.setCurrentText(toMonthString)



	mdbcf_data	 = []

	month_string = calendar.month_abbr[int(month)]

	report_title = f'MDBCF for  {toMonthString.upper()}'

	# Add the header title as a paragraph
	mdbcf_data.append(report_title)

	##########################################################

	tableNamesList = ['MDBCF']

	##########################################################


	table_data = []

	
	# Fetch headers
	header_text = []
	columnstoSelect = list(range(self.tableForMDBCFDashboard.columnCount()-5)) + list(range(self.tableForMDBCFDashboard.columnCount()-3, self.tableForMDBCFDashboard.columnCount()))
	
	for col in columnstoSelect:
		if not self.tableForMDBCFDashboard.isColumnHidden(col):
			header_item = self.tableForMDBCFDashboard.horizontalHeaderItem(col)
			if header_item:
				header_text.append(header_item.text())

	# Add headers to the table_data
	table_data.append(header_text)



	# Fetch data
	for row in range(self.tableForMDBCFDashboard.rowCount()):
		row_data = []
		for col in columnstoSelect:
			if not self.tableForMDBCFDashboard.isColumnHidden(col):

		# for col in range(self.tableForMDBCFDashboard.columnCount()):
				item = self.tableForMDBCFDashboard.item(row, col)
				if item:
					row_data.append(item.text())
				else:
					row_data.append('')
		
		table_data.append(row_data)


	# Add the table to the mdbcf_data
	mdbcf_data.append(table_data)


	##########################################################


	mdbcf_chart_list = []


	mdbcfResultList_PieChart = []

	for row in range(self.tableForMDBCFDashboard.rowCount()):
		item = self.tableForMDBCFDashboard.item(row, self.tableForMDBCFDashboard.columnCount()-1)
		if item and item.text() != '':
			mdbcfResultList_PieChart.append(item.text())
		else:
			pass
	

	mdbcfResultDict = {}
	mdbcfResultDict['Pass'] = mdbcfResultList_PieChart.count('Pass')
	mdbcfResultDict['Fail'] = mdbcfResultList_PieChart.count('Fail')


	mdbcfResultChartView = self.createPieChart(mdbcfResultDict, f'MDBCF For {toMonthString}')
	mdbcfResultChartView.setFixedHeight(525)
	mdbcfResultChartView.setFixedWidth(int(0.4 * QApplication.primaryScreen().availableGeometry().width()))

	mdbcf_chart_image = mdbcfResultChartView.grab().toImage()
	mdbcf_chart_list.append(mdbcf_chart_image)


	##########################################################


	# Generate the report
	self.generate_pdf_report(selected_report_title, mdbcf_data, tableNamesList, 0, mdbcf_chart_list, boldCells=self.systemsInMDBCFDashboard)
	self.clearAllFiltersButton_MDBCF.click()
