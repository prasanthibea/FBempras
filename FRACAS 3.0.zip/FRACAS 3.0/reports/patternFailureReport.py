from datetime import datetime, timedelta
from dateutil.relativedelta import relativedelta
import calendar

def patternFailureReportUi(self, month, year, selected_report_title):

	three_months_ago = datetime(year, month, 1) - relativedelta(months=2)

	three_months_agoDate = three_months_ago.date()
	fromDateMonthString = three_months_agoDate.strftime('%b - %Y')
	allItems = []
	for index in range(self.fromCombobox_PF.count()):
		item_text = self.fromCombobox_PF.itemText(index)
		allItems.append(item_text)
	

	if fromDateMonthString in allItems:
		self.fromCombobox_PF.setCurrentText(fromDateMonthString)
	else:
		self.fromCombobox_PF.setCurrentIndex(0)


	# month_string = calendar.month_abbr[int(month)]
	date_object = datetime(year, month, 1)
	toMonthString = date_object.strftime('%b - %Y')

	self.toCombobox_PF.setCurrentText(toMonthString)


	pf_data = []

	report_title = f'PATTERN FAILURES for  {toMonthString.upper()}'

	pf_data.append(report_title)

	##########################################################

	tableNamesList = ['Pattern Failures']
	
	##########################################################

	# monthlyFailurePFTableData = []

	# header_text = []
	# for col in range(self.monthlyFailuresTable_mdbf.columnCount()):
	# 	header_item = self.monthlyFailuresTable_mdbf.horizontalHeaderItem(col)
	# 	if header_item:
	# 		header_text.append(header_item.text())

	# # Add headers to the table_data
	# monthlyFailurePFTableData.append(header_text)


	# Fetch data
	# for row in range(self.monthlyFailuresTable_mdbf.rowCount()):
	# 	row_data = []
	# 	for col in range(self.monthlyFailuresTable_mdbf.columnCount()):
	# 		item = self.monthlyFailuresTable_mdbf.item(row, col)

	# 		if item:
	# 			row_data.append(item.text())
	# 		else:
	# 			row_data.append('')
		
	# 	monthlyFailurePFTableData.append(row_data)


	# pf_data.append(monthlyFailurePFTableData)

	

	##########################################################


	columnstoSelect = [0, 1, 2] + list(range(4, self.tableForPFDashboard.columnCount()-3)) + [self.tableForPFDashboard.columnCount()-1]

	PFDashboardTableData = []

	header_text = []
	for col in columnstoSelect:
		if not self.tableForPFDashboard.isColumnHidden(col):
			header_item = self.tableForPFDashboard.horizontalHeaderItem(col)
			if header_item:
				header_text.append(header_item.text())

	# Add headers to the table_data
	PFDashboardTableData.append(header_text)


	# Fetch data
	for row in range(self.tableForPFDashboard.rowCount()):
		row_data = []
		for col in columnstoSelect:
			if not self.tableForPFDashboard.isColumnHidden(col):
				if not self.tableForPFDashboard.isRowHidden(row):
					item = self.tableForPFDashboard.item(row, col)
					if item:
						row_data.append(item.text())
					else:
						row_data.append('')
		if row_data:
			PFDashboardTableData.append(row_data)


	pf_data.append(PFDashboardTableData)

	
	##########################################################

	# Generate the report
	self.generate_pdf_report(selected_report_title, pf_data, tableNamesList, 1, [], boldCells = self.systemsInPFDashboard)
	self.clearAllFiltersButton_PF.click()