from datetime import datetime, timedelta
from dateutil.relativedelta import relativedelta
import calendar

from PySide6.QtWidgets import QApplication
from PySide6.QtCore import Qt
from functions import createLineChart

def mdbfReportUi(self, month, year, selected_report_title):

	six_months_ago = datetime(year, month, 1) - relativedelta(months=5)

	six_months_agoDate = six_months_ago.date()
	fromDateMonthString = six_months_agoDate.strftime('%b - %Y')
	allItems = []
	for index in range(self.fromCombobox_MDBFDash.count()):
		item_text = self.fromCombobox_MDBFDash.itemText(index)
		allItems.append(item_text)
	

	if fromDateMonthString in allItems:
		self.fromCombobox_MDBFDash.setCurrentText(fromDateMonthString)
	else:
		self.fromCombobox_MDBFDash.setCurrentIndex(0)


	# month_string = calendar.month_abbr[int(month)]
	date_object = datetime(year, month, 1)
	toMonthString = date_object.strftime('%b - %Y')

	self.toCombobox_MDBFDash.setCurrentText(toMonthString)

	mdbf_data = []

	report_title = f'MDBF Report for {toMonthString}'
	mdbf_data.append(report_title)

	tableNamesList = ['MDBF']

	# for line_name in self.uniqueLines:
	# 	tableNamesList.append(f'MDBF for {line_name}')

	# for tab in self.lineTablesList_mdbfDash:
		
	# 	##########################################################

	# 	mdbfDashboardTableData = []

	# 	header_text = []
	# 	for col in range(tab.columnCount()):
	# 		if not tab.isColumnHidden(col):
	# 			header_item = tab.horizontalHeaderItem(col)
	# 			if header_item:
	# 				header_text.append(header_item.text())

	# 	# Add headers to the table_data
	# 	mdbfDashboardTableData.append(header_text)


	# 	# Fetch data
	# 	for row in range(tab.rowCount()):
	# 		row_data = []
	# 		for col in range(tab.columnCount()):
	# 			if not tab.isColumnHidden(col):
	# 				item = tab.item(row, col)

	# 				if item:
	# 					row_data.append(item.text())
	# 				else:
	# 					row_data.append('')
			
	# 		mdbfDashboardTableData.append(row_data)


	# 	mdbf_data.append(mdbfDashboardTableData)

	
	##########################################################

	mdbfDashboardTableData = []

	header_text = []
	for col in range(self.mdbfDashboardTable.columnCount()):
		if not self.mdbfDashboardTable.isColumnHidden(col):
			header_item = self.mdbfDashboardTable.horizontalHeaderItem(col)
			if header_item:
				header_text.append(header_item.text())

	# Add headers to the table_data
	mdbfDashboardTableData.append(header_text)


	# Fetch data
	for row in range(self.mdbfDashboardTable.rowCount()):
		row_data = []
		for col in range(self.mdbfDashboardTable.columnCount()):
			if not self.mdbfDashboardTable.isColumnHidden(col):
				item = self.mdbfDashboardTable.item(row, col)

				if item:
					row_data.append(item.text())
				else:
					row_data.append('')
		
		mdbfDashboardTableData.append(row_data)


	mdbf_data.append(mdbfDashboardTableData)

	
	##########################################################

	#######################################################################################################
	## MonthWise Target vs Achieved MDBF Line Chart (Line 2A & 7, Line 2B)

	mdbf_charts_list = []


	xlabels_mdbf_chart = []
	for col in range(1, self.mdbfDashboardTable.columnCount()):
		if not self.mdbfDashboardTable.isColumnHidden(col):
			header_item = self.mdbfDashboardTable.horizontalHeaderItem(col)
			if header_item:
				xlabels_mdbf_chart.append(header_item.text())

	
	targetAndAchievedMdbfValues = []

	for row in [7,9]:
		row_data = []
		for col in range(1, self.mdbfDashboardTable.columnCount()):
			if not self.mdbfDashboardTable.isColumnHidden(col):
				item = self.mdbfDashboardTable.item(row, col)

				if item:
					cell_value = item.text()

					try:
						if cell_value == 'No Fails':
							row_data.append(0.0)
						else:
							row_data.append(float(cell_value))
					except ValueError:
						row_data.append(0.0)
				else:
					row_data.append(0.0)

		targetAndAchievedMdbfValues.append(row_data)



	mdbfValuesList = targetAndAchievedMdbfValues
	chartTitle_MDBF = f"MDBF with Shortfall Trains (6M)"
	xLabels_MDBF = "Months"
	yLabels_MDBF = "MDBF (KM)"


	legends_MDBF= ['Target MDBF', 'Achieved MDBF']
	colors_MDBF = [Qt.red, Qt.green]
	lineType_MDBF = [Qt.DashLine, Qt.SolidLine]
	

	mdbfChartView = self.createLineChart(xlabels_mdbf_chart, mdbfValuesList, legends_MDBF, colors_MDBF, lineType_MDBF, chartTitle_MDBF, xLabels_MDBF, yLabels_MDBF)
	mdbfChartView.setFixedHeight(525)
	mdbfChartView.setFixedWidth(int(0.45 * QApplication.primaryScreen().availableGeometry().width()))

	mdbf_chart_image = mdbfChartView.grab().toImage()
	mdbf_charts_list.append(mdbf_chart_image)


	######################################################################################################################################


	targetAndAchievedMdbfValues_WithoutSFT = []

	for row in [7,8]:
		row_data = []
		for col in range(1, self.mdbfDashboardTable.columnCount()):
			if not self.mdbfDashboardTable.isColumnHidden(col):
				item = self.mdbfDashboardTable.item(row, col)

				if item:
					cell_value = item.text()

					try:
						if cell_value == 'No Fails':
							row_data.append(0.0)
						else:
							row_data.append(float(cell_value))
					except ValueError:
						row_data.append(0.0)
				else:
					row_data.append(0.0)

		targetAndAchievedMdbfValues_WithoutSFT.append(row_data)

	mdbfValuesList_WithoutSFT = targetAndAchievedMdbfValues_WithoutSFT
	chartTitle_MDBF_WithoutSFT = f"MDBF without Shortfall Trains(6M)"
	xLabels_MDBF_WithoutSFT = "Months"
	yLabels_MDBF_WithoutSFT = "MDBF (KM)"


	legends_MDBF_WithoutSFT = ['Target MDBF', 'Achieved MDBF']
	colors_MDBF_WithoutSFT = [Qt.red, Qt.green]
	lineType_MDBF_WithoutSFT = [Qt.DashLine, Qt.SolidLine]
	

	mdbfChartView_WithoutSFT = self.createLineChart(xlabels_mdbf_chart, mdbfValuesList_WithoutSFT, legends_MDBF_WithoutSFT, colors_MDBF_WithoutSFT, lineType_MDBF_WithoutSFT, chartTitle_MDBF_WithoutSFT, xLabels_MDBF_WithoutSFT, yLabels_MDBF_WithoutSFT)
	mdbfChartView_WithoutSFT.setFixedHeight(525)
	mdbfChartView_WithoutSFT.setFixedWidth(int(0.45 * QApplication.primaryScreen().availableGeometry().width()))

	mdbf_chart_image_WithoutSFT = mdbfChartView_WithoutSFT.grab().toImage()
	mdbf_charts_list.append(mdbf_chart_image_WithoutSFT)


	# Generate the report
	self.generate_pdf_report(selected_report_title, mdbf_data, tableNamesList, 0, mdbf_charts_list)
	self.clearAllFiltersButton_MDBFDash.click()