from PySide6.QtWidgets import (QLabel, QTableWidgetItem, QHBoxLayout, QFormLayout, QSpacerItem, QSizePolicy, QFileDialog, QMessageBox)
from PySide6.QtCore import Qt
from PySide6.QtGui import QIcon

from datetime import datetime, timedelta, date
from dateutil.relativedelta import relativedelta
import calendar

from functions import TableWidget


## Function to create a pdf report with headers and footers:
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import letter,landscape, portrait, A4
from reportlab.platypus import SimpleDocTemplate, Paragraph, Table, LongTable, PageTemplate, TableStyle, Frame, KeepInFrame, Spacer, PageBreak, BaseDocTemplate
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib import colors, pdfencrypt
from reportlab.lib.enums import TA_CENTER, TA_LEFT
from reportlab.lib.units import inch, cm

from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.graphics import shapes



def monthwiseSummaryReportUi(self, year, month):

	totalTableData = []

	totalReportTitles = []

	tableColumnWidthsList = []
	
	tableStylesList = []

	reportsPageOrientationList = []

	month_string = calendar.month_abbr[month]
	totalDaysOfSelectedMonth = calendar.monthrange(year, month)[1]
	
	############################################################################################
	## Summary of monthly reliability data:

	report_title_rm_summary = f'Summary of Reliability Data for {month_string} - {year}'


	firstColumnLabels = ['KM', 'Total Service Failures', 'Agreed Service Failure(Nos.)', 'Disputed Service Failure(Nos.)', 'Deemed Service Failure(Nos.)', 'Deemed Disputed Service Failure(Nos.)',
						'Deboarding Cases(Nos.)', 'Relevant Failure(Nos.)', 'Downtime (CM) in Hrs', 'Downtime (OPM) in Hrs', 'Downtime (SC) in Hrs']


	monthlyReliabilitySummaryTable_OutputReport = TableWidget()
	headers = ['Sr.No', 'Data Type', 'Total', 'Remarks']
	monthlyReliabilitySummaryTable_OutputReport.setColumnCount(len(headers))
	monthlyReliabilitySummaryTable_OutputReport.setHorizontalHeaderLabels(headers)
	monthlyReliabilitySummaryTable_OutputReport.setRowCount(len(firstColumnLabels))


	for i, label in enumerate(firstColumnLabels):
		serialNumberItem = QTableWidgetItem(str(i + 1))
		monthlyReliabilitySummaryTable_OutputReport.setItem(i, 0, serialNumberItem)

		firstColumnLabelItem = QTableWidgetItem(label)
		monthlyReliabilitySummaryTable_OutputReport.setItem(i, 1, firstColumnLabelItem)


	#################################################################################################

	### Calculate monthly mileage:
	last_day = calendar.monthrange(year, month)[1]
	firstDayOfCurrentMonth = date(year, month, 1)
	lastDayOfCurrentMonth = date(year, month, last_day)


	runningMileageQuery = f"""
		SELECT SUM(tm.monthly_mileage)
		FROM trainsets_mileage tm
		JOIN trainsets t ON tm.trainset_id = t.id
		WHERE
			tm.year = {year}
			AND tm.month = {month}
			AND t.stabilization < '{lastDayOfCurrentMonth}';
		"""

	self.cursor.execute(runningMileageQuery)
	mileageResult = self.cursor.fetchone()

	mileageItem = QTableWidgetItem(str(mileageResult[0]))
	monthlyReliabilitySummaryTable_OutputReport.setItem(0, 2, mileageItem)


	

	#################################################################################################
	#### Calculate the total service failures of the month:

	# Calculate the first and last day of the selected month
	failureCountQuery = f"""
		SELECT failure_type, COUNT(*) AS category_count
		FROM corrective_maintenance cm
		JOIN trainsets t ON cm.trainset_id = t.id
		WHERE
			YEAR(cm.work_start_at) = {year}
			AND MONTH(cm.work_start_at) = {month}
			AND (cm.failure_type = 'Service Failure' OR (cm.failure_type = 'Relevant Failure' AND (cm.consider_for_relevant_fails = 'Yes' OR cm.consider_for_relevant_fails IS NULL)))
			AND cm.verification = 'Yes'
			AND cm.failure_responsibility = 'BEML'
			AND t.stabilization < cm.work_start_at
		GROUP BY failure_type;
		"""

	self.cursor.execute(failureCountQuery)
	failureCountResult = self.cursor.fetchall()

	failureCountRowIndex = [1,7]

	if failureCountResult:
		for grp in failureCountResult:
			if grp[0] == 'Service Failure':
				item = QTableWidgetItem(str(grp[1]))
				monthlyReliabilitySummaryTable_OutputReport.setItem(1, 2, item)

			elif grp[0] == 'Relevant Failure':
				item = QTableWidgetItem(str(grp[1]))
				monthlyReliabilitySummaryTable_OutputReport.setItem(7, 2, item)

	else:
		monthlyReliabilitySummaryTable_OutputReport.setItem(1, 2, QTableWidgetItem('0'))
		monthlyReliabilitySummaryTable_OutputReport.setItem(7, 2, QTableWidgetItem('0'))
	

	#################################################################################################
	#### Calculate the total deboarding cases of service failures of the month:

	deboardingCountQuery = f"""
		SELECT COUNT(service_failure_effect)
		FROM corrective_maintenance cm
		JOIN trainsets t ON cm.trainset_id = t.id
		WHERE
			service_failure_effect = 'Deboarding'
			AND YEAR(cm.work_start_at) = {year}
			AND MONTH(cm.work_start_at) = {month}
			AND cm.verification = 'Yes'
			AND cm.failure_responsibility = 'BEML'
			AND t.stabilization < cm.work_start_at
	"""

	self.cursor.execute(deboardingCountQuery)
	deboardingCountResult = self.cursor.fetchone()
	
	if deboardingCountResult:
		deboardingCountItem = QTableWidgetItem(str(deboardingCountResult[0]))
		monthlyReliabilitySummaryTable_OutputReport.setItem(6, 2, deboardingCountItem)
	else:
		deboardingCountItem = QTableWidgetItem('0')
		monthlyReliabilitySummaryTable_OutputReport.setItem(6, 2, deboardingCountItem)


	#################################################################################################
	## Calculate the total downtime (CM) for the selected month in hours:

	# cmDowntimeQuery = f"""
	# 		SELECT SUM(cm.down_time)
	# 		FROM corrective_maintenance cm
	# 		JOIN trainsets t ON cm.trainset_id = t.id
	# 		WHERE
	# 			YEAR(cm.work_start_at) = {year}
	# 			AND MONTH(cm.work_start_at) = {month}
	# 			AND (cm.failure_type = 'Service Failure' OR cm.failure_type = 'Relevant Failure')
	# 			AND cm.verification = 'Yes'
	# 			AND cm.failure_responsibility = 'BEML'
	# 			AND t.stabilization < cm.work_start_at;
	# 		"""
	# self.cursor.execute(cmDowntimeQuery)
	# totalCMDowntimeInMinutes = self.cursor.fetchone()
	# if totalCMDowntimeInMinutes[0]:
	# 	totalCMDowntimeInHours = round(totalCMDowntimeInMinutes[0] / 60, 2)
	# 	cmDowntimeItem = QTableWidgetItem(str(totalCMDowntimeInHours))
	# 	monthlyReliabilitySummaryTable_OutputReport.setItem(8, 2, cmDowntimeItem)
	# else:
	# 	cmDowntimeItem = QTableWidgetItem('0')
	# 	monthlyReliabilitySummaryTable_OutputReport.setItem(8, 2, cmDowntimeItem)



	#################################################################################################
	## Calculate the total downtime (CM) for the selected month in hours:

	# opmDowntimeQuery = f"""
	# 		SELECT SUM(opm.downtime)
	# 		FROM other_preventive_maintenance opm
	# 		JOIN trainsets t ON opm.trainset_id = t.id
	# 		WHERE
	# 			YEAR(opm.work_start_at) = {year}
	# 			AND MONTH(opm.work_start_at) = {month}
	# 			AND t.stabilization < opm.work_start_at;
	# 		"""
	
	# self.cursor.execute(opmDowntimeQuery)
	# totalOPMDowntimeInMinutes = self.cursor.fetchone()



	# if totalOPMDowntimeInMinutes[0]:
	# 	# Convert downtime to hours
	# 	totalOPMDowntimeInHours = round(totalOPMDowntimeInMinutes[0] / 60, 2)
		
	# 	opmDowntimeItem = QTableWidgetItem(str(totalOPMDowntimeInHours))
	# 	monthlyReliabilitySummaryTable_OutputReport.setItem(9, 2, opmDowntimeItem)
	# else:
	# 	opmDowntimeItem = QTableWidgetItem('0')
	# 	monthlyReliabilitySummaryTable_OutputReport.setItem(9, 2, opmDowntimeItem)



	#################################################################################################
	## Calculate the total downtime (CM) for the selected month in hours:

	# last_day = calendar.monthrange(year, month)[1]
	# last_date = date(year, month, last_day)

	# sql_query = "SELECT id FROM trainsets WHERE stabilization < %s"
	# self.cursor.execute(sql_query, (last_date,))
	# trainIds_ = self.cursor.fetchall()

	# trainIds_List = []
	# for tr in trainIds_:
	# 	trainIds_List.append(tr[0])

	# trainIds_Tuple = tuple(trainIds_List)


	# scDowntimeQuery = f"""
	# 		SELECT SUM(sc.downtime)
	# 		FROM service_checks sc
	# 		JOIN trainsets t ON sc.trainset_id = t.id
	# 		WHERE
	# 			sc.year = {year}
	# 			AND sc.month = {month}
	# 			AND sc.trainset_id IN {trainIds_Tuple}
	# 		"""
	
	# self.cursor.execute(scDowntimeQuery)
	# totalSCDowntimeInHours = self.cursor.fetchone()

	# # Calculate total downtime in minutes
	# # totalSCDowntimeInHours = sum(sc_down_time[0] for sc_down_time in totalSCDowntimeInHours)

	# # Convert downtime to hours


	# if totalSCDowntimeInHours[0]:
	# 	scDowntimeItem = QTableWidgetItem(str(totalSCDowntimeInHours[0]))
	# 	monthlyReliabilitySummaryTable_OutputReport.setItem(10, 2, scDowntimeItem)
	# else:
	# 	scDowntimeItem = QTableWidgetItem('0')
	# 	monthlyReliabilitySummaryTable_OutputReport.setItem(10, 2, scDowntimeItem)



	remarksNoteText = QTableWidgetItem(str('As per MMMOCL Downtime in hours as below:\nCM-\n\nOPM-\n\nSC-\n'))
	# remarksNoteText.setTextAlignment(Qt.AlignLeft)
	# lastColumn = monthlyReliabilitySummaryTable_OutputReport.columnCount()-1
	monthlyReliabilitySummaryTable_OutputReport.setItem(8, 3, remarksNoteText)




	# for i in range(monthlyReliabilitySummaryTable_OutputReport.rowCount()):


	monthlyReliabilitySummaryTableData = []

	header_text = []
	for col in range(monthlyReliabilitySummaryTable_OutputReport.columnCount()):
		header_item = monthlyReliabilitySummaryTable_OutputReport.horizontalHeaderItem(col)
		if header_item:
			header_text.append(header_item.text())

	# Add headers to the table_data
	monthlyReliabilitySummaryTableData.append(header_text)


	# Fetch data
	for row in range(monthlyReliabilitySummaryTable_OutputReport.rowCount()):
		row_data = []
		for col in range(monthlyReliabilitySummaryTable_OutputReport.columnCount()):
			item = monthlyReliabilitySummaryTable_OutputReport.item(row, col)

			if item:
				row_data.append(item.text())
			else:
				row_data.append('')
		
		monthlyReliabilitySummaryTableData.append(row_data)


	## 1st table.
	reliabilitySummaryTableColWidths = [30, 200, 100, 200]

	reliabilitySummaryTableStyle = TableStyle([
			('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#669999')),
			('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
			('ALIGN', (0, 0), (-1, -1), 'CENTER'),
			('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
			('FONT', (0, 0), (-1, -1), 'RobotoFont', 9),
			('GRID', (0, 0), (-1, -1), 0.5, colors.black),

			('SPAN', (-1, -3), (-1, -1)), ## To merge the last column cells
			('ALIGN', (-1, 1), (-1, -1), 'LEFT'),  # Align the data cells in the last column to the left
			('WORDWRAP', (0, 0), (-1, -1)),
		])
	

	totalReportTitles.append(report_title_rm_summary)
	tableColumnWidthsList.append(reliabilitySummaryTableColWidths)
	tableStylesList.append(reliabilitySummaryTableStyle)
	totalTableData.append(monthlyReliabilitySummaryTableData)


	reportsPageOrientationList.append('portrait')


########################################################################################################################
########################################################################################################################

	## Summary of monthly trainwise running mileage data:
	trainwiseRMMonthlyReportTitle = f'Kilometer data for {month_string} - {year}'

	trainsetsIdsList = []

	firstColumnTrainsetsLabelsForRMTable = []

	secondColumnDepotLabelsForRMTable = []
	lineCounts = []

	trainsetsQueryResult = []
	for depott in self.depotsList:
		trainsetsQuery = 'SELECT id, trainset, depot FROM trainsets WHERE depot = %s AND stabilization < %s AND deleted_at IS NULL ORDER BY trainset'
		self.cursor.execute(trainsetsQuery, (depott, lastDayOfCurrentMonth))
		allTrainsOfCurrentLine = self.cursor.fetchall()
		trainsetsQueryResult += allTrainsOfCurrentLine
		lineCounts.append(len(allTrainsOfCurrentLine))

	
	for data in trainsetsQueryResult:
		trainsetsIdsList.append(data[0])
		firstColumnTrainsetsLabelsForRMTable.append(data[1])
		secondColumnDepotLabelsForRMTable.append(data[2])



	monthlyRMofEachTrainsetTable_OR = TableWidget()
	headersForRMTable = ['Sr.No', 'Trainset No', 'Depot', 'KM', 'Remarks']
	monthlyRMofEachTrainsetTable_OR.setColumnCount(len(headersForRMTable))
	monthlyRMofEachTrainsetTable_OR.setHorizontalHeaderLabels(headersForRMTable)
	monthlyRMofEachTrainsetTable_OR.setRowCount(len(firstColumnTrainsetsLabelsForRMTable))


	for i, label in enumerate(firstColumnTrainsetsLabelsForRMTable):

		serialNumberItem = QTableWidgetItem(str(i + 1))
		monthlyRMofEachTrainsetTable_OR.setItem(i, 0, serialNumberItem)

		firstColumnLabelItem = QTableWidgetItem(label)
		monthlyRMofEachTrainsetTable_OR.setItem(i, 1, firstColumnLabelItem)


	for i, label in enumerate(secondColumnDepotLabelsForRMTable):
		depotColumnLabelItem = QTableWidgetItem(label)
		monthlyRMofEachTrainsetTable_OR.setItem(i, 2, depotColumnLabelItem)

	trainwiseRMQuery = f"""
					SELECT tm.monthly_mileage, t.trainset
					FROM trainsets_mileage tm
					JOIN trainsets t ON tm.trainset_id = t.id
					WHERE
						tm.year = {year}
						AND tm.month = {month}
						AND t.stabilization < '{lastDayOfCurrentMonth}'
					"""


	self.cursor.execute(trainwiseRMQuery)
	trainwiseRMQueryResult = self.cursor.fetchall()

	for row1, trainsetName in enumerate(firstColumnTrainsetsLabelsForRMTable):

		matching_row = None
		for row in trainwiseRMQueryResult:
			if row[1] == trainsetName:
				matching_row = row
				break

		if matching_row is not None:
			runningMileageLabelItem = QTableWidgetItem(str(matching_row[0]))
			monthlyRMofEachTrainsetTable_OR.setItem(row1, 3, runningMileageLabelItem)
		else:
			runningMileageLabelItem = QTableWidgetItem('0')
			monthlyRMofEachTrainsetTable_OR.setItem(row1, 3, runningMileageLabelItem)


	trainsetsRunningMileageTableData = []

	header_text = []
	for col in range(monthlyRMofEachTrainsetTable_OR.columnCount()):
		header_item = monthlyRMofEachTrainsetTable_OR.horizontalHeaderItem(col)
		if header_item:
			header_text.append(header_item.text())

	# Add headers to the table_data
	trainsetsRunningMileageTableData.append(header_text)


	# Fetch data
	for row in range(monthlyRMofEachTrainsetTable_OR.rowCount()):
		row_data = []
		for col in range(monthlyRMofEachTrainsetTable_OR.columnCount()):
			item = monthlyRMofEachTrainsetTable_OR.item(row, col)

			if item:
				row_data.append(item.text())
			else:
				row_data.append('')
		
		trainsetsRunningMileageTableData.append(row_data)



	# # Calculate the total counts of the relevant failures:
	totalRM_RMD = 0

	for row in range(monthlyRMofEachTrainsetTable_OR.rowCount()):
		if monthlyRMofEachTrainsetTable_OR.item(row, 3):
	 		totalRM_RMD += int(monthlyRMofEachTrainsetTable_OR.item(row, 3).text())


	summary_RMD = ['Total Kilometer', '', '', str(totalRM_RMD), '']

	trainsetsRunningMileageTableData.append(summary_RMD)



	## 2nd table Style
	monthlyKilometerSummaryTableColWidths = [30, 100, 80, 100, 200]
	
	monthlyKilometerSummaryTableStyleList = [
			('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#669999')),
			('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
			('ALIGN', (0, 0), (-1, -1), 'CENTER'),
			('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
			('FONT', (0, 0), (-1, -1), 'RobotoFont', 9),
			('GRID', (0, 0), (-1, -1), 0.5, colors.black),
			# Merge cells for the summary row
			('SPAN', (0, -1), (2, -1)),  # Merge the first 3 cells in the last row
			('FONT', (0, -1), (-1, -1), 'Roboto-Bold', 12), # Bold style for the last row

			('WORDWRAP', (0, 0), (-1, -1))
		]

	# for index, line in enumerate(self.depotsList):
	# 	additionalStyle = ('SPAN', (2, sum(lineCounts[:index])+1), (2, sum(lineCounts[:index+1])))
	
	# 	monthlyKilometerSummaryTableStyleList.append(additionalStyle)

	monthlyKilometerSummaryTableStyle = TableStyle(monthlyKilometerSummaryTableStyleList)

	
	totalReportTitles.append(trainwiseRMMonthlyReportTitle)
	tableColumnWidthsList.append(monthlyKilometerSummaryTableColWidths)
	tableStylesList.append(monthlyKilometerSummaryTableStyle)
	totalTableData.append(trainsetsRunningMileageTableData)

	reportsPageOrientationList.append('landscape')

	


	########################################################################################################################
	# ########################################################################################################################

	## Summary of monthly trainwise service failure  data:

	trainwiseSFMonthlyReportTitle = f'Service Failure data for {month_string} - {year}'


	monthlyServiceFailureCountOfEachTrainsetTable_OR = TableWidget()
	headersForSFTable = ['Sr.No', 'Trainset No', 'Depot', 'No. of Failure', 'Remarks']
	monthlyServiceFailureCountOfEachTrainsetTable_OR.setColumnCount(len(headersForSFTable))
	monthlyServiceFailureCountOfEachTrainsetTable_OR.setHorizontalHeaderLabels(headersForSFTable)
	monthlyServiceFailureCountOfEachTrainsetTable_OR.setRowCount(len(firstColumnTrainsetsLabelsForRMTable))

	failureQuery = f"""
			SELECT COUNT(*) AS failure_count, t.trainset
			FROM corrective_maintenance cm
			JOIN trainsets t ON cm.trainset_id = t.id
			WHERE
				YEAR(cm.work_start_at) = {year}
				AND MONTH(cm.work_start_at) = {month}
				AND cm.failure_type = 'Service Failure'
				AND cm.verification = 'Yes'
				AND cm.failure_responsibility = 'BEML'
				AND t.stabilization < cm.work_start_at
			GROUP BY t.trainset;
		"""

	self.cursor.execute(failureQuery)
	failureQueryResult = self.cursor.fetchall()
	

	for i, trainsetLabel in enumerate(firstColumnTrainsetsLabelsForRMTable):

		serialNumberItem = QTableWidgetItem(str(i + 1))
		monthlyServiceFailureCountOfEachTrainsetTable_OR.setItem(i, 0, serialNumberItem)

		firstColumnLabelItem = QTableWidgetItem(trainsetLabel)
		monthlyServiceFailureCountOfEachTrainsetTable_OR.setItem(i, 1, firstColumnLabelItem)


		# Find the corresponding failure count, if any
		# matching_row = next((row for row in failureQueryResult if row[2] == trainsetLabel), None)
		


	for i, depotLabel in enumerate(secondColumnDepotLabelsForRMTable):
		depotColumnLabelItem = QTableWidgetItem(depotLabel)
		monthlyServiceFailureCountOfEachTrainsetTable_OR.setItem(i, 2, depotColumnLabelItem)

	for i, trainsetLabel in enumerate(firstColumnTrainsetsLabelsForRMTable):
		matching_row = None
		for row in failureQueryResult:
			if row[1] == trainsetLabel:
				matching_row = row
				break


		if matching_row is not None:
			# Set the failure count in the third column
			serviceFailureLabelItem = QTableWidgetItem(str(matching_row[0]))
			monthlyServiceFailureCountOfEachTrainsetTable_OR.setItem(i, 3, serviceFailureLabelItem)
		else:
			# Set 0 if there is no matching row
			serviceFailureLabelItem = QTableWidgetItem('0')
			monthlyServiceFailureCountOfEachTrainsetTable_OR.setItem(i, 3, serviceFailureLabelItem)



	trainsetsServiceFailureTableData = []

	header_text = []
	for col in range(monthlyServiceFailureCountOfEachTrainsetTable_OR.columnCount()):
		header_item = monthlyServiceFailureCountOfEachTrainsetTable_OR.horizontalHeaderItem(col)
		if header_item:
			header_text.append(header_item.text())

	# Add headers to the table_data
	trainsetsServiceFailureTableData.append(header_text)


	# Fetch data
	for row in range(monthlyServiceFailureCountOfEachTrainsetTable_OR.rowCount()):
		row_data = []
		for col in range(monthlyServiceFailureCountOfEachTrainsetTable_OR.columnCount()):
			item = monthlyServiceFailureCountOfEachTrainsetTable_OR.item(row, col)

			if item:
				row_data.append(item.text())
			else:
				row_data.append('')
		
		trainsetsServiceFailureTableData.append(row_data)




	# # Calculate the total counts of the service failures:
	totalSF_SFD = 0

	for row in range(monthlyServiceFailureCountOfEachTrainsetTable_OR.rowCount()):
		if monthlyServiceFailureCountOfEachTrainsetTable_OR.item(row, 3):
			totalSF_SFD += int(monthlyServiceFailureCountOfEachTrainsetTable_OR.item(row, 3).text())


	summary_SFD = ['Total Service Failure', '', '', str(totalSF_SFD), '']

	trainsetsServiceFailureTableData.append(summary_SFD)


	# 3rd Table style
	monthlyServiceFailureSummaryTableColWidths = [30, 100, 80, 100, 200]
	
	monthlyServiceFailureSummaryTableStyleList = [
			('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#669999')),
			('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
			('ALIGN', (0, 0), (-1, -1), 'CENTER'),
			('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
			('FONT', (0, 0), (-1, -1), 'RobotoFont', 9),
			('GRID', (0, 0), (-1, -1), 0.5, colors.black),

			# Merge cells for the summary row
			('SPAN', (0, -1), (2, -1)),  # Merge the first 3 cells in the last row
			('FONT', (0, -1), (-1, -1), 'Roboto-Bold', 12), # Bold style for the last row

			('WORDWRAP', (0, 0), (-1, -1))
		]

	# for index, line in enumerate(self.depotsList):
	# 	additionalStyle = ('SPAN', (2, sum(lineCounts[:index])+1), (2, sum(lineCounts[:index+1])))
	
	# 	monthlyServiceFailureSummaryTableStyleList.append(additionalStyle)

	monthlyServiceFailureSummaryTableStyle = TableStyle(monthlyServiceFailureSummaryTableStyleList)

	

	totalReportTitles.append(trainwiseSFMonthlyReportTitle)
	tableColumnWidthsList.append(monthlyServiceFailureSummaryTableColWidths)
	tableStylesList.append(monthlyServiceFailureSummaryTableStyle)
	totalTableData.append(trainsetsServiceFailureTableData)

	reportsPageOrientationList.append('portrait')


	####################################################################################################
	########################################################################################################################

	## Summary of monthly trainwise relevant failure data:

	trainwiseRFMonthlyReportTitle = f'Relevant Failures data for {month_string} - {year}'


	monthlyRelevantFailureCountOfEachTrainsetTable_OR = TableWidget()
	headersForRFTable = ['Sr.No', 'Trainset No', 'Depot', 'Service Failure', 'ML(RF)', 'DEPOT(RF)', 'Total Failures']
	monthlyRelevantFailureCountOfEachTrainsetTable_OR.setColumnCount(len(headersForRFTable))
	monthlyRelevantFailureCountOfEachTrainsetTable_OR.setHorizontalHeaderLabels(headersForRFTable)
	monthlyRelevantFailureCountOfEachTrainsetTable_OR.setRowCount(len(firstColumnTrainsetsLabelsForRMTable))


	relevantFailureQuery = f"""
			SELECT ml_depot, COUNT(*) AS ml_depot_count, t.trainset
			FROM corrective_maintenance cm
			JOIN trainsets t ON cm.trainset_id = t.id
			WHERE
				YEAR(cm.work_start_at) = {year}
				AND MONTH(cm.work_start_at) = {month}
				AND cm.failure_type = 'Relevant Failure'
				AND cm.consider_for_relevant_fails = 'Yes'
				AND (cm.ml_depot = 'Depot' OR cm.ml_depot = 'M/L')
				AND cm.verification = 'Yes'
				AND cm.failure_responsibility = 'BEML'
				AND t.stabilization < cm.work_start_at
			GROUP BY ml_depot , t.trainset;
		"""

	self.cursor.execute(relevantFailureQuery)
	relevantFailureQueryResult = self.cursor.fetchall()


	for i, trainsetLabel in enumerate(firstColumnTrainsetsLabelsForRMTable):

		serialNumberItem = QTableWidgetItem(str(i + 1))
		monthlyRelevantFailureCountOfEachTrainsetTable_OR.setItem(i, 0, serialNumberItem)

		firstColumnLabelItem = QTableWidgetItem(trainsetLabel)
		monthlyRelevantFailureCountOfEachTrainsetTable_OR.setItem(i, 1, firstColumnLabelItem)


		sublist = [item for item in relevantFailureQueryResult if item[2] == trainsetLabel]

		if sublist:
			if len(sublist) == 2:
				for lis in sublist:
					if lis[0] == 'M/L':
						mainLineRFCountItem = QTableWidgetItem(str(lis[1]))
						monthlyRelevantFailureCountOfEachTrainsetTable_OR.setItem(i, 4, mainLineRFCountItem)
					elif lis[0] == 'Depot':
						depotRFCountItem = QTableWidgetItem(str(lis[1]))
						monthlyRelevantFailureCountOfEachTrainsetTable_OR.setItem(i, 5, depotRFCountItem)
			if len(sublist) == 1:
				if sublist[0][0] == 'M/L':
					mainLineRFCountItem = QTableWidgetItem(str(sublist[0][1]))
					monthlyRelevantFailureCountOfEachTrainsetTable_OR.setItem(i, 4, mainLineRFCountItem)

					depotZeroRFItem = QTableWidgetItem('0')
					monthlyRelevantFailureCountOfEachTrainsetTable_OR.setItem(i, 5, depotZeroRFItem)

				elif sublist[0][0] == 'Depot':
					depotRFCountItem = QTableWidgetItem(str(sublist[0][1]))
					monthlyRelevantFailureCountOfEachTrainsetTable_OR.setItem(i, 5, depotRFCountItem)

					mainLineZeroRFItem = QTableWidgetItem('0')
					monthlyRelevantFailureCountOfEachTrainsetTable_OR.setItem(i, 4, mainLineZeroRFItem)

		else:
			mainLineZeroRFItem = QTableWidgetItem('0')
			monthlyRelevantFailureCountOfEachTrainsetTable_OR.setItem(i, 4, mainLineZeroRFItem)

			depotZeroRFItem = QTableWidgetItem('0')
			monthlyRelevantFailureCountOfEachTrainsetTable_OR.setItem(i, 5, depotZeroRFItem)

		matching_row_rf2 = None
		for row in failureQueryResult:
			if row[1] == trainsetLabel:
				matching_row_rf2 = row
				break


		if matching_row_rf2 is not None:
			serviceFailureLabelItem1 = QTableWidgetItem(str(matching_row_rf2[0]))
			monthlyRelevantFailureCountOfEachTrainsetTable_OR.setItem(i, 3, serviceFailureLabelItem1)
		else:
			serviceFailureLabelItem1 = QTableWidgetItem('0')
			monthlyRelevantFailureCountOfEachTrainsetTable_OR.setItem(i, 3, serviceFailureLabelItem1)


	for i, depotLabel in enumerate(secondColumnDepotLabelsForRMTable):
		depotColumnLabelItem = QTableWidgetItem(depotLabel)
		monthlyRelevantFailureCountOfEachTrainsetTable_OR.setItem(i, 2, depotColumnLabelItem)

		

	# To get the total count of relevant failures:
	for i in range(monthlyRelevantFailureCountOfEachTrainsetTable_OR.rowCount()):
		if monthlyRelevantFailureCountOfEachTrainsetTable_OR.item(i, 3):
			sfCount = int(monthlyRelevantFailureCountOfEachTrainsetTable_OR.item(i, 3).text())
		else:
			sfCount = 0

		if monthlyRelevantFailureCountOfEachTrainsetTable_OR.item(i, 4):
			mainLineCount = int(monthlyRelevantFailureCountOfEachTrainsetTable_OR.item(i, 4).text())
		else:
			mainLineCount = 0

		if monthlyRelevantFailureCountOfEachTrainsetTable_OR.item(i, 5):
			depotCount = int(monthlyRelevantFailureCountOfEachTrainsetTable_OR.item(i, 5).text())

		totalCount = sfCount + mainLineCount + depotCount

		totalRelevantFailureCountItem = QTableWidgetItem(str(totalCount))
		monthlyRelevantFailureCountOfEachTrainsetTable_OR.setItem(i, 6, totalRelevantFailureCountItem)



	trainsetsRelevantFailureTableData = []

	header_text = []
	for col in range(monthlyRelevantFailureCountOfEachTrainsetTable_OR.columnCount()):
		header_item = monthlyRelevantFailureCountOfEachTrainsetTable_OR.horizontalHeaderItem(col)
		if header_item:
			header_text.append(header_item.text())

	# Add headers to the table_data
	trainsetsRelevantFailureTableData.append(header_text)


	# Fetch data
	for row in range(monthlyRelevantFailureCountOfEachTrainsetTable_OR.rowCount()):
		row_data = []
		for col in range(monthlyRelevantFailureCountOfEachTrainsetTable_OR.columnCount()):
			item = monthlyRelevantFailureCountOfEachTrainsetTable_OR.item(row, col)

			if item:
				row_data.append(item.text())
			else:
				row_data.append('')
		
		trainsetsRelevantFailureTableData.append(row_data)


	# Calculate the total counts of the relevant failures:
	totalSF_RFD = 0
	totalML_RFD = 0
	totalDepot_RFD = 0
	totalRF_RFD = 0


	for row in range(monthlyRelevantFailureCountOfEachTrainsetTable_OR.rowCount()):
		if monthlyRelevantFailureCountOfEachTrainsetTable_OR.item(row, 3):
			totalSF_RFD += int(monthlyRelevantFailureCountOfEachTrainsetTable_OR.item(row, 3).text())
		if monthlyRelevantFailureCountOfEachTrainsetTable_OR.item(row, 4):
			totalML_RFD += int(monthlyRelevantFailureCountOfEachTrainsetTable_OR.item(row, 4).text())
		if monthlyRelevantFailureCountOfEachTrainsetTable_OR.item(row, 5):
			totalDepot_RFD += int(monthlyRelevantFailureCountOfEachTrainsetTable_OR.item(row, 5).text())
		if monthlyRelevantFailureCountOfEachTrainsetTable_OR.item(row, 6):
			totalRF_RFD += int(monthlyRelevantFailureCountOfEachTrainsetTable_OR.item(row, 6).text())



	summary_RFD = ['Grand Total', '', '', str(totalSF_RFD), str(totalML_RFD), str(totalDepot_RFD), str(totalRF_RFD)]

	trainsetsRelevantFailureTableData.append(summary_RFD)



	
	## Column width for Relevant Service failure summary report (4th table):
	monthlyRelevantFailuresTableColumnWidths = [30, 70, 60, 80, 80, 80, 100]
	
	monthlyRelevantFailureSummaryTableStyleList = [
			('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#669999')),
			('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
			('TEXTOUTLINE', (0, 0), (-1, 0), 1, colors.black),
			('ALIGN', (0, 0), (-1, -1), 'CENTER'),
			('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
			('FONT', (0, 0), (-1, -1), 'RobotoFont', 9),
			('GRID', (0, 0), (-1, -1), 0.5, colors.black),

			# Merge cells for the summary row
			('SPAN', (0, -1), (2, -1)),  # Merge the first 3 cells in the last row
			('FONT', (0, -1), (-1, -1), 'Roboto-Bold', 12), # Bold style for the last row

			('WORDWRAP', (0, 0), (-1, -1))
		]


	# for index, line in enumerate(self.depotsList):
	# 	additionalStyle = ('SPAN', (2, sum(lineCounts[:index])+1), (2, sum(lineCounts[:index+1])))
	
	# 	monthlyRelevantFailureSummaryTableStyleList.append(additionalStyle)

	monthlyRelevantFailureSummaryTableStyle = TableStyle(monthlyRelevantFailureSummaryTableStyleList)


	totalReportTitles.append(trainwiseRFMonthlyReportTitle)
	tableColumnWidthsList.append(monthlyRelevantFailuresTableColumnWidths)
	tableStylesList.append(monthlyRelevantFailureSummaryTableStyle)
	totalTableData.append(trainsetsRelevantFailureTableData)


	reportsPageOrientationList.append('portrait')









	##############################################################################################################################################
	##############################################################################################################################################
	## Summary of monthly trainwise relevant failure data:

	systemAndSubsytemRFDataReportTitle = f'Relevant Failures for {month_string} - {year}'

	equipmentSqlQuery = 'SELECT id, parent_id, equipment FROM bom'
	self.cursor.execute(equipmentSqlQuery)
	bomEquipmentsResult = self.cursor.fetchall()

	monthlyRelevantFailureCountOfSystemAndSubsystemTable_OR = TableWidget()
	headersForRFSSTable = ['Sr.No', 'System', 'Sub System', 'No of Failures', 'Total\nRelevant Failures']
	monthlyRelevantFailureCountOfSystemAndSubsystemTable_OR.setColumnCount(len(headersForRFSSTable))
	monthlyRelevantFailureCountOfSystemAndSubsystemTable_OR.setHorizontalHeaderLabels(headersForRFSSTable)
	# monthlyRelevantFailureCountOfSystemAndSubsystemTable_OR.setRowCount(len(bomEquipmentsResult))



	monthlyRelevantFailureCountOfSystemAndSubsystemList = []

	for i, equipmentDetails in enumerate(bomEquipmentsResult):

		row_index = len(monthlyRelevantFailureCountOfSystemAndSubsystemList)
		query1 = f'''
					SELECT COUNT(*)
					FROM corrective_maintenance cm
					JOIN trainsets t ON cm.trainset_id = t.id
					WHERE
						(cm.failure_type = 'Relevant Failure')
						AND YEAR(cm.work_start_at) = {year}
						AND MONTH(cm.work_start_at) = {month}
						AND cm.verification = 'Yes'
						AND (cm.consider_for_relevant_fails = 'Yes' OR cm.consider_for_relevant_fails IS NULL)
						AND cm.failure_responsibility = 'BEML'
						AND t.stabilization < cm.work_start_at
						AND (cm.system_id = {equipmentDetails[0]} OR cm.subsystem_id = {equipmentDetails[0]})
					'''

		self.cursor.execute(query1)
		noOfFails = self.cursor.fetchone()[0]

		
		if equipmentDetails[1] == 0:
			# This is a system
			monthlyRelevantFailureCountOfSystemAndSubsystemList.append(['', equipmentDetails[2], '', '', str(noOfFails)])
		else:
			# This is a subsystem
			monthlyRelevantFailureCountOfSystemAndSubsystemList.append(['', '', equipmentDetails[2], str(noOfFails), ''])

			if equipmentDetails[2] == 'Others':

				# Query to fetch other subsystems and their counts if applicable
				query2 = f"""
							SELECT cm.other_subsystem, COUNT(*)
							FROM corrective_maintenance cm
							JOIN trainsets t ON cm.trainset_id = t.id
							WHERE cm.failure_type = 'Relevant Failure'
							AND YEAR(cm.work_start_at) = {year}
							AND MONTH(cm.work_start_at) = {month}
							AND cm.verification = 'Yes'
							AND (cm.consider_for_relevant_fails = 'Yes' OR cm.consider_for_relevant_fails IS NULL)
							AND cm.failure_responsibility = 'BEML'
							AND t.stabilization < cm.work_start_at
							AND (cm.system_id = {equipmentDetails[0]} OR cm.subsystem_id = {equipmentDetails[0]})
							AND cm.other_subsystem IS NOT NULL
							GROUP BY cm.other_subsystem
						"""

				self.cursor.execute(query2)
				other_subsystems = self.cursor.fetchall()
				

				for idx, other_subsystem in enumerate(other_subsystems):
					other_row = ['', '', f'Others-{other_subsystem[0]}', str(other_subsystem[1]), '']

					monthlyRelevantFailureCountOfSystemAndSubsystemList.append(other_row)

				
	monthlyRelevantFailureCountOfSystemAndSubsystemTable_OR.setRowCount(len(monthlyRelevantFailureCountOfSystemAndSubsystemList))
	for k, relevantValue in enumerate(monthlyRelevantFailureCountOfSystemAndSubsystemList):

		monthlyRelevantFailureCountOfSystemAndSubsystemTable_OR.setItem(k, 0, QTableWidgetItem(str(k+1)))
		monthlyRelevantFailureCountOfSystemAndSubsystemTable_OR.setItem(k, 1, QTableWidgetItem(relevantValue[1]))
		monthlyRelevantFailureCountOfSystemAndSubsystemTable_OR.setItem(k, 2, QTableWidgetItem(relevantValue[2]))
		monthlyRelevantFailureCountOfSystemAndSubsystemTable_OR.setItem(k, 3, QTableWidgetItem(relevantValue[3]))
		monthlyRelevantFailureCountOfSystemAndSubsystemTable_OR.setItem(k, 4, QTableWidgetItem(relevantValue[4]))






	systemAndSubsystemRelevantFailureTableData = []

	header_text = []
	for col in range(monthlyRelevantFailureCountOfSystemAndSubsystemTable_OR.columnCount()):
		header_item = monthlyRelevantFailureCountOfSystemAndSubsystemTable_OR.horizontalHeaderItem(col)
		if header_item:
			header_text.append(header_item.text())

	# Add headers to the table_data
	systemAndSubsystemRelevantFailureTableData.append(header_text)


	# Fetch data
	for row in range(monthlyRelevantFailureCountOfSystemAndSubsystemTable_OR.rowCount()):
		row_data = []
		for col in range(monthlyRelevantFailureCountOfSystemAndSubsystemTable_OR.columnCount()):
			item = monthlyRelevantFailureCountOfSystemAndSubsystemTable_OR.item(row, col)

			if item:
				row_data.append(item.text())
			else:
				row_data.append('')
		
		systemAndSubsystemRelevantFailureTableData.append(row_data)




	# Calculate the total counts of the relevant failures all equipments:
	totalRF_ERFD = 0


	for row in range(monthlyRelevantFailureCountOfSystemAndSubsystemTable_OR.rowCount()):
		columnIndex = monthlyRelevantFailureCountOfSystemAndSubsystemTable_OR.columnCount()-1

		# Check if the item is not None before accessing its text attribute
		item = monthlyRelevantFailureCountOfSystemAndSubsystemTable_OR.item(row, columnIndex)
		if item is not None:
			if item.text() != '':
				totalRF_ERFD += int(item.text())

		# if item and item.text().isdigit():
		# 	totalRF_ERFD += int(item.text())
		# else:
		# 	continue



	summary_ERFD = ['Grand Total', '', '', '', str(totalRF_ERFD)]

	systemAndSubsystemRelevantFailureTableData.append(summary_ERFD)





	## 5th table.
	equipmentsRelevantFailuresTableColumnWidths = [30, 180, 180, 70, 80]

	
	equipmentsRelevantFailuresTableStyle = TableStyle([
			('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#669999')),
			('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
			('ALIGN', (0, 0), (-1, -1), 'CENTER'),
			('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
			('FONT', (0, 0), (-1, -1), 'RobotoFont', 9),
			('GRID', (0, 0), (-1, -1), 0.5, colors.black),

			# Merge cells for the summary row
			('SPAN', (0, -1), (3, -1)),  # Merge the first 3 cells in the last row
			('FONT', (0, -1), (-1, -1), 'Roboto-Bold', 12), # Bold style for the last row

			('WORDWRAP', (0, 0), (-1, -1))
		])


	totalReportTitles.append(systemAndSubsytemRFDataReportTitle)
	tableColumnWidthsList.append(equipmentsRelevantFailuresTableColumnWidths)
	tableStylesList.append(equipmentsRelevantFailuresTableStyle)
	totalTableData.append(systemAndSubsystemRelevantFailureTableData)


	reportsPageOrientationList.append('landscape')


#######################################################################################################################################
#######################################################################################################################################
		
	replacedDataReportTitle = f'Replaced Components Details for {month_string} - {year}'

	query = f'''SELECT bo.parent_id, cm.replaced_component, t.trainset, cm.work_start_at, boo.equipment, cm.other_subsystem
				FROM corrective_maintenance cm
				JOIN bom bo ON cm.subsystem_id = bo.id
				JOIN bom boo ON cm.system_id = boo.id
				JOIN trainsets t ON cm.trainset_id = t.id
				WHERE
					YEAR(cm.work_start_at) = {year}
					AND MONTH(cm.work_start_at) = {month}
					AND component_replaced = 'Yes'
					AND cm.verification = 'Yes'
					AND cm.failure_responsibility = 'BEML'
					AND t.stabilization < cm.work_start_at
					'''
	self.cursor.execute(query)
	res = self.cursor.fetchall()

	relaventSysSubsysTabel_OR = TableWidget()
	headersForRFSS_OR = ['Sl.No', 'System ', 'Component', 'Other\nSub Sytem', 'Quantity', 'Train', 'Date']
	relaventSysSubsysTabel_OR.setColumnCount(len(headersForRFSS_OR))
	relaventSysSubsysTabel_OR.setHorizontalHeaderLabels(headersForRFSS_OR)
	relaventSysSubsysTabel_OR.setRowCount(len(res))



	for i, equipmentDetails in enumerate(res):

		serialNumberItem = QTableWidgetItem(str(i + 1))
		relaventSysSubsysTabel_OR.setItem(i, 0, serialNumberItem)

		if equipmentDetails[0] == 0:
			systemNameItem = QTableWidgetItem(str(equipmentDetails[1]))
			relaventSysSubsysTabel_OR.setItem(i, 1, systemNameItem)

		else:
			subSystemNameItem = QTableWidgetItem(str(equipmentDetails[1]))
			relaventSysSubsysTabel_OR.setItem(i, 2, subSystemNameItem)

		if equipmentDetails[5]:
			otherSubSystemItem = QTableWidgetItem(str(equipmentDetails[5]))
			relaventSysSubsysTabel_OR.setItem(i, 3, otherSubSystemItem)

		item = QTableWidgetItem(str(equipmentDetails[2]))
		relaventSysSubsysTabel_OR.setItem(i, 5, item)

		item = QTableWidgetItem(str(equipmentDetails[4]))
		relaventSysSubsysTabel_OR.setItem(i, 1, item)

		item = QTableWidgetItem(str(equipmentDetails[3].date()))
		relaventSysSubsysTabel_OR.setItem(i, 6, item)

		sysCount = 0
		for item in res:
			if (item[1] == equipmentDetails[1]) and (item[2] == equipmentDetails[2]) and (item[3] == equipmentDetails[3]) and (item[4] == equipmentDetails[4]):
				sysCount += 1

		relaventSysSubsysTabel_OR.setItem(i, 4, QTableWidgetItem(str(sysCount)))




	# unique_rows = {}

	# rows_to_delete = []

	# for row in range(relaventSysSubsysTabel_OR.rowCount()):
	# 	col2_value = relaventSysSubsysTabel_OR.item(row, 1).text()
	# 	col3_value = relaventSysSubsysTabel_OR.item(row, 2).text()
	# 	col4_value = relaventSysSubsysTabel_OR.item(row, 3).text()
	# 	col5_value = relaventSysSubsysTabel_OR.item(row, 4).text()
	# 	col6_value = relaventSysSubsysTabel_OR.item(row, 5).text()

	# 	row_key = (col2_value, col3_value, col4_value, col5_value, col6_value)

	# 	if row_key in unique_rows:
	# 		# Duplicate row found
	# 		rows_to_delete.append(row)
	# 	else:
	# 		unique_rows[row_key] = row

	# for row in reversed(rows_to_delete):
	# 	relaventSysSubsysTabel_OR.removeRow(row)


	# secondColumnSpans = {}

	# # Iterate through the second column to find start and end row indices for each unique value
	# for row in range(relaventSysSubsysTabel_OR.rowCount()):
	# 	value = relaventSysSubsysTabel_OR.item(row, 1).text()
	# 	if value not in secondColumnSpans:
	# 		secondColumnSpans[value] = [row, row]
	# 	else:
	# 		secondColumnSpans[value][1] = row


	# # val = 1
	# # for key, value in secondColumnSpans.items():
	# # 	for i in range(value[0], value[1]+1):
	# # 		relaventSysSubsysTabel_OR.setItem(i, 0, QTableWidgetItem(str(val)))
	# # 	val += 1


	# thirdColumnSpans = {}
	# for row in range(relaventSysSubsysTabel_OR.rowCount()):
	# 	value = relaventSysSubsysTabel_OR.item(row, 2).text()
	# 	if value not in thirdColumnSpans:
	# 		thirdColumnSpans[value] = [row, row]
	# 	else:
	# 		thirdColumnSpans[value][1] = row


	# fourthColumnSpans = {}

	# threeColsList = []
	# for row in range(relaventSysSubsysTabel_OR.rowCount()):
	# 	threeColsList.append((relaventSysSubsysTabel_OR.item(row, 2).text(), relaventSysSubsysTabel_OR.item(row, 4).text(), relaventSysSubsysTabel_OR.item(row, 5).text()))
		

	# for row, tup in enumerate(threeColsList):
	# 	if tup not in fourthColumnSpans:
	# 		fourthColumnSpans[tup] = [row, row]
	# 	else:
	# 		fourthColumnSpans[tup][1] = row









	replacedTabledata = []

	header_text = []
	for col in range(relaventSysSubsysTabel_OR.columnCount()):
		header_item = relaventSysSubsysTabel_OR.horizontalHeaderItem(col)
		if header_item:
			header_text.append(header_item.text())

	# Add headers to the table_data
	replacedTabledata.append(header_text)


	# Fetch data
	for row in range(relaventSysSubsysTabel_OR.rowCount()):
		row_data = []
		for col in range(relaventSysSubsysTabel_OR.columnCount()):
			item = relaventSysSubsysTabel_OR.item(row, col)

			if item:
				row_data.append(item.text())
			else:
				row_data.append('')
		
		replacedTabledata.append(row_data)




	## 6th table style
	# replacedTableColumnWidths = [30, 170, 170, 50, 50, 60]
	replacedTableColumnWidths = [25, 160, 140, 120, 35, 35, 50]
	
	replacedTableStyleList = [
			('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#669999')),
			('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
			('ALIGN', (0, 0), (-1, -1), 'CENTER'),
			('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
			('FONT', (0, 0), (-1, -1), 'RobotoFont', 8),
			('GRID', (0, 0), (-1, -1), 0.5, colors.black),

			('WORDWRAP', (0, 0), (-1, -1))
		]


	# for key, value in secondColumnSpans.items():
	# 	replacedTableStyleList.append(('SPAN', (0, value[0]+1), (0, value[1]+1)))

	# for key, value in secondColumnSpans.items():
	# 	replacedTableStyleList.append(('SPAN', (1, value[0]+1), (1, value[1]+1)))

	# for key, value in thirdColumnSpans.items():
	# 	replacedTableStyleList.append(('SPAN', (2, value[0]+1), (2, value[1]+1)))

	# for key, value in fourthColumnSpans.items():
	# 	replacedTableStyleList.append(('SPAN', (3, value[0]+1), (3, value[1]+1)))
	# 	replacedTableStyleList.append(('SPAN', (4, value[0]+1), (4, value[1]+1)))
	# 	replacedTableStyleList.append(('SPAN', (5, value[0]+1), (5, value[1]+1)))


	replacedTableStyle = TableStyle(replacedTableStyleList)

	totalReportTitles.append(replacedDataReportTitle)
	tableColumnWidthsList.append(replacedTableColumnWidths)
	tableStylesList.append(replacedTableStyle)
	totalTableData.append(replacedTabledata)



	#################################################################################################################################################################
	#################################################################################################################################################################
	downtimeDataReportTitle = f'Downtime data for {month_string} - {year}'
	


	monthlyDowntimeDataTable_OR = TableWidget()
	# headersForDTTable = ['Sr.No', 'Trainset\nNo.', 'Depot', 'CM', 'OPM', 'SC', 'Total Down\nTime(Hrs)', 'R', 
	# 						'CM', 'Cyclic\nCheck', 'Fleet\nCheck', 'HECP', 'SECP','Testing', 'Others',
	# 						'A', 'B1', 'B4', 'B8', 'Total\n(T)', f'Avaialbility\n(1-(T/{totalDaysOfSelectedMonth}*24)))*100', 'T1']

	headersForDTTable = ['Sr.No', 'Trainset\nNo.', 'Depot', 'CM', 'OPM', 'SC', 'Total Down\nTime(Hrs)', 
							'CM', 'Cyclic\nCheck', 'Fleet\nCheck', 'HECP', 'SECP','Testing', 'Others',
							'A', 'B1', 'B4', 'B8', 'Total\n(T)','T1', f'Availability\n(1-(T1/{totalDaysOfSelectedMonth}*24)))*100']
	monthlyDowntimeDataTable_OR.setColumnCount(len(headersForDTTable))
	monthlyDowntimeDataTable_OR.setHorizontalHeaderLabels(headersForDTTable)
	monthlyDowntimeDataTable_OR.setRowCount(len(firstColumnTrainsetsLabelsForRMTable))


	def find_totalDuration(datetime_pairs):
		totalDuration = timedelta()

		# Sort datetime pairs by start datetime
		if datetime_pairs:
			sorted_datetime_pairs = sorted(datetime_pairs, key=lambda x: x[0])
			# #print(sorted_datetime_pairs)
			# Initialize variables to keep track of the current start and end datetime
			current_start = sorted_datetime_pairs[0][0]
			current_end = sorted_datetime_pairs[0][1]

			# Iterate through the sorted datetime pairs
			for start, end in sorted_datetime_pairs[1:]:
				# Check for overlap
				if start < current_end:
					# Update the current end datetime if there is an overlap
					current_end = max(current_end, end)
				else:
					# Add the overlapping duration to the total
					totalDuration += current_end - current_start

					# Update the current start and end datetimes
					current_start = start
					current_end = end

			# Add the final overlapping duration (if any)
			totalDuration += current_end - current_start

			return totalDuration




	def calculateDowntimeForMonth(trainId, yearMonthValues):
		year, month = yearMonthValues

		query1 = f"""
				SELECT cm.work_start_at, cm.work_end_at
				FROM corrective_maintenance cm
				JOIN trainsets t ON cm.trainset_id = t.id
				WHERE
					cm.trainset_id = {trainId}
					AND YEAR(cm.work_start_at) = {year}
					AND MONTH(cm.work_start_at) = {month}
					AND (cm.failure_type = 'Service Failure' OR cm.failure_type = 'Relevant Failure')
					AND cm.verification = 'Yes'
					AND cm.failure_responsibility = 'BEML'
					AND t.stabilization < cm.work_start_at;
				"""
		self.cursor.execute(query1)
		result1 = self.cursor.fetchall()
		# print(f'CM data for  trainId {trainId} for month {month} and year {year}', result1)


		query2 = f"""
			SELECT opm.work_start_at, opm.work_end_at
			FROM other_preventive_maintenance opm
			JOIN trainsets t ON opm.trainset_id = t.id
			WHERE
				opm.trainset_id = {trainId}
				AND YEAR(opm.work_start_at) = {year}
				AND MONTH(opm.work_start_at) = {month}
				AND t.stabilization < opm.work_start_at;
			"""

		self.cursor.execute(query2)
		result2 = self.cursor.fetchall()
		# print(f'OPM data for  trainId {trainId} for month {month} and year {year}', result2)
		


		query3 = f"""
			SELECT sc.A_1, sc.A_2, sc.A_3, sc.B1_1, sc.B1_2, sc.B4, sc.B8, sc.C1, sc.C2
			FROM service_checks sc
			JOIN trainsets t ON sc.trainset_id = t.id
			WHERE
				sc.trainset_id = {trainId}
				AND sc.year = {year}
				AND sc.month = {month}
			"""
		self.cursor.execute(query3)
		result3 = self.cursor.fetchall()
		# print(f'SC data for  trainId {trainId} for month {month} and year {year}', result3)


		query = f'SELECT stabilization FROM trainsets WHERE id = {trainId}'
		self.cursor.execute(query)
		stabilization = self.cursor.fetchone()



		scDates = []
		if result3:
			for i, startDate in enumerate(result3[0]):
				if startDate:
					if startDate.date() > stabilization[0]:
						if i in [0, 1, 2]:
							endDate = startDate + timedelta(hours=self.ASCHours)

						if i in [3, 4]:
							endDate = startDate + timedelta(hours=self.B1SCHours)

						if i == 5:
							endDate = startDate + timedelta(hours=self.B4SCHours)

						if i == 6:
							endDate = startDate + timedelta(hours=self.B8SCHours)

						if i == 7:
							endDate = startDate + timedelta(hours=self.C1SCHours)

						if i == 8:
							endDate = startDate + timedelta(hours=self.C2SCHours)

						scDates.append((startDate, endDate))

		# #print('sc data is-->', scDates)
		allDatePairsOfCurrentTrain = result1 + result2 + scDates
		# #print('all data-->', allDatePairsOfCurrentTrain)

		return find_totalDuration(allDatePairsOfCurrentTrain)




	cmDowntimeList = []
	opmDowntimeList = []
	scDowntimeList = []


	cyclicCheckDowntimeList = []
	fleetCheckDowntimeList = []
	HECPDowntimeList = []
	SECPDowntimeList = []
	testingDowntimeList = []
	othersDowntimeList = []



	


	for i, trainId in enumerate(trainsetsIdsList):


		downTimeWithoutOverlap = calculateDowntimeForMonth(trainId, (year, month))
		# currentMonthDownTime = timedelta()
		# 	for trainID in trainIds:
		# 		monthDownTime = calculateDowntimeForMonth(trainID, YM)
		# 		# print('monthDownTime', monthDownTime)
		# 		if monthDownTime:
		# 			currentMonthDownTime += monthDownTime
		# 			# print(currentMonthDownTime)


		if downTimeWithoutOverlap:
			totalDownTimeForThisMonth = downTimeWithoutOverlap.days*24*60 + downTimeWithoutOverlap.seconds//60
			totalDownTimeForThisMonthHours = totalDownTimeForThisMonth/60
			roundedDownTimeWithoutOverlap = round(totalDownTimeForThisMonthHours, 2)
		else:
			roundedDownTimeWithoutOverlap = 0

		monthlyDowntimeDataTable_OR.setItem(i, monthlyDowntimeDataTable_OR.columnCount()-2, QTableWidgetItem(str(roundedDownTimeWithoutOverlap)))

		## Trainwise cm downtime:
		cmDowntimeQuery1 = f"""
				SELECT SUM(cm.down_time)
				FROM corrective_maintenance cm
				JOIN trainsets t ON cm.trainset_id = t.id
				WHERE
					YEAR(cm.work_start_at) = {year}
					AND MONTH(cm.work_start_at) = {month}
					AND cm.trainset_id = {trainId}
					AND (cm.failure_type = 'Service Failure' OR cm.failure_type = 'Relevant Failure')
					AND cm.verification = 'Yes'
					AND cm.failure_responsibility = 'BEML'
					AND t.stabilization < cm.work_start_at;
				"""
		self.cursor.execute(cmDowntimeQuery1)
		cmDowntimeResult1 = self.cursor.fetchone()


		cm_downtime_value = 0 if cmDowntimeResult1[0] is None else cmDowntimeResult1[0]
		cm_downtime_value_hrs = round(cm_downtime_value / 60 , 2)
		cmDowntimeList.append(cm_downtime_value_hrs)
		

		opmDowntimeQuery1 = f"""
				SELECT SUM(opm.downtime)
				FROM other_preventive_maintenance opm
				JOIN trainsets t ON opm.trainset_id = t.id
				WHERE
					YEAR(opm.work_start_at) = {year}
					AND MONTH(opm.work_start_at) = {month}
					AND opm.trainset_id = {trainId}
					AND t.stabilization < opm.work_start_at;
				"""

		self.cursor.execute(opmDowntimeQuery1)
		opmDowntimeResult1 = self.cursor.fetchone()

		opm_downtime_value = 0 if opmDowntimeResult1[0] is None else opmDowntimeResult1[0]
		opm_downtime_value_hrs = round(opm_downtime_value / 60 , 2)
		opmDowntimeList.append(opm_downtime_value_hrs)



		scDowntimeQuery1 = f"""
				SELECT SUM(sc.downtime)
				FROM service_checks sc
				JOIN trainsets t ON sc.trainset_id = t.id
				WHERE
					sc.year = {year}
					AND sc.month = {month}
					AND sc.trainset_id = {trainId}
				"""
		
		self.cursor.execute(scDowntimeQuery1)
		scDowntimeResult1 = self.cursor.fetchone()

		# sc_downtime_value = 0 if scDowntimeResult1[0] is None else scDowntimeResult1[0]
		sc_downtime_value = 0 if scDowntimeResult1[0] is None else round(scDowntimeResult1[0], 2)
		scDowntimeList.append(sc_downtime_value)



###################################################################################################################
		
		### Querys for opm type wise downtimes:
		cyclicCheckOpmTypeQuery = f"""
				SELECT 
					SUM(opm.downtime)
				FROM other_preventive_maintenance opm
				JOIN trainsets t ON opm.trainset_id = t.id
				WHERE
					YEAR(opm.work_start_at) = {year}
					AND MONTH(opm.work_start_at) = {month}
					AND opm.trainset_id = {trainId}
					AND opm.opm_type = 'Cyclic Check'
					AND t.stabilization < opm.work_start_at;
			"""

		self.cursor.execute(cyclicCheckOpmTypeQuery)
		cyclicCheckDTResult = self.cursor.fetchone()

		cyclic_dt = 0 if cyclicCheckDTResult[0] is None else cyclicCheckDTResult[0]
		cyclic_dt_hrs = round(cyclic_dt / 60 , 2)
		cyclicCheckDowntimeList.append(cyclic_dt_hrs)




		fleetCheckOpmTypeQuery = f"""
				SELECT 
					SUM(opm.downtime)
				FROM other_preventive_maintenance opm
				JOIN trainsets t ON opm.trainset_id = t.id
				WHERE
					YEAR(opm.work_start_at) = {year}
					AND MONTH(opm.work_start_at) = {month}
					AND opm.trainset_id = {trainId}
					AND opm.opm_type = 'Fleet Check'
					AND t.stabilization < opm.work_start_at;
			"""

		self.cursor.execute(fleetCheckOpmTypeQuery)
		fleetCheckDTResult = self.cursor.fetchone()

		fleet_check_dt = 0 if fleetCheckDTResult[0] is None else fleetCheckDTResult[0]
		fleet_check_dt_hrs = round(fleet_check_dt / 60 , 2)
		fleetCheckDowntimeList.append(fleet_check_dt_hrs)



		HECPOpmTypeQuery = f"""
				SELECT 
					SUM(opm.downtime)
				FROM other_preventive_maintenance opm
				JOIN trainsets t ON opm.trainset_id = t.id
				WHERE
					YEAR(opm.work_start_at) = {year}
					AND MONTH(opm.work_start_at) = {month}
					AND opm.trainset_id = {trainId}
					AND opm.opm_type = 'HECP'
					AND t.stabilization < opm.work_start_at;
			"""

		self.cursor.execute(HECPOpmTypeQuery)
		HECPDTResult = self.cursor.fetchone()

		hecp_dt = 0 if HECPDTResult[0] is None else HECPDTResult[0]
		hecp_dt_hrs = round(hecp_dt / 60 , 2)
		HECPDowntimeList.append(hecp_dt_hrs)




		SECPOpmTypeQuery = f"""
				SELECT 
					SUM(opm.downtime)
				FROM other_preventive_maintenance opm
				JOIN trainsets t ON opm.trainset_id = t.id
				WHERE
					YEAR(opm.work_start_at) = {year}
					AND MONTH(opm.work_start_at) = {month}
					AND opm.trainset_id = {trainId}
					AND opm.opm_type = 'SECP'
					AND t.stabilization < opm.work_start_at;
			"""

		self.cursor.execute(SECPOpmTypeQuery)
		SECPDTResult = self.cursor.fetchone()

		secp_dt = 0 if SECPDTResult[0] is None else SECPDTResult[0]
		secp_dt_hrs = round(secp_dt / 60, 2)
		SECPDowntimeList.append(secp_dt_hrs)




		testingOpmTypeQuery = f"""
				SELECT 
					SUM(opm.downtime)
				FROM other_preventive_maintenance opm
				JOIN trainsets t ON opm.trainset_id = t.id
				WHERE
					YEAR(opm.work_start_at) = {year}
					AND MONTH(opm.work_start_at) = {month}
					AND opm.trainset_id = {trainId}
					AND opm.opm_type = 'Testing'
					AND t.stabilization < opm.work_start_at;
			"""

		self.cursor.execute(testingOpmTypeQuery)
		testingDTResult = self.cursor.fetchone()

		testing_dt = 0 if testingDTResult[0] is None else testingDTResult[0]
		testing_dt_hrs = round(testing_dt / 60, 2)
		testingDowntimeList.append(testing_dt_hrs)



		othersOpmTypeQuery = f"""
				SELECT 
					SUM(opm.downtime)
				FROM other_preventive_maintenance opm
				JOIN trainsets t ON opm.trainset_id = t.id
				WHERE
					YEAR(opm.work_start_at) = {year}
					AND MONTH(opm.work_start_at) = {month}
					AND opm.trainset_id = {trainId}
					AND opm.opm_type = 'Others'
					AND t.stabilization < opm.work_start_at;
			"""

		self.cursor.execute(othersOpmTypeQuery)
		othersDTResult = self.cursor.fetchone()

		others_dt = 0 if othersDTResult[0] is None else othersDTResult[0]
		others_dt_hrs = round(others_dt / 60, 2)
		othersDowntimeList.append(others_dt_hrs)



		#### Schedule checks downtime calculations:

		scDowntimeQuery_A = f"""
				SELECT sc.A_1, sc.A_2, sc.A_3
				FROM service_checks sc
				JOIN trainsets t ON sc.trainset_id = t.id
				WHERE
					sc.year = {year}
					AND sc.month = {month}
					AND sc.trainset_id = {trainId}
				"""

		self.cursor.execute(scDowntimeQuery_A)
		scDowntimeResult_A = self.cursor.fetchone()

		if scDowntimeResult_A:
			# lengthOf_A = len(tuple(x for x in scDowntimeResult_A if x is not None))

			# if lengthOf_A == 0:
			# 	a_dt = '0'

			# elif lengthOf_A == 1:
			# 	a_dt = '2.5'

			# elif lengthOf_A == 2:
			# 	a_dt = '5'

			# elif lengthOf_A == 3:
			# 	a_dt = '7.5'


			# ascDowntimeItem = QTableWidgetItem(str(a_dt))
			# monthlyDowntimeDataTable_OR.setItem(i, 15, ascDowntimeItem)

			lengthOf_A = len(tuple(x for x in scDowntimeResult_A if x is not None))

			# a_dt = 2.5 * lengthOf_A
			a_dt = self.ASCHours * lengthOf_A 
			a_dt_rounded = round(a_dt, 2)

			aDowntimeItem = QTableWidgetItem(str(a_dt_rounded))
			# monthlyDowntimeDataTable_OR.setItem(i, 15, aDowntimeItem)
			monthlyDowntimeDataTable_OR.setItem(i, 14, aDowntimeItem)

		else:
			aDowntimeItem = QTableWidgetItem('0')
			# monthlyDowntimeDataTable_OR.setItem(i, 15, aDowntimeItem)
			monthlyDowntimeDataTable_OR.setItem(i, 14, aDowntimeItem)


 
	
		scDowntimeQuery_B1 = f"""
				SELECT sc.B1_1, sc.B1_2
				FROM service_checks sc
				WHERE
					sc.year = {year}
					AND sc.month = {month}
					AND sc.trainset_id = {trainId}
				"""
		self.cursor.execute(scDowntimeQuery_B1)
		scDowntimeResult_B1 = self.cursor.fetchone()

		if scDowntimeResult_B1:

			lengthOf_B1 = len(tuple(x for x in scDowntimeResult_B1 if x is not None))

			# b1_dt = 10 * lengthOf_B1
			# b1_dt = 9 * lengthOf_B1
			b1_dt = self.B1SCHours * lengthOf_B1
			b1_dt_rounded = round(b1_dt, 2)

			b1DowntimeItem = QTableWidgetItem(str(b1_dt_rounded))
			# monthlyDowntimeDataTable_OR.setItem(i, 16, b1DowntimeItem)
			monthlyDowntimeDataTable_OR.setItem(i, 15, b1DowntimeItem)

		else:
			b1DowntimeItem = QTableWidgetItem('0')
			# monthlyDowntimeDataTable_OR.setItem(i, 16, b1DowntimeItem)
			monthlyDowntimeDataTable_OR.setItem(i, 15, b1DowntimeItem)




		scDowntimeQuery_B4 = f"""
				SELECT sc.B4
				FROM service_checks sc
				WHERE
					sc.year = {year}
					AND sc.month = {month}
					AND sc.trainset_id = {trainId}
				"""
		self.cursor.execute(scDowntimeQuery_B4)
		scDowntimeResult_B4 = self.cursor.fetchone()
		

		if scDowntimeResult_B4:

			lengthOf_B4 = len(tuple(x for x in scDowntimeResult_B4 if x is not None))

			# b4_dt = 20.5
			# b4_dt = 17
			b4_dt = self.B4SCHours * lengthOf_B4
			b4_dt_rounded = round(b4_dt, 2)

			b4DowntimeItem = QTableWidgetItem(str(b4_dt_rounded))
			# monthlyDowntimeDataTable_OR.setItem(i, 17, b4DowntimeItem)
			monthlyDowntimeDataTable_OR.setItem(i, 16, b4DowntimeItem)

		else:
			b4DowntimeItem = QTableWidgetItem('0')
			# monthlyDowntimeDataTable_OR.setItem(i, 17, b4DowntimeItem)
			monthlyDowntimeDataTable_OR.setItem(i, 16, b4DowntimeItem)




		scDowntimeQuery_B8 = f"""
				SELECT sc.B8
				FROM service_checks sc
				WHERE
					sc.year = {year}
					AND sc.month = {month}
					AND sc.trainset_id = {trainId}
				"""
		self.cursor.execute(scDowntimeQuery_B8)
		scDowntimeResult_B8 = self.cursor.fetchone()

		if scDowntimeResult_B8:

			lengthOf_B8 = len(tuple(x for x in scDowntimeResult_B8 if x is not None))

			# b8_dt = 47.5
			# b8_dt = 33
			b8_dt = self.B8SCHours * lengthOf_B8
			b8_dt_rounded = round(b8_dt, 2)  # Round off to two digits

			b8DowntimeItem = QTableWidgetItem(str(b8_dt_rounded))
			# monthlyDowntimeDataTable_OR.setItem(i, 18, b8DowntimeItem)
			monthlyDowntimeDataTable_OR.setItem(i, 17, b8DowntimeItem)

		else:
			b8DowntimeItem = QTableWidgetItem('0')
			# monthlyDowntimeDataTable_OR.setItem(i, 18, b8DowntimeItem)
			monthlyDowntimeDataTable_OR.setItem(i, 17, b8DowntimeItem)






	for i, label in enumerate(firstColumnTrainsetsLabelsForRMTable):

		serialNumberItem = QTableWidgetItem(str(i + 1))
		monthlyDowntimeDataTable_OR.setItem(i, 0, serialNumberItem)

		firstColumnLabelItem = QTableWidgetItem(label)
		monthlyDowntimeDataTable_OR.setItem(i, 1, firstColumnLabelItem)



	for i, label in enumerate(secondColumnDepotLabelsForRMTable):
		depotColumnLabelItem = QTableWidgetItem(label)
		monthlyDowntimeDataTable_OR.setItem(i, 2, depotColumnLabelItem)



	for i, cmdt in enumerate(cmDowntimeList):
		cmDowntimeItem = QTableWidgetItem(str(cmdt))
		monthlyDowntimeDataTable_OR.setItem(i, 3, cmDowntimeItem)


		cmDowntimeItem1 = QTableWidgetItem(str(cmdt))
		# monthlyDowntimeDataTable_OR.setItem(i, 8, cmDowntimeItem1)
		monthlyDowntimeDataTable_OR.setItem(i, 7, cmDowntimeItem1)


	for i, opmdt in enumerate(opmDowntimeList):
		opmDowntimeItem = QTableWidgetItem(str(opmdt))
		monthlyDowntimeDataTable_OR.setItem(i, 4, opmDowntimeItem)




	for i, scdt in enumerate(scDowntimeList):
		scDowntimeItem = QTableWidgetItem(str(scdt))
		monthlyDowntimeDataTable_OR.setItem(i, 5, scDowntimeItem)


	#####################################################################


	## Total downtime:
	cmDowntimeList_floats = [float(val) for val in cmDowntimeList]
	opmDowntimeList_floats = [float(val) for val in opmDowntimeList]
	scDowntimeList_floats = [float(val) for val in scDowntimeList]
	totalDowntimeList = [sum(x) for x in zip(cmDowntimeList_floats, opmDowntimeList_floats, scDowntimeList_floats)]
	# totalDowntimeList = [float(sum(map(float, x))) for x in zip(cmDowntimeList, opmDowntimeList, scDowntimeList)]

	for i, totaldt in enumerate(totalDowntimeList):
		rounded_totaldt = round(totaldt, 2)
		totalDowntimeItem = QTableWidgetItem(str(rounded_totaldt))
		monthlyDowntimeDataTable_OR.setItem(i, 6, totalDowntimeItem)



	### OPM Typewise downtimes:
	
	for i, sc_dt in enumerate(cyclicCheckDowntimeList):
		cyclicCheckDowntimeItem = QTableWidgetItem(str(sc_dt))
		# monthlyDowntimeDataTable_OR.setItem(i, 9, cyclicCheckDowntimeItem)
		monthlyDowntimeDataTable_OR.setItem(i, 8, cyclicCheckDowntimeItem)


	for i, fc_dt in enumerate(fleetCheckDowntimeList):
		fleetCheckDowntimeItem = QTableWidgetItem(str(fc_dt))
		# monthlyDowntimeDataTable_OR.setItem(i, 10, fleetCheckDowntimeItem)
		monthlyDowntimeDataTable_OR.setItem(i, 9, fleetCheckDowntimeItem)


	for i, hecp_dt in enumerate(HECPDowntimeList):
		hecpDowntimeItem = QTableWidgetItem(str(hecp_dt))
		# monthlyDowntimeDataTable_OR.setItem(i, 11, hecpDowntimeItem)
		monthlyDowntimeDataTable_OR.setItem(i, 10, hecpDowntimeItem)


	for i, secp_dt in enumerate(SECPDowntimeList):
		secpDowntimeItem = QTableWidgetItem(str(secp_dt))
		# monthlyDowntimeDataTable_OR.setItem(i, 12, secpDowntimeItem)
		monthlyDowntimeDataTable_OR.setItem(i, 11, secpDowntimeItem)


	for i, testing_dt in enumerate(testingDowntimeList):
		testingDowntimeItem = QTableWidgetItem(str(testing_dt))
		# monthlyDowntimeDataTable_OR.setItem(i, 13, testingDowntimeItem)
		monthlyDowntimeDataTable_OR.setItem(i, 12, testingDowntimeItem)


	for i, others_dt in enumerate(othersDowntimeList):
		othersDowntimeItem = QTableWidgetItem(str(others_dt))
		# monthlyDowntimeDataTable_OR.setItem(i, 14, othersDowntimeItem)
		monthlyDowntimeDataTable_OR.setItem(i, 13, othersDowntimeItem)




	### Total downtime from column: 8-19 (11 Columns):
	for row in range(monthlyDowntimeDataTable_OR.rowCount()):
		totalDownTimeValue = 0
		# for col in range(8, 19):
		for col in range(7, 18):
			totalDTitem =  monthlyDowntimeDataTable_OR.item(row, col)
			if totalDTitem and totalDTitem.text():
				totalDownTimeValue += float(totalDTitem.text())


		totalDownTime_rounded = round(totalDownTimeValue, 2)
		totalDowntimeItem = QTableWidgetItem(str(totalDownTime_rounded))
		monthlyDowntimeDataTable_OR.setItem(row, 18, totalDowntimeItem)


	for row in range(monthlyDowntimeDataTable_OR.rowCount()):
		# totalDownTimeValue = 0
		totalDownTimeValue2Text = monthlyDowntimeDataTable_OR.item(row, monthlyDowntimeDataTable_OR.columnCount()-2).text()
		totalDownTimeValue2Float = round(float(totalDownTimeValue2Text), 2)


		# for col in range(8, 19):
		# 	totalDTitem =  monthlyDowntimeDataTable_OR.item(row, col)
		# 	if totalDTitem and totalDTitem.text():
		# 		totalDownTimeValue += float(totalDTitem.text())


		# totalDownTime_rounded = round(totalDownTimeValue, 2)
		# totalDowntimeItem = QTableWidgetItem(str(totalDownTime_rounded))
		# monthlyDowntimeDataTable_OR.setItem(row, 19, totalDowntimeItem)


		# totalDowntimeItem = QTableWidgetItem(str(totalDownTimeValue2Float))
		# monthlyDowntimeDataTable_OR.setItem(row, 18, totalDowntimeItem)


		availability = round((1 - (totalDownTimeValue2Float / (totalDaysOfSelectedMonth*24))) * 100, 2)

		if availability:
			monthlyDowntimeDataTable_OR.setItem(row, 20, QTableWidgetItem(str(availability)))
		else:
			monthlyDowntimeDataTable_OR.setItem(row, 20, QTableWidgetItem('0'))



	monthlyDowntimeDataTable_OR.insertRow(monthlyDowntimeDataTable_OR.rowCount())

	for j in range(3,20):
		sumValue = 0.0 
		for i in range(monthlyDowntimeDataTable_OR.rowCount()-1):
			value = float(monthlyDowntimeDataTable_OR.item(i, j).text())
			sumValue += value

		monthlyDowntimeDataTable_OR.setItem(monthlyDowntimeDataTable_OR.rowCount()-1, j, QTableWidgetItem(str(round(sumValue, 2))))

	

	T1Total = float(monthlyDowntimeDataTable_OR.item(monthlyDowntimeDataTable_OR.rowCount()-1, monthlyDowntimeDataTable_OR.columnCount()-2).text())

	grandAvailabilityAverage = round((1 - (T1Total / (totalDaysOfSelectedMonth*24*(monthlyDowntimeDataTable_OR.rowCount()-1)))) * 100, 2)
	monthlyDowntimeDataTable_OR.setItem(monthlyDowntimeDataTable_OR.rowCount()-1, monthlyDowntimeDataTable_OR.columnCount()-1, QTableWidgetItem(str(grandAvailabilityAverage)))
	monthlyDowntimeDataTable_OR.setItem(monthlyDowntimeDataTable_OR.rowCount()-1, 0, QTableWidgetItem('Grand Total'))
	


	downTimeTableData = []

	header_text = []
	for col in range(monthlyDowntimeDataTable_OR.columnCount()):
		header_item = monthlyDowntimeDataTable_OR.horizontalHeaderItem(col)
		if header_item:
			header_text.append(header_item.text())

	# Add headers to the table_data
	downTimeTableData.append(header_text)


	# Fetch data
	for row in range(monthlyDowntimeDataTable_OR.rowCount()):
		row_data = []
		for col in range(monthlyDowntimeDataTable_OR.columnCount()):
			item = monthlyDowntimeDataTable_OR.item(row, col)

			if item:
				row_data.append(item.text())
			else:
				row_data.append('')
		
		downTimeTableData.append(row_data)

	




	downtimeDataTableStyleList = [
			('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#669999')),
			('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
			('ALIGN', (0, 0), (-1, -1), 'CENTER'),
			('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
			('FONT', (0, 0), (-1, 0), 'RobotoFont', 6),
			('FONT', (0, 1), (-1, -1), 'RobotoFont', 7),
			('GRID', (0, 0), (-1, -1), 0.5, colors.black),

			# Merge cells for the summary row
			('SPAN', (0, -1), (2, -1)),  # Merge the first 3 cells in the last row
			('FONT', (0, -1), (-1, -1), 'Roboto-Bold', 7), # Bold style for the last row

			('WORDWRAP', (0, 0), (-1, -1))
		]


	# for index, line in enumerate(self.depotsList):
	# 	additionalStyle1 = ('SPAN', (2, sum(lineCounts[:index])+1), (2, sum(lineCounts[:index+1])))
	
	# 	downtimeDataTableStyleList.append(additionalStyle1)

	downtimeDataTableStyle = TableStyle(downtimeDataTableStyleList)

	# downtimeDataTableColumnWidths = [17, 30, 23, 25, 25, 25, 36, 5, 25, 25, 25, 25, 25, 25, 25, 23, 23, 23, 23, 30, 63, 30] ## Portrait
	downtimeDataTableColumnWidths = [17, 30, 23, 25, 25, 25, 36, 25, 25, 25, 25, 25, 25, 25, 23, 23, 23, 23, 30, 30, 63] ## Portrait

	totalReportTitles.append(downtimeDataReportTitle)
	tableColumnWidthsList.append(downtimeDataTableColumnWidths)
	tableStylesList.append(downtimeDataTableStyle)
	totalTableData.append(downTimeTableData)



	# print('totalTableData', totalTableData)

	totalTableData[0][9][2] = monthlyDowntimeDataTable_OR.item(monthlyDowntimeDataTable_OR.rowCount()-1, 3).text()
	totalTableData[0][10][2] = monthlyDowntimeDataTable_OR.item(monthlyDowntimeDataTable_OR.rowCount()-1, 4).text()
	totalTableData[0][11][2] = monthlyDowntimeDataTable_OR.item(monthlyDowntimeDataTable_OR.rowCount()-1, 5).text()
	generate_summary_pdf_report(totalReportTitles, totalTableData, tableColumnWidthsList, tableStylesList,  0)

	
	# generate_summary_pdf_report(totalReportTitles, totalTableData, tableColumnWidthsList, tableStylesList,  reportsPageOrientationList)




	# print(reportsPageOrientationList)







########################################################################################################################

# Register the TrueType font
pdfmetrics.registerFont(TTFont('RobotoFont', 'Roboto-Regular.ttf'))
pdfmetrics.registerFont(TTFont('Roboto_Italics_Font', 'Roboto-Italic.ttf'))
pdfmetrics.registerFont(TTFont('Roboto-Bold', 'Roboto-Bold.ttf'))



# def summaryReportHeaderSection_Landscape(c):
	
# 	c.setFont('RobotoFont', 18)

# 	c.setFillColor(colors.HexColor('#003366'))
	
# 	# BEML Logo at the left end of header part:
# 	beml_logo_path = 'Media/BEML.png'
# 	beml_logo_width = 140
# 	beml_logo_height = 55
# 	c.drawInlineImage(beml_logo_path, 30, 530, width=beml_logo_width, height=beml_logo_height)

# 	# MMRC Logo at the right end of header part:
# 	mmrc_logo_path = 'Media/MMRC.png'
# 	mmrc_logo_width = 60
# 	mmrc_logo_height = 60
# 	mmrc_logo_x = A4[1] - 30 - mmrc_logo_width  # Calculate X-coordinate for the right logo
# 	c.drawInlineImage(mmrc_logo_path, mmrc_logo_x, 530, width=mmrc_logo_width, height=mmrc_logo_height)

# 	# Set the line thickness to reduce the thickness
# 	c.setLineWidth(0.3)  # Adjust this value as needed

# 	# Draw a horizontal line below the header
# 	lineBelowTheHeader = 525  # Adjust the Y-coordinate based on your layout
# 	c.line(20, lineBelowTheHeader, A4[1] - 20, lineBelowTheHeader)




# def summaryReportFooterSection_Landscape(c):
# 	# Draw a horizontal line above the footer:
# 	lineAboveTheFooter = 65  # Adjust the Y-coordinate based on your layout
# 	c.line(20, lineAboveTheFooter, A4[1] - 20, lineAboveTheFooter)

# 	# BEA Logo at the left end of footer part:
# 	bea_logo_path = 'Media/BeALogo.jpg'
# 	bea_logo_width = 120
# 	bea_logo_height = 50
# 	c.drawInlineImage(bea_logo_path, 30, 10, width=bea_logo_width, height=bea_logo_height)

# 	# Common Footer
# 	c.setFont('Helvetica-Oblique', 8)

# 	# Display the current date and time
# 	current_datetime = datetime.now().strftime('%d-%b-%y %H:%M')
# 	c.drawRightString(A4[1] - 20, 40, f'Report Generated on: {current_datetime}')

# 	# Display the page number
# 	c.drawRightString(A4[1] - 20, 25, 'Page %d' % c.getPageNumber())



# ################################################################################################################

# def summaryReportHeaderSection_Portrait(c):

	
# 	c.setFont('RobotoFont', 18)

# 	c.setFillColor(colors.HexColor('#003366'))

# 	# c.drawCentredString(A4[0] / 1.8 , A4[1] - 50, report_title)  # Centered header text

# 	# BEML Logo at the left end of header part:
# 	beml_logo_path = 'Media/BEML.png'
# 	beml_logo_width = 140
# 	beml_logo_height = 55
# 	c.drawInlineImage(beml_logo_path, 20, A4[1] - 70, width=beml_logo_width, height=beml_logo_height)

# 	# MMRC Logo at the right end of header part:
# 	mmrc_logo_path = 'Media/MMRC.png'
# 	mmrc_logo_width = 60
# 	mmrc_logo_height = 60
# 	mmrc_logo_x = A4[0] - 30 - mmrc_logo_width  # Calculate X-coordinate for the right logo
# 	c.drawInlineImage(mmrc_logo_path, mmrc_logo_x, A4[1] - 70, width=mmrc_logo_width, height=mmrc_logo_height)

# 	# Set the line thickness to reduce the thickness
# 	c.setLineWidth(0.3)  # Adjust this value as needed

# 	# Draw a horizontal line below the header
# 	lineBelowTheHeader = A4[1] - 80  # Adjust the Y-coordinate based on your layout
# 	c.line(20, lineBelowTheHeader, A4[0] - 20, lineBelowTheHeader)


# def summaryReportFooterSection_Portrait(c):
# 	# Draw a horizontal line above the footer:
# 	lineAboveTheFooter = 65  # Adjust the Y-coordinate based on your layout
# 	c.line(20, lineAboveTheFooter, A4[0] - 20, lineAboveTheFooter)

# 	# BEA Logo at the left end of footer part:
# 	bea_logo_path = 'Media/BeALogo.jpg'
# 	bea_logo_width = 120
# 	bea_logo_height = 50
# 	c.drawInlineImage(bea_logo_path, 30, 10, width=bea_logo_width, height=bea_logo_height)

# 	# Common Footer
# 	c.setFont('Helvetica-Oblique', 8)

# 	# Display the current date and time
# 	current_datetime = datetime.now().strftime('%d-%b-%y %H:%M')							# %I give you the hour in the range of 01 to 12, %H give the hour in the range of 00 to 23.
# 	c.drawRightString(A4[0] - 20, 40, f'Report Generated on: {current_datetime}')

# 	# Display the page number
# 	c.drawRightString(A4[0] - 20, 25, 'Page %d' % c.getPageNumber())




def summaryReportHeaderSection_Portrait(c):

	
	c.setFont('RobotoFont', 18)

	c.setFillColor(colors.HexColor('#003366'))

	# BEML Logo at the left end of header part:
	beml_logo_path = 'Media/BEML.png'
	beml_logo_width = 120
	beml_logo_height = 45
	c.drawInlineImage(beml_logo_path, 20, A4[1] - 70, width=beml_logo_width, height=beml_logo_height)

	#dmrc logo at the center of the header
	dmrc_logo_path = 'Media/dmrc.jpg'
	dmrc_logo_width = 90
	dmrc_logo_height = 50
	dmrc_logo_x = (A4[0] - dmrc_logo_width) / 2  # Calculate X-coordinate for the center logo
	c.drawInlineImage(dmrc_logo_path, dmrc_logo_x, A4[1] - 70, width=dmrc_logo_width, height=dmrc_logo_height)

	# MMRC Logo at the right end of header part:
	mmrc_logo_path = 'Media/MMRC.png'
	mmrc_logo_width = 60
	mmrc_logo_height = 60
	mmrc_logo_x = A4[0] - 30 - mmrc_logo_width  # Calculate X-coordinate for the right logo
	c.drawInlineImage(mmrc_logo_path, mmrc_logo_x, A4[1] - 77, width=mmrc_logo_width, height=mmrc_logo_height)

	# Set the line thickness to reduce the thickness
	c.setLineWidth(0.3)  # Adjust this value as needed

	# Draw a horizontal line below the header
	lineBelowTheHeader = A4[1] - 80  # Adjust the Y-coordinate based on your layout
	c.line(20, lineBelowTheHeader, A4[0] - 20, lineBelowTheHeader)


def summaryReportFooterSection_Portrait(c):
	# Draw a horizontal line above the footer:
	lineAboveTheFooter = 65  # Adjust the Y-coordinate based on your layout
	c.line(20, lineAboveTheFooter, A4[0] - 20, lineAboveTheFooter)

	# BEA Logo at the left end of footer part:
	bea_logo_path = 'Media/ramsify3.png'
	bea_logo_width = 150
	bea_logo_height = 40
	c.drawInlineImage(bea_logo_path, 30, 20, width=bea_logo_width, height=bea_logo_height)

	# Common Footer
	c.setFont('Helvetica-Oblique', 8)

	# Display the current date and time
	current_datetime = datetime.now().strftime('%d-%b-%y %H:%M')
	c.drawRightString(A4[0] - 20, 40, f'Report Generated on: {current_datetime}')

	# Display the page number
	c.drawRightString(A4[0] - 20, 25, 'Page %d' % c.getPageNumber())








### Original:

def generate_summary_pdf_report(report_titles, report_data_list, col_widths_list, table_styles_list, orientation):
	file_path, _ = QFileDialog.getSaveFileName(None, "Save Report", "", "Pdf Files (*.pdf)")

	if file_path:

		if orientation == 0:
			pagesize = A4
		elif orientation == 1:
			pagesize = landscape(A4)


		report_title_style = ParagraphStyle(
			'TitleStyle',
			fontName='RobotoFont',
			fontSize=18,
			leading=18,
			textColor='#ffffff',
			alignment=TA_CENTER,
			backColor='#44546a',
			# borderColor='#000000',
			borderPadding=(5, 2, 10),
			borderRadius=None,
			borderWidth=0.5,
		)

		signing_designation_style = ParagraphStyle(
			'SigningLine',
			fontName='RobotoFont',  
			fontSize=15,
			spaceBefore=20,   
			spaceAfter=20,
			alignment=TA_CENTER, 
			textColor='#000000',  
		)

		def my_first_page(canvas, doc):
			_header_footer(canvas, orientation)

		# def my_later_pages(canvas, doc):
		# 	_header_footer(canvas, orientation)

		def _header_footer(canvas, orientation):
			if orientation == 0:
				summaryReportHeaderSection_Portrait(canvas)
				summaryReportFooterSection_Portrait(canvas)
			# elif orientation == 1:
			# 	summaryReportHeaderSection_Landscape(canvas)
			# 	summaryReportFooterSection_Landscape(canvas)

		page_template = PageTemplate(id='AllPages', frames=[Frame(20, 70, pagesize[0] - 40, pagesize[1] - 170, showBoundary=0)], onPage=my_first_page)

		doc = BaseDocTemplate(file_path, pagesize=pagesize)
		doc.addPageTemplates([page_template, page_template])

		elements = []

		y_coordinate = A4[1] - 110
		line_height = 14
		remaining_space = pagesize[1] - y_coordinate

		emptySpace = u'\u00A0' * 45

		for title, data, col_widths, table_style in zip(report_titles, report_data_list, col_widths_list, table_styles_list):
			# Add the title as a paragraph
			title_paragraph = Paragraph(title, style=report_title_style)
			title_paragraph.wrap(A4[0] - 30, line_height)
			elements.append(title_paragraph)

			# Create the table
			table = Table(data, colWidths=col_widths, rowHeights=25, repeatRows=1)
			table.setStyle(table_style)

			# Add style for wrapping text and setting text color to black
			# table.setStyle(TableStyle([('VALIGN', (0, 0), (-1, -1), 'TOP'), ('TEXTCOLOR', (0, 0), (-1, -1), colors.black)]))
			elements.extend([Spacer(1, 20), table])

			# Update y_coordinate based on the height of the last added element
			y_coordinate -= title_paragraph.wrap(A4[0] - 30, line_height)[1]

			signing_line_height = 25
			if remaining_space > signing_line_height:
				signing_line = Paragraph(f"BEML {emptySpace} MMMOCL {emptySpace} DMRC", style=signing_designation_style)
				signing_line.wrap(A4[0] - 30, signing_line_height)
				elements.extend([Spacer(1, 20), signing_line])
				y_coordinate -= signing_line.wrap(A4[0] - 30, signing_line_height)[1]
			else:
				# Add a page break and place signing line on the next page
				elements.append(PageBreak())
				signing_line = Paragraph(f"BEML {emptySpace} MMMOCL {emptySpace} DMRC", style=signing_designation_style)
				signing_line.wrap(A4[0] - 30, signing_line_height)
				elements.extend([Spacer(1, 20), signing_line])
				y_coordinate = pagesize[1] - signing_line.wrap(A4[0] - 30, signing_line_height)[1]
			
			# Add a page break after each table
			elements.append(PageBreak())


		# Add a spacer
		elements.append(Spacer(2, 0.7*inch))

		# draw your shapes and add to the platypus doc which is letter 8.5x11 inch
		x = 0  # Starting from the left edge of the page
		y = 0  # Starting from the bottom edge of the page
		width = A4[0] - 0.5 * inch  # Width of A4 minus 0.5 inches margin on each side
		height = 2.5 * inch  # Increased height

		d = shapes.Drawing(width, height)
		r = shapes.Rect(x, y, width, height, fillColor=colors.white, strokeColor=colors.black, strokeWidth=0.5) 
		d.add(r)

		# Calculate the x-coordinate for aligning with the right edge of the page
		x_translate = (A4[0] - width) / 2 - 0.35 * inch  # Adjust as needed

		# # Add 'Note:' text to the top-left corner of the rectangle
		note_text = shapes.String(0.1 * inch, height - 0.3 * inch, "Note:", fontSize=12, fillColor=colors.black)
		d.add(note_text)

		# Move the drawing to the desired position on the page
		d.translate(x_translate, y)

		elements.append(d)

		doc.build(elements)

		reportMsgBox = QMessageBox()
		reportMsgBox.setIcon(QMessageBox.Information) 
		reportMsgBox.setText('Report Generated Successfully')
		reportMsgBox.setWindowTitle("Message")
		reportMsgBox.setWindowIcon(QIcon('Media/ramsify.png'))
		reportMsgBox.setStandardButtons(QMessageBox.Ok)
		reportMsgBox.exec_()