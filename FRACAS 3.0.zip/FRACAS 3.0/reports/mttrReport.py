from datetime import datetime, timedelta
from dateutil.relativedelta import relativedelta
import calendar

from PySide6.QtWidgets import QApplication
from functions import createPieChart

def mttrReportUi(self, month, year, selected_report_title):

	six_months_ago = datetime(year, month, 1) - relativedelta(months=5)

	six_months_agoDate = six_months_ago.date()
	fromDateMonthString = six_months_agoDate.strftime('%b - %Y')
	allItems = []
	for index in range(self.fromCombobox_MTTR.count()):
		item_text = self.fromCombobox_MTTR.itemText(index)
		allItems.append(item_text)
	

	if fromDateMonthString in allItems:
		self.fromCombobox_MTTR.setCurrentText(fromDateMonthString)
	else:
		self.fromCombobox_MTTR.setCurrentIndex(0)


	date_object = datetime(year, month, 1)
	toMonthString = date_object.strftime('%b - %Y')

	self.toCombobox_MTTR.setCurrentText(toMonthString)
	

########################################################################
	
	mttr_data = []


	month_string = calendar.month_abbr[int(month)]

	report_title = f'MTTR REPORT FOR {toMonthString.upper()}'

	# Add the header title as a paragraph
	mttr_data.append(report_title)


	##########################################################

	tableNamesList = [f'MTTR for {toMonthString}']

	##########################################################


	table_data = []

	
	# # Fetch headers
	# header_text = []
	# for col in range(self.tableForMTTRDashboard.columnCount()):
	# 	header_item = self.tableForMTTRDashboard.horizontalHeaderItem(col)
	# 	if header_item:
	# 		header_text.append(header_item.text())

	# # Add headers to the table_data
	# table_data.append(header_text)



	# # Fetch data
	# for row in range(self.tableForMTTRDashboard.rowCount()):
	# 	row_data = []
	# 	for col in range(self.tableForMTTRDashboard.columnCount()):
	# 		item = self.tableForMTTRDashboard.item(row, col)

	# 		if item:
	# 			row_data.append(item.text())
	# 		else:
	# 			row_data.append('')
		
	# 	table_data.append(row_data)



	# Fetch headers
	header_text = []
	for col in range(self.tableForMTTRDashboard.columnCount()):
		if not self.tableForMTTRDashboard.isColumnHidden(col):
			header_item = self.tableForMTTRDashboard.horizontalHeaderItem(col)
			if header_item:
				header_text.append(header_item.text())

	# Add headers to the table_data
	table_data.append(header_text)

	# Fetch data
	for row in range(self.tableForMTTRDashboard.rowCount()):
		row_data = []
		for col in range(self.tableForMTTRDashboard.columnCount()):
			if not self.tableForMTTRDashboard.isColumnHidden(col):
				item = self.tableForMTTRDashboard.item(row, col)
				if item:
					row_data.append(item.text())
				else:
					row_data.append('')
		
		table_data.append(row_data)


	# Add the table to the mttr_data
	mttr_data.append(table_data)


	##########################################################


	mttr_chart_list = []


	mttrResultList_PieChart = []

	for row in range(self.tableForMTTRDashboard.rowCount()):
		item = self.tableForMTTRDashboard.item(row, self.tableForMTTRDashboard.columnCount()-1)
		if item and item.text() != '':
			mttrResultList_PieChart.append(item.text())
		else:
			pass


	mttrResultDict = {}
	mttrResultDict['Pass'] = mttrResultList_PieChart.count('Pass')
	mttrResultDict['Fail'] = mttrResultList_PieChart.count('Fail')


	mttrResultChartView = self.createPieChart(mttrResultDict, f'MTTR For {toMonthString}')
	mttrResultChartView.setFixedHeight(525)
	mttrResultChartView.setFixedWidth(int(0.4 * QApplication.primaryScreen().availableGeometry().width()))

	mttr_chart_image = mttrResultChartView.grab().toImage()
	mttr_chart_list.append(mttr_chart_image)


	##########################################################


	#Generate the report
	self.generate_pdf_report(selected_report_title, mttr_data, tableNamesList, 1, mttr_chart_list, boldCells=self.systemsInMDBCFDashboard)

	self.clearAllFiltersButton_MTTRDash.click()