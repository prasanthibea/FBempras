from functions import *

def settingsUI(self):
	def onclosingSettingsWindow():
		onClickingCancelButton_settingsPage()
	class settingsWindow(QWidget):
		def closeEvent(self, event):
			# Call your function here
			onclosingSettingsWindow()
			event.accept()


	self.settingsWidget = settingsWindow()
	self.settingsWidget.setWindowFlags(self.settingsWidget.windowFlags() & ~Qt.WindowMaximizeButtonHint)
	self.settingsWidget.setWindowIcon(QIcon('Media/ramsify.png'))
	self.settingsWidget.setWindowTitle('Settings')
	self.settingsWidget.setStyleSheet(self.widgetQSS)

	self.settingsLayout = QFormLayout()
	self.settingsWidget.setLayout(self.settingsLayout)
	self.settingsWidget.resize(400, 300)

	

	self.appFontSize = 12
	self.widgetsToChangeFont = [self.scrollAreaWidgetContents_2, self.scrollAreaWidgetContents_3, self.scrollAreaWidgetContents_4, self.scrollAreaWidgetContents_5, self.scrollAreaWidgetContents_6, self.scrollAreaWidgetContents_7, self.scrollAreaWidgetContents_8, self.scrollAreaWidgetContents_9]
	fontLabel = QLabel('Font Size: ')
	fontOptions = ['Small', 'Normal', 'Large']
	self.createComboBox(fontOptions, 'fontCombobox')
	self.fontCombobox.setCurrentIndex(1)
	self.fontCombobox.setStyleSheet(self.comboBoxQSS)
	#self.formLayoutForSettingsPage.addRow(fontLabel, self.fontCombobox)
	self.settingsLayout.addRow(fontLabel, self.fontCombobox)


	themeLabel = QLabel('Theme: ')
	themeOptions = ['Light', 'Dark']
	self.createComboBox(themeOptions, 'themeCombobox')
	self.themeCombobox.setCurrentIndex(0)
	self.themeCombobox.setStyleSheet(self.comboBoxQSS)
	self.settingsLayout.addRow(themeLabel, self.themeCombobox)


	self.saveButton_settingsPage = QPushButton('Save')
	self.saveButton_settingsPage.setFixedWidth(75)
	self.saveButton_settingsPage.setFixedHeight(25)
	self.saveButton_settingsPage.setStyleSheet(self.pushbuttonQSS)

	self.cancelButton_settingsPage = QPushButton('Cancel')
	self.cancelButton_settingsPage.setFixedWidth(75)
	self.cancelButton_settingsPage.setFixedHeight(25)
	self.cancelButton_settingsPage.setStyleSheet(self.pushbuttonQSS)

	layoutForSaveAndCancelButtons_settingsPage = QHBoxLayout()
	layoutForSaveAndCancelButtons_settingsPage.addWidget(self.saveButton_settingsPage)
	layoutForSaveAndCancelButtons_settingsPage.addWidget(self.cancelButton_settingsPage)
	layoutForSaveAndCancelButtons_settingsPage.setAlignment(Qt.AlignCenter)
	
	self.settingsLayout.addRow(QLabel(''), layoutForSaveAndCancelButtons_settingsPage)

	def onClickingSaveButton_settingsPage():
		self.settings.setValue("fontSize", self.fontCombobox.currentText())
		self.settings.setValue("theme", self.themeCombobox.currentText())
		self.settingsWidget.close()
		self.onChangingThemeCombobox()
	def onClickingCancelButton_settingsPage():
		self.fontCombobox.setCurrentText(self.settings.value('fontSize'))
		self.themeCombobox.setCurrentText(self.settings.value('theme'))
		self.settingsWidget.close()
	self.saveButton_settingsPage.clicked.connect(onClickingSaveButton_settingsPage)
	self.cancelButton_settingsPage.clicked.connect(onClickingCancelButton_settingsPage)

	savedFontSize = self.settings.value("fontSize")
	savedTheme = self.settings.value("theme")
	if savedFontSize is not None:
		self.fontCombobox.setCurrentText(savedFontSize)
	
	if savedTheme is not None:
		self.themeCombobox.setCurrentText(savedTheme)

	self.fontIndex = self.fontCombobox.currentIndex()
	self.onChangingFontCombobox()
	self.fontCombobox.currentIndexChanged.connect(self.onChangingFontCombobox)
	#self.themeCombobox.currentIndexChanged.connect(self.onChangingThemeCombobox)

def onChangingFontCombobox(self):

	if self.fontCombobox.currentIndex() == 0:
		self.appFontSize = 10
	elif self.fontCombobox.currentIndex() == 1:
		self.appFontSize = 12
	elif self.fontCombobox.currentIndex() == 2:
		self.appFontSize = 14


	font = self.sideMenuTree.font()
	font.setPointSize(self.appFontSize-1)  # Increase the font size by 2 points
	self.sideMenuTree.setFont(font)

	

	#for table in self.tableWidgetsFontToChange:
	#	for row in range(table.rowCount()):
	#		for col in range(table.columnCount()):
	#			item = table.item(row, col)
	#			font = item.font()
	#			font.setPointSize(self.appFontSize)
	#			item.setFont(font)

	for widget in self.widgetsToChangeFont:
		layoutOfWidget = widget.layout()

		def iterateThroughLayout(layout_):
			for i in range(layout_.count()):
				item = layout_.itemAt(i)
				if isinstance(item.widget(), QWidget):
					if item.widget().layout() == None:
						if isinstance(item.widget(), (QTableWidget, TableWidget)):
							# Set font size for horizontal header
							horizontal_header = item.widget().horizontalHeader()
							font = horizontal_header.font()
							font.setPointSize(self.appFontSize)
							horizontal_header.setFont(font)

							# Set font size for vertical header
							vertical_header = item.widget().verticalHeader()
							font = vertical_header.font()
							font.setPointSize(self.appFontSize)
							vertical_header.setFont(font)

							# Update the headers to reflect the font size change
							item.widget().setHorizontalHeader(horizontal_header)
							item.widget().setVerticalHeader(vertical_header)

							for row in range(item.widget().rowCount()):
								for col in range(item.widget().columnCount()):
									itemm = item.widget().item(row, col)
									if itemm != None:
										font = itemm.font()
										font.setPointSize(self.appFontSize)
										itemm.setFont(font)


						# elif isinstance(item.widget(), QLabel):
						# 	label = item.widget()
						# 	font = label.font()
						# 	fontSize = font.pointSize()
						# 	print(label.text(), fontSize)

						# 	#if self.fontCombobox.currentIndex() < self.fontIndex:
						# 	#	print(self.fontIndex, self.fontCombobox.currentIndex())
						# 	#	font.setPointSize(fontSize+1)
						# 	#	label.setFont(font)
						# 	#	self.fontIndex = self.fontCombobox.currentIndex()
						# 	#elif self.fontCombobox.currentIndex() > self.fontIndex:
						# 	#	print(self.fontIndex, self.fontCombobox.currentIndex())
						# 	#	font.setPointSize(fontSize+1)
						# 	#	label.setFont(font)
						# 	#	self.fontIndex = self.fontCombobox.currentIndex()


						# 	if self.fontCombobox.currentIndex() == 0:
						# 		font.setPointSize(fontSize+1)
						# 		label.setFont(font)

						# 	if self.fontCombobox.currentIndex() == 1:
						# 		font.setPointSize(fontSize+1)
						# 		label.setFont(font)

						# 	if self.fontCombobox.currentIndex() == 2:
						# 		font.setPointSize(fontSize+1)
						# 		label.setFont(font)
					else:
						iterateThroughLayout(item.widget().layout())



				if isinstance(item.layout(), QLayout):
					iterateThroughLayout(item.layout())


		iterateThroughLayout(layoutOfWidget)


def onChangingThemeCombobox(self):
	#self.settings.setValue("theme", self.themeCombobox.currentText())
	self.QSSValues()
	self.settingThemeFunction()

	for widget in self.widgetsToChangeFont:
		layoutOfWidget = widget.layout()

		def iterateThroughLayout(layout_):
			for i in range(layout_.count()):
				item = layout_.itemAt(i)
				if item != None:
					if isinstance(item.widget(), QWidget):
						if item.widget().layout() == None:
							if isinstance(item.widget(), (QTableWidget, TableWidget)):
								# Set font size for horizontal header
								horizontal_header = item.widget().horizontalHeader()
								horizontal_header.setStyleSheet(self.headerHorizontalQSS)
							

								# Set font size for vertical header
								vertical_header = item.widget().verticalHeader()
								vertical_header.setStyleSheet(self.headerVerticalQSS)

								item.widget().setStyleSheet(self.tableWidgetQSS)

								for row in range(item.widget().rowCount()):
									for col in range(item.widget().columnCount()):
										cellWidget = item.widget().cellWidget(row, col)
										if isinstance(cellWidget, QLineEdit):
											cellWidget.setStyleSheet(self.lineEditBoxQSS)
										elif isinstance(cellWidget, QSpinBox):
											cellWidget.setStyleSheet(self.spinBoxQSS)
										elif isinstance(cellWidget, QComboBox):
											cellWidget.setStyleSheet(self.comboBoxQSS)
										elif isinstance(cellWidget, QCheckBox):
											cellWidget.setStyleSheet(self.checkBoxQSS)


							elif isinstance(item.widget(), QComboBox):
								item.widget().setStyleSheet(self.comboBoxQSS)

							elif isinstance(item.widget(), QSpinBox):
								item.widget().setStyleSheet(self.spinBoxQSS)

							elif isinstance(item.widget(), QLineEdit):
								item.widget().setStyleSheet(self.lineEditBoxQSS)

							elif isinstance(item.widget(), QPushButton):
								item.widget().setStyleSheet(self.pushbuttonQSS)
								

						else:
							iterateThroughLayout(item.widget().layout())



					if isinstance(item.layout(), QLayout):
						iterateThroughLayout(item.layout())


		iterateThroughLayout(layoutOfWidget)