from configuration import *
from PySide6.QtWidgets import QLabel, QHBoxLayout, QFormLayout, QFileDialog, QLineEdit, QComboBox, QMessageBox, QGridLayout, QPushButton, QSpinBox, QTableWidgetItem, QSizePolicy, QSpacerItem
from PySide6.QtCore import Qt
from PySide6.QtGui import QFont, QIcon
from datetime import datetime, timedelta
from functions import CustomSpinBox
from runningMileageData import onButtonClicked_rmData
import pandas as pd

def runningMileageUI(self):
	
	formLayout_RM= QFormLayout()
	startingYear = int(self.config.get('startingYearMonth', 'startingYear'))
	startingMonth = int(self.config.get('startingYearMonth', 'startingMonth'))

	query = 'SELECT COUNT(*) FROM trainsets_mileage'
	self.cursor.execute(query)
	result = self.cursor.fetchone()
	if result[0] != 0:
		query = """SELECT year, month
		FROM trainsets_mileage
		ORDER BY year DESC, month DESC
		LIMIT 1;
		"""
		self.cursor.execute(query)
		result =self.cursor.fetchone()
		if result[1] != 12:
			cbYear = result[0]
			cbMonth = result[1] + 1
		else:
			cbYear = result[0] + 1
			cbMonth = 1
	else:
		cbYear = startingYear
		cbMonth = startingMonth

	self.createComboBox([str(cbYear)], 'yearCombobox_RM')
	formLayout_RM.addRow('Year:<font color="red">*</font>', self.yearCombobox_RM)

	self.createComboBox([str(cbMonth)], 'monthCombobox_RM')
	formLayout_RM.addRow('Month:<font color="red">*</font>', self.monthCombobox_RM)

	self.createComboBox(['Odometer Reading', 'Monthly Running Mileage'], 'typeOfDataCombobox_RMForm')

	##################################################################
	HLayoutOfRM = QHBoxLayout()

	self.createPushButton('templateButton_RM', '', self.currentTheme.get('exportTemplateIcon'), tooltip='export template')
	self.templateButton_RM.setToolTip('Export template')
	self.templateButton_RM.setFixedWidth(29)
	self.templateButton_RM.setFixedHeight(25)

	self.createPushButton('importButton_RM', '', self.currentTheme.get('importDataIcon'), tooltip='Import RM data')
	self.importButton_RM.setFixedWidth(29)
	self.importButton_RM.setFixedHeight(25)
	
	HLayoutOfRM.addWidget(self.typeOfDataCombobox_RMForm)
	spacerItem = QSpacerItem(20, 1, QSizePolicy.Expanding, QSizePolicy.Fixed)
	HLayoutOfRM.addItem(spacerItem)

	HLayoutOfRM.addWidget(self.templateButton_RM, alignment = Qt.AlignRight)
	HLayoutOfRM.addWidget(self.importButton_RM, alignment = Qt.AlignRight)
	formLayout_RM.addRow('Type of Data:', HLayoutOfRM)

	#################################################################

	# formLayout_RM.addRow('Type of Data:', self.typeOfDataCombobox_RMForm)
	

	self.mainVerticalLayout_runningMileage.addLayout(formLayout_RM)

	self.cummulativeMileageSpinbox_RM = []
		
	gridLayout_Rm= QGridLayout()

	hLayoutForLabels_RMForm = QHBoxLayout()

	trainsetsNameLabel = QLabel('Trainsets')
	trainsetsNameLabel.setFixedHeight(50)
	font = QFont()
	font.setBold(True)
	trainsetsNameLabel.setFont(font)
	cumulativeRunningMileage_Label = QLabel('Odometer Reading')
	cumulativeRunningMileage_Label.setFont(font)
	monthlyRunningMileage_Label = QLabel('Monthly Running Mileage')
	monthlyRunningMileage_Label.setFont(font)

	hLayoutForLabels_RMForm.addWidget(trainsetsNameLabel, alignment = Qt.AlignCenter)
	hLayoutForLabels_RMForm.addWidget(cumulativeRunningMileage_Label)
	hLayoutForLabels_RMForm.addWidget(monthlyRunningMileage_Label)

	# layoutForSpacer = QHBoxLayout()
	# self.mainVerticalLayout_runningMileage.addLayout(layoutForSpacer)
	# layoutForSpacer.addItem(QSpacerItem(0, 50, QSizePolicy.Minimum, QSizePolicy.Expanding))
	self.mainVerticalLayout_runningMileage.addLayout(hLayoutForLabels_RMForm)

	self.spinboxlist_Rm= []
	lastMonthCumulativeMileage_RM = []

	for i, trainset in enumerate(self.trainsetsList):
		trainsetlabel = QLabel(trainset)

		cummulativeMileageSpinbox_RM = CustomSpinBox()
		cummulativeMileageSpinbox_RM.setStyleSheet(self.spinBoxQSS)
		cummulativeMileageSpinbox_RM.setMinimumWidth(200)
		cummulativeMileageSpinbox_RM.setEnabled(False)
		cummulativeMileageSpinbox_RM.setMaximum(1000000000)   
	
		monthlyMileageSpinbox_RM = CustomSpinBox()
		monthlyMileageSpinbox_RM.setStyleSheet(self.spinBoxQSS)

		monthlyMileageSpinbox_RM.setValue(0)
		monthlyMileageSpinbox_RM.setMinimumWidth(200)
		monthlyMileageSpinbox_RM.setEnabled(False)
		monthlyMileageSpinbox_RM.setMaximum(1000000000)
			
		gridLayout_Rm.addWidget(trainsetlabel, i, 0, alignment = Qt.AlignCenter)
		gridLayout_Rm.addWidget(cummulativeMileageSpinbox_RM, i, 1, alignment = Qt.AlignLeft)
		gridLayout_Rm.addWidget(monthlyMileageSpinbox_RM, i, 2, alignment = Qt.AlignLeft)
		self.spinboxlist_Rm.append((cummulativeMileageSpinbox_RM, monthlyMileageSpinbox_RM))		
	

		def onChangingMonthlyMileageCB(value, row, spinboxlist_Rm):
			spinbox1 = spinboxlist_Rm[row][0]
			if lastMonthCumulativeMileage_RM:
				spinbox1.setValue(value + lastMonthCumulativeMileage_RM[row])
			else:
				spinbox1.setValue(value)
		monthlyMileageSpinbox_RM.valueChanged.connect(lambda value, row=i: onChangingMonthlyMileageCB(value, row, self.spinboxlist_Rm))

		def onChangingCumulativeMileageCB(value, row, spinboxlist_Rm):
			spinbox2 = spinboxlist_Rm[row][1]
			if lastMonthCumulativeMileage_RM:		
				spinbox2.setValue(value - lastMonthCumulativeMileage_RM[row])
			else:
				spinbox2.setValue(value)
		cummulativeMileageSpinbox_RM.valueChanged.connect(lambda value, row=i: onChangingCumulativeMileageCB(value, row, self.spinboxlist_Rm))

	self.mainVerticalLayout_runningMileage.addLayout(gridLayout_Rm)
	


	

	horizontalLayout_RM = QHBoxLayout()
	self.createPushButton('rmSubmitButton', 'Submit')
	horizontalLayout_RM.addWidget(self.rmSubmitButton)

	self.createPushButton('rmCancelButton', 'Cancel')
	horizontalLayout_RM.addWidget(self.rmCancelButton)

	horizontalLayout_RM.setAlignment(Qt.AlignCenter)

	self.mainVerticalLayout_runningMileage.addLayout(horizontalLayout_RM)

	####################################################################

	def onClickingimportButton_RM():
		if self.monthCombobox_RM.currentIndex() == -1:
			self.monthCombobox_RM.setProperty("error", True)
			self.monthCombobox_RM.setStyleSheet(self.comboBoxQSS)
		else:
			self.monthCombobox_RM.setProperty("error", False)
			self.monthCombobox_RM.setStyleSheet(self.comboBoxQSS)
			
		if self.yearCombobox_RM.currentIndex() == -1:		
			self.yearCombobox_RM.setProperty("error", True)
			self.yearCombobox_RM.setStyleSheet(self.comboBoxQSS)
		else:
			self.yearCombobox_RM.setProperty("error", False)
			self.yearCombobox_RM.setStyleSheet(self.comboBoxQSS)

		if self.monthCombobox_RM.currentIndex() != -1 and self.yearCombobox_RM.currentIndex() != -1:
			file_path, _ = QFileDialog.getOpenFileName(self, "Select Excel File", "", "Excel Files (*.xlsx)")
			if file_path:
				df = pd.read_excel(file_path)
				for row, trainset_name in enumerate(self.trainsetsList):
					if trainset_name in df.iloc[:, 0].values:
						index_in_df = df.index[df.iloc[:, 0] == trainset_name][0]
						if self.typeOfDataCombobox_RMForm.currentIndex() == 0:
							gridLayout_Rm.itemAtPosition(row, 1).widget().setValue(df.iloc[index_in_df, 1])								
						else:
							gridLayout_Rm.itemAtPosition(row, 2).widget().setValue(df.iloc[index_in_df, 1])

				rmMsgBox = QMessageBox()
				rmMsgBox.setIcon(QMessageBox.Information) 
				rmMsgBox.setText('Data Imported Successfully')
				rmMsgBox.setWindowTitle("Message")
				rmMsgBox.setWindowIcon(QIcon('Media/ramsify.png'))
				rmMsgBox.setStandardButtons(QMessageBox.Ok)
				rmMsgBox.exec_()
			

	self.importButton_RM.clicked.connect(onClickingimportButton_RM)

	

	def exportRMInputTemplate():
		file_path, _ = QFileDialog.getSaveFileName(None, "Save Excel File", "", "Excel Files (*.xlsx)")

		if file_path:

			headersOfRMImportTableTemplate = ['Trainsets']
			headersOfRMImportTableTemplate.append(self.typeOfDataCombobox_RMForm.currentText())

			df = pd.DataFrame([headersOfRMImportTableTemplate])
			df.to_excel(file_path, index=False, header=False)

			msg = QMessageBox()
			msg.setIcon(QMessageBox.Information)
			msg.setText("Exported Successfully")
			msg.setWindowTitle("Message")
			msg.setWindowIcon(QIcon('Media/ramsify.png'))
			msg.exec_()

	self.templateButton_RM.clicked.connect(exportRMInputTemplate)
	
			
	##########################################################################
	
	def load_previous_month_data():
		lastMonthCumulativeMileage_RM.clear()	
		if self.yearCombobox_RM.currentText() != '':
			if self.monthCombobox_RM.currentText() != '':
				selected_year_Rm = int(self.yearCombobox_RM.currentText())
				selected_month_Rm= int(self.monthCombobox_RM.currentText())
				
				previous_month = selected_month_Rm - 1
				previous_year = selected_year_Rm		

				if previous_month == 0:
					previous_month = 12
					previous_year -= 1

				query_previous_month = """
				SELECT trainsets_mileage.cummulative_mileage, trainsets.trainset
				FROM trainsets_mileage
				JOIN trainsets ON trainsets_mileage.trainset_id = trainsets.id
				WHERE trainsets_mileage.year = %s AND trainsets_mileage.month = %s
				AND trainsets.deleted_at IS NULL;
				"""
				self.cursor.execute(query_previous_month, (previous_year, previous_month))
				previous_month_data = self.cursor.fetchall()

				
				for i in range(len(self.spinboxlist_Rm)):
					cummulativeMileageSpinbox_RM, monthlyMileageSpinbox_RM = self.spinboxlist_Rm[i]

					if i < len(previous_month_data):
						if previous_month_data[i][1] == gridLayout_Rm.itemAtPosition(i,0).widget().text():
							cummulative_mileage = previous_month_data[i][0]
							lastMonthCumulativeMileage_RM.append(cummulative_mileage)
							cummulativeMileageSpinbox_RM.setValue(cummulative_mileage)
							cummulativeMileageSpinbox_RM.setMinimum(cummulative_mileage)
						else:
							previous_month_data.insert(i, 0)
							cummulative_mileage = 0
							lastMonthCumulativeMileage_RM.append(cummulative_mileage)
							cummulativeMileageSpinbox_RM.setValue(cummulative_mileage)
							cummulativeMileageSpinbox_RM.setMinimum(cummulative_mileage)
					else:
						cummulative_mileage = 0
						lastMonthCumulativeMileage_RM.append(cummulative_mileage)
						cummulativeMileageSpinbox_RM.setValue(cummulative_mileage)
						cummulativeMileageSpinbox_RM.setMinimum(cummulative_mileage)


					cummulativeMileageSpinbox_RM.setEnabled(True)
					monthlyMileageSpinbox_RM.setEnabled(True)
	

	self.yearCombobox_RM.currentIndexChanged.connect(load_previous_month_data)
	self.monthCombobox_RM.currentIndexChanged.connect(load_previous_month_data)
	


	def onChangingTypeOfData_RmForm():
		if self.typeOfDataCombobox_RMForm.currentIndex() == 0:
			hLayoutForLabels_RMForm.itemAt(1).widget().show()
			hLayoutForLabels_RMForm.itemAt(2).widget().hide()
			
			for row in range(gridLayout_Rm.rowCount()):
				if gridLayout_Rm.itemAtPosition(row, 1):
					gridLayout_Rm.itemAtPosition(row, 1).widget().show()
				if gridLayout_Rm.itemAtPosition(row, 2):
					gridLayout_Rm.itemAtPosition(row, 2).widget().hide()

		else:
			hLayoutForLabels_RMForm.itemAt(2).widget().show()
			hLayoutForLabels_RMForm.itemAt(1).widget().hide()

			for row in range(gridLayout_Rm.rowCount()):
				if gridLayout_Rm.itemAtPosition(row, 2):
					gridLayout_Rm.itemAtPosition(row, 2).widget().show()
				if gridLayout_Rm.itemAtPosition(row, 1):
					gridLayout_Rm.itemAtPosition(row, 1).widget().hide()

	self.typeOfDataCombobox_RMForm.currentIndexChanged.connect(onChangingTypeOfData_RmForm)
	self.typeOfDataCombobox_RMForm.setCurrentIndex(0)



	def save_running_mileage():
		if self.yearCombobox_RM.currentText() != '':
			self.yearCombobox_RM.setProperty("error", False)
			self.yearCombobox_RM.setStyleSheet(self.comboBoxQSS)
			if self.monthCombobox_RM.currentText() != '':
				self.monthCombobox_RM.setProperty("error", False)
				self.monthCombobox_RM.setStyleSheet(self.comboBoxQSS)

				rmyearlabel = int(self.yearCombobox_RM.currentText())
				rmMonthlabel = int(self.monthCombobox_RM.currentText())

				if len(str(rmMonthlabel)) == 1:
					rmInId = f'0{rmMonthlabel}'
				else:
					rmInId = rmMonthlabel
				rmId = 'RM_' + str(rmyearlabel) + str(rmInId)

				monthlyMileageSum = 0
				for trainset_name, (cummulativeMileageSpinbox_RM, monthlyMileageSpinbox_RM) in zip(self.trainsetsList, self.spinboxlist_Rm):
					cumulativeMileage_RM = cummulativeMileageSpinbox_RM.value()
					currentMonthMileage_RM = monthlyMileageSpinbox_RM.value()
					query = """
					INSERT INTO trainsets_mileage
					(rm_id, year, month, trainset_id, cummulative_mileage, monthly_mileage, user_id)
					SELECT %s, %s, %s, trainsets.id, %s, %s, %s
					FROM trainsets
					WHERE trainsets.trainset = %s;
					"""


					self.cursor.execute(query, (rmId, rmyearlabel, rmMonthlabel, cumulativeMileage_RM, currentMonthMileage_RM, self.user_id, trainset_name))
					self.mydb.commit()
					monthlyMileageSum += currentMonthMileage_RM


				



				self.rmDataTable.setRowCount(self.rmDataTable.rowCount()+1)

				new_data = [rmId, rmyearlabel, rmMonthlabel, monthlyMileageSum]
				button = QPushButton(rmId)
				button.setStyleSheet("QPushButton { text-decoration: none; }"
					"QPushButton:hover { text-decoration: underline; }")
				button.setCursor(Qt.PointingHandCursor)
				self.rmDataTable.setCellWidget(self.rmDataTable.rowCount()-1, 0, button)
				button.clicked.connect(lambda : onButtonClicked_rmData(self, button.text()))


				item = QTableWidgetItem(str(rmyearlabel))
				item.setTextAlignment(Qt.AlignCenter)
				self.rmDataTable.setItem(self.rmDataTable.rowCount()-1, 1, item)

				item = QTableWidgetItem(str(rmMonthlabel))
				item.setTextAlignment(Qt.AlignCenter)
				self.rmDataTable.setItem(self.rmDataTable.rowCount()-1, 2, item)

				item = QTableWidgetItem(str(monthlyMileageSum))
				item.setTextAlignment(Qt.AlignCenter)
				self.rmDataTable.setItem(self.rmDataTable.rowCount()-1, 3, item)



				yearInCB = int(self.yearCombobox_RM.currentText())
				monthInCB = int(self.monthCombobox_RM.currentText())

				if monthInCB != 12:
					self.yearCombobox_RM.clear()
					self.monthCombobox_RM.clear()
					self.yearCombobox_RM.addItem(str(yearInCB))
					self.monthCombobox_RM.addItem(str(monthInCB+1))
				else:
					self.yearCombobox_RM.clear()
					self.monthCombobox_RM.clear()
					self.yearCombobox_RM.addItem(str(yearInCB+1))
					self.monthCombobox_RM.addItem(str(1))


				clear_running_mileage()

				rmMsgBox = QMessageBox()
				rmMsgBox.setIcon(QMessageBox.Information) 
				rmMsgBox.setText(f'Data submitted successfully.\nID:{rmId}')
				rmMsgBox.setWindowTitle("Message")
				rmMsgBox.setWindowIcon(QIcon('Media/ramsify.png'))
				rmMsgBox.setStandardButtons(QMessageBox.Ok)
				rmMsgBox.exec_()

			else:
				self.monthCombobox_RM.setProperty("error", True)
				self.monthCombobox_RM.setStyleSheet(self.comboBoxQSS)
		else:
			self.yearCombobox_RM.setProperty("error", True)
			self.yearCombobox_RM.setStyleSheet(self.comboBoxQSS)

	self.rmSubmitButton.clicked.connect(save_running_mileage)

		
	def clear_running_mileage():
		
		self.yearCombobox_RM.setCurrentIndex(-1)
		self.monthCombobox_RM.setCurrentIndex(-1)

		self.yearCombobox_RM.setProperty("error", False)
		self.yearCombobox_RM.setStyleSheet(self.comboBoxQSS)

		self.monthCombobox_RM.setProperty("error", False)
		self.monthCombobox_RM.setStyleSheet(self.comboBoxQSS)

		for cummulativeMileageSpinbox_RM, monthlyMileageSpinbox_RM in self.spinboxlist_Rm:
			cummulativeMileageSpinbox_RM.setMinimum(0)
			cummulativeMileageSpinbox_RM.setValue(0)
			monthlyMileageSpinbox_RM.setValue(0)
			cummulativeMileageSpinbox_RM.setEnabled(False)
			monthlyMileageSpinbox_RM.setEnabled(False)


	self.rmCancelButton.clicked.connect(clear_running_mileage)