#from PySide6.QtChart import QChart, QChartView, QBarSet, QBarSeries, QPercentBarSeries, QBarCategoryAxis, QValueAxis, QAbstractBarSeries
#from PySide6.QtGui import QIcon, QPainter

from PySide6.QtWidgets import (QHBoxLayout, QLabel, QVBoxLayout, QGridLayout, QApplication)

import sys
from configuration import *
from functions import *

# from runningMileageDashboard import *
import time
from datetime import datetime, date
from dateutil.relativedelta import relativedelta
import calendar



def homeUi(self):

	self.homePageHorizontalLayout = QHBoxLayout()
	self.homePageGridLayout = QGridLayout()

	refreshTableIconPath = self.currentTheme.get('refreshIcon')
	self.createPushButton('refreshButton_home', '', refreshTableIconPath, 35, 'Refresh')

	self.homePageHorizontalLayout.addWidget(self.refreshButton_home, alignment = Qt.AlignRight)
	self.refreshButton_home.clicked.connect(lambda: self.onClickingRefresh_home(self.mainVerticalLayout_home))


	currentDate = datetime.now()

	previousMonthDate = currentDate - timedelta(days=currentDate.day)
	previousMonthYearString = previousMonthDate.strftime('%b - %Y')


	#######################################################################################################
	## Stacked bar chart for Running Mileage data for last 6 months to current month 

	xlabelsForAccumulatedRunningMileage_SBC = []

	for col in range(1, self.dashboardRmMonthlyTable.columnCount()):
		if not self.dashboardRmMonthlyTable.isColumnHidden(col):
			header_item = self.dashboardRmMonthlyTable.horizontalHeaderItem(col)
			if header_item and header_item.text() is not None:
				xlabelsForAccumulatedRunningMileage_SBC.append(header_item.text())


	
	runningMileageDataList_SBC = []

	for row in range(self.dashboardRmMonthlyTable.rowCount()):
		row_data = []
		for col in range(1, self.dashboardRmMonthlyTable.columnCount()):
			if not self.dashboardRmMonthlyTable.isColumnHidden(col):
				item = self.dashboardRmMonthlyTable.item(row, col)

				if item:
					row_data.append(int(item.text()))
				else:
					row_data.append(0)
		
		runningMileageDataList_SBC.append(row_data)



	title = "Monthly Running Mileage"
	x_label = "Months"
	y_label = "Mileage (KM)"

	accumulatedRMChartView = createStackedBarChart(self, xlabelsForAccumulatedRunningMileage_SBC, runningMileageDataList_SBC,  title, x_label, y_label, self.uniqueLines)
	accumulatedRMChartView.setFixedHeight(525)
	accumulatedRMChartView.setFixedWidth(int(0.4 * QApplication.primaryScreen().availableGeometry().width()))
	
	# self.homePageVerticalLayout1.addWidget(accumulatedRMChartView)
	self.homePageGridLayout.addWidget(accumulatedRMChartView, 0, 0)

	

	#######################################################################################################
	## Stacked bar chart for linewise actual downtimes: (Line 2A & 7, Line 2B)

	xlabelsForActualDowntime_SBC = []

	if self.listOfLinesTablesInAvailDash:
		for col in range(1, self.listOfLinesTablesInAvailDash[0].columnCount()):
			if not self.listOfLinesTablesInAvailDash[0].isColumnHidden(col):
				header_item = self.listOfLinesTablesInAvailDash[0].horizontalHeaderItem(col)
				if header_item and header_item.text() is not None:
					xlabelsForActualDowntime_SBC.append(header_item.text())


	linewiseAvailabilityActualDowntimes_SBC = []

	for table_widget in self.listOfLinesTablesInAvailDash:
		row_data = []
		for col in range(1, table_widget.columnCount()):
			if not table_widget.isColumnHidden(col):
				item = table_widget.item(5, col)
				if item:
					row_data.append(float(item.text()))
				else:
					row_data.append(0)  # or any other placeholder value
		
		linewiseAvailabilityActualDowntimes_SBC.append(row_data)

	allLinesDowntimes = [sum(x) for x in zip(*linewiseAvailabilityActualDowntimes_SBC)]
	linewiseAvailabilityActualDowntimes_SBC.append(allLinesDowntimes)

	downtimeChartTitle = "Downtime"
	downtimeChartXLabel = "Months"
	downtimeChartYLabel = "Downtime (Min)"

	# actualDowntimeChartView = createStackedTwoBarChart(self, xlabelsForActualDowntime_SBC, linewiseAvailabilityActualDowntimes_SBC,  downtimeChartTitle, downtimeChartXLabel, downtimeChartYLabel, self.uniqueLines)
	actualDowntimeChartView = createStackedBarChart(self, xlabelsForActualDowntime_SBC, linewiseAvailabilityActualDowntimes_SBC,  downtimeChartTitle, downtimeChartXLabel, downtimeChartYLabel, self.uniqueLines)
	actualDowntimeChartView.setFixedHeight(525)
	actualDowntimeChartView.setFixedWidth(int(0.4 * QApplication.primaryScreen().availableGeometry().width()))

	
	# self.homePageVerticalLayout1.addWidget(actualDowntimeChartView)
	self.homePageGridLayout.addWidget(actualDowntimeChartView, 0, 1)



	#######################################################################################################
	## Pie chart for linewise last six months downtimes: (Line 2A & 7, Line 2B)

	linewiseSixMonthsTotalDowntime_PieChart = []

	for table_widget in self.listOfLinesTablesInAvailDash:
		row_data = []
		item = table_widget.item(6, table_widget.columnCount()-1)
		if item:
			row_data.append(float(item.text()))
		else:
			row_data.append(0)  # or any other placeholder value
	
		linewiseSixMonthsTotalDowntime_PieChart.append(row_data)


	linewiseLastSixMonthsTotalDowntimeDict = {}
	for i, line in enumerate(self.uniqueLines):
		linewiseLastSixMonthsTotalDowntimeDict[line] = linewiseSixMonthsTotalDowntime_PieChart[i]


	fromMonthString = xlabelsForActualDowntime_SBC[0]
	toMonthString = xlabelsForActualDowntime_SBC[-1]


	# totalDownTimeChartView = self.createPieChart(linewiseLastSixMonthsTotalDowntimeDict, 'Last 6 Months Total Downtime (Mins)')
	totalDownTimeChartView = self.createPieChart(linewiseLastSixMonthsTotalDowntimeDict, f'Downtime (Mins) From {fromMonthString} to {toMonthString}')
	totalDownTimeChartView.setFixedHeight(525)
	totalDownTimeChartView.setFixedWidth(int(0.4 * QApplication.primaryScreen().availableGeometry().width()))


	# self.homePageVerticalLayout2.addWidget(totalDownTimeChartView)
	self.homePageGridLayout.addWidget(totalDownTimeChartView, 1, 0)


	#######################################################################################################
	## MonthWise Fleet Availability Line Chart (Line 2A & 7, Line 2B)


	fleetAvailabilityValues = []

	# for row in range(1,3):
	for row in range(1+len(self.uniqueLines)):
		row_data = []
		for col in range(1, self.availabilitySummaryTable.columnCount()):
			if not self.availabilitySummaryTable.isColumnHidden(col):
				item = self.availabilitySummaryTable.item(row, col)

				if item:
					row_data.append(float(item.text()))
				else:
					row_data.append(0.0)
		
		fleetAvailabilityValues.append(row_data)



	# fleetAvailabilityValuesList = fleetAvailabilityValues
	chartTitle_FAC = f"Availability (6M)"
	xLabels_FAC = "Months"
	yLabels_FAC = "Availability (%)"


	legends_FAC = ['Target Availability'] + self.uniqueLines
	colors_FAC = [Qt.red, Qt.blue, Qt.green]
	lineType_FAC = [Qt.DashLine, Qt.SolidLine, Qt.SolidLine]
	

	fleetAvailabilityValues = [sett for sett in fleetAvailabilityValues if not all(value == 0 for value in sett)]

	fleetAvailabilityChartView = self.createLineChart(xlabelsForActualDowntime_SBC, fleetAvailabilityValues, legends_FAC, colors_FAC, lineType_FAC, chartTitle_FAC, xLabels_FAC, yLabels_FAC)
	fleetAvailabilityChartView.chart().axisY().setMax(100)



	fleetAvailabilityChartView.setFixedHeight(525)
	fleetAvailabilityChartView.setFixedWidth(int(0.4 * QApplication.primaryScreen().availableGeometry().width()))


	# self.homePageVerticalLayout2.addWidget(fleetAvailabilityChartView)
	self.homePageGridLayout.addWidget(fleetAvailabilityChartView, 1, 1)

	

	#######################################################################################################
	## MonthWise Number of shortfall trains bar chart:


	shortFallTrainsList = []

	shortFallTrainRowDataIndex = self.availabilitySummaryTable.rowCount() - 1

	for col in range(1, self.availabilitySummaryTable.columnCount()):
		if not self.availabilitySummaryTable.isColumnHidden(col):
			item = self.availabilitySummaryTable.item(shortFallTrainRowDataIndex, col)
			if item:
				shortFallTrainsList.append(int(item.text()))
			else:
				shortFallTrainsList.append(0)


	xValues_SFT = xlabelsForActualDowntime_SBC
	yValues_SFT = shortFallTrainsList
	# yValues_SFT = [0,0,1,2]
	chartTitle_SFT = "Number of Shortfall Trains"
	xLabels_SFT = "Months"
	yLabels_SFT = "No of Trains"


	shortFallTrainsChartView = createBarChart(self, xValues_SFT, [yValues_SFT], chartTitle_SFT, xLabels_SFT, yLabels_SFT, ['Shortfall Trains'])
	shortFallTrainsChartView.setFixedHeight(525)
	shortFallTrainsChartView.setFixedWidth(int(0.4 * QApplication.primaryScreen().availableGeometry().width()))

	# self.homePageVerticalLayout1.addWidget(shortFallTrainsChartView)
	self.homePageGridLayout.addWidget(shortFallTrainsChartView, 2, 0)


	#######################################################################################################
	## MonthWise Target vs Achieved MDBF Line Chart (Line 2A & 7, Line 2B)


	targetAndAchievedMdbfValues = []


	for row in [7,9]:
		row_data = []
		for col in range(1, self.mdbfDashboardTable.columnCount()):
			if not self.mdbfDashboardTable.isColumnHidden(col):
				item = self.mdbfDashboardTable.item(row, col)

				if item:
					cell_value = item.text()

					try:
						if cell_value == 'No Fails':
							row_data.append(0.0)
						else:
							row_data.append(float(cell_value))
					except ValueError:
						row_data.append(0.0)
				else:
					row_data.append(0.0)

		targetAndAchievedMdbfValues.append(row_data)



	mdbfValuesList = targetAndAchievedMdbfValues
	chartTitle_MDBF = f"MDBF with Shortfall Trains(6M)"
	xLabels_MDBF = "Months"
	yLabels_MDBF = "MDBF (KM)"


	legends_MDBF= ['Target MDBF', 'Achieved MDBF']
	colors_MDBF = [Qt.red, Qt.green]
	lineType_MDBF = [Qt.DashLine, Qt.SolidLine]
	

	mdbfChartView = self.createLineChart(xlabelsForActualDowntime_SBC, mdbfValuesList, legends_MDBF, colors_MDBF, lineType_MDBF, chartTitle_MDBF, xLabels_MDBF, yLabels_MDBF)
	mdbfChartView.setFixedHeight(525)
	mdbfChartView.setFixedWidth(int(0.4 * QApplication.primaryScreen().availableGeometry().width()))


	self.homePageGridLayout.addWidget(mdbfChartView, 2, 1)

	

	#######################################################################################################
	## Pie chart for linewise last six months downtimes: (Line 2A & 7, Line 2B)

	mttrResultList_PieChart = []

	for row in range(self.tableForMTTRDashboard.rowCount()):
		item = self.tableForMTTRDashboard.item(row, self.tableForMTTRDashboard.columnCount()-1)
		if item and item.text() != '':
			mttrResultList_PieChart.append(item.text())
		else:
			pass


	mttrResultDict = {}
	mttrResultDict['Pass'] = mttrResultList_PieChart.count('Pass')
	mttrResultDict['Fail'] = mttrResultList_PieChart.count('Fail')


	mttrResultChartView = self.createPieChart(mttrResultDict, f'MTTR For {previousMonthYearString}')
	mttrResultChartView.setFixedHeight(525)
	mttrResultChartView.setFixedWidth(int(0.4 * QApplication.primaryScreen().availableGeometry().width()))


	# self.homePageVerticalLayout1.addWidget(mttrResultChartView)
	self.homePageGridLayout.addWidget(mttrResultChartView, 3, 0)

	#######################################################################################################

	#######################################################################################################
	## Pie chart for linewise last six months downtimes: (Line 2A & 7, Line 2B)

	mdbcfResultList_PieChart = []

	for row in range(self.tableForMDBCFDashboard.rowCount()):
		item = self.tableForMDBCFDashboard.item(row, self.tableForMDBCFDashboard.columnCount()-1)
		if item and item.text() != '':
			mdbcfResultList_PieChart.append(item.text())
		else:
			pass
	

	mdbcfResultDict = {}
	mdbcfResultDict['Pass'] = mdbcfResultList_PieChart.count('Pass')
	mdbcfResultDict['Fail'] = mdbcfResultList_PieChart.count('Fail')


	mdbcfResultChartView = self.createPieChart(mdbcfResultDict, f'MDBCF For {previousMonthYearString}')
	mdbcfResultChartView.setFixedHeight(525)
	mdbcfResultChartView.setFixedWidth(int(0.4 * QApplication.primaryScreen().availableGeometry().width()))

	self.homePageGridLayout.addWidget(mdbcfResultChartView, 3, 1)

	#######################################################################################################

	self.mainVerticalLayout_home.addLayout(self.homePageHorizontalLayout)
	self.mainVerticalLayout_home.addLayout(self.homePageGridLayout)


def deleteItems_home(layout):
	if layout:
		while layout.count():
			item = layout.takeAt(0)
			widget = item.widget()
			if widget:
				widget.setParent(None)
			else:
				deleteItems_home(item.layout())

def onClickingRefresh_home(self, layout):
	deleteItems_home(layout)
	self.refreshBtn_RMDash.click()
	self.refreshButton_availDash.click()
	self.refreshBtn_MDBCFDash.click()
	self.refreshButton_MDBFDash.click()
	self.refreshBtn_MTTRDash.click()
	self.refreshBtn_PF.click()
	self.refreshBtn_SRF.click()
	self.homeUi()