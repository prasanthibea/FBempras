from PySide6.QtWidgets import QTableWidgetItem, QSpacerItem, QSizePolicy, QMessageBox, QPushButton, QFileDialog, QAbstractItemView, QWidget, QLabel, QHBoxLayout, QVBoxLayout, QFormLayout, QHeaderView, QDateTimeEdit
from functions import TableWidget, CustomDateTimeEdit
from PySide6.QtCore import Qt, QDateTime
from datetime import datetime, timedelta, date
from PySide6.QtCore import Qt, QDate, QTime, QDateTime
import calendar
from PySide6.QtGui import QIcon
from openpyxl import Workbook
from dateutil.relativedelta import relativedelta

def scDataUI(self, mainLayout):
	from PySide6.QtWidgets import QApplication
	self.layoutForFilters_scDataTable = QHBoxLayout()

	self.createLineEditBox('serachBarOfSCDataTable', 'Search..' )
	self.serachBarOfSCDataTable.setClearButtonEnabled(True)
	self.serachBarOfSCDataTable.setFixedWidth(int(0.2 * QApplication.primaryScreen().availableGeometry().width()))

	self.layoutForFilters_scDataTable.addItem(QSpacerItem(1, 0, QSizePolicy.Expanding, QSizePolicy.Minimum))
	self.layoutForFilters_scDataTable.addWidget(self.serachBarOfSCDataTable)

	self.scDataTable = TableWidget()

	headers = ['Id', 'Year', 'Month', 'Downtime', 'Overlapped IDs']
	self.scDataTable.setColumnCount(len(headers))
	self.scDataTable.setHorizontalHeaderLabels(headers)
	self.scDataTable.setStyleSheet(self.tableWidgetQSS)
	self.scDataTable.horizontalHeader().setStyleSheet(self.headerHorizontalQSS)
	self.scDataTable.setAlternatingRowColors(True)
	self.scDataTable.setShowGrid(False)
	self.scDataTable.setEditTriggers(QAbstractItemView.NoEditTriggers)
	mainLayout.addLayout(self.layoutForFilters_scDataTable)
	mainLayout.addWidget(self.scDataTable)

	self.scDataTable.setColumnWidth(0, int(0.1 * QApplication.primaryScreen().availableGeometry().width()))
	self.scDataTable.setColumnWidth(3, int(0.1 * QApplication.primaryScreen().availableGeometry().width()))
	self.scDataTable.setColumnWidth(4, int(0.1 * QApplication.primaryScreen().availableGeometry().width()))


	query = '''SELECT DISTINCT
			service_checks.sc_id,
			service_checks.year,
			service_checks.month
		FROM
			service_checks'''
	
	self.cursor.execute(query)
	uniqueSCData = self.cursor.fetchall()
	self.scDataTable.setRowCount(len(uniqueSCData))

	query = '''SELECT
		service_checks.sc_id,
		service_checks.trainset_id,
		service_checks.A_1,
		service_checks.A_2,
		service_checks.A_3,
		service_checks.B1_1,
		service_checks.B1_2,
		service_checks.B4,
		service_checks.B8,
		service_checks.C1,
		service_checks.C2
	FROM
		service_checks'''

	self.cursor.execute(query)
	dataForOverLaps = self.cursor.fetchall()
	# print(dataForOverLaps)
	
	dataToFindOverlappIds_SC = []
	for row in dataForOverLaps:
		for i, val in enumerate(row[2:]):
			if val:
				if i == 0:
					endDate = val + timedelta(hours=self.ASCHours)
					strr = 'A1'
				
				if i == 1:
					endDate = val + timedelta(hours=self.ASCHours)
					strr = 'A2'

				if i == 2:
					endDate = val + timedelta(hours=self.ASCHours)
					strr = 'A3'

				if i == 3:
					endDate = val + timedelta(hours=self.B1SCHours)
					strr = 'B1_1'

				if i == 4:
					endDate = val + timedelta(hours=self.B1SCHours)
					strr = 'B1_2'

				if i == 5:
					endDate = val + timedelta(hours=self.B4SCHours)
					strr = 'B4'

				if i == 6:
					endDate = val + timedelta(hours=self.B8SCHours)
					strr = 'B8'

				if i == 7:
					endDate = val + timedelta(hours=self.C1SCHours)
					strr = 'C1'

				if i == 8:
					endDate = val + timedelta(hours=self.C2SCHours)
					strr = 'C2'

				dataToFindOverlappIds_SC.append(((val, endDate), row[0]+' tr' +str(row[1]) + ' ' + strr, row[1]))

	self.totalDataToFindOverlapIds += dataToFindOverlappIds_SC



	

	def connect_button_clicked_SC(button, on_clicked_function):
		button.clicked.connect(lambda : on_clicked_function(self, button.text()))

	for i, scRowData in enumerate(uniqueSCData):
		scId = scRowData[0]
		for j, value in enumerate(scRowData):

			if j == 0:
				button = QPushButton(str(value))
				button.setStyleSheet(self.tableButtonQSS)
				connect_button_clicked_SC(button, onButtonClicked_SC)

				button.setCursor(Qt.PointingHandCursor)
				self.scDataTable.setCellWidget(i, 0, button)

			else:
				item = QTableWidgetItem(str(value))
				item.setFlags(item.flags()^Qt.ItemIsEditable)
				self.scDataTable.setItem(i, j, item)

		downtime_query = "SELECT SUM(downtime) FROM service_checks WHERE sc_id = %s"
		self.cursor.execute(downtime_query, (scId,))
		total_downtime = self.cursor.fetchone()[0]

		item = QTableWidgetItem(str(total_downtime))
		self.scDataTable.setItem(i, len(scRowData), item)
		item.setFlags(item.flags() ^Qt.ItemIsEditable)

	for row in range(self.scDataTable.rowCount()):
		for col in range(1,self.scDataTable.columnCount()):
			item = self.scDataTable.item(row, col)
			if item:
				item.setTextAlignment(Qt.AlignCenter)
	
	self.scDataTable.setColumnHidden(self.scDataTable.columnCount()-1, True)
	
	def onChangingSearchbarOf_SCDT():
		searchText = self.serachBarOfSCDataTable.text().lower()
		for row in range(self.scDataTable.rowCount()):
			self.scDataTable.setRowHidden(row, True)
			if searchText in self.scDataTable.cellWidget(row, 0).text().lower():
				self.scDataTable.setRowHidden(row, False)

			for col in range(1, self.scDataTable.columnCount()):
				item = self.scDataTable.item(row, col)
				if item is not None and searchText in item.text().lower():
					self.scDataTable.setRowHidden(row, False)
					break

	self.serachBarOfSCDataTable.textChanged.connect(onChangingSearchbarOf_SCDT)
	# onChangingSearchbarOf_SCDT()

def onButtonClicked_SC(self, scId):
	from PySide6.QtWidgets import QApplication

	self.totalDataToFindOverlapIds_SC = []

	query = '''SELECT
		trainsets.trainset,
		service_checks.year,
		service_checks.month,
		service_checks.trainset_id,
		service_checks.A_1,
		service_checks.A_2,
		service_checks.A_3,
		service_checks.B1_1,
		service_checks.B1_2,
		service_checks.B4,
		service_checks.B8,
		service_checks.C1,
		service_checks.C2
	FROM
		service_checks
	LEFT JOIN
		trainsets ON service_checks.trainset_id = trainsets.id
	WHERE
		service_checks.sc_id = %s
	'''
	self.cursor.execute(query, tuple([scId]))
	clickedSCData = self.cursor.fetchall()


	dataToFindOverlappIds_SC = []
	for row in clickedSCData:
		for i, val in enumerate(row[4:]):
			if val:
				if i == 0:
					endDate = val + timedelta(hours=self.ASCHours)
					strr = 'A1'
				
				if i == 1:
					endDate = val + timedelta(hours=self.ASCHours)
					strr = 'A2'

				if i == 2:
					endDate = val + timedelta(hours=self.ASCHours)
					strr = 'A3'

				if i == 3:
					endDate = val + timedelta(hours=self.B1SCHours)
					strr = 'B1_1'

				if i == 4:
					endDate = val + timedelta(hours=self.B1SCHours)
					strr = 'B1_2'

				if i == 5:
					endDate = val + timedelta(hours=self.B4SCHours)
					strr = 'B4'

				if i == 6:
					endDate = val + timedelta(hours=self.B8SCHours)
					strr = 'B8'

				if i == 7:
					endDate = val + timedelta(hours=self.C1SCHours)
					strr = 'C1'

				if i == 8:
					endDate = val + timedelta(hours=self.C2SCHours)
					strr = 'C2'

				dataToFindOverlappIds_SC.append(((val, endDate), scId +' tr' +str(row[0].split('#')[1]) + ' ' + strr, row[3]))

	self.totalDataToFindOverlapIds_SC += dataToFindOverlappIds_SC
	

	query1 = '''SELECT
				corrective_maintenance.cm_id,
				corrective_maintenance.work_start_at,
				corrective_maintenance.work_end_at,
				corrective_maintenance.trainset_id
				FROM
					corrective_maintenance
				WHERE
					corrective_maintenance.work_start_at BETWEEN %s AND %s
				ORDER BY work_start_at
			'''

	selected_year, selected_month = clickedSCData[0][1], clickedSCData[0][2]

	from_date = datetime(selected_year, selected_month, 1).strftime("%Y-%m-%d")
	to_date_ = datetime(selected_year, selected_month, calendar.monthrange(selected_year, selected_month)[1])
	to_date_ = to_date_ + timedelta(days=1)
	to_date = to_date_.strftime("%Y-%m-%d")


	self.cursor.execute(query1, (from_date, to_date))
	CMDataResult2 = self.cursor.fetchall()

	
	dataToFindOverlappIds_SC2 = [((row[1], row[2]), row[0], row[3]) for row in CMDataResult2]
	self.totalDataToFindOverlapIds_SC += dataToFindOverlappIds_SC2


	queryToFetchOpmData = '''SELECT 
		other_preventive_maintenance.opm_id,
		other_preventive_maintenance.work_start_at,
		other_preventive_maintenance.work_end_at,
		other_preventive_maintenance.trainset_id

	FROM
		other_preventive_maintenance
	WHERE
		other_preventive_maintenance.work_start_at BETWEEN %s AND %s

	'''



	self.cursor.execute(queryToFetchOpmData, (from_date, to_date))
	opmDataTableResult = self.cursor.fetchall()

	dataToFindOverlappIds_SC3 = [((row[1], row[2]), row[0], row[3]) for row in opmDataTableResult]

	self.totalDataToFindOverlapIds_SC += dataToFindOverlappIds_SC3

	train_id_dict = {}

	for tup in self.totalDataToFindOverlapIds_SC:
		train_id = tup[2]
		if train_id not in train_id_dict:
			train_id_dict[train_id] = []

		train_id_dict[train_id].append(tup)


	def find_totalDuration(datetime_pairs):
		totalDuration = timedelta()

		# Sort datetime pairs by start datetime
		if datetime_pairs:
			sorted_datetime_pairs = sorted(datetime_pairs, key=lambda x: x[0])
			# #print(sorted_datetime_pairs)
			# Initialize variables to keep track of the current start and end datetime
			current_start = sorted_datetime_pairs[0][0]
			current_end = sorted_datetime_pairs[0][1]

			# Iterate through the sorted datetime pairs
			for start, end in sorted_datetime_pairs[1:]:
				# Check for overlap
				if start < current_end:
					# Update the current end datetime if there is an overlap
					current_end = max(current_end, end)
				else:
					# Add the overlapping duration to the total
					totalDuration += current_end - current_start

					# Update the current start and end datetimes
					current_start = start
					current_end = end

			# Add the final overlapping duration (if any)
			totalDuration += current_end - current_start

			return totalDuration


	def find_overlapping_sets_with_ids(datetime_pairs):

		# Sort datetime pairs by start datetime
		sorted_datetime_pairs = sorted(datetime_pairs, key=lambda x: x[0][0])

		checkedIds = []
		totalSets = []
		totalSetsDurations = []
		totalSetsStartEndPairs = []
		checkedTrain = []
		# print(sorted_datetime_pairs)
		# print('--------------------------')
		for i, ((start, end), current_id, trainId) in enumerate(sorted_datetime_pairs):
			if current_id not in checkedIds:
				currentSet = [current_id]
				currentSetDurations = [end - start]
				CurrentStartEndPair = [(start, end)]
				for j in range(i+1, len(sorted_datetime_pairs)):
					if trainId == sorted_datetime_pairs[j][2]:
						if end > sorted_datetime_pairs[j][0][0]:
							# print(sorted_datetime_pairs[j][1])
							currentSet.append(sorted_datetime_pairs[j][1])
							currentSetDurations.append(sorted_datetime_pairs[j][0][1] - sorted_datetime_pairs[j][0][0])
							CurrentStartEndPair.append((sorted_datetime_pairs[j][0][0], sorted_datetime_pairs[j][0][1]))
							end = max(end, sorted_datetime_pairs[j][0][1])
				totalSets.append(currentSet)
				totalSetsDurations.append(currentSetDurations)
				totalSetsStartEndPairs.append(CurrentStartEndPair)
				checkedIds += currentSet

		return totalSets, totalSetsDurations, totalSetsStartEndPairs
	

	allSets = []
	for train_id, listt in train_id_dict.items():
		sett, settDurations, settStartEndPairs = find_overlapping_sets_with_ids(listt)
		allSets.append([sett, settDurations, settStartEndPairs])


	tableHeaderLabels_SC_ = ["Train", "A Check-I", "A Check-II", "A Check-III", "B1 Check-I", "B1 Check-II", "B4 Check", "B8 Check", "C1", "C2"]

	self.tableWidgetDownTimes_SC = TableWidget(len(self.trainsetsList), len(tableHeaderLabels_SC_))
	self.tableWidgetDownTimes_SC.setStyleSheet(self.tableWidgetQSS)
	self.tableWidgetDownTimes_SC.horizontalHeader().setStyleSheet(self.headerHorizontalQSS)
	# self.tableWidgetDownTimes_SC.verticalHeader().setStyleSheet(self.headerVerticalQSS)
	self.tableWidgetDownTimes_SC.setAlternatingRowColors(True)
	self.tableWidgetDownTimes_SC.setShowGrid(False)
	self.tableWidgetDownTimes_SC.setEditTriggers(QAbstractItemView.NoEditTriggers)

	

	self.tableWidgetDownTimes_SC.setRowCount(len(clickedSCData))
	self.tableWidgetDownTimes_SC.verticalHeader().setSectionResizeMode(QHeaderView.ResizeToContents)
	self.tableWidgetDownTimes_SC.setHorizontalHeaderLabels(tableHeaderLabels_SC_)
	# self.tableWidgetDownTimes_SC.show()

	for i, row_data in enumerate(clickedSCData):
		item = QTableWidgetItem(row_data[0])
		item.setFlags(item.flags() ^Qt.ItemIsEditable)
		self.tableWidgetDownTimes_SC.setItem(i, 0, item)


	self.tableWidgetDownTimes_SC.setColumnHidden(3, True)
	self.tableWidgetDownTimes_SC.setColumnHidden(5, True)
	self.tableWidgetDownTimes_SC.setColumnHidden(8, True)
	self.tableWidgetDownTimes_SC.setColumnHidden(9, True)
	
	# print(allSets)
	for a, trainIdsData in enumerate(allSets):
		for b, lisst in enumerate(trainIdsData[0]):
			if scId in [item.split(' ')[0] for item in lisst]:
				if len(lisst) > 1:
					totalTimeOfLisst = sum(allSets[a][1][b], timedelta())
					totalTimeOfLisstInMinutes = totalTimeOfLisst.total_seconds() / 60

					totalTimeOfLisstWithoutOverlap = find_totalDuration(allSets[a][2][b])
					totalTimeOfLisstWithoutOverlapInMinutes = totalTimeOfLisstWithoutOverlap.total_seconds() / 60

					# item = QTableWidgetItem(str(lisst))
					# item.setFlags(item.flags() & ~Qt.ItemIsEditable)
					# item.setTextAlignment(Qt.AlignCenter)
					# item.setToolTip(item.text())
					# self.cmDataTable.setItem(i, self.cmDataTable.columnCount()-2, item)

					# print(lisst)
					for idd in lisst:
						if idd.startswith('SC_'):
							[currentScId, currentTr, currentCheck] = idd.split(' ')


							if currentCheck == 'A1':
								col = 1
							elif currentCheck == 'A2':
								col = 2
							elif currentCheck == 'A3':
								col = 3
							elif currentCheck == 'B1_1':
								col = 4
							elif currentCheck == 'B1_2':
								col = 5
							elif currentCheck == 'B4':
								col = 6
							elif currentCheck == 'B8':
								col = 7
							elif currentCheck == 'C1':
								col = 8
							elif currentCheck == 'C2':
								col = 9

							for c in range(self.tableWidgetDownTimes_SC.rowCount()):
								if self.tableWidgetDownTimes_SC.item(c, 0).text()[3:] == currentTr[2:]:

									currentDurationInList = allSets[a][1][b][lisst.index(idd)]
									currentDurationInListInMinutes = currentDurationInList.total_seconds() / 60

									overlapDuration = (currentDurationInListInMinutes/totalTimeOfLisstInMinutes)*totalTimeOfLisstWithoutOverlapInMinutes

									downtimeItem = QTableWidgetItem(str(round(overlapDuration,2)))
									downtimeItem.setFlags(downtimeItem.flags() & ~Qt.ItemIsEditable)
									downtimeItem.setTextAlignment(Qt.AlignCenter)
									downtimeItem.setToolTip(downtimeItem.text())

									self.tableWidgetDownTimes_SC.setItem(c, col, downtimeItem)


				else:
					# totalTimeOfLisst = sum(allSets[a][1][b], timedelta())
					# totalTimeOfLisstInMinutes = totalTimeOfLisst.total_seconds() / 60

					[currentScId, currentTr, currentCheck] = lisst[0].split(' ')


					if currentCheck == 'A1':
						col = 1
						dt = 150
					elif currentCheck == 'A2':
						col = 2
						dt = 150
					elif currentCheck == 'A3':
						col = 3
						dt = 150
					elif currentCheck == 'B1_1':
						col = 4
						dt = 540
					elif currentCheck == 'B1_2':
						col = 5
						dt = 540
					elif currentCheck == 'B4':
						col = 6
						dt = 1020
					elif currentCheck == 'B8':
						col = 7
						dt = 1980
					elif currentCheck == 'C1':
						col = 8
						dt = 7920
					elif currentCheck == 'C2':
						col = 9
						dt = 16560

					for c in range(self.tableWidgetDownTimes_SC.rowCount()):
						if self.tableWidgetDownTimes_SC.item(c, 0).text()[3:] == currentTr[2:]:

							# currentDurationInList = allSets[a][1][b][lisst.index(lisst[0])]
							# currentDurationInListInMinutes = currentDurationInList.total_seconds() / 60

							# overlapDuration = (currentDurationInListInMinutes/totalTimeOfLisstInMinutes)*totalTimeOfLisstWithoutOverlapInMinutes
							# print(overlapDuration)



							downtimeItem = QTableWidgetItem(str(round(dt,2)))
							downtimeItem.setFlags(downtimeItem.flags() & ~Qt.ItemIsEditable)
							downtimeItem.setTextAlignment(Qt.AlignCenter)
							downtimeItem.setToolTip(downtimeItem.text())

							self.tableWidgetDownTimes_SC.setItem(c, col, downtimeItem)


					

					
					









	
	current_date_ = datetime.now().date()
	currentMonthStartingDate = datetime(current_date_.year, current_date_.month, 1)
	previous_month = currentMonthStartingDate - timedelta(days=1)
	six_months_ago = current_date_ - relativedelta(months=6)
	six_months_ago = six_months_ago.replace(day=1)

	firstDayOfSelectedYearMonth = datetime(selected_year, selected_month, 1).date()

	if (selected_year == previous_month.year and selected_month == previous_month.month) or (selected_year == current_date_.year and selected_month == current_date_.month):
		prevMonth = True
	else:
		prevMonth = False

	if ((self.userName == 'Ravikumar') and (self.editableOptionMaxDate > datetime.now().date())):
		prevMonth = True

	if self.userRole == 0:
		prevMonth = True

	if (self.userRole == 1) and (six_months_ago <= firstDayOfSelectedYearMonth <= current_date_):
		prevMonth = True

	self.scWindow = QWidget()	
	VLayout = QVBoxLayout()
	self.scWindow.setLayout(VLayout)
	self.scWindow.setWindowTitle(scId)
	self.scWindow.setWindowIcon(QIcon('Media/ramsify.png'))
	self.scWindow.setGeometry(100, 100, 1800, 850)


	##############################

	HLayoutOfSc = QHBoxLayout()
	downloadIconPath = self.currentTheme.get('downloadIcon')
	self.createPushButton('downloadButton_SCDT','', downloadIconPath, 35, 'Download')
	self.downloadButton_SCDT.setFixedHeight(23)
	HLayoutOfSc.addWidget(self.downloadButton_SCDT, alignment=Qt.AlignRight)
	VLayout.addLayout(HLayoutOfSc)

	#######################################

	formlayout_SC_ = QFormLayout()
	formlayout_SC_.addRow('Year:', QLabel(str(clickedSCData[0][1]))) 
	formlayout_SC_.addRow('Month:', QLabel(str(clickedSCData[0][2])))

	VLayout.addLayout(formlayout_SC_)

	

	self.tableWidget_SC_ = TableWidget(len(self.trainsetsList), len(tableHeaderLabels_SC_))
	self.tableWidget_SC_.setStyleSheet(self.tableWidgetQSS)
	self.tableWidget_SC_.horizontalHeader().setStyleSheet(self.headerHorizontalQSS)
	# self.tableWidget_SC_.verticalHeader().setStyleSheet(self.headerVerticalQSS)
	self.tableWidget_SC_.setAlternatingRowColors(True)
	self.tableWidget_SC_.setShowGrid(False)

	

	self.tableWidget_SC_.setRowCount(len(clickedSCData))
	self.tableWidget_SC_.verticalHeader().setSectionResizeMode(QHeaderView.ResizeToContents)
	self.tableWidget_SC_.setHorizontalHeaderLabels(tableHeaderLabels_SC_)
	layoutForTables = QHBoxLayout()
	layoutForTables.addWidget(self.tableWidget_SC_)
	self.tableWidgetDownTimes_SC.setFixedWidth(int(0.35 * QApplication.primaryScreen().availableGeometry().width()))
	layoutForTables.addWidget(self.tableWidgetDownTimes_SC)
	VLayout.addLayout(layoutForTables)

	self.createPushButton('updateButtonSC_', 'Update')
	VLayout.addWidget(self.updateButtonSC_, alignment = Qt.AlignCenter)

	for i, row_data in enumerate(clickedSCData):
		item = QTableWidgetItem(row_data[0])
		item.setFlags(item.flags() ^Qt.ItemIsEditable)
		self.tableWidget_SC_.setItem(i, 0, item)

	for i in range(len(clickedSCData)):
		for j in range (1, 10):
			widgetForCell_ = QWidget()
			hboxLayoutInCell_SC_ = QHBoxLayout()
			widgetForCell_.setLayout(hboxLayoutInCell_SC_)

			plusButtonInCell_SC_ = QPushButton('+')
			# plusButtonInCell_SC_.setStyleSheet(self.pushbuttonQSS)
			plusButtonInCell_SC_.setStyleSheet(self.pushbuttonQSS)
			plusButtonInCell_SC_.setMaximumWidth(int(0.017 * QApplication.primaryScreen().availableGeometry().width()))
			# plusButtonInCell_SC_.setMaximumWidth(70)
			hboxLayoutInCell_SC_.addWidget(plusButtonInCell_SC_)
			

			dateTimeEdit_InCell_SC_ = CustomDateTimeEdit()
			dateTimeEdit_InCell_SC_.setVisible(False)
			dateTimeEdit_InCell_SC_.setButtonSymbols(QDateTimeEdit.NoButtons)
			hboxLayoutInCell_SC_.addWidget(dateTimeEdit_InCell_SC_)
			min_dateTime = QDateTime(QDate(clickedSCData[0][1], clickedSCData[0][2], 1), QTime(0, 0))
			dateTimeEdit_InCell_SC_.setMinimumDateTime(min_dateTime)
			_, last_day = calendar.monthrange(clickedSCData[0][1], clickedSCData[0][2])

			# max_date = date(year, month, last_day)
			max_dateTime = QDateTime(QDate(clickedSCData[0][1], clickedSCData[0][2], last_day), QTime(23, 59))
			dateTimeEdit_InCell_SC_.setMaximumDateTime(max_dateTime)
			dateTimeEdit_InCell_SC_.setStyleSheet(self.dateTimeEditBoxQSS)
			dateTimeEdit_InCell_SC_.setFixedWidth(int(0.07 * QApplication.primaryScreen().availableGeometry().width()))

			crossButtonInCell_SC_ = QPushButton('X')
			crossButtonInCell_SC_.setStyleSheet(f'''{self.pushbuttonQSS} QPushButton {{ background: red; }}
													QPushButton:hover {{background: red;
													}}
													QPushButton:pressed {{
														background: red;
													}}''')
			crossButtonInCell_SC_.setVisible(False)
			hboxLayoutInCell_SC_.addWidget(crossButtonInCell_SC_)
			crossButtonInCell_SC_.setMaximumWidth(int(0.017 * QApplication.primaryScreen().availableGeometry().width()))


			def unhide_dateTimeEdit_andcrossbutton_(plus_button_, cross_button_, dateTimeEdit_):
				if plus_button_.isVisible():
					plus_button_.setVisible(False)
					cross_button_.setVisible(True)
					dateTimeEdit_.setVisible(True)
				else:
					plus_button_.setVisible(True)
					cross_button_.setVisible(False)
					dateTimeEdit_.setVisible(False)

			plusButtonInCell_SC_.clicked.connect(lambda plus_button_=plusButtonInCell_SC_, cross_button_=crossButtonInCell_SC_, dateTimeEdit_ = dateTimeEdit_InCell_SC_: unhide_dateTimeEdit_andcrossbutton_(plus_button_, cross_button_, dateTimeEdit_))
			crossButtonInCell_SC_.clicked.connect(lambda plus_button_=plusButtonInCell_SC_, cross_button_=crossButtonInCell_SC_, dateTimeEdit_ = dateTimeEdit_InCell_SC_: unhide_dateTimeEdit_andcrossbutton_(plus_button_, cross_button_, dateTimeEdit_))
		
			self.tableWidget_SC_.setCellWidget(i, j, widgetForCell_)


	self.tableWidget_SC_.setColumnHidden(3, True)
	self.tableWidget_SC_.setColumnHidden(5, True)
	self.tableWidget_SC_.setColumnHidden(8, True)
	self.tableWidget_SC_.setColumnHidden(9, True)
	
	for i in range(1,self.tableWidget_SC_.columnCount()):
		self.tableWidget_SC_.setColumnWidth(i, 180)
	
	for i, row_data in enumerate(clickedSCData):
		for j, cell_value in enumerate(row_data[4:]):
			widget_in_cell = self.tableWidget_SC_.cellWidget(i, j+1)
			
			if widget_in_cell:
				plus_button = widget_in_cell.layout().itemAt(0).widget()
				dateTimeEdit = widget_in_cell.layout().itemAt(1).widget()
				cross_button = widget_in_cell.layout().itemAt(2).widget()
				
				if cell_value is not None:
					plus_button.setVisible(False)
					cross_button.setVisible(True)
					dateTimeEdit.setVisible(True)

					qdatetime = QDateTime(cell_value)
					dateTimeEdit.setDateTime(qdatetime)

				else:
					plus_button.setVisible(True)
					dateTimeEdit.setVisible(False)
					cross_button.setVisible(False)

	if not prevMonth:
		for i in range(self.tableWidget_SC_.rowCount()):
			for column in range(1, self.tableWidget_SC_.columnCount()):
				cell_widget_ = self.tableWidget_SC_.cellWidget(i, column)
				if cell_widget_:
					wid = cell_widget_.layout().itemAt(0).widget()
					wid.setEnabled(False)
					wid = cell_widget_.layout().itemAt(1).widget()
					wid.setEnabled(False)
					wid = cell_widget_.layout().itemAt(2).widget()
					wid.setEnabled(False)

		self.updateButtonSC_.hide()

	self.scWindow.show()

	########################################

	def onClickingDownloadButton_SCDT():
		file_path, _ = QFileDialog.getSaveFileName(self, "Save Excel File", "", "Excel Files (*.xlsx)")
		if file_path:
			wb = Workbook()
			ws = wb.active		
			year_label = clickedSCData[0][1]
			month_label = clickedSCData[0][2]
			ws.append(['Year:', year_label])
			ws.append(['Month:', month_label])		
			# headers = ['Trainset', 'A Check-I', 'A Check-II', 'B1 Check-I', 'B4 Check', 'B8 Check' ]
			# ws.append(headers)

			headers = []
			for j in range(self.tableWidget_SC_.columnCount()):  
				if not self.tableWidget_SC_.isColumnHidden(j):
					header_item = self.tableWidget_SC_.horizontalHeaderItem(j)
					if header_item is not None:
						headers.append(header_item.text())
			ws.append(headers) 
			

			for i in range(self.tableWidget_SC_.rowCount()):
				row_data = []
				for j in range(self.tableWidget_SC_.columnCount()):  
					if not self.tableWidget_SC_.isColumnHidden(j):   
						if j==0:
							item = self.tableWidget_SC_.item(i, j)
							row_data.append(item.text())
						else:
							cell_widget = self.tableWidget_SC_.cellWidget(i, j)
							if cell_widget is not None:
								dateTimeEdit = cell_widget.layout().itemAt(1).widget()
								if dateTimeEdit.isVisible():
									row_data.append(dateTimeEdit.dateTime().toString("dd-MM-yyyy hh:mm"))
								else:
									row_data.append(None)
				ws.append(row_data)
			wb.save(file_path)

			ScDownloadMsgBox = QMessageBox()
			ScDownloadMsgBox.setIcon(QMessageBox.Information) 
			ScDownloadMsgBox.setText(f'Data downloaded successfully')
			ScDownloadMsgBox.setWindowTitle("Message")
			ScDownloadMsgBox.setWindowIcon(QIcon('Media/ramsify.png'))
			ScDownloadMsgBox.setStandardButtons(QMessageBox.Ok)
			ScDownloadMsgBox.exec_()

	self.downloadButton_SCDT.clicked.connect(onClickingDownloadButton_SCDT)

	#########################################


	def onClickingUpdate_SCData(scId):

		trainset_id_query = "SELECT trainset_id FROM service_checks WHERE sc_id = %s"
		self.cursor.execute(trainset_id_query, (str(scId),))
		trainset_id_result = self.cursor.fetchall()


		downtimesList = []
		if trainset_id_result:
			for i in range(self.tableWidget_SC_.rowCount()):
				trainset_id = trainset_id_result[i][0]
				row_dataa = [] 
        
				count_a = 0
				count_b1 = 0
				count_b4 = 0
				count_b8 = 0
				count_c1 = 0
				count_c2 = 0

				for column in range(1, 4): 
					cell_widget_ = self.tableWidget_SC_.cellWidget(i, column)
					if cell_widget_:
						dateTime_Edit = cell_widget_.layout().itemAt(1).widget()
						if dateTime_Edit.isVisible():
							count_a += 1

				for col in range(4, 6): 
					cell_widget_ = self.tableWidget_SC_.cellWidget(i, col)
					if cell_widget_:
						dateTime_Edit = cell_widget_.layout().itemAt(1).widget()
						if dateTime_Edit.isVisible():
							count_b1 += 1

				cell_widget_ = self.tableWidget_SC_.cellWidget(i, 6)
				if cell_widget_:
					dateTime_Edit = cell_widget_.layout().itemAt(1).widget()
					if dateTime_Edit.isVisible():
						count_b4 += 1

				cell_widget_ = self.tableWidget_SC_.cellWidget(i, 7)
				if cell_widget_:
					dateTime_Edit = cell_widget_.layout().itemAt(1).widget()
					if dateTime_Edit.isVisible():
						count_b8 += 1
        

				cell_widget_ = self.tableWidget_SC_.cellWidget(i, 8)
				if cell_widget_:
					dateTime_Edit = cell_widget_.layout().itemAt(1).widget()
					if dateTime_Edit.isVisible():
						count_c1 += 1
            

				cell_widget_ = self.tableWidget_SC_.cellWidget(i, 9)
				if cell_widget_:
					dateTime_Edit = cell_widget_.layout().itemAt(1).widget()
					if dateTime_Edit.isVisible():
						count_c2 += 1

				downtime = (count_a * self.ASCHours) + (count_b1 * self.B1SCHours) + (count_b4 * self.B4SCHours) + (count_b8 * self.B8SCHours) + (count_c1 * self.C1SCHours) + (count_c2 * self.C2SCHours)              
				downtimesList.append(downtime)
				for j in range(1, 10):
					widget_in_cell = self.tableWidget_SC_.cellWidget(i, j)
					if widget_in_cell:
						dateTimeWid = widget_in_cell.layout().itemAt(1).widget()
						
						if dateTimeWid.isVisible():
							qdatetime = dateTimeWid.dateTime().toPython()
							row_dataa.append(qdatetime)

						else :
							row_dataa.append(None)
					else :
						pass
				row_dataa.append(downtime)				
				row_dataa.append(str(scId))
				row_dataa.append(trainset_id)

				update_query = '''
					UPDATE service_checks
					SET A_1 = %s,
						A_2 = %s,
						A_3 = %s,
						B1_1 = %s,
						B1_2 = %s,
						B4 = %s,
						B8 = %s,
						C1 = %s,
						C2 = %s,
						downtime = %s
					WHERE sc_id = %s
						AND trainset_id = %s
					'''	

				self.cursor.execute(update_query, tuple(row_dataa))
				self.mydb.commit()

			scMsgBox_ = QMessageBox()
			scMsgBox_.setIcon(QMessageBox.Information) 
			scMsgBox_.setText(f'Data Updated successfully.')
			scMsgBox_.setWindowTitle("Message")
			scMsgBox_.setWindowIcon(QIcon('Media/ramsify.png'))
			scMsgBox_.setStandardButtons(QMessageBox.Ok)
			scMsgBox_.exec_()

			self.scWindow.close()
			
			for i in range(self.scDataTable.rowCount()):
				buttonn_ = self.scDataTable.cellWidget(i,0)
				if buttonn_.text() == scId:
					item = QTableWidgetItem(str(sum(downtimesList)))
					item.setFlags(item.flags() ^Qt.ItemIsEditable)
					item.setTextAlignment(Qt.AlignCenter)
					self.scDataTable.setItem(i, 3, item)
					return

	self.updateButtonSC_.clicked.connect(lambda: onClickingUpdate_SCData(scId))