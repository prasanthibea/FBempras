from PySide6.QtWidgets import QTableWidgetItem, QSpacerItem, QSizePolicy, QMessageBox, QPushButton, QFileDialog, QCheckBox, QTextEdit, QComboBox, QScrollBar, QScrollArea, QAbstractItemView,QLineEdit, QWidget, QLabel, QHBoxLayout, QVBoxLayout, QFormLayout, QHeaderView
from functions import TableWidget
from PySide6.QtCore import Qt, QDate
from PySide6.QtGui import QIcon, QColor
from openpyxl import Workbook
from datetime import date, datetime
from collections import defaultdict

def vccModDataUI(self, layout):
	from PySide6.QtWidgets import QApplication, QLabel
	
	checkAllUserIconPath = self.currentTheme.get('oppositeColorCheckBoxIcon')
	unCheckAllUserIconPath = self.currentTheme.get('oppositeColorUnCheckBoxIcon')
	partiallyCheckedIconPath = self.currentTheme.get('oppositeColorPartiallyCheckedBoxIcon')
	deleteIconPath = self.currentTheme.get('whiteDeleteIcon')
	downloadIconPath = self.currentTheme.get('downloadIcon')
	refreshTableIconPath = self.currentTheme.get('refreshIcon')


	self.createPushButton('selectAllVccButton', '', unCheckAllUserIconPath, 30)
	self.createPushButton('deleteButton_Vcc', '', deleteIconPath, 35, 'Delete')
	self.createLineEditBox('searchBarOfVcc', 'Search...' )
	self.searchBarOfVcc.setClearButtonEnabled(True)
	self.searchBarOfVcc.setFixedWidth(self.geometryWidth(0.2))
	self.createPushButton('download_Vcc', '', downloadIconPath, 35, 'Download')
	self.createPushButton('refreshButton_Vcc', '', refreshTableIconPath, 35, 'Refresh')
	self.createPushButton('newModification_Vcc', '+ New Modification', '', self.geometryWidth(0.079))
	

	self.vccHBoxLayout = QHBoxLayout()
	self.vccHBoxLayout.addWidget(self.selectAllVccButton)
	self.vccHBoxLayout.addWidget(self.deleteButton_Vcc)
	self.vccHBoxLayout.addWidget(self.searchBarOfVcc)
	self.vccHBoxLayout.addWidget(self.download_Vcc)
	self.vccHBoxLayout.addWidget(self.refreshButton_Vcc)
	self.vccHBoxLayout.addItem(QSpacerItem(1, 0, QSizePolicy.Expanding, QSizePolicy.Minimum))
	self.vccHBoxLayout.addWidget(self.newModification_Vcc)
	layout.addLayout(self.vccHBoxLayout)

	self.dataTable_VCC = TableWidget()
	self.headersOfVCCTable  = ['', 'Modification No', 'Rev', 'Modification Description', 'Car'] + self.trainsetsList
	self.dataTable_VCC.setColumnCount(len(self.headersOfVCCTable))
	self.dataTable_VCC.setHorizontalHeaderLabels(self.headersOfVCCTable)
	self.dataTable_VCC.setStyleSheet(self.tableWidgetQSS)
	self.dataTable_VCC.horizontalHeader().setStyleSheet(self.headerHorizontalQSS)
	self.dataTable_VCC.setAlternatingRowColors(True)
	self.dataTable_VCC.setShowGrid(False)
	self.dataTable_VCC.setEditTriggers(QAbstractItemView.NoEditTriggers)
	layout.addWidget(self.dataTable_VCC)

	self.selectAllVccButton.setCheckable(True)

	self.dataTable_VCC.setColumnWidth(0, self.geometryWidth(0.03))
	self.dataTable_VCC.setColumnWidth(1, self.geometryWidth(0.12))
	self.dataTable_VCC.setColumnWidth(2, self.geometryWidth(0.08))
	self.dataTable_VCC.setColumnWidth(3, self.geometryWidth(0.12))

	
	def OnClickingNewModificationButton():
		self.modificationWindow = QWidget()
		self.modificationWindow.move(600, 200)
		self.modificationWindow.resize(600, 400)
		self.modificationWindow.setWindowTitle('New Modification')
		self.modificationWindow.setWindowIcon(QIcon('Media/ramsify.png'))


		vboxLayout = QVBoxLayout()
		formLayout = QFormLayout()
		vboxLayout.addLayout(formLayout)

		self.modificationWindow.setLayout(vboxLayout)

		self.createLineEditBox('modificatioLineEdit_VCC')
		self.createNumberLineEditBox('revLineEdit_VCC')
		self.createTextEditBox('description_VCC')
		self.createCheckableComboBox(self.carsList, 'carComboBox_VCC')
		self.createCheckableComboBox(self.trainsetsList, 'factoryTrainComboBox_VCC')
		
		formLayout.addRow('Modification No: <font color="red">*</font>', self.modificatioLineEdit_VCC)
		formLayout.addRow('Rev: <font color="red">*</font>', self.revLineEdit_VCC)
		formLayout.addRow('Description: <font color="red">*</font>', self.description_VCC)
		formLayout.addRow('Cars: <font color="red">*</font>', self.carComboBox_VCC)
		formLayout.addRow('Factory Trains: ', self.factoryTrainComboBox_VCC)

		self.createPushButton('submitBtn_VCC', 'Submit', '',self.geometryWidth(0.04))
		self.createPushButton('cancelBtn_VCC', 'Cancel', '',self.geometryWidth(0.04))

		# vboxLayout.addWidget(self.submitBtn_VCC, alignment = Qt.AlignCenter)
		hBoxLayout = QHBoxLayout()
		hBoxLayout.addWidget(self.submitBtn_VCC, alignment = Qt.AlignRight)
		hBoxLayout.addWidget(self.cancelBtn_VCC, alignment = Qt.AlignLeft)

		vboxLayout.addLayout(hBoxLayout)
			

		allFieldsData = [self.modificatioLineEdit_VCC, self.revLineEdit_VCC, self.description_VCC, self.carComboBox_VCC, self.factoryTrainComboBox_VCC]
			
		def onClickingSubmit_VCC():
			mandatoryVerification_VCC = True
			mandatoryIndexesVcc = [0, 1, 2, 3]
			vccmoddata = []

			for i, wid in enumerate(allFieldsData):
				if isinstance(wid, QLineEdit):
					if wid.text() == '':
						vccmoddata.append(None)
						if i in mandatoryIndexesVcc:
							mandatoryVerification_VCC = False
							wid.setProperty("error", True)
							wid.setStyleSheet(self.lineEditBoxQSS)
					else:
						if wid.text().isdigit():
							vccmoddata.append(int(wid.text().strip()))
						else:
							vccmoddata.append(wid.text().strip()) 	

						wid.setProperty("error", False)
						wid.setStyleSheet(self.lineEditBoxQSS)

				if isinstance(wid, QTextEdit):
					if wid.toPlainText() == '':
						vccmoddata.append(None)
						if i in mandatoryIndexesVcc:
							mandatoryVerification_VCC = False
							wid.setProperty("error", True)
							wid.setStyleSheet(self.textEditBoxQSS)

					else:
						vccmoddata.append(wid.toPlainText().strip())
						wid.setProperty("error", False)
						wid.setStyleSheet(self.textEditBoxQSS)

				if isinstance(wid, QComboBox):
					if wid.isEnabled():
						if wid.currentText() == '':
							vccmoddata.append(None)
							if i in mandatoryIndexesVcc:
								mandatoryVerification_VCC = False
								wid.setProperty("error", True)
								wid.setStyleSheet(self.comboBoxQSS)

						else:
							vccmoddata.append(wid.currentText())
							wid.setProperty("error", False)
							wid.setStyleSheet(self.comboBoxQSS)

				
			vccmoddata.append(self.user_id)

			if not mandatoryVerification_VCC:
				print('Mandatory fields missing.')

			else:
				query = '''
							SELECT rev
							FROM vcc
							WHERE modification_no = %s AND rev = %s AND deleted_at IS NULL
						'''

				self.cursor.execute(query, (vccmoddata[0], vccmoddata[1]))
				resultRev = self.cursor.fetchall()

				if len(resultRev) > 0:
					QMessageBox.critical(self, "Duplicate Entry", "Duplicate Modification number with revision.")

				else:
			
					query = """
						INSERT INTO vcc				
						(modification_no, rev, modification_description, car, factory_trains, user_id) 
						VALUES (%s, %s, %s, %s, %s, %s)
					""" 

					try:
						self.cursor.execute(query, tuple(vccmoddata))
						self.mydb.commit()
						self.refreshButton_Vcc.click()

						vccSubmitMsgBox = QMessageBox()
						vccSubmitMsgBox.setIcon(QMessageBox.Information) 
						vccSubmitMsgBox.setText(f'Data Submitted successfully.')
						vccSubmitMsgBox.setWindowTitle("Message")
						vccSubmitMsgBox.setWindowIcon(QIcon('Media/ramsify.png'))
						vccSubmitMsgBox.setStandardButtons(QMessageBox.Ok)
						vccSubmitMsgBox.exec_()
						self.modificationWindow.close()

					except Exception as e:
						QMessageBox.critical(self, "Database Error", f"An error occurred: {e}")

		self.submitBtn_VCC.clicked.connect(onClickingSubmit_VCC)

		self.modificationWindow.show()

		def onClickingCancel_VCC():
			self.modificatioLineEdit_VCC.clear()
			self.revLineEdit_VCC.clear()
			self.description_VCC.clear()
			self.carComboBox_VCC.clearItems()
			self.factoryTrainComboBox_VCC.clearItems()

		self.cancelBtn_VCC.clicked.connect(onClickingCancel_VCC)


	self.newModification_Vcc.clicked.connect(OnClickingNewModificationButton)


	

	def onClickingRefreshButton_Vcc():
		self.deleteButton_Vcc.hide()
		self.selectAllVccButton.setIcon(QIcon(unCheckAllUserIconPath))

		queryone = '''
			SELECT
				modification_no,
				rev,
				modification_description,
				car,
				factory_trains
			FROM
				vcc
			WHERE
				deleted_at IS NULL
			ORDER BY
				modification_no ASC
				
		'''
		self.cursor.execute(queryone)
		vccDataResultWithCombinedCars = self.cursor.fetchall()

		vccDataResult = []

		for row in vccDataResultWithCombinedCars:
			modification_no, rev, modification_description, car, factory_trains = row
			
			# Split the 'car' field if it contains multiple values separated by ', '
			car_split = car.split(', ') if car else ()
			factory_trains_split = factory_trains.split(', ') if factory_trains else []
			
			# Append the processed row with the split car values
			vccDataResult.append((modification_no, rev, modification_description, car_split, factory_trains_split))

		def givingFunctionalityToButton(button, funct, data):
			button.clicked.connect(lambda: funct(data))

		def onbuttonClickedVcc(dataofvcc):
			self.vccWindow = QWidget()
			self.vccWindow.move(600, 200)
			self.vccWindow.resize(600, 400)

			self.vccWindow.setWindowTitle(dataofvcc[0])
			self.vccWindow.setWindowIcon(QIcon('Media/ramsify.png'))

			scrollArea = QScrollArea()
			scrollArea.setWidgetResizable(True)
			scrollArea.setStyleSheet(self.scrollAreaQSS)
			self.vccWindow.setLayout(QVBoxLayout())
			self.vccWindow.layout().addWidget(scrollArea)

			contentsWidget = QWidget()
			vboxLayout = QVBoxLayout()
			contentsWidget.setLayout(vboxLayout)
			scrollArea.setWidget(contentsWidget)

			formLayout = QFormLayout()
			vboxLayout.addLayout(formLayout)

			self.createLineEditBox('modificatioLineEdit_VCC_')
			self.modificatioLineEdit_VCC_.setText(dataofvcc[0])

			self.createNumberLineEditBox('revLineEdit_VCC_')
			self.revLineEdit_VCC_.setText(str(dataofvcc[1]))
			self.revLineEdit_VCC_.setToolTip(str(dataofvcc[1]))

			self.createTextEditBox('description_VCC_')
			self.description_VCC_.setText(dataofvcc[2])
			self.description_VCC_.setToolTip(dataofvcc[2])

			self.createCheckableComboBox(self.carsList, 'carComboBox_VCC_')
			selected_caritems = [dataofvcc[3]]
			self.carComboBox_VCC_.selectItems(str(selected_caritems))
			
			self.createCheckableComboBox(self.trainsetsList, 'factoryTrainComboBox_VCC_')
			selected_items = [dataofvcc[4]]
			self.factoryTrainComboBox_VCC_.selectItems(str(selected_items))
			
			
			formLayout.addRow('Modification No: <font color="red">*</font>', self.modificatioLineEdit_VCC_)
			formLayout.addRow('Rev: <font color="red">*</font>', self.revLineEdit_VCC_)
			formLayout.addRow('Description: <font color="red">*</font>', self.description_VCC_)
			formLayout.addRow('Cars: <font color="red">*</font>', self.carComboBox_VCC_)
			formLayout.addRow('Factory Trains: ', self.factoryTrainComboBox_VCC_)

			self.createPushButton('updateBtn_VCC', 'Update', '', self.geometryWidth(0.04))
			vboxLayout.addWidget(self.updateBtn_VCC, alignment = Qt.AlignCenter)

				

			allFieldsData_ = [self.modificatioLineEdit_VCC_, self.revLineEdit_VCC_, self.description_VCC_, self.carComboBox_VCC_, self.factoryTrainComboBox_VCC_]
			

			def setToolTip(wid, text):
				wid.setToolTip(text)

			def settingToolTipToLineEdits(wid):
				wid.textChanged.connect(lambda: setToolTip(wid, wid.text()))

			def settingToolTipToTextEdits(wid):
				wid.textChanged.connect(lambda: setToolTip(wid, wid.toPlainText()))

			for wid in allFieldsData_:
				if isinstance(wid, QLineEdit):
					settingToolTipToLineEdits(wid)

				if isinstance(wid, QTextEdit):
					settingToolTipToTextEdits(wid)
			

			def onClickingUpdateVccDataButton():
				mandatoryVerification_VCC = True
				mandatoryIndexesVcc = [0, 1, 2, 3]
				vccUpdateFormData = []

				for i, wid in enumerate(allFieldsData_):
					if isinstance(wid, QLineEdit):
						if wid.text() == '':
							vccUpdateFormData.append(None)
							if i in mandatoryIndexesNcr:
								mandatoryVerification_NCR = False
								wid.setProperty("error", True)
								wid.setStyleSheet(self.lineEditBoxQSS)
						else:
							if wid.text().isdigit():
								vccUpdateFormData.append(int(wid.text().strip()))
								
							else:
								vccUpdateFormData.append(wid.text().strip())
								
							wid.setProperty("error", False)
							wid.setStyleSheet(self.lineEditBoxQSS)
						

					if isinstance(wid, QTextEdit):
						if wid.toPlainText() == '':
							vccUpdateFormData.append(None)
							if i in mandatoryIndexesVcc:
								mandatoryVerification_VCC = False
								wid.setProperty("error", True)
								wid.setStyleSheet(self.textEditBoxQSS)
						else:
							vccUpdateFormData.append(wid.toPlainText().strip())
							wid.setProperty("error", False)
							wid.setStyleSheet(self.textEditBoxQSS)

					if isinstance(wid, QComboBox):
						if wid.isEnabled():
							if wid.currentText() == '':
								vccUpdateFormData.append(None)
								if i in mandatoryIndexesVcc:
									mandatoryVerification_VCC = False
									wid.setProperty("error", True)
									wid.setStyleSheet(self.comboBoxQSS)

							else:
								vccUpdateFormData.append(wid.currentText())
								wid.setProperty("error", False)
								wid.setStyleSheet(self.comboBoxQSS)
						else:
							vccUpdateFormData.append(None)
	

				if not mandatoryVerification_VCC:
					print('Mandatory fields missing.')


				else:
					query = '''
								SELECT modification_no
								FROM vcc
								WHERE modification_no = %s AND rev = %s AND deleted_at IS NULL
							'''

					self.cursor.execute(query, (vccUpdateFormData[0], vccUpdateFormData[1]))
					resultRev = self.cursor.fetchall()


					def updatingDatabase():
						vccUpdateFormData.append(self.user_id)
						update_queryone = """
											UPDATE vcc
											SET
												modification_no = %s,
												rev = %s,
												modification_description = %s,
												car = %s,
												factory_trains = %s,
												user_id = %s
											WHERE modification_no = %s AND rev = %s
										"""
						vccUpdateFormData.append(dataofvcc[0])
						vccUpdateFormData.append(dataofvcc[1])

						try:
							self.cursor.execute(update_queryone, tuple(vccUpdateFormData))
							self.mydb.commit()
							self.refreshButton_Vcc.click()

							vccUpdateMsgBox = QMessageBox()
							vccUpdateMsgBox.setIcon(QMessageBox.Information) 
							vccUpdateMsgBox.setText(f'Data Updated successfully.')
							vccUpdateMsgBox.setWindowTitle("Message")
							vccUpdateMsgBox.setWindowIcon(QIcon('Media/ramsify.png'))
							vccUpdateMsgBox.setStandardButtons(QMessageBox.Ok)
							vccUpdateMsgBox.exec_()

							self.vccWindow.close()

						except Exception as e:
							QMessageBox.critical(self, "Database Error", f"An error occurred: {e}")


					if (vccUpdateFormData[0] == dataofvcc[0]) and (vccUpdateFormData[1] == dataofvcc[1]):
						if len(resultRev) == 1:
							updatingDatabase()

					else:
						if len(resultRev) == 0:
							updatingDatabase()
						else:
							QMessageBox.critical(self, "Duplicate Entry", "Duplicate Modification number with revision.")


			self.updateBtn_VCC.clicked.connect(onClickingUpdateVccDataButton)

			self.vccWindow.show()


		self.dataTable_VCC.setRowCount(0)		

		for rowIndex, rowData in enumerate(vccDataResult):
			self.dataTable_VCC.insertRow(self.dataTable_VCC.rowCount())
			factory_trains = rowData[4]

			vccCheckBoxWidget = QCheckBox('')
			vccCheckBoxWidget.setStyleSheet(self.checkBoxQSS)
			self.dataTable_VCC.setCellWidget(self.dataTable_VCC.rowCount()-1, 0, vccCheckBoxWidget)
			vccCheckBoxWidget.stateChanged.connect(onStateChangedOf_VCCCheckBox)

			for colIndex, vcData in enumerate(rowData[:-1]):
				if colIndex == 0: 
					button = QPushButton(str(vcData))
					givingFunctionalityToButton(button, onbuttonClickedVcc, rowData)
					button.setStyleSheet(self.tableButtonQSS)
					button.setCursor(Qt.PointingHandCursor)
					self.dataTable_VCC.setCellWidget(self.dataTable_VCC.rowCount()-1, 1, button)

				else:
					item = QTableWidgetItem(str(vcData) if vcData is not None else '')
					item.setTextAlignment(Qt.AlignCenter)
					item.setToolTip(item.text())
					self.dataTable_VCC.setItem(self.dataTable_VCC.rowCount() - 1, colIndex + 1, item)


			query_opm = '''
							SELECT
								opm.car_number, trainsets.trainset, opm.work_start_at
							FROM
								other_preventive_maintenance AS opm

							JOIN
								trainsets ON opm.trainset_id = trainsets.id
							
							WHERE
								opm.t_c_no = %s AND
								opm.t_c_rev = %s AND
								opm.opm_type = 'VCC'
						'''

			self.cursor.execute(query_opm, (rowData[0], rowData[1]))
			opmDataResult = self.cursor.fetchall()

			desired_cars = rowData[3]
			
			# Grouping by trainset
			grouped_by_trainset = defaultdict(list)
			trainset_work_start_date = defaultdict(dict)  # Store start dates for completed cars

			for car, trainset, work_start_date in opmDataResult:
				grouped_by_trainset[trainset].append(car)
				trainset_work_start_date[trainset][car] = work_start_date  # Save start date per car


			for trainset in self.trainsetsList:
				trainset_col_index = self.headersOfVCCTable.index(trainset)  # Get the index of each trainset header
				
				if not factory_trains:
					factory_trains = []
					
				if trainset in factory_trains:  # Check if this trainset is in factory_trains
					item = QTableWidgetItem("Factory")
					item.setBackground(QColor(self.currentTheme.get('grayBGColor')))
				else:
					if trainset in grouped_by_trainset.keys():
						if set(desired_cars).issubset(set(grouped_by_trainset[trainset])):
							item = QTableWidgetItem("Completed")
							item.setBackground(QColor(self.currentTheme.get('greenBGColor')))
						else:
							item = QTableWidgetItem("Pending")
							item.setBackground(QColor(self.currentTheme.get('orangeBGColor')))

					else:
						item = QTableWidgetItem("Pending")
						item.setBackground(QColor(self.currentTheme.get('orangeBGColor')))


					toolTipText = ''
					for car in desired_cars:
						toolTipText += f"{car}:    {trainset_work_start_date.get(trainset, {}).get(car, '')}\n"
					item.setToolTip(toolTipText)


				item.setTextAlignment(Qt.AlignCenter)
				self.dataTable_VCC.setItem(self.dataTable_VCC.rowCount() - 1, trainset_col_index, item)

		

	self.refreshButton_Vcc.clicked.connect(onClickingRefreshButton_Vcc)

	def onSearchBox_Vcc_Button():

		searchText = self.searchBarOfVcc.text().lower()

		for row in range(self.dataTable_VCC.rowCount()):
			self.dataTable_VCC.setRowHidden(row, True)

			if self.dataTable_VCC.cellWidget(row, 1) and (searchText in self.dataTable_VCC.cellWidget(row, 1).text().lower()):
				self.dataTable_VCC.setRowHidden(row, False)
				continue

			for col in range(2, self.dataTable_VCC.columnCount()):
				item = self.dataTable_VCC.item(row, col)
				if item and searchText in item.text().lower():
					self.dataTable_VCC.setRowHidden(row, False)
					break

	self.searchBarOfVcc.textChanged.connect(onSearchBox_Vcc_Button)


	def onClickingDownloadBtn_VCCDT():
		file_path, _ = QFileDialog.getSaveFileName(self, "Save Excel File", "", "Excel Files (*.xlsx)")

		if file_path:

			wb = Workbook()
			ws = wb.active

			headers = []
			for col in range(1, self.dataTable_VCC.columnCount()):
				if not self.dataTable_VCC.isColumnHidden(col):
					header_item = self.dataTable_VCC.horizontalHeaderItem(col)
					if header_item is not None:
						headers.append(header_item.text())

			ws.append(headers)

			row_index = 2
			for row in range(self.dataTable_VCC.rowCount()):
				if not self.dataTable_VCC.isRowHidden(row):
					for col in range(1, self.dataTable_VCC.columnCount()):
						if col == 1:
							wid = self.dataTable_VCC.cellWidget(row, col)
							if isinstance(wid, QPushButton):
								ws.cell(row=row_index, column=col).value = wid.text()
						else:	
							item = self.dataTable_VCC.item(row, col)
							if item is not None:
								ws.cell(row=row_index, column=col).value = item.text()

					row_index += 1

			wb.save(file_path)

			vccDownloadedMsgBox = QMessageBox()
			vccDownloadedMsgBox.setIcon(QMessageBox.Information) 
			vccDownloadedMsgBox.setText(f'Data downloaded successfully')
			vccDownloadedMsgBox.setWindowTitle("Message")
			vccDownloadedMsgBox.setWindowIcon(QIcon('Media/ramsify.png'))
			vccDownloadedMsgBox.setStandardButtons(QMessageBox.Ok)
			vccDownloadedMsgBox.exec_()

	self.download_Vcc.clicked.connect(onClickingDownloadBtn_VCCDT)

	def onClicking_SelectAll_VCCDT(checked):
		if checked:
			self.selectAllVccButton.setIcon(QIcon(checkAllUserIconPath))

			for i in range(self.dataTable_VCC.rowCount()):
				if not self.dataTable_VCC.isRowHidden(i):
					if isinstance(self.dataTable_VCC.cellWidget(i,0), QCheckBox):
						self.dataTable_VCC.cellWidget(i,0).setCheckState(Qt.Checked)
		
		else:
			self.selectAllVccButton.setIcon(QIcon(unCheckAllUserIconPath))

			for i in range(self.dataTable_VCC.rowCount()):
				if not self.dataTable_VCC.isRowHidden(i):
					if isinstance(self.dataTable_VCC.cellWidget(i,0), QCheckBox):
						self.dataTable_VCC.cellWidget(i,0).setCheckState(Qt.Unchecked)
	
	self.selectAllVccButton.toggled.connect(onClicking_SelectAll_VCCDT)


	def onStateChangedOf_VCCCheckBox():
		all_checked = True
		all_unchecked = True

		for i in range(self.dataTable_VCC.rowCount()):
			if not self.dataTable_VCC.isRowHidden(i):
				if isinstance(self.dataTable_VCC.cellWidget(i,0), QCheckBox):
					if self.dataTable_VCC.cellWidget(i,0).isChecked():
						all_unchecked = False
					else:
						all_checked = False

		if all_checked or all_unchecked:
			some_checked = False
		else:
			some_checked = True


		if all_checked:
			self.deleteButton_Vcc.show()
			self.selectAllVccButton.setIcon(QIcon(checkAllUserIconPath))
			self.selectAllVccButton.setChecked(True)
			

		if all_unchecked:
			self.deleteButton_Vcc.hide()
			self.selectAllVccButton.setIcon(QIcon(unCheckAllUserIconPath))
			self.selectAllVccButton.setChecked(False)

		if some_checked:
			self.deleteButton_Vcc.show()
			self.selectAllVccButton.setIcon(QIcon(partiallyCheckedIconPath))


	def onClicking_Delete_VCCDT():
			
		selectedVccnoIndices_ = []
		selectedVccnos = []
		selectedRevs = []

		numberOfSelectedVccnos = 0

		for i in range(self.dataTable_VCC.rowCount()):
			if not self.dataTable_VCC.isRowHidden(i):
				if isinstance(self.dataTable_VCC.cellWidget(i,0), QCheckBox):
					if self.dataTable_VCC.cellWidget(i,0).checkState() == Qt.Checked:
						selectedVccnoIndices_.append(i)

						vccnoButton = self.dataTable_VCC.cellWidget(i, 1)
						if vccnoButton:
							selectedVccnos.append(vccnoButton.text())
							numberOfSelectedVccnos += 1
						rev = self.dataTable_VCC.item(i, 2).text()
						selectedRevs.append(int(rev))
		

		if selectedVccnos:

			confirmDeleteVCCMsgBox = QMessageBox()
			confirmDeleteVCCMsgBox.setIcon(QMessageBox.Question) 
			confirmDeleteVCCMsgBox.setText(f"Are you sure you want to delete {numberOfSelectedVccnos} VCC(s)?")
			confirmDeleteVCCMsgBox.setWindowTitle("Confirm")
			confirmDeleteVCCMsgBox.setWindowIcon(QIcon('Media/ramsify.png'))
			confirmDeleteVCCMsgBox.setStandardButtons(QMessageBox.Ok | QMessageBox.No)
			
			userResponse = confirmDeleteVCCMsgBox.exec()

			if userResponse == QMessageBox.Ok:
				current_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
				for ind in sorted(selectedVccnoIndices_, reverse=True):
					vccnoToDelete = selectedVccnos[selectedVccnoIndices_.index(ind)]
					revOfVccNoToDelete = selectedRevs[selectedVccnoIndices_.index(ind)]
					sql = "UPDATE vcc SET deleted_at = %s, user_id = %s WHERE modification_no = %s AND rev = %s"
					values = (current_time, self.user_id, vccnoToDelete, revOfVccNoToDelete)
					self.cursor.execute(sql, values)
					self.mydb.commit()
					self.dataTable_VCC.removeRow(ind)

				vccDeleteSuccessMsgBox = QMessageBox()
				vccDeleteSuccessMsgBox.setIcon(QMessageBox.Information) 
				vccDeleteSuccessMsgBox.setText(f'{numberOfSelectedVccnos} VCC(s) deleted successfully.')
				vccDeleteSuccessMsgBox.setWindowTitle("Message")
				vccDeleteSuccessMsgBox.setWindowIcon(QIcon('Media/ramsify.png'))
				vccDeleteSuccessMsgBox.setStandardButtons(QMessageBox.Ok)
				vccDeleteSuccessMsgBox.exec()
			
				self.deleteButton_Vcc.hide()
				self.selectAllVccButton.setIcon(QIcon(unCheckAllUserIconPath))
			
			else:
				pass


	self.deleteButton_Vcc.clicked.connect(onClicking_Delete_VCCDT)

	onClickingRefreshButton_Vcc()

	