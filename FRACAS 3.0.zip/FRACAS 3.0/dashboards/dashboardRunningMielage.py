from PySide6.QtWidgets import QTableWidgetItem, QWidget, QLabel, QHBoxLayout, QSpacerItem, QSizePolicy, QFormLayout, QAbstractItemView
from functions import TableWidget
from PySide6.QtCore import Qt
from datetime import datetime, timedelta, date
from dateutil.relativedelta import relativedelta
import calendar

def dashboardRunningmileageUI(self):
	from PySide6.QtWidgets import QApplication
	self.layoutForFilters_RMDash = QHBoxLayout()
	self.fromFormLayout_RMDash = QFormLayout()
	self.toFormLayout_RMDash = QFormLayout()


	currentYear = datetime.now().year
	currentMonth = datetime.now().month

	firstDayOfNextMonth = (datetime(currentYear, currentMonth, 1) + relativedelta(months=1)).date()
	lastDayOfCurrentMonth = (firstDayOfNextMonth - relativedelta(days=1))
	
	start_date = datetime(self.startingYear, self.startingMonth, 1).date()
	end_date = lastDayOfCurrentMonth

	current_date = start_date
	yearMonthStringsForCalculations = []
	yearMonthValuesForCalculations = []

	while current_date <= end_date:
		if (current_date.month != currentMonth) or (current_date.year != currentYear):
			yearMonthValuesForCalculations.append((current_date.year, current_date.month))
			formatted_month = current_date.strftime('%b - %Y')
			yearMonthStringsForCalculations.append(formatted_month)

		# Move to the next month
		current_date += relativedelta(months=1)

	self.createComboBox(yearMonthStringsForCalculations, 'fromCombobox_RMDash') 
	self.createComboBox(yearMonthStringsForCalculations, 'toCombobox_RMDash')

	self.fromFormLayout_RMDash.addRow(QLabel('From: '), self.fromCombobox_RMDash)
	self.toFormLayout_RMDash.addRow(QLabel('To: '), self.toCombobox_RMDash)


	clearFilterIconPath = self.currentTheme.get('clearTableFilterIcon')
	refreshTableIconPath = self.currentTheme.get('refreshIcon')

	self.createPushButton('clearAllFiltersButton_RMDash', '', clearFilterIconPath, 35, 'Clear Filters')
	self.createPushButton('refreshBtn_RMDash','', refreshTableIconPath, 35, 'Refresh')
	self.refreshBtn_RMDash.clicked.connect(lambda: self.onClickingRefresh_RM(self.mainVerticalLayout_RM))

	self.layoutForFilters_RMDash.addItem(QSpacerItem(1, 0, QSizePolicy.Expanding, QSizePolicy.Minimum))
	self.layoutForFilters_RMDash.addLayout(self.fromFormLayout_RMDash)
	self.layoutForFilters_RMDash.addLayout(self.toFormLayout_RMDash)
	self.layoutForFilters_RMDash.addWidget(self.clearAllFiltersButton_RMDash)
	self.layoutForFilters_RMDash.addWidget(self.refreshBtn_RMDash)

	self.mainVerticalLayout_RM.addLayout(self.layoutForFilters_RMDash)
	rmLabel = QLabel('Monthly Running Mileage')
	rmLabel.setStyleSheet("font-size: 14pt;")
	self.mainVerticalLayout_RM.addWidget(rmLabel)



	self.dashboardRmMonthlyTable  = TableWidget()
	headers = [''] + yearMonthStringsForCalculations 
	self.dashboardRmMonthlyTable.setColumnCount(len(headers))
	self.dashboardRmMonthlyTable.setHorizontalHeaderLabels(headers)
	self.dashboardRmMonthlyTable.setStyleSheet(self.tableWidgetQSS)
	self.dashboardRmMonthlyTable.horizontalHeader().setStyleSheet(self.headerHorizontalQSS)
	# self.dashboardRmMonthlyTable.verticalHeader().setStyleSheet(self.headerVerticalQSS)
	self.dashboardRmMonthlyTable.setAlternatingRowColors(True)
	self.dashboardRmMonthlyTable.setFixedHeight(int(0.15 * QApplication.primaryScreen().availableGeometry().height()))
	self.dashboardRmMonthlyTable.setShowGrid(False)
	self.mainVerticalLayout_RM.addWidget(self.dashboardRmMonthlyTable)
	self.dashboardRmMonthlyTable.setEditTriggers(QAbstractItemView.NoEditTriggers)

	self.dashboardRmMonthlyTable.setColumnWidth(0, int(0.2 * QApplication.primaryScreen().availableGeometry().width()))
	for i in range(1, self.dashboardRmMonthlyTable.columnCount()):
		self.dashboardRmMonthlyTable.setColumnWidth(i, int(0.07 * QApplication.primaryScreen().availableGeometry().width()))

	

	firstColumn = self.uniqueLines + ['Total']
	self.dashboardRmMonthlyTable.setRowCount(len(firstColumn))

	for i, strr in enumerate(firstColumn):
		self.dashboardRmMonthlyTable.setItem(i, 0, QTableWidgetItem(strr))


	armLabel = QLabel('Accumulated Running Mileage')
	armLabel.setStyleSheet("font-size: 14pt;")
	self.mainVerticalLayout_RM.addWidget(armLabel)

	self.dashboardRmAccumulatedTable  = TableWidget()
	headers = [''] + yearMonthStringsForCalculations
	self.dashboardRmAccumulatedTable.setColumnCount(len(headers))
	self.dashboardRmAccumulatedTable.setHorizontalHeaderLabels(headers)
	self.dashboardRmAccumulatedTable.setStyleSheet(self.tableWidgetQSS)
	self.dashboardRmAccumulatedTable.horizontalHeader().setStyleSheet(self.headerHorizontalQSS)
	# self.dashboardRmAccumulatedTable.verticalHeader().setStyleSheet(self.headerVerticalQSS)
	self.dashboardRmAccumulatedTable.setAlternatingRowColors(True)
	self.dashboardRmAccumulatedTable.setShowGrid(False)
	self.dashboardRmAccumulatedTable.setFixedHeight(int(0.24 * QApplication.primaryScreen().availableGeometry().height()))
	self.mainVerticalLayout_RM.addWidget(self.dashboardRmAccumulatedTable)
	self.dashboardRmAccumulatedTable.setEditTriggers(QAbstractItemView.NoEditTriggers)

	self.dashboardRmAccumulatedTable.setColumnWidth(0, int(0.2 * QApplication.primaryScreen().availableGeometry().width()))
	for i in range(1, self.dashboardRmAccumulatedTable.columnCount()):
		self.dashboardRmAccumulatedTable.setColumnWidth(i, int(0.07 * QApplication.primaryScreen().availableGeometry().width()))

	firstColumn = []
	for lin in self.uniqueLines:
		firstColumn.append(f'Accumulated Running Mileage For {lin} (6M)')
	firstColumn.append('Accumulated Running Mileage For All Trains (6M)')

	for lin in self.uniqueLines:
		firstColumn.append(f'Accumulated Running Mileage For {lin}')
	firstColumn.append('Accumulated Running Mileage For All Trains')

	self.dashboardRmAccumulatedTable.setRowCount(len(firstColumn))

	for i, strr in enumerate(firstColumn):
		item = QTableWidgetItem(strr)
		# item.setTextAlignment(Qt.AlignCenter)
		self.dashboardRmAccumulatedTable.setItem(i, 0, item)


	averageRmLabel = QLabel('Average Running Mileage')
	averageRmLabel.setStyleSheet("font-size: 14pt;")
	self.mainVerticalLayout_RM.addWidget(averageRmLabel)

	self.dashboardRmAvgTable  = TableWidget()
	headers = [''] + yearMonthStringsForCalculations
	self.dashboardRmAvgTable.setColumnCount(len(headers))
	self.dashboardRmAvgTable.setHorizontalHeaderLabels(headers)
	self.dashboardRmAvgTable.setStyleSheet(self.tableWidgetQSS)
	self.dashboardRmAvgTable.horizontalHeader().setStyleSheet(self.headerHorizontalQSS)
	# self.dashboardRmAvgTable.verticalHeader().setStyleSheet(self.headerVerticalQSS)
	self.dashboardRmAvgTable.setAlternatingRowColors(True)
	self.dashboardRmAvgTable.setShowGrid(False)
	self.dashboardRmAvgTable.setFixedHeight(int(0.1 * QApplication.primaryScreen().availableGeometry().height()))
	self.dashboardRmAvgTable.setEditTriggers(QAbstractItemView.NoEditTriggers)
	self.mainVerticalLayout_RM.addWidget(self.dashboardRmAvgTable)

	self.dashboardRmAvgTable.setColumnWidth(0, int(0.2 * QApplication.primaryScreen().availableGeometry().width()))
	for i in range(1, self.dashboardRmAvgTable.columnCount()):
		self.dashboardRmAvgTable.setColumnWidth(i, int(0.07 * QApplication.primaryScreen().availableGeometry().width()))


	firstColumn = ['Average running mileage (per train/Month)']
	self.dashboardRmAvgTable.setRowCount(len(firstColumn))
	for i, stri in enumerate(firstColumn):
		item = QTableWidgetItem(stri)
		# item.setTextAlignment(Qt.AlignCenter)
		self.dashboardRmAvgTable.setItem(i,0, item)

	self.listOfLinesTablesInRMDash = []
	allLinesAllMonthsRunningMileagesSum = []
	for h, line_name in enumerate(self.uniqueLines):

		label = QLabel(f'Running Mileage for {line_name}')
		label.setStyleSheet("font-size: 14pt;")
		self.mainVerticalLayout_RM.addWidget(label)

		query = f"SELECT trainset, revenue_date FROM trainsets WHERE line = '{line_name}' AND deleted_at IS NULL ORDER BY trainset"
		self.cursor.execute(query)
		trainNames_ = self.cursor.fetchall()
		trainNames = [train[0] for train in trainNames_]
		revenueDates = [date[1] for date in trainNames_]
		
		table_widget = TableWidget()
		self.listOfLinesTablesInRMDash.append(table_widget)
		headers = ['Train set', 'Start of Revenue Service'] + yearMonthStringsForCalculations
		table_widget.setColumnCount(len(headers))
		table_widget.setHorizontalHeaderLabels(headers)
		table_widget.setStyleSheet(self.tableWidgetQSS)
		table_widget.horizontalHeader().setStyleSheet(self.headerHorizontalQSS)
		# table_widget.verticalHeader().setStyleSheet(self.headerVerticalQSS)
		table_widget.setAlternatingRowColors(True)
		table_widget.setShowGrid(False)
		table_widget.setFixedHeight(int(0.35 * QApplication.primaryScreen().availableGeometry().height()))
		table_widget.setEditTriggers(QAbstractItemView.NoEditTriggers)
		self.mainVerticalLayout_RM.addWidget(table_widget)
		table_widget.setRowCount(len(trainNames))

		table_widget.setColumnWidth(0, int(0.08 * QApplication.primaryScreen().availableGeometry().width()))
		table_widget.setColumnWidth(1, int(0.12 * QApplication.primaryScreen().availableGeometry().width()))
		for i in range(2, table_widget.columnCount()):
			table_widget.setColumnWidth(i, int(0.07 * QApplication.primaryScreen().availableGeometry().width()))


		for i, train in enumerate(trainNames):
			table_widget.setItem(i, 0, QTableWidgetItem(train))

		for i, date in enumerate(revenueDates):
			item = QTableWidgetItem(str(date))
			item.setTextAlignment(Qt.AlignCenter)
			table_widget.setItem(i, 1, item)

		listOfMonthlyRunningMileages = []
		for i, YM in enumerate(yearMonthValuesForCalculations):
			from datetime import date

			year, month = YM[0], YM[1]
			last_day = calendar.monthrange(year, month)[1]
			last_date = date(year, month, last_day)

			sql_query = "SELECT id FROM trainsets WHERE line = %s AND deleted_at IS NULL ORDER BY trainset"
			self.cursor.execute(sql_query, (line_name,))
			trainIds_ = self.cursor.fetchall()
			trainIds = [idd[0] for idd in trainIds_]

			monthRunningMileage = 0
			for j, trainId in enumerate(trainIds):
				query = f"""
					SELECT tm.monthly_mileage
					FROM trainsets_mileage tm
					JOIN trainsets t ON tm.trainset_id = t.id
					WHERE
						tm.trainset_id = {trainId}
						AND tm.year = {year}
						AND tm.month = {month}
						AND t.stabilization < '{last_date}';
					"""

				self.cursor.execute(query)
				mileage = self.cursor.fetchone()
				
				if mileage:
					item = QTableWidgetItem(str(mileage[0]))
					item.setTextAlignment(Qt.AlignCenter)
					table_widget.setItem(j, i+2, item)
					monthRunningMileage += mileage[0]
				else:
					item = QTableWidgetItem('NA')
					item.setTextAlignment(Qt.AlignCenter)
					table_widget.setItem(j, i+2, item)

			listOfMonthlyRunningMileages.append(monthRunningMileage)
			item = QTableWidgetItem(str(monthRunningMileage))
			item.setTextAlignment(Qt.AlignCenter)
			self.dashboardRmMonthlyTable.setItem(h, i+1, item)

		allLinesAllMonthsRunningMileagesSum.append(listOfMonthlyRunningMileages)


	monthlyRMOfAllTrains = []
	sums = [sum(x) for x in zip(*allLinesAllMonthsRunningMileagesSum)]
	for i, val in enumerate(sums):
		item = QTableWidgetItem(str(val))
		item.setTextAlignment(Qt.AlignCenter)
		self.dashboardRmMonthlyTable.setItem(self.dashboardRmMonthlyTable.rowCount()-1, i+1, item)
		monthlyRMOfAllTrains.append(val)
	
	lineAccumulatedSums = []
	for h in range(len(self.uniqueLines)):
		currentLineSums = []
		for i,YM in enumerate(yearMonthValuesForCalculations):
			if i < 6:
				accumulatedValue = sum(allLinesAllMonthsRunningMileagesSum[h][:i+1])
				item = QTableWidgetItem(str(accumulatedValue))
				item.setTextAlignment(Qt.AlignCenter)
				self.dashboardRmAccumulatedTable.setItem(h, i+1, item)
				currentLineSums.append(accumulatedValue)

			else:
				accumulatedValue = sum(allLinesAllMonthsRunningMileagesSum[h][i:i-6:-1])
				item = QTableWidgetItem(str(accumulatedValue))
				item.setTextAlignment(Qt.AlignCenter)
				self.dashboardRmAccumulatedTable.setItem(h, i+1, item)
				currentLineSums.append(accumulatedValue)
		lineAccumulatedSums.append(currentLineSums)

	sums = [sum(x) for x in zip(*lineAccumulatedSums)]
	for i, val in enumerate(sums):
		item = QTableWidgetItem(str(val))
		item.setTextAlignment(Qt.AlignCenter)
		self.dashboardRmAccumulatedTable.setItem(len(self.uniqueLines), i+1, item)

	accumulatedRMForAllTrainsAllMonths = []
	for h in range(len(self.uniqueLines)):
		currentLineSums = []
		for i,YM in enumerate(yearMonthValuesForCalculations):
			accumulatedValue = sum(allLinesAllMonthsRunningMileagesSum[h][:i+1])
			item = QTableWidgetItem(str(accumulatedValue))
			item.setTextAlignment(Qt.AlignCenter)
			self.dashboardRmAccumulatedTable.setItem(h+len(self.uniqueLines)+1, i+1, item)
			currentLineSums.append(accumulatedValue)

		accumulatedRMForAllTrainsAllMonths.append(currentLineSums)


	sums = [sum(x) for x in zip(*accumulatedRMForAllTrainsAllMonths)]
	for i, val in enumerate(sums):
		item = QTableWidgetItem(str(val))
		item.setTextAlignment(Qt.AlignCenter)
		self.dashboardRmAccumulatedTable.setItem((len(self.uniqueLines)*2)+1, i+1, item)

	monthlyStabilizedTrains = []
	from datetime import date
	for i, YM in enumerate(yearMonthValuesForCalculations):
		year, month = YM[0], YM[1]
		last_day = calendar.monthrange(year, month)[1]
		last_date = date(year, month, last_day)
		query = f"SELECT COUNT(*) FROM trainsets WHERE stabilization < '{last_date}' AND deleted_at IS NULL"
		self.cursor.execute(query)
		noOfTrains = self.cursor.fetchone()
		monthlyStabilizedTrains.append(noOfTrains[0])


	for i in range(len(monthlyRMOfAllTrains)):
		if monthlyStabilizedTrains[i]:
			averageValue = round(monthlyRMOfAllTrains[i]/monthlyStabilizedTrains[i], 2)
			item = QTableWidgetItem(str(averageValue))
			item.setTextAlignment(Qt.AlignCenter)
			self.dashboardRmAvgTable.setItem(0, i+1, item)



	dataRangeRMDash3Tables = range(1, 1+len(yearMonthStringsForCalculations))
	dataRangeRMDashLineTables = range(2, 2+len(yearMonthStringsForCalculations))

	
	def onChangingToCombobox_RM():
		fromIndex = self.fromCombobox_RMDash.currentIndex()
		toIndex = self.toCombobox_RMDash.currentIndex()

		for indx in dataRangeRMDash3Tables[fromIndex+toIndex+1:]:
			self.dashboardRmMonthlyTable.setColumnHidden(indx, True)
			self.dashboardRmAccumulatedTable.setColumnHidden(indx, True)
			self.dashboardRmAvgTable.setColumnHidden(indx, True)

		for indx in dataRangeRMDash3Tables[fromIndex:fromIndex+toIndex+1]:
			self.dashboardRmMonthlyTable.setColumnHidden(indx, False)
			self.dashboardRmAccumulatedTable.setColumnHidden(indx, False)
			self.dashboardRmAvgTable.setColumnHidden(indx, False)


		for indx in dataRangeRMDashLineTables[fromIndex+toIndex+1:]:
			for table in self.listOfLinesTablesInRMDash:
				table.setColumnHidden(indx, True)

		for indx in dataRangeRMDashLineTables[fromIndex:fromIndex+toIndex+1]:
			for table in self.listOfLinesTablesInRMDash:
				table.setColumnHidden(indx, False)


	def onChangingFromCombobox_RM():
		self.toCombobox_RMDash.clear()
		fromIndex = self.fromCombobox_RMDash.currentIndex()
		self.toCombobox_RMDash.addItems(yearMonthStringsForCalculations[fromIndex:])

		for indx in dataRangeRMDash3Tables[:fromIndex]:
			self.dashboardRmMonthlyTable.setColumnHidden(indx, True)
			self.dashboardRmAccumulatedTable.setColumnHidden(indx, True)
			self.dashboardRmAvgTable.setColumnHidden(indx, True)


		for indx in dataRangeRMDash3Tables[fromIndex:]:
			self.dashboardRmMonthlyTable.setColumnHidden(indx, False)
			self.dashboardRmAccumulatedTable.setColumnHidden(indx, False)
			self.dashboardRmAvgTable.setColumnHidden(indx, False)

		for indx in dataRangeRMDashLineTables[:fromIndex]:
			for table in self.listOfLinesTablesInRMDash:
				table.setColumnHidden(indx, True)

		for indx in dataRangeRMDashLineTables[fromIndex:]:
			for table in self.listOfLinesTablesInRMDash:
				table.setColumnHidden(indx, False)

		self.toCombobox_RMDash.setCurrentIndex(len(yearMonthStringsForCalculations[fromIndex:])-1)

	self.fromCombobox_RMDash.currentIndexChanged.connect(onChangingFromCombobox_RM)
	self.toCombobox_RMDash.currentIndexChanged.connect(onChangingToCombobox_RM)



	def settingToLastSixMonthsFilters():
		if len(yearMonthStringsForCalculations)<=6:
			self.fromCombobox_RMDash.setCurrentIndex(0)
		else:
			self.fromCombobox_RMDash.setCurrentIndex((len(yearMonthStringsForCalculations))-6)

		self.toCombobox_RMDash.setCurrentIndex(self.toCombobox_RMDash.count()-1)

	self.clearAllFiltersButton_RMDash.clicked.connect(settingToLastSixMonthsFilters)

	settingToLastSixMonthsFilters()

def deleteItems_RM(layout):
	if layout:
		while layout.count():
			item = layout.takeAt(0)
			widget = item.widget()
			if widget:
				widget.setParent(None)
			else:
				deleteItems_RM(item.layout())

def onClickingRefresh_RM(self, layout):
	deleteItems_RM(layout)
	self.dashboardRunningmileageUI()