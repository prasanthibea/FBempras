from PySide6.QtWidgets import (QLabel, QTableWidgetItem, QPushButton, QWidget, QHBoxLayout, QVBoxLayout, QFormLayout, QLabel, QComboBox, QApplication,
								QSpacerItem, QSizePolicy, QAbstractItemView)
from PySide6.QtGui import QIcon, QFont, QColor, QBrush
from functions import TableWidget
from datetime import datetime, timedelta, date
import time
import calendar
from PySide6.QtCore import Qt
from dateutil.relativedelta import relativedelta

def systemsFailuresUi(self):

	self.layoutForFilters_SRF = QHBoxLayout()

	self.fromFormLayout_SRF = QFormLayout()
	self.toFormLayout_SRF = QFormLayout()

	currentYear = datetime.now().year
	currentMonth = datetime.now().month

	firstDayOfNextMonth = (datetime(currentYear, currentMonth, 1) + relativedelta(months=1)).date()
	lastDayOfCurrentMonth = (firstDayOfNextMonth - relativedelta(days=1))
	
	start_date = datetime(self.startingYear, self.startingMonth, 1).date()
	end_date = lastDayOfCurrentMonth

	current_date = start_date
	yearMonthStringsForCalculations = []
	yearMonthValuesForCalculations = []

	while current_date <= end_date:
		if (current_date.month != currentMonth) or (current_date.year != currentYear):
			yearMonthValuesForCalculations.append((current_date.year, current_date.month))
			formatted_month = current_date.strftime('%b - %Y')
			yearMonthStringsForCalculations.append(formatted_month)
		current_date += relativedelta(months=1)

	self.createComboBox(yearMonthStringsForCalculations, 'fromCombobox_SRF') 
	self.createComboBox(yearMonthStringsForCalculations, 'toCombobox_SRF')

	self.fromFormLayout_SRF.addRow(QLabel('From: '), self.fromCombobox_SRF)
	self.toFormLayout_SRF.addRow(QLabel('To: '), self.toCombobox_SRF)


	clearFilterIconPath = self.currentTheme.get('clearTableFilterIcon')
	refreshTableIconPath = self.currentTheme.get('refreshIcon')

	self.createPushButton('clearAllFiltersButton_SRF', '', clearFilterIconPath, 35, 'Clear filters')
	self.createPushButton('refreshBtn_SRF','', refreshTableIconPath, 35, 'Refresh')


	self.layoutForFilters_SRF.addItem(QSpacerItem(1, 0, QSizePolicy.Expanding, QSizePolicy.Minimum))
	self.layoutForFilters_SRF.addLayout(self.fromFormLayout_SRF)
	self.layoutForFilters_SRF.addLayout(self.toFormLayout_SRF)
	self.layoutForFilters_SRF.addWidget(self.clearAllFiltersButton_SRF)
	self.layoutForFilters_SRF.addWidget(self.refreshBtn_SRF)

	self.mainVerticalLayout_FailuresDash.addLayout(self.layoutForFilters_SRF)

	self.refreshBtn_SRF.clicked.connect(lambda: self.onClickingRefresh_SRF(self.mainVerticalLayout_FailuresDash))

	equipmentIdsList = tuple(self.systemIdsList)

	if len(equipmentIdsList) > 1:
		equipmentSqlQuery = f"SELECT equipment FROM bom WHERE id IN {equipmentIdsList}"
	elif len(equipmentIdsList) == 1:
		equipmentSqlQuery = f"SELECT equipment FROM bom WHERE id = {equipmentIdsList[0]}"

	self.cursor.execute(equipmentSqlQuery)
	bomEquipments = self.cursor.fetchall()
	bomEquipments.append(('Total',))

	rftableHeaderLabels = ['System'] + yearMonthStringsForCalculations + ['Total Relevant Failures']
	

	self.tableForRelevantFailuresCount = TableWidget(len(bomEquipments), len(rftableHeaderLabels))
	self.tableForRelevantFailuresCount.setStyleSheet(self.tableWidgetQSS)
	self.tableForRelevantFailuresCount.horizontalHeader().setStyleSheet(self.headerVerticalQSS)
	self.tableForRelevantFailuresCount.setAlternatingRowColors(True)
	self.tableForRelevantFailuresCount.setShowGrid(False)
	self.tableForRelevantFailuresCount.setFixedHeight(int(0.42 * QApplication.primaryScreen().availableGeometry().height()))
	# self.tableForRelevantFailuresCount.setFixedHeight(400)
	self.tableForRelevantFailuresCount.setCornerButtonEnabled(False)
	self.tableForRelevantFailuresCount.setEditTriggers(QAbstractItemView.NoEditTriggers)
	self.tableForRelevantFailuresCount.setHorizontalHeaderLabels(rftableHeaderLabels)


	headingLabelForRelavantFailsTable_SRF = QLabel('Relevant Failures')
	headingLabelForRelavantFailsTable_SRF.setStyleSheet("font-size: 14pt;")
	
	headingLabelForServiceFailsTable_SRF = QLabel('Service Failures')
	headingLabelForServiceFailsTable_SRF.setStyleSheet("font-size: 14pt;")


	self.mainVerticalLayout_FailuresDash.addWidget(headingLabelForRelavantFailsTable_SRF)
	self.mainVerticalLayout_FailuresDash.addWidget(self.tableForRelevantFailuresCount)
	self.mainVerticalLayout_FailuresDash.addWidget(headingLabelForServiceFailsTable_SRF)


	self.tableForRelevantFailuresCount.setColumnWidth(0, int(0.16 * QApplication.primaryScreen().availableGeometry().width()))
	for col in range(1, self.tableForRelevantFailuresCount.columnCount()):
		self.tableForRelevantFailuresCount.setColumnWidth(col, int(0.07 * QApplication.primaryScreen().availableGeometry().width()))
	self.tableForRelevantFailuresCount.setColumnWidth(self.tableForRelevantFailuresCount.columnCount()-1, int(0.1 * QApplication.primaryScreen().availableGeometry().width()))


	sctableHeaderLabels = ['System'] + yearMonthStringsForCalculations + ['Total Service Failures'] 

	self.tableForServiceFailuresCount = TableWidget(len(bomEquipments), len(sctableHeaderLabels))
	self.tableForServiceFailuresCount.setStyleSheet(self.tableWidgetQSS)
	self.tableForServiceFailuresCount.horizontalHeader().setStyleSheet(self.headerVerticalQSS)
	self.tableForServiceFailuresCount.setAlternatingRowColors(True)
	self.tableForServiceFailuresCount.setFixedHeight(int(0.42 * QApplication.primaryScreen().availableGeometry().height()))
	self.tableForServiceFailuresCount.setShowGrid(False)
	# self.tableForServiceFailuresCount.setFixedHeight(400)
	self.tableForServiceFailuresCount.setCornerButtonEnabled(False)
	self.tableForServiceFailuresCount.setEditTriggers(QAbstractItemView.NoEditTriggers)
	self.tableForServiceFailuresCount.setHorizontalHeaderLabels(sctableHeaderLabels)

	self.mainVerticalLayout_FailuresDash.addWidget(self.tableForServiceFailuresCount)


	self.tableForServiceFailuresCount.setColumnWidth(0, int(0.16 * QApplication.primaryScreen().availableGeometry().width()))
	for col in range(1, self.tableForServiceFailuresCount.columnCount()):
		self.tableForServiceFailuresCount.setColumnWidth(col, int(0.07 * QApplication.primaryScreen().availableGeometry().width()))
	self.tableForServiceFailuresCount.setColumnWidth(self.tableForServiceFailuresCount.columnCount()-1, int(0.1 * QApplication.primaryScreen().availableGeometry().width()))


	for i, equipmentDetails in enumerate(bomEquipments):
		self.tableForRelevantFailuresCount.setItem(i, 0, QTableWidgetItem(equipmentDetails[0]))
		self.tableForServiceFailuresCount.setItem(i, 0, QTableWidgetItem(equipmentDetails[0]))

	# self.tableForRelevantFailuresCount.setItem(self.tableForRelevantFailuresCount.rowCount()-1, 0, QTableWidgetItem(str('Total')))
	# self.tableForServiceFailuresCount.setItem(self.tableForServiceFailuresCount.rowCount()-1, 0, QTableWidgetItem(str('Total')))


	dataRangeFailureCountsTable = range(1, 1+len(yearMonthStringsForCalculations))

	for col,YM in enumerate(yearMonthValuesForCalculations):

		year, month = YM[0], YM[1]
		firstDayOfNextMonth = (datetime(year, month, 1) + relativedelta(months=1)).date()
		lastDayOfCurrentMonth = (firstDayOfNextMonth)



		firstDayOfCurrentMonth = (datetime(year, month, 1)).date()
		firstDateOfSixMonthsBeforeMonth = (firstDayOfCurrentMonth - relativedelta(months=5))


		for row, equipmentId in enumerate(self.systemIdsList):
			query = f"""
					SELECT failure_type, COUNT(*) AS category_count
					FROM corrective_maintenance cm
					JOIN trainsets t ON cm.trainset_id = t.id
					WHERE
						cm.work_start_at >= '{firstDayOfCurrentMonth}'
						AND cm.work_start_at <= '{lastDayOfCurrentMonth}'
						AND cm.system_id = {equipmentId}
						AND cm.failure_type IN ('Relevant Failure', 'Service Failure')
						AND cm.verification = 'Yes'
						AND cm.failure_responsibility = 'BEML'
						AND (cm.consider_for_relevant_fails = 'Yes' OR cm.consider_for_relevant_fails IS NULL)
						AND t.stabilization < cm.work_start_at
					GROUP BY failure_type;
				"""

			self.cursor.execute(query)
			failureCountResult = self.cursor.fetchall()
			




			if len(failureCountResult) == 2:
				for cat in failureCountResult:
					category, count = cat
					if category == 'Relevant Failure':
						monthlyRFCountItem = QTableWidgetItem(str(count))
						monthlyRFCountItem.setTextAlignment(Qt.AlignCenter)
						self.tableForRelevantFailuresCount.setItem(row, col + 1, monthlyRFCountItem)
						
					elif category == 'Service Failure':
						monthlySFCountItem = QTableWidgetItem(str(count))
						monthlySFCountItem.setTextAlignment(Qt.AlignCenter)
						self.tableForServiceFailuresCount.setItem(row, col + 1, monthlySFCountItem)
						

			if len(failureCountResult) == 1:
				category, count = failureCountResult[0]
				
				if category == 'Relevant Failure':

					zeroSFCountItem = QTableWidgetItem(str(0))
					zeroSFCountItem.setTextAlignment(Qt.AlignCenter)

					foundRFCountItem = QTableWidgetItem(str(count))
					foundRFCountItem.setTextAlignment(Qt.AlignCenter)

					self.tableForRelevantFailuresCount.setItem(row, col + 1, foundRFCountItem)
					self.tableForServiceFailuresCount.setItem(row, col + 1, zeroSFCountItem)
				


				elif category == 'Service Failure':

					zeroRFCountItem = QTableWidgetItem(str(0))
					zeroRFCountItem.setTextAlignment(Qt.AlignCenter)

					foundSFCountItem = QTableWidgetItem(str(count))
					foundSFCountItem.setTextAlignment(Qt.AlignCenter)

					self.tableForRelevantFailuresCount.setItem(row, col + 1, zeroRFCountItem)
					self.tableForServiceFailuresCount.setItem(row, col + 1, foundSFCountItem)
					
			if len(failureCountResult) == 0:
				zeroRFCountItem = QTableWidgetItem(str(0))
				zeroRFCountItem.setTextAlignment(Qt.AlignCenter)
				self.tableForRelevantFailuresCount.setItem(row, col + 1, zeroRFCountItem)

				zeroSFCountItem = QTableWidgetItem(str(0))
				zeroSFCountItem.setTextAlignment(Qt.AlignCenter)
				self.tableForServiceFailuresCount.setItem(row, col + 1, zeroSFCountItem)

		# if col != 0:
		totalMonthwiseRelevantFailures = 0
		for i in range(self.tableForRelevantFailuresCount.rowCount()-1):
			item = self.tableForRelevantFailuresCount.item(i, col +1)
			if item:
				val = int(item.text())
				totalMonthwiseRelevantFailures += val

		totalMWRFItem = QTableWidgetItem(str(totalMonthwiseRelevantFailures))
		totalMWRFItem.setTextAlignment(Qt.AlignCenter)
		self.tableForRelevantFailuresCount.setItem(self.tableForRelevantFailuresCount.rowCount()-1, col +1, totalMWRFItem)



		totalMonthwiseServiceFailures = 0
		for i in range(self.tableForServiceFailuresCount.rowCount()-1):
			item = self.tableForServiceFailuresCount.item(i, col +1)
			if item:
				val = int(item.text())
				totalMonthwiseServiceFailures += val

		totalMWSFItem = QTableWidgetItem(str(totalMonthwiseServiceFailures))
		totalMWSFItem.setTextAlignment(Qt.AlignCenter)
		self.tableForServiceFailuresCount.setItem(self.tableForServiceFailuresCount.rowCount()-1, col +1, totalMWSFItem)

	def getTotalRelevantFailuresCount():

		for i in range(self.tableForRelevantFailuresCount.rowCount()):
			totalRelaventFailures = 0
			for j in range(1, self.tableForRelevantFailuresCount.columnCount()-1):
				if not self.tableForRelevantFailuresCount.isColumnHidden(j):
					item = self.tableForRelevantFailuresCount.item(i,j)
					if item:
						val = int(item.text())
						totalRelaventFailures += val

			totalRFItem = QTableWidgetItem(str(totalRelaventFailures))
			totalRFItem.setTextAlignment(Qt.AlignCenter)
			self.tableForRelevantFailuresCount.setItem(i, self.tableForRelevantFailuresCount.columnCount()-1, totalRFItem)


	def getTotalServiceFailuresCount():

		for i in range(self.tableForServiceFailuresCount.rowCount()):
			totalServiceFailures = 0
			for j in range(1, self.tableForServiceFailuresCount.columnCount()-1):
				if not self.tableForServiceFailuresCount.isColumnHidden(j):
					item = self.tableForServiceFailuresCount.item(i,j)
					if item:
						val = int(item.text())
						totalServiceFailures += val

			totalSFItem = QTableWidgetItem(str(totalServiceFailures))
			totalSFItem.setTextAlignment(Qt.AlignCenter)
			self.tableForServiceFailuresCount.setItem(i, self.tableForServiceFailuresCount.columnCount()-1, totalSFItem)




	def onChangingToCombobox_SRF():
		
		fromIndex = self.fromCombobox_SRF.currentIndex()
		toIndex = self.toCombobox_SRF.currentIndex()

		for indx in dataRangeFailureCountsTable[fromIndex+toIndex+1:]:
			self.tableForRelevantFailuresCount.setColumnHidden(indx, True)
			self.tableForServiceFailuresCount.setColumnHidden(indx, True)

		for indx in dataRangeFailureCountsTable[fromIndex:fromIndex+toIndex+1]:
			self.tableForRelevantFailuresCount.setColumnHidden(indx, False)
			self.tableForServiceFailuresCount.setColumnHidden(indx, False)

		getTotalRelevantFailuresCount()
		getTotalServiceFailuresCount()

		
	def onChangingfromCombobox_SRF():
		self.toCombobox_SRF.clear()
		fromIndex = self.fromCombobox_SRF.currentIndex()
		self.toCombobox_SRF.addItems(yearMonthStringsForCalculations[fromIndex:])

		for indx in dataRangeFailureCountsTable[:fromIndex]:
			self.tableForRelevantFailuresCount.setColumnHidden(indx, True)
			self.tableForServiceFailuresCount.setColumnHidden(indx, True)


		for indx in dataRangeFailureCountsTable[fromIndex:]:
			self.tableForRelevantFailuresCount.setColumnHidden(indx, False)
			self.tableForServiceFailuresCount.setColumnHidden(indx, False)

		self.toCombobox_SRF.setCurrentIndex(len(yearMonthStringsForCalculations[fromIndex:])-1)
		
	self.fromCombobox_SRF.currentIndexChanged.connect(onChangingfromCombobox_SRF)
	self.toCombobox_SRF.currentIndexChanged.connect(onChangingToCombobox_SRF)

	def settingToLastSixMonthsFilters():
		if len(yearMonthStringsForCalculations)<=6:
			self.fromCombobox_SRF.setCurrentIndex(0)
		else:
			self.fromCombobox_SRF.setCurrentIndex((len(yearMonthStringsForCalculations))-6)

		self.toCombobox_SRF.setCurrentIndex(self.toCombobox_SRF.count()-1)

	self.clearAllFiltersButton_SRF.clicked.connect(settingToLastSixMonthsFilters)

	settingToLastSixMonthsFilters()



def deleteItems_SRF(layout):
	if layout:
		while layout.count():
			item = layout.takeAt(0)
			widget = item.widget()
			if widget:
				widget.setParent(None)
			else:
				deleteItems_SRF(item.layout())

def onClickingRefresh_SRF(self, layout):
	deleteItems_SRF(layout)
	self.systemsFailuresUi()