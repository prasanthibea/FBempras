from PySide6.QtWidgets import (QLabel, QTableWidgetItem, QHBoxLayout, QSpacerItem, QSizePolicy, QFormLayout, QAbstractItemView)
from functions import TableWidget, createComboBox, createPushButton
from datetime import datetime, timedelta, date
import calendar
from PySide6.QtCore import Qt
from dateutil.relativedelta import relativedelta
from PySide6.QtGui import QColor, QFont

def availabilityUi(self):
	from PySide6.QtWidgets import QApplication
	self.layoutForFilters_AvailDash = QHBoxLayout()
	self.fromFormLayout_AvailDash = QFormLayout()
	self.toFormLayout_AvailDash = QFormLayout()


	# Get the current year and month
	currentYear = datetime.now().year
	currentMonth = datetime.now().month

	firstDayOfNextMonth = (datetime(currentYear, currentMonth, 1) + relativedelta(months=1)).date()
	lastDayOfCurrentMonth = (firstDayOfNextMonth - relativedelta(days=1))
	
	start_date = datetime(self.startingYear, self.startingMonth, 1).date()
	end_date = lastDayOfCurrentMonth

	current_date = start_date
	yearMonthStringsForCalculations = []
	yearMonthValuesForCalculations = []

	while current_date <= end_date:
		if (current_date.month != currentMonth) or (current_date.year != currentYear):
			yearMonthValuesForCalculations.append((current_date.year, current_date.month))
			formatted_month = current_date.strftime('%b - %Y')
			yearMonthStringsForCalculations.append(formatted_month)

		# Move to the next month
		current_date += relativedelta(months=1)



	# self.layoutForFilters_AvailDash = QHBoxLayout()
	self.createComboBox(yearMonthStringsForCalculations, 'fromCombobox_availDash')
	self.createComboBox(yearMonthStringsForCalculations, 'toCombobox_availDash')

	self.fromFormLayout_AvailDash.addRow('From:', self.fromCombobox_availDash)
	self.toFormLayout_AvailDash.addRow('To:', self.toCombobox_availDash)


	clearFilterIconPath = self.currentTheme.get('clearTableFilterIcon')
	refreshTableIconPath = self.currentTheme.get('refreshIcon')


	self.createPushButton('clearAllFiltersButton_availDash', '', clearFilterIconPath, 35, 'Clear filters')

	self.createPushButton('refreshButton_availDash', '', refreshTableIconPath, 35, 'Refresh')

	self.refreshButton_availDash.clicked.connect(lambda: self.onClickingRefresh_availDash(self.mainVerticalLayout_availabilityDash))


	self.layoutForFilters_AvailDash.addItem(QSpacerItem(1, 0, QSizePolicy.Expanding, QSizePolicy.Minimum))
	self.layoutForFilters_AvailDash.addLayout(self.fromFormLayout_AvailDash)
	self.layoutForFilters_AvailDash.addLayout(self.toFormLayout_AvailDash)
	self.layoutForFilters_AvailDash.addWidget(self.clearAllFiltersButton_availDash)
	self.layoutForFilters_AvailDash.addWidget(self.refreshButton_availDash)

	self.mainVerticalLayout_availabilityDash.addLayout(self.layoutForFilters_AvailDash)



	lineAvailabilityAnswers = []

	def find_totalDuration(datetime_pairs):
		totalDuration = timedelta()

		# Sort datetime pairs by start datetime
		if datetime_pairs:
			sorted_datetime_pairs = sorted(datetime_pairs, key=lambda x: x[0])
			# #print(sorted_datetime_pairs)
			# Initialize variables to keep track of the current start and end datetime
			current_start = sorted_datetime_pairs[0][0]
			current_end = sorted_datetime_pairs[0][1]

			# Iterate through the sorted datetime pairs
			for start, end in sorted_datetime_pairs[1:]:
				# Check for overlap
				if start < current_end:
					# Update the current end datetime if there is an overlap
					current_end = max(current_end, end)
				else:
					# Add the overlapping duration to the total
					totalDuration += current_end - current_start

					# Update the current start and end datetimes
					current_start = start
					current_end = end

			# Add the final overlapping duration (if any)
			totalDuration += current_end - current_start

			return totalDuration




	def calculateDowntimeForMonth(trainId, yearMonthValues):
		year, month = yearMonthValues

		query1 = f"""
				SELECT cm.work_start_at, cm.work_end_at
				FROM corrective_maintenance cm
				JOIN trainsets t ON cm.trainset_id = t.id
				WHERE
					cm.trainset_id = {trainId}
					AND YEAR(cm.work_start_at) = {year}
					AND MONTH(cm.work_start_at) = {month}
					AND (cm.failure_type = 'Service Failure' OR cm.failure_type = 'Relevant Failure')
					AND cm.verification = 'Yes'
					AND cm.failure_responsibility = 'BEML'
					AND t.stabilization < cm.work_start_at;
				"""
		self.cursor.execute(query1)
		result1 = self.cursor.fetchall()
		# print(f'CM data for  trainId {trainId} for month {month} and year {year}', result1)


		query2 = f"""
			SELECT opm.work_start_at, opm.work_end_at
			FROM other_preventive_maintenance opm
			JOIN trainsets t ON opm.trainset_id = t.id
			WHERE
				opm.trainset_id = {trainId}
				AND YEAR(opm.work_start_at) = {year}
				AND MONTH(opm.work_start_at) = {month}
				AND t.stabilization < opm.work_start_at;
			"""

		self.cursor.execute(query2)
		result2 = self.cursor.fetchall()
		# print(f'OPM data for  trainId {trainId} for month {month} and year {year}', result2)
		


		query3 = f"""
			SELECT sc.A_1, sc.A_2, sc.A_3, sc.B1_1, sc.B1_2, sc.B4, sc.B8, sc.C1, sc.C2
			FROM service_checks sc
			JOIN trainsets t ON sc.trainset_id = t.id
			WHERE
				sc.trainset_id = {trainId}
				AND sc.year = {year}
				AND sc.month = {month}
			"""
		self.cursor.execute(query3)
		result3 = self.cursor.fetchall()
		# print(f'SC data for  trainId {trainId} for month {month} and year {year}', result3)


		query = f'SELECT stabilization FROM trainsets WHERE id = {trainId}'
		self.cursor.execute(query)
		stabilization = self.cursor.fetchone()



		scDates = []
		if result3:
			for i, startDate in enumerate(result3[0]):
				if startDate:
					if startDate.date() > stabilization[0]:
						if i in [0, 1, 2]:
							endDate = startDate + timedelta(hours=self.ASCHours)

						if i in [3, 4]:
							endDate = startDate + timedelta(hours=self.B1SCHours)

						if i == 5:
							endDate = startDate + timedelta(hours=self.B4SCHours)

						if i == 6:
							endDate = startDate + timedelta(hours=self.B8SCHours)

						if i == 7:
							endDate = startDate + timedelta(hours=self.C1SCHours)

						if i == 8:
							endDate = startDate + timedelta(hours=self.C2SCHours)

						scDates.append((startDate, endDate))

		# #print('sc data is-->', scDates)
		allDatePairsOfCurrentTrain = result1 + result2 + scDates
		# #print('all data-->', allDatePairsOfCurrentTrain)

		return find_totalDuration(allDatePairsOfCurrentTrain)
	

	self.listOfLinesTablesInAvailDash = []
	for linee in self.uniqueLines:
		lineLabel = QLabel(f'Availability for {linee}')
		lineLabel.setStyleSheet("font-size: 14pt;")
		self.mainVerticalLayout_availabilityDash.addWidget(lineLabel)

		lineTable = TableWidget()
		headers = [''] + yearMonthStringsForCalculations
		lineTable.setColumnCount(len(headers))
		lineTable.setHorizontalHeaderLabels(headers)
		lineTable.setStyleSheet(self.tableWidgetQSS)
		lineTable.horizontalHeader().setStyleSheet(self.headerHorizontalQSS)
		# lineTable.verticalHeader().setStyleSheet(self.headerVerticalQSS)
		lineTable.setAlternatingRowColors(True)
		lineTable.setFixedHeight(int(0.375 * QApplication.primaryScreen().availableGeometry().height()))
		lineTable.setShowGrid(False)
		self.mainVerticalLayout_availabilityDash.addWidget(lineTable)
		lineTable.setEditTriggers(QAbstractItemView.NoEditTriggers)

		lineTable.setColumnWidth(0, int(0.2 * QApplication.primaryScreen().availableGeometry().width()))
		for i in range(1, lineTable.columnCount()):
			lineTable.setColumnWidth(i, int(0.07 * QApplication.primaryScreen().availableGeometry().width()))

		self.listOfLinesTablesInAvailDash.append(lineTable)


		firstColumnLineTabl =['Downtime due to Corrective Maintenance (Hrs)', 'Downtime due to Preventive Maintenance (Hrs)','Downtime due to Service Checks (Hrs)',
		'Total Downtime (Hrs)', 'Total Downtime for Last 6 Months (Hrs)', 'Actual Downtime (Hrs)', 'Actual Downtime for Last 6 Months', 'Total Time', 'Total Time in 6 Months (Hrs)', 'Availability for Last 6 Months', 'Availability (1 Month)']

		lineTable.setRowCount(len(firstColumnLineTabl))
		for i in range(len(firstColumnLineTabl)):
			item = QTableWidgetItem(firstColumnLineTabl[i])
			# item.setTextAlignment(Qt.AlignCenter)
			lineTable.setItem(i, 0, item)

		for i,YM in enumerate(yearMonthValuesForCalculations):
			year, month = YM[0], YM[1]
			last_day = calendar.monthrange(year, month)[1]
			last_date = date(year, month, last_day)

			sql_query = "SELECT id FROM trainsets WHERE line = %s AND stabilization < %s AND deleted_at IS NULL ORDER BY trainset"
			self.cursor.execute(sql_query, (linee, last_date))
			trainIds_ = self.cursor.fetchall()
			trainIds = [idd[0] for idd in trainIds_]


			monthDownTimeOfCM = 0
			# for trainId in trainIds:
			query = f"""
				SELECT cm.down_time
				FROM corrective_maintenance cm
				JOIN trainsets t ON cm.trainset_id = t.id
				WHERE
					YEAR(cm.work_start_at) = {year}
					AND MONTH(cm.work_start_at) = {month}
					AND (cm.failure_type = 'Service Failure' OR cm.failure_type = 'Relevant Failure')
					AND cm.verification = 'Yes'
					AND cm.failure_responsibility = 'BEML'
					AND t.line = '{linee}'
					AND t.stabilization < cm.work_start_at
					AND t.deleted_at IS NULL;
				"""
			self.cursor.execute(query)
			result = self.cursor.fetchall()
			
			
			if result:
				for dt in result:
					monthDownTimeOfCM += dt[0]
					
			

			item = QTableWidgetItem(str(round(monthDownTimeOfCM/60, 2)))
			item.setTextAlignment(Qt.AlignCenter)
			lineTable.setItem(0, i+1, item)

			monthDownTimeOfOPM = 0
			# for trainId in trainIds:
			query = f"""
				SELECT opm.downtime
				FROM other_preventive_maintenance opm
				JOIN trainsets t ON opm.trainset_id = t.id
				WHERE
					YEAR(opm.work_start_at) = {year}
					AND MONTH(opm.work_start_at) = {month}
					AND t.line = '{linee}'
					AND t.stabilization < opm.work_start_at;
				"""
			self.cursor.execute(query)
			result = self.cursor.fetchall()
			
			if result:
				for dt in result:
					monthDownTimeOfOPM += dt[0]
			
			item = QTableWidgetItem(str(round(monthDownTimeOfOPM/60, 2)))
			item.setTextAlignment(Qt.AlignCenter)
			lineTable.setItem(1, i+1, item)


			# monthDownTimeOfSC = 0
			# for trainId in trainIds:
			# 	query3 = f"""
			# 		SELECT sc.downtime
			# 		FROM service_checks sc
			# 		JOIN trainsets t ON sc.trainset_id = t.id
			# 		WHERE
			# 			sc.trainset_id = {trainId}
			# 			AND sc.year = {year}
			# 			AND sc.month = {month}

			# 		"""
			# 	self.cursor.execute(query3)
			# 	result3 = self.cursor.fetchall()
			# 	if result3:
			# 		monthDownTimeOfSC += result3[0][0]




			monthDownTimeOfSC = 0
			for trainId in trainIds:
				query3 = f"""
					SELECT sc.A_1, sc.A_2, sc.A_3, sc.B1_1, sc.B1_2, sc.B4, sc.B8, sc.C1, sc.C2
					FROM service_checks sc
					JOIN trainsets t ON sc.trainset_id = t.id
					WHERE
						sc.trainset_id = {trainId}
						AND sc.year = {year}
						AND sc.month = {month}
					"""
				self.cursor.execute(query3)
				result3 = self.cursor.fetchall()
				# print(f'SC data for  trainId {trainId} for month {month} and year {year}', result3)


				query = f'SELECT stabilization FROM trainsets WHERE id = {trainId}'
				self.cursor.execute(query)
				stabilization = self.cursor.fetchone()



				# scDates = []
				if result3:
					for r, startDate in enumerate(result3[0]):
						if startDate:
							if startDate.date() > stabilization[0]:
								if r in [0, 1, 2]:
									monthDownTimeOfSC += self.ASCHours

								if r in [3, 4]:
									monthDownTimeOfSC += self.B1SCHours

								if r == 5:
									monthDownTimeOfSC += self.B4SCHours

								if r == 6:
									monthDownTimeOfSC += self.B8SCHours

								if r == 7:
									monthDownTimeOfSC += self.C1SCHours

								if r == 8:
									monthDownTimeOfSC += self.C2SCHours




			
			# print(monthDownTimeOfSC)
			intValueOfMonthDownTimeOfSC = float(monthDownTimeOfSC*60)
			item = QTableWidgetItem(str(round(intValueOfMonthDownTimeOfSC/60, 2)))
			item.setTextAlignment(Qt.AlignCenter)
			lineTable.setItem(2, i+1, item)
			
			totalDownTime = monthDownTimeOfCM + monthDownTimeOfOPM + (monthDownTimeOfSC*60)

			item = QTableWidgetItem(str(round(totalDownTime/60, 2)))
			item.setTextAlignment(Qt.AlignCenter)
			lineTable.setItem(3, i+1, item)


		for i in range(len(yearMonthValuesForCalculations), 0, -1):
			# print(i)
			sixMonthsDownTime = 0

			if i < 6:
				for d in range(i, 0, -1):
					valu = lineTable.item(3, d)
					if valu:
						val = float(valu.text())
						sixMonthsDownTime += val
			else:
				for d in range(i, i-6, -1):
					valu = lineTable.item(3, d)
					if valu:
						val = float(valu.text())
						sixMonthsDownTime += val
			item = QTableWidgetItem(str(round(sixMonthsDownTime, 2)))
			item.setTextAlignment(Qt.AlignCenter)
			lineTable.setItem(4, i, item)

		for i,YM in enumerate(yearMonthValuesForCalculations):
			year, month = YM[0], YM[1]
			last_day = calendar.monthrange(year, month)[1]
			last_date = date(year, month, last_day)

			sql_query = "SELECT id FROM trainsets WHERE line = %s AND stabilization < %s AND deleted_at IS NULL ORDER BY trainset"
			self.cursor.execute(sql_query, (linee, last_date))
			trainIds_ = self.cursor.fetchall()
			trainIds = [idd[0] for idd in trainIds_]
			# print(trainIds)

			currentMonthDownTime = timedelta()
			for trainID in trainIds:
				monthDownTime = calculateDowntimeForMonth(trainID, YM)
				# print('monthDownTime', monthDownTime)
				if monthDownTime:
					currentMonthDownTime += monthDownTime
					# print(currentMonthDownTime)

			totalDownTimeForThisMonth = currentMonthDownTime.days*24*60 + currentMonthDownTime.seconds//60
			# print(f'Downtime for {YM} is', totalDownTimeForThisMonth)

			item = QTableWidgetItem(str(round(totalDownTimeForThisMonth/60, 2)))
			item.setTextAlignment(Qt.AlignCenter)
			lineTable.setItem(5, i+1, item)


		for i in range(len(yearMonthValuesForCalculations), 0, -1):
			# print(i)
			sixMonthsActualDownTime = 0

			if i < 6:
				for d in range(i, 0, -1):
					valu = lineTable.item(5, d)
					if valu:
						val = float(valu.text())
						sixMonthsActualDownTime += val
			else:
				for d in range(i, i-6, -1):
					valu = lineTable.item(5, d)
					if valu:
						val = float(valu.text())
						sixMonthsActualDownTime += val

			item = QTableWidgetItem(str(round(sixMonthsActualDownTime, 2)))
			item.setTextAlignment(Qt.AlignCenter)
			lineTable.setItem(6, i, item)



		for i,YM in enumerate(yearMonthValuesForCalculations):
			year, month = YM[0], YM[1]
			last_day = calendar.monthrange(year, month)[1]
			last_date = date(year, month, last_day)
			sql_query = "SELECT id FROM trainsets WHERE line = %s AND stabilization < %s AND deleted_at IS NULL ORDER BY trainset"
			self.cursor.execute(sql_query, (linee, last_date))
			trainIds_ = self.cursor.fetchall()
			# print('trainIds_', YM, len(trainIds_))

			_, last_day = calendar.monthrange(YM[0], YM[1])
			minutes_in_day = 24 * 60
			totalMinutesInMonth = last_day * minutes_in_day * len(trainIds_)
			item = QTableWidgetItem(str(round(totalMinutesInMonth/60, 2)))
			item.setTextAlignment(Qt.AlignCenter)
			lineTable.setItem(7, i+1, item)


		for i in range(len(yearMonthValuesForCalculations), 0, -1):
			# print(i)
			totalTimeInLastSixMonths_ = 0

			if i < 6:
				for d in range(i, 0, -1):
					valu = lineTable.item(7, d)
					if valu:
						val = float(valu.text())
						# print(i, val)
						totalTimeInLastSixMonths_ += val
			else:
				for d in range(i, i-6, -1):
					valu = lineTable.item(7, d)
					if valu:
						val = float(valu.text())
						totalTimeInLastSixMonths_ += val

			item = QTableWidgetItem(str(totalTimeInLastSixMonths_))
			item.setTextAlignment(Qt.AlignCenter)
			lineTable.setItem(8, i, item)

		availabilties = []
		for i,YM in enumerate(yearMonthValuesForCalculations):
			DT = float(lineTable.item(6, i+1).text())
			TT = float(lineTable.item(8, i+1).text())

			# print(DT, TT)
			if TT ==0:
				availabilty = 0
			else:
				availabilty = round((1-(DT/TT))*100, 2)

			item = QTableWidgetItem(str(availabilty))
			item.setTextAlignment(Qt.AlignCenter)
			lineTable.setItem(9, i+1, item)
			availabilties.append(availabilty)

		lineAvailabilityAnswers.append(availabilties)

		for i,YM in enumerate(yearMonthValuesForCalculations):
			DT = float(lineTable.item(5, i+1).text())
			TT = float(lineTable.item(7, i+1).text())

			# print(DT, TT)
			if TT == 0:
				availabilty = 0
			else:
				availabilty = round((1-(DT/TT))*100, 2)
				
			item = QTableWidgetItem(str(availabilty))
			item.setTextAlignment(Qt.AlignCenter)
			lineTable.setItem(10, i+1, item)


		



	self.availabilitySummaryTable = TableWidget()
	headers = [''] + yearMonthStringsForCalculations
	self.availabilitySummaryTable.setColumnCount(len(headers))
	self.availabilitySummaryTable.setHorizontalHeaderLabels(headers)
	self.availabilitySummaryTable.setStyleSheet(self.tableWidgetQSS)
	self.availabilitySummaryTable.horizontalHeader().setStyleSheet(self.headerHorizontalQSS)
	self.availabilitySummaryTable.setAlternatingRowColors(True)
	self.availabilitySummaryTable.setFixedHeight(int(0.28 * QApplication.primaryScreen().availableGeometry().height()))
	self.availabilitySummaryTable.setShowGrid(False)

	fleetLabel = QLabel('Fleet Availability Based on last 6 Months')
	fleetLabel.setStyleSheet("font-size: 14pt;")
	self.mainVerticalLayout_availabilityDash.addWidget(fleetLabel)

	self.mainVerticalLayout_availabilityDash.addWidget(self.availabilitySummaryTable)
	self.availabilitySummaryTable.setEditTriggers(QAbstractItemView.NoEditTriggers)

	self.availabilitySummaryTable.setColumnWidth(0, int(0.2 * QApplication.primaryScreen().availableGeometry().width()))
	for i in range(1, self.availabilitySummaryTable.columnCount()):
		self.availabilitySummaryTable.setColumnWidth(i, int(0.07 * QApplication.primaryScreen().availableGeometry().width()))






	firstColumn_availabilityDash = ['Target Availability'] + self.uniqueLines + ['Total Fleet Availability (1 Month)', 'Total Fleet Availability For Last 6 Months', '6 Months Result', 'No Of Short Fall Trains']

	self.availabilitySummaryTable.setRowCount(len(firstColumn_availabilityDash))
	for i in range(len(firstColumn_availabilityDash)):
		item = QTableWidgetItem(firstColumn_availabilityDash[i])
		item.setTextAlignment(Qt.AlignCenter)
		
		self.availabilitySummaryTable.setItem(i, 0, item)
	for i in range(1, self.availabilitySummaryTable.columnCount()):
		item = QTableWidgetItem(str(self.availabilityTarget))
		item.setTextAlignment(Qt.AlignCenter)
		
		self.availabilitySummaryTable.setItem(0, i, item)

	for i in range(len(self.uniqueLines)):
		for j in range(1, self.availabilitySummaryTable.columnCount()):
			item = QTableWidgetItem(str(lineAvailabilityAnswers[i][j-1]))
			item.setTextAlignment(Qt.AlignCenter)
			
			self.availabilitySummaryTable.setItem(i+1, j, item)


	rowCount = self.availabilitySummaryTable.rowCount()

	allActualMonthlyDowntimes = []
	for i,YM in enumerate(yearMonthValuesForCalculations):
		year, month = YM[0], YM[1]
		last_day = calendar.monthrange(year, month)[1]
		last_date = date(year, month, last_day)

		# sql_query = "SELECT id FROM trainsets WHERE stabilization < %s"
		sql_query = "SELECT id FROM trainsets WHERE deleted_at IS NULL ORDER BY trainset"
		self.cursor.execute(sql_query)
		trainIds_ = self.cursor.fetchall()
		trainIds = [idd[0] for idd in trainIds_]
		# print(trainIds)

		currentMonthDownTime = timedelta()
		for trainID in trainIds:
			monthDownTime = calculateDowntimeForMonth(trainID, YM)
			# print('monthDownTime', monthDownTime)
			if monthDownTime:
				currentMonthDownTime += monthDownTime
				# print(currentMonthDownTime)

		totalDownTimeForThisMonth = currentMonthDownTime.days*24*60 + currentMonthDownTime.seconds//60
		allActualMonthlyDowntimes.append(totalDownTimeForThisMonth)
		
	allActual6MonthsDowntimes = []
	for i in range(len(yearMonthValuesForCalculations)):
		if i < 6:
			sixMonthsActualDowntime = sum(allActualMonthlyDowntimes[:i+1])
		else:
			sixMonthsActualDowntime = sum(allActualMonthlyDowntimes[i:i-6:-1])

		allActual6MonthsDowntimes.append(sixMonthsActualDowntime)
	


	totalMinutesInMonthForAllTrains = []
	for i,YM in enumerate(yearMonthValuesForCalculations):
		year, month = YM[0], YM[1]
		last_day = calendar.monthrange(year, month)[1]
		last_date = date(year, month, last_day)

		sql_query = "SELECT id FROM trainsets WHERE stabilization < %s AND deleted_at IS NULL ORDER BY trainset"
		self.cursor.execute(sql_query, (last_date,))
		trainIds_ = self.cursor.fetchall()

		_, last_day = calendar.monthrange(YM[0], YM[1])
		minutes_in_day = 24 * 60
		totalMinutesInMonth = last_day * minutes_in_day * len(trainIds_)
		totalMinutesInMonthForAllTrains.append(totalMinutesInMonth)

	# print('totalMinutesInMonthForAllTrains', totalMinutesInMonthForAllTrains)
	


	totalTimeIn6MonthsForAllTrains = []
	for i in range(len(yearMonthValuesForCalculations)):
		if i < 6:
			sixMonthsTotalTime = sum(totalMinutesInMonthForAllTrains[:i+1])
		else:
			sixMonthsTotalTime = sum(totalMinutesInMonthForAllTrains[i:i-6:-1])

		totalTimeIn6MonthsForAllTrains.append(sixMonthsTotalTime)
	# print('totalTimeIn6MonthsForAllTrains', totalTimeIn6MonthsForAllTrains)
	


	self.MonthlyShortFallTrains = []
	for i, YM in enumerate(yearMonthValuesForCalculations):
		year, month = YM[0], YM[1]
		last_day = calendar.monthrange(year, month)[1]
		last_date = date(year, month, last_day)

		sql_query = "SELECT id FROM trainsets WHERE stabilization < %s AND deleted_at IS NULL ORDER BY trainset"
		self.cursor.execute(sql_query, (last_date,))
		trainIds_ = self.cursor.fetchall()
		


		if totalTimeIn6MonthsForAllTrains[i]:
			availabiltyVal = 1-(allActual6MonthsDowntimes[i]/totalTimeIn6MonthsForAllTrains[i])
			# print('allActual6MonthsDowntimes[i]', allActual6MonthsDowntimes[i])
			# print('totalTimeIn6MonthsForAllTrains[i]', totalTimeIn6MonthsForAllTrains[i])
			availabiltyPercentage = round(availabiltyVal*100, 2)
			item = QTableWidgetItem(str(availabiltyPercentage))
			item.setTextAlignment(Qt.AlignCenter)
			
			self.availabilitySummaryTable.setItem(rowCount - 3, i+1, item)


			availabiltyValForCurrentMonth = 1-(allActualMonthlyDowntimes[i]/totalMinutesInMonthForAllTrains[i])
			availabiltyPercentageForCurrentMonth = round(availabiltyValForCurrentMonth*100, 2)
			item = QTableWidgetItem(str(availabiltyPercentageForCurrentMonth))
			item.setTextAlignment(Qt.AlignCenter)
			
			self.availabilitySummaryTable.setItem(rowCount - 4, i+1, item)


			redBg = QColor(self.currentTheme.get('redBGColor'))
			greenBg = QColor(self.currentTheme.get('greenBGColor'))

			if self.availabilityTarget < availabiltyPercentage:
				resultItem = QTableWidgetItem('Achieved')
				resultItem.setTextAlignment(Qt.AlignCenter)
				resultItem.setBackground(greenBg)

			else:
				resultItem = QTableWidgetItem('Not Achieved')
				resultItem.setTextAlignment(Qt.AlignCenter)
				resultItem.setBackground(redBg)

			self.availabilitySummaryTable.setItem(rowCount - 2, i+1, resultItem)


			if ((self.availabilityTarget/100) - availabiltyVal)*len(trainIds_) < 0:
				shortFallTrains = 0
			else:
				shortFallTrains = int(((self.availabilityTarget/100) - availabiltyVal)*len(trainIds_))+1

			self.MonthlyShortFallTrains.append((YM, shortFallTrains))
			item = QTableWidgetItem(str(shortFallTrains))
			item.setTextAlignment(Qt.AlignCenter)
			self.availabilitySummaryTable.setItem(rowCount - 1, i+1, item)
		else:
			self.MonthlyShortFallTrains.append((YM, 0))


	monthsRangeForMonthlyFailuresTable_availDash = range(1, 1+len(yearMonthStringsForCalculations))
	monthsRangeForAvailDashboardTable = range(1, 1+len(yearMonthStringsForCalculations))

	def onChangingToCombobox_availDash():
		fromIndex = self.fromCombobox_availDash.currentIndex()
		toIndex = self.toCombobox_availDash.currentIndex()

		for indx in monthsRangeForMonthlyFailuresTable_availDash[fromIndex+toIndex+1:]:
			for i in range(self.mainVerticalLayout_availabilityDash.count()):
				item = self.mainVerticalLayout_availabilityDash.itemAt(i)
				if item.widget():
					if isinstance(item.widget(), TableWidget):
						item.widget().setColumnHidden(indx, True)

		for indx in monthsRangeForMonthlyFailuresTable_availDash[fromIndex:fromIndex+toIndex+1]:
			for i in range(self.mainVerticalLayout_availabilityDash.count()):
				item = self.mainVerticalLayout_availabilityDash.itemAt(i)
				if item.widget():
					if isinstance(item.widget(), TableWidget):
						item.widget().setColumnHidden(indx, False)



	def onChangingFromCombobox_availDash():
		self.toCombobox_availDash.clear()
		fromIndex = self.fromCombobox_availDash.currentIndex()
		self.toCombobox_availDash.addItems(yearMonthStringsForCalculations[fromIndex:])

		for indx in monthsRangeForMonthlyFailuresTable_availDash[:fromIndex]:
			for i in range(self.mainVerticalLayout_availabilityDash.count()):
				item = self.mainVerticalLayout_availabilityDash.itemAt(i)
				if item.widget():
					if isinstance(item.widget(), TableWidget):
						item.widget().setColumnHidden(indx, True)


		for indx in monthsRangeForMonthlyFailuresTable_availDash[fromIndex:]:
			for i in range(self.mainVerticalLayout_availabilityDash.count()):
				item = self.mainVerticalLayout_availabilityDash.itemAt(i)
				if item.widget():
					if isinstance(item.widget(), TableWidget):
						item.widget().setColumnHidden(indx, False)

		self.toCombobox_availDash.setCurrentIndex(len(yearMonthStringsForCalculations[fromIndex:])-1)

	self.fromCombobox_availDash.currentIndexChanged.connect(onChangingFromCombobox_availDash)
	self.toCombobox_availDash.currentIndexChanged.connect(onChangingToCombobox_availDash)



	def settingToLastSixMonthsFilters():
		
		if len(yearMonthStringsForCalculations)<=6:
			self.fromCombobox_availDash.setCurrentIndex(0)
		else:
			self.fromCombobox_availDash.setCurrentIndex((len(yearMonthStringsForCalculations))-6)

		self.toCombobox_availDash.setCurrentIndex(self.toCombobox_availDash.count()-1)

	self.clearAllFiltersButton_availDash.clicked.connect(settingToLastSixMonthsFilters)

	settingToLastSixMonthsFilters()


def deleteItems_availDash(layout):
	if layout:
		while layout.count():
			item = layout.takeAt(0)
			widget = item.widget()
			if widget:
				widget.setParent(None)
			else:
				deleteItems_availDash(item.layout())

def onClickingRefresh_availDash(self, layout):
	deleteItems_availDash(layout)
	self.availabilityUi()