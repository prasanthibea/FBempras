from PySide6.QtWidgets import QTableWidgetItem, QPushButton, QWidget, QHBoxLayout, QVBoxLayout, QAbstractItemView, QFormLayout, QScrollArea, QGridLayout, QLabel, QComboBox, QCheckBox, QFileDialog, QDateEdit, QTimeEdit, QTextEdit, QSizePolicy, QSpacerItem, QLineEdit, QDialog, QDialogButtonBox, QMessageBox
from PySide6.QtGui import QIcon, QIntValidator
from functions import TableWidget
from datetime import datetime, timedelta
from dateutil.relativedelta import relativedelta
from PySide6.QtCore import Qt, QDateTime, QDate, QTime
import time
from openpyxl import Workbook
import os
import shutil

def opmDataUI(self, mainLayout):
	from PySide6.QtWidgets import QApplication


	self.layoutForFilters_opmDataTable = QHBoxLayout()

	self.createLineEditBox('serachBarOfOPMDataTable', 'Search..' )
	self.serachBarOfOPMDataTable.setClearButtonEnabled(True)
	self.serachBarOfOPMDataTable.setFixedWidth(int(0.2 * QApplication.primaryScreen().availableGeometry().width()))


	self.fromFormLayout_OPMDT = QFormLayout()
	self.toFormLayout_OPMDT = QFormLayout()
	
	start_date = datetime(self.startingYear, self.startingMonth, 1).date()
	#print('start_date', start_date)

	self.createDateEditBox('fromDateEditBox_OPMDT')
	self.fromDateEditBox_OPMDT.setMinimumDate(QDate(self.startingYear, self.startingMonth, 1))
	# self.fromDateEditBox_OPMDT.setDate(start_date)

	self.createDateEditBox('toDateEditBox_OPMDT')
	self.toDateEditBox_OPMDT.setMinimumDate(QDate(self.startingYear, self.startingMonth, 1))
	# self.toDateEditBox_OPMDT.setDate(QDate.currentDate())

	self.fromFormLayout_OPMDT.addRow(QLabel('From: '), self.fromDateEditBox_OPMDT)
	self.toFormLayout_OPMDT.addRow(QLabel('To: '), self.toDateEditBox_OPMDT)


	clearFilterIconPath = self.currentTheme.get('clearTableFilterIcon')
	downloadIconPath = self.currentTheme.get('downloadIcon')

	deleteIconPath = self.currentTheme.get('whiteDeleteIcon')
	darkCheckBoxIconPath = self.currentTheme.get('darkCheckBoxIcon')
	darkUnCheckBoxIconPath = self.currentTheme.get('darkUnCheckBoxIcon')


	checkAllUserIconPath = self.currentTheme.get('oppositeColorCheckBoxIcon')
	unCheckAllUserIconPath = self.currentTheme.get('oppositeColorUnCheckBoxIcon')
	partiallyCheckedIconPath = self.currentTheme.get('oppositeColorPartiallyCheckedBoxIcon')

	customFilterIconPath = self.currentTheme.get('customFilterIcon')

	self.createPushButton('selectAllOPMdataButton', '', unCheckAllUserIconPath, 30)
	self.createPushButton('deleteButton_OPMDT', '', deleteIconPath, 35, 'Delete')
	self.createPushButton('customFilterButton_OPMDT', '', customFilterIconPath, 35, 'Custom Filter')
	self.createPushButton('clearAllFiltersButton_OPMDT', '', clearFilterIconPath, 35, 'Clear filters')
	self.createPushButton('downloadButton_OPMDT', '', downloadIconPath, 35, 'Download')
	self.createPushButton('apply_OPMDT', 'Apply', '', 80)


	self.layoutForFilters_opmDataTable.addWidget(self.selectAllOPMdataButton)
	self.layoutForFilters_opmDataTable.addWidget(self.deleteButton_OPMDT)
	self.layoutForFilters_opmDataTable.addWidget(self.customFilterButton_OPMDT)

	self.layoutForFilters_opmDataTable.addItem(QSpacerItem(1, 0, QSizePolicy.Expanding, QSizePolicy.Minimum))
	self.layoutForFilters_opmDataTable.addWidget(self.serachBarOfOPMDataTable)
	self.layoutForFilters_opmDataTable.addLayout(self.fromFormLayout_OPMDT)
	self.layoutForFilters_opmDataTable.addLayout(self.toFormLayout_OPMDT)
	self.layoutForFilters_opmDataTable.addWidget(self.apply_OPMDT)
	self.layoutForFilters_opmDataTable.addWidget(self.clearAllFiltersButton_OPMDT)
	self.layoutForFilters_opmDataTable.addWidget(self.downloadButton_OPMDT)


	mainLayout.addLayout(self.layoutForFilters_opmDataTable)



	## Create a tablewidget to display brief data table of OPM data:
	self.opmDataTable = TableWidget()

	headers = ['', "OPM Id", "Event Date & Time", 'Depot', "Train", "Car No", "OPM Type", 'T&C No', 'T&C Rev', 'Fault Details', 'Investigation Details', "System", "Sub System", 'Other Sub-System', 'Jobcard No', 'Work Start At', 'Work End At', 'Down Time', 'Overlapped IDs']
	self.opmDataTable.setColumnCount(len(headers))
	self.opmDataTable.setHorizontalHeaderLabels(headers)
	self.opmDataTable.setStyleSheet(self.tableWidgetQSS)
	self.opmDataTable.horizontalHeader().setStyleSheet(self.headerHorizontalQSS)
	# self.opmDataTable.verticalHeader().setStyleSheet(self.headerVerticalQSS)
	self.opmDataTable.setAlternatingRowColors(True)
	self.opmDataTable.setShowGrid(False)
	self.opmDataTable.setEditTriggers(QAbstractItemView.NoEditTriggers)
	mainLayout.addWidget(self.opmDataTable)

	self.opmDataTable.setColumnWidth(0, int(0.01 * QApplication.primaryScreen().availableGeometry().width()))
	self.opmDataTable.setColumnWidth(1, int(0.1 * QApplication.primaryScreen().availableGeometry().width()))
	self.opmDataTable.setColumnWidth(2, int(0.09 * QApplication.primaryScreen().availableGeometry().width()))
	self.opmDataTable.setColumnWidth(7, int(0.03 * QApplication.primaryScreen().availableGeometry().width()))
	self.opmDataTable.setColumnWidth(9, int(0.09 * QApplication.primaryScreen().availableGeometry().width()))
	self.opmDataTable.setColumnWidth(10, int(0.09 * QApplication.primaryScreen().availableGeometry().width()))
	self.opmDataTable.setColumnWidth(11, int(0.09 * QApplication.primaryScreen().availableGeometry().width()))
	self.opmDataTable.setColumnWidth(12, int(0.09 * QApplication.primaryScreen().availableGeometry().width()))
	self.opmDataTable.setColumnWidth(13, int(0.09 * QApplication.primaryScreen().availableGeometry().width()))
	self.opmDataTable.setColumnWidth(14, int(0.09 * QApplication.primaryScreen().availableGeometry().width()))
	self.opmDataTable.setColumnWidth(15, int(0.08 * QApplication.primaryScreen().availableGeometry().width()))
	self.opmDataTable.setColumnWidth(16, int(0.08 * QApplication.primaryScreen().availableGeometry().width()))
	self.opmDataTable.setColumnWidth(17, int(0.09 * QApplication.primaryScreen().availableGeometry().width()))
	self.opmDataTable.setColumnWidth(18, int(0.12 * QApplication.primaryScreen().availableGeometry().width()))

	self.selectAllOPMdataButton.setVisible(True)
	self.selectAllOPMdataButton.setCheckable(True)
	self.selectAllOPMdataButton.setFixedHeight(26)

	self.deleteButton_OPMDT.setVisible(False)




	def OnClickingCustomFilterButton_OPMDT():

		self.customFilterWidget_OPMDT = QWidget()
		customFiltertWindowWidth_OPMDT = int(0.365* QApplication.primaryScreen().availableGeometry().width())
		customFiltertWindowHeight_OPMDT = int(0.6 * QApplication.primaryScreen().availableGeometry().height())

		self.customFilterWidget_OPMDT.setWindowTitle("Custom Filter for OPM")
		self.customFilterWidget_OPMDT.setWindowIcon(QIcon('Media/ramsify.png'))
		self.customFilterWidget_OPMDT.setStyleSheet(self.widgetQSS)
		self.customFilterWidget_OPMDT.resize(customFiltertWindowWidth_OPMDT, customFiltertWindowHeight_OPMDT)


		layoutToAddScrollArea = QVBoxLayout()
		self.customFilterWidget_OPMDT.setLayout(layoutToAddScrollArea)
		self.ScrollAreaForCustomFilters_OPMDT = QScrollArea()
		self.ScrollAreaForCustomFilters_OPMDT.setWidgetResizable(True)
		layoutToAddScrollArea.addWidget(self.ScrollAreaForCustomFilters_OPMDT)
		self.ScrollAreaForCustomFilters_OPMDT.setStyleSheet(self.scrollAreaQSS)
		widgetToPutInScrollArea = QWidget()
		mainLayoutOfCustomFilterWidget_OPMDT = QVBoxLayout()
		gridLayoutOfCustomFilterWidget_OPMDT = QGridLayout()
		LayoutForApplyButttonFilterWidget_OPMDT = QHBoxLayout()
		widgetToPutInScrollArea.setLayout(mainLayoutOfCustomFilterWidget_OPMDT)
		self.ScrollAreaForCustomFilters_OPMDT.setWidget(widgetToPutInScrollArea)

		mainLayoutOfCustomFilterWidget_OPMDT.addLayout(gridLayoutOfCustomFilterWidget_OPMDT)
		mainLayoutOfCustomFilterWidget_OPMDT.addLayout(LayoutForApplyButttonFilterWidget_OPMDT)


		lablesForCustomFilters_OPMDT = ['Event Date', 'Depot', "Train", "Car No", "OPM Type", 'T&C No', 'T&C Rev', 'Fault Details', 'Investigation Details', "System", "Sub System", 'Other Sub-System', 'Jobcard No', 'Work Start Date', 'Work End Date', 'Down Time']

		indicesOfComboboxes_OPMDT = [1, 2, 3, 4, 9, 10]
		indicesOfDateEdits_OPMDT = [0, 13, 14]
		indicesOfLineEdits_OPMDT = [5, 6, 7, 8, 11, 12]
		indicesOfSpinBox_OPMDT = [15]

		indicesOfMandatoryFields_OPMDTFilter = [0, 1, 2, 4, 9, 10, 13, 14]


		conditionsForDateEdit = ['Equals To', 'Not Equals To', 'Greater-than or Equals to', 'Less-than or Equals to']
		conditionsForCombobox = ['Equals To', 'Not Equals To']
		conditionsForLineEdits = ['Equals To', 'Not Equals To', 'Contains', 'Does not Contains']
		conditionsForSpinBox = ['Equals To', 'Not Equals To', 'Greater-than or Equals to', 'Less-than or Equals to']

		for i, stri in enumerate(lablesForCustomFilters_OPMDT):
			if i in indicesOfMandatoryFields_OPMDTFilter:
				gridLayoutOfCustomFilterWidget_OPMDT.addWidget(QLabel(stri+'<font color="red">*</font>'), i, 0)
			else:
				gridLayoutOfCustomFilterWidget_OPMDT.addWidget(QLabel(stri), i, 0)


		for ind in indicesOfDateEdits_OPMDT:
			self.createComboBox(conditionsForDateEdit, 'conditionComboboxForDE_OPMDT')
			self.conditionComboboxForDE_OPMDT.setFixedWidth(int(0.1* QApplication.primaryScreen().availableGeometry().width()))
			gridLayoutOfCustomFilterWidget_OPMDT.addWidget(self.conditionComboboxForDE_OPMDT, ind, 1)


			self.createDateEditBox('customFilterDateEdit_OPMDT')
			gridLayoutOfCustomFilterWidget_OPMDT.addWidget(self.customFilterDateEdit_OPMDT, ind, 2)


		comboBoxOptions = {
							1: self.depotsList,
							2: self.trainsetsList,
							3: self.carsList,
							4: ['Cyclic Check', 'Fleet Check', 'HECP', 'SECP', 'Testing', 'Others'],
							9: list(self.BOMSystemDictionary.keys()),
							10: []
							}
		for ind in indicesOfComboboxes_OPMDT:
			self.createComboBox(conditionsForCombobox, 'conditionComboboxForCB_OPMDT')
			self.conditionComboboxForCB_OPMDT.setFixedWidth(int(0.1* QApplication.primaryScreen().availableGeometry().width()))
			gridLayoutOfCustomFilterWidget_OPMDT.addWidget(self.conditionComboboxForCB_OPMDT, ind, 1)

			self.createComboBox(comboBoxOptions[ind], 'customFilterCombobox_OPMDT')
			gridLayoutOfCustomFilterWidget_OPMDT.addWidget(self.customFilterCombobox_OPMDT, ind, 2)


			if ind == 1:
				self.depotComboboxInCustomFilter_OPMDT = self.customFilterCombobox_OPMDT
			if ind == 2:
				self.trainComboboxInCustomFilter_OPMDT = self.customFilterCombobox_OPMDT

				def onChanginDepotCustomFilter_OPMDT():
					if self.depotComboboxInCustomFilter_OPMDT.currentIndex() != -1:
						self.trainComboboxInCustomFilter_OPMDT.setEnabled(True)
						self.trainComboboxInCustomFilter_OPMDT.clear()
						self.trainComboboxInCustomFilter_OPMDT.addItems(self.depotTrainDictionary[self.depotComboboxInCustomFilter_OPMDT.currentText()])
				self.depotComboboxInCustomFilter_OPMDT.currentIndexChanged.connect(onChanginDepotCustomFilter_OPMDT)

				self.trainComboboxInCustomFilter_OPMDT.setEnabled(False)


			if ind == 9:
				self.systemComboboxInCustomFilter_OPMDT = self.customFilterCombobox_OPMDT
			if ind == 10:
				self.subSystemComboboxInCustomFilter_OPMDT = self.customFilterCombobox_OPMDT

				def onChanginSystemCustomFilter_OPMDT():
					if self.systemComboboxInCustomFilter_OPMDT.currentIndex() != -1:
						self.subSystemComboboxInCustomFilter_OPMDT.setEnabled(True)
						self.subSystemComboboxInCustomFilter_OPMDT.clear()
						self.subSystemComboboxInCustomFilter_OPMDT.addItems(self.BOMSystemDictionary[self.systemComboboxInCustomFilter_OPMDT.currentText()])
				self.systemComboboxInCustomFilter_OPMDT.currentIndexChanged.connect(onChanginSystemCustomFilter_OPMDT)

				self.subSystemComboboxInCustomFilter_OPMDT.setEnabled(False)


		for ind in indicesOfLineEdits_OPMDT:
			self.createComboBox(conditionsForLineEdits, 'conditionComboboxForLE_OPMDT')
			self.conditionComboboxForLE_OPMDT.setFixedWidth(int(0.1* QApplication.primaryScreen().availableGeometry().width()))
			gridLayoutOfCustomFilterWidget_OPMDT.addWidget(self.conditionComboboxForLE_OPMDT, ind, 1)

			self.createLineEditBox('customFilterLineEdit_OPMDT')
			gridLayoutOfCustomFilterWidget_OPMDT.addWidget(self.customFilterLineEdit_OPMDT, ind, 2)

		

		for ind in indicesOfSpinBox_OPMDT:
			self.createComboBox(conditionsForSpinBox, 'conditionComboboxForSB_OPMDT')
			self.conditionComboboxForSB_OPMDT.setFixedWidth(int(0.1* QApplication.primaryScreen().availableGeometry().width()))
			gridLayoutOfCustomFilterWidget_OPMDT.addWidget(self.conditionComboboxForSB_OPMDT, ind, 1)

			self.createLineEditBox('customFilterSpinBoxEdit_OPMDT')
			validator = QIntValidator(0, 2147483647)
			self.customFilterSpinBoxEdit_OPMDT.setValidator(validator)
			gridLayoutOfCustomFilterWidget_OPMDT.addWidget(self.customFilterSpinBoxEdit_OPMDT, ind, 2)


		# Create apply and cancel buttons
		self.createPushButton('applyCustomFilterBtn_OPMDT', 'Apply', '', width=int(0.050 * QApplication.primaryScreen().availableGeometry().width()))
		self.applyCustomFilterBtn_OPMDT.setFixedHeight(30)

		self.createPushButton('cancelCustomFilterBtn_OPMDT', 'Cancel', '',width=int(0.050 * QApplication.primaryScreen().availableGeometry().width()))
		self.cancelCustomFilterBtn_OPMDT.setFixedHeight(30)
		
		LayoutForApplyButttonFilterWidget_OPMDT.addWidget(self.applyCustomFilterBtn_OPMDT, alignment = Qt.AlignRight)
		LayoutForApplyButttonFilterWidget_OPMDT.addWidget(self.cancelCustomFilterBtn_OPMDT, alignment = Qt.AlignLeft)


		def onClickingApplyCustomFilter_OPMDT():
			customFilterValid = True
			selectedIndicesInCustomFilter = []

			for r in range(gridLayoutOfCustomFilterWidget_OPMDT.rowCount()):
				if r not in indicesOfDateEdits_OPMDT:
					conditionBoxSelected = False
					fieldBoxSelected = False

					if gridLayoutOfCustomFilterWidget_OPMDT.itemAtPosition(r, 1).widget().currentIndex() != -1:
						conditionBoxSelected = True

					if r in indicesOfComboboxes_OPMDT:
						if gridLayoutOfCustomFilterWidget_OPMDT.itemAtPosition(r, 2).widget().currentIndex() != -1:
							fieldBoxSelected = True


					elif r in indicesOfLineEdits_OPMDT:
						if gridLayoutOfCustomFilterWidget_OPMDT.itemAtPosition(r, 2).widget().text() != '':
							fieldBoxSelected = True

					elif r in indicesOfSpinBox_OPMDT:
						if gridLayoutOfCustomFilterWidget_OPMDT.itemAtPosition(r, 2).widget().text() != '':
							fieldBoxSelected = True



					if conditionBoxSelected ^ fieldBoxSelected:
						if conditionBoxSelected:
							if r in indicesOfComboboxes_OPMDT:
								gridLayoutOfCustomFilterWidget_OPMDT.itemAtPosition(r, 1).widget().setProperty('error', False)
								gridLayoutOfCustomFilterWidget_OPMDT.itemAtPosition(r, 1).widget().setStyleSheet(self.comboBoxQSS)

								if r in indicesOfMandatoryFields_OPMDTFilter:
									gridLayoutOfCustomFilterWidget_OPMDT.itemAtPosition(r, 2).widget().setProperty('error', True)
									gridLayoutOfCustomFilterWidget_OPMDT.itemAtPosition(r, 2).widget().setStyleSheet(self.comboBoxQSS)
									customFilterValid = False
								else:
									selectedIndicesInCustomFilter.append(r)


							if r in indicesOfLineEdits_OPMDT:
								gridLayoutOfCustomFilterWidget_OPMDT.itemAtPosition(r, 1).widget().setProperty('error', False)
								gridLayoutOfCustomFilterWidget_OPMDT.itemAtPosition(r, 1).widget().setStyleSheet(self.comboBoxQSS)

								if r in indicesOfMandatoryFields_OPMDTFilter:
									gridLayoutOfCustomFilterWidget_OPMDT.itemAtPosition(r, 2).widget().setProperty('error', True)
									gridLayoutOfCustomFilterWidget_OPMDT.itemAtPosition(r, 2).widget().setStyleSheet(self.lineEditBoxQSS)
									customFilterValid = False
								else:
									selectedIndicesInCustomFilter.append(r)

							if r in indicesOfSpinBox_OPMDT:
								gridLayoutOfCustomFilterWidget_OPMDT.itemAtPosition(r, 1).widget().setProperty('error', False)
								gridLayoutOfCustomFilterWidget_OPMDT.itemAtPosition(r, 1).widget().setStyleSheet(self.comboBoxQSS)

								if r in indicesOfMandatoryFields_OPMDTFilter:
									gridLayoutOfCustomFilterWidget_OPMDT.itemAtPosition(r, 2).widget().setProperty('error', True)
									gridLayoutOfCustomFilterWidget_OPMDT.itemAtPosition(r, 2).widget().setStyleSheet(self.lineEditBoxQSS)
									customFilterValid = False
								else:
									selectedIndicesInCustomFilter.append(r)

						if fieldBoxSelected:
							gridLayoutOfCustomFilterWidget_OPMDT.itemAtPosition(r, 2).widget().setProperty('error', False)
							if r in indicesOfComboboxes_OPMDT:
								gridLayoutOfCustomFilterWidget_OPMDT.itemAtPosition(r, 2).widget().setStyleSheet(self.comboBoxQSS)
							elif r in indicesOfLineEdits_OPMDT:
								gridLayoutOfCustomFilterWidget_OPMDT.itemAtPosition(r, 2).widget().setStyleSheet(self.lineEditBoxQSS)
							elif r in indicesOfSpinBox_OPMDT:
								gridLayoutOfCustomFilterWidget_OPMDT.itemAtPosition(r, 2).widget().setStyleSheet(self.lineEditBoxQSS)


							gridLayoutOfCustomFilterWidget_OPMDT.itemAtPosition(r, 1).widget().setProperty('error', True)
							gridLayoutOfCustomFilterWidget_OPMDT.itemAtPosition(r, 1).widget().setStyleSheet(self.comboBoxQSS)
							customFilterValid = False

					else:
						gridLayoutOfCustomFilterWidget_OPMDT.itemAtPosition(r, 1).widget().setProperty('error', False)
						gridLayoutOfCustomFilterWidget_OPMDT.itemAtPosition(r, 1).widget().setStyleSheet(self.comboBoxQSS)

						if r in indicesOfComboboxes_OPMDT:
							gridLayoutOfCustomFilterWidget_OPMDT.itemAtPosition(r, 2).widget().setProperty('error', False)
							gridLayoutOfCustomFilterWidget_OPMDT.itemAtPosition(r, 2).widget().setStyleSheet(self.comboBoxQSS)

						if r in indicesOfLineEdits_OPMDT:
							gridLayoutOfCustomFilterWidget_OPMDT.itemAtPosition(r, 2).widget().setProperty('error', False)
							gridLayoutOfCustomFilterWidget_OPMDT.itemAtPosition(r, 2).widget().setStyleSheet(self.lineEditBoxQSS)

						if r in indicesOfSpinBox_OPMDT:
							gridLayoutOfCustomFilterWidget_OPMDT.itemAtPosition(r, 2).widget().setProperty('error', False)
							gridLayoutOfCustomFilterWidget_OPMDT.itemAtPosition(r, 2).widget().setStyleSheet(self.lineEditBoxQSS)

					if conditionBoxSelected and fieldBoxSelected:
						if r not in selectedIndicesInCustomFilter:
							selectedIndicesInCustomFilter.append(r)
				else:
					if gridLayoutOfCustomFilterWidget_OPMDT.itemAtPosition(r, 1).widget().currentIndex() != -1:
						if r not in selectedIndicesInCustomFilter:
							selectedIndicesInCustomFilter.append(r)


			if customFilterValid:
				for row in range(self.opmDataTable.rowCount()):
					self.opmDataTable.setRowHidden(row, False)
				


				for r in selectedIndicesInCustomFilter:
					for row in range(self.opmDataTable.rowCount()):
						if not self.opmDataTable.isRowHidden(row):
							conditionWidget = gridLayoutOfCustomFilterWidget_OPMDT.itemAtPosition(r, 1).widget()
							fieldWidget = gridLayoutOfCustomFilterWidget_OPMDT.itemAtPosition(r, 2).widget()

							if r in indicesOfComboboxes_OPMDT:
								if conditionWidget.currentIndex() == 0:
									if fieldWidget.currentIndex() != -1:
										if fieldWidget.currentText() != self.opmDataTable.item(row, r+2).text():
											self.opmDataTable.setRowHidden(row, True)
									else:
										if '' != self.opmDataTable.item(row, r+2).text():
											self.opmDataTable.setRowHidden(row, True)

								elif conditionWidget.currentIndex() == 1:
									if fieldWidget.currentIndex() != -1:
										if fieldWidget.currentText() == self.opmDataTable.item(row, r+2).text():
											self.opmDataTable.setRowHidden(row, True)
									else:
										if '' == self.opmDataTable.item(row, r+2).text():
											self.opmDataTable.setRowHidden(row, True)


							if r in indicesOfLineEdits_OPMDT:
								if conditionWidget.currentIndex() == 0:
									if fieldWidget.text().lower() != self.opmDataTable.item(row, r+2).text().lower():
										self.opmDataTable.setRowHidden(row, True)

								elif conditionWidget.currentIndex() == 1:
									if fieldWidget.text().lower() == self.opmDataTable.item(row, r+2).text().lower():
										self.opmDataTable.setRowHidden(row, True)

								elif conditionWidget.currentIndex() == 2:
									if not fieldWidget.text().lower() in self.opmDataTable.item(row, r+2).text().lower():
										self.opmDataTable.setRowHidden(row, True)

								elif conditionWidget.currentIndex() == 2:
									if fieldWidget.text().lower() in self.opmDataTable.item(row, r+2).text().lower():
										self.opmDataTable.setRowHidden(row, True)


							if r in indicesOfSpinBox_OPMDT:
								if conditionWidget.currentIndex() == 0:
									if int(fieldWidget.text()) != int(self.opmDataTable.item(row, r+2).text()):
										self.opmDataTable.setRowHidden(row, True)

								elif conditionWidget.currentIndex() == 1:
									if int(fieldWidget.text()) == int(self.opmDataTable.item(row, r+2).text()):
										self.opmDataTable.setRowHidden(row, True)

								elif conditionWidget.currentIndex() == 2:
									if int(fieldWidget.text()) > int(self.opmDataTable.item(row, r+2).text()):
										self.opmDataTable.setRowHidden(row, True)

								elif conditionWidget.currentIndex() == 3:
									if int(fieldWidget.text()) < int(self.opmDataTable.item(row, r+2).text()):
										self.opmDataTable.setRowHidden(row, True)



							if r in indicesOfDateEdits_OPMDT:

								stringDateFromTable = self.opmDataTable.item(row, r+2).text().split(' ')[0]

								qdateFromTable = QDate.fromString(stringDateFromTable, "yyyy-MM-dd")

								if conditionWidget.currentIndex() == 0:
									if fieldWidget.date() != qdateFromTable:
										self.opmDataTable.setRowHidden(row, True)

								elif conditionWidget.currentIndex() == 1:
									if fieldWidget.date() == qdateFromTable:
										self.opmDataTable.setRowHidden(row, True)

								elif conditionWidget.currentIndex() == 2:
									if fieldWidget.date() > qdateFromTable:
										self.opmDataTable.setRowHidden(row, True)

								elif conditionWidget.currentIndex() == 3:
									if fieldWidget.date() < qdateFromTable:
										self.opmDataTable.setRowHidden(row, True)


		self.applyCustomFilterBtn_OPMDT.clicked.connect(onClickingApplyCustomFilter_OPMDT)

		def onClickingCancelCustomFilter_OPMDT():
			for r in range(gridLayoutOfCustomFilterWidget_OPMDT.rowCount()):
				gridLayoutOfCustomFilterWidget_OPMDT.itemAtPosition(r, 1).widget().setCurrentIndex(-1)
				gridLayoutOfCustomFilterWidget_OPMDT.itemAtPosition(r, 1).widget().setProperty('error', False)
				gridLayoutOfCustomFilterWidget_OPMDT.itemAtPosition(r, 1).widget().setStyleSheet(self.comboBoxQSS)

				if r in indicesOfComboboxes_OPMDT:
					gridLayoutOfCustomFilterWidget_OPMDT.itemAtPosition(r, 2).widget().setCurrentIndex(-1)
					if r in [2, 9]:
						gridLayoutOfCustomFilterWidget_OPMDT.itemAtPosition(r, 2).widget().setEnabled(False)
					gridLayoutOfCustomFilterWidget_OPMDT.itemAtPosition(r, 2).widget().setProperty('error', False)
					gridLayoutOfCustomFilterWidget_OPMDT.itemAtPosition(r, 2).widget().setStyleSheet(self.comboBoxQSS)

				if r in indicesOfLineEdits_OPMDT:
					gridLayoutOfCustomFilterWidget_OPMDT.itemAtPosition(r, 2).widget().clear()
					gridLayoutOfCustomFilterWidget_OPMDT.itemAtPosition(r, 2).widget().setProperty('error', False)
					gridLayoutOfCustomFilterWidget_OPMDT.itemAtPosition(r, 2).widget().setStyleSheet(self.lineEditBoxQSS)

				if r in indicesOfSpinBox_OPMDT:
					gridLayoutOfCustomFilterWidget_OPMDT.itemAtPosition(r, 2).widget().clear()
					gridLayoutOfCustomFilterWidget_OPMDT.itemAtPosition(r, 2).widget().setProperty('error', False)
					gridLayoutOfCustomFilterWidget_OPMDT.itemAtPosition(r, 2).widget().setStyleSheet(self.lineEditBoxQSS)

				if r in indicesOfDateEdits_OPMDT:
					gridLayoutOfCustomFilterWidget_OPMDT.itemAtPosition(r, 2).widget().setDate(gridLayoutOfCustomFilterWidget_OPMDT.itemAtPosition(r, 2).widget().minimumDate())





		self.cancelCustomFilterBtn_OPMDT.clicked.connect(onClickingCancelCustomFilter_OPMDT)

		self.customFilterWidget_OPMDT.show()

	self.customFilterButton_OPMDT.clicked.connect(OnClickingCustomFilterButton_OPMDT)


	def onclicking_delete_OPMDT():
			
		selectedOPMIndices_ = []
		selectedOPMIds = []

		numberOfSelectedOPMIds = 0

		for i in range(self.opmDataTable.rowCount()):
			if not self.opmDataTable.isRowHidden(i):
				if isinstance(self.opmDataTable.cellWidget(i,0), QCheckBox):
					if self.opmDataTable.cellWidget(i,0).checkState() == Qt.Checked:
						selectedOPMIndices_.append(i)

						OPMIdButton = self.opmDataTable.cellWidget(i, 1)
						if OPMIdButton:
							# selectedOPMIds = OPMIdButton.text()
							selectedOPMIds.append(OPMIdButton.text())
							numberOfSelectedOPMIds += 1
		

		if selectedOPMIds:

			confirmDeleteOPMsgBox = QMessageBox()
			confirmDeleteOPMsgBox.setIcon(QMessageBox.Question)
			confirmDeleteOPMsgBox.setText(f"Are you sure you want to delete {numberOfSelectedOPMIds} OPMs?")
			confirmDeleteOPMsgBox.setWindowTitle("Confirm")
			confirmDeleteOPMsgBox.setWindowIcon(QIcon('Media/ramsify.png'))
			confirmDeleteOPMsgBox.setStandardButtons(QMessageBox.Ok | QMessageBox.No)
			
			userResponse = confirmDeleteOPMsgBox.exec()

			if userResponse == QMessageBox.Ok:
				for ind in sorted(selectedOPMIndices_, reverse=True):
					opmIdToDelete = selectedOPMIds[selectedOPMIndices_.index(ind)]
					sql = "DELETE FROM other_preventive_maintenance WHERE opm_id = %s"
					values = (opmIdToDelete,)
					self.cursor.execute(sql, values)
					self.mydb.commit()
					self.opmDataTable.removeRow(ind)

				opmDeleteSuccessMsgBox = QMessageBox()
				opmDeleteSuccessMsgBox.setIcon(QMessageBox.Information) 
				opmDeleteSuccessMsgBox.setText(f'{numberOfSelectedOPMIds} OPMs deleted successfully.')
				opmDeleteSuccessMsgBox.setWindowTitle("Message")
				opmDeleteSuccessMsgBox.setWindowIcon(QIcon('Media/ramsify.png'))
				opmDeleteSuccessMsgBox.setStandardButtons(QMessageBox.Ok)
				opmDeleteSuccessMsgBox.exec()
			
				self.deleteButton_OPMDT.hide()
				self.selectAllOPMdataButton.setChecked(False)
				self.selectAllOPMdataButton.setIcon(QIcon(unCheckAllUserIconPath))
			
			else:
				pass

	self.deleteButton_OPMDT.clicked.connect(onclicking_delete_OPMDT)


	def onclicking_selectall_OPMDT2(checked):
		if checked:
			self.selectAllOPMdataButton.setIcon(QIcon(checkAllUserIconPath))

			for i in range(self.opmDataTable.rowCount()):
				if not self.opmDataTable.isRowHidden(i):
					if isinstance(self.opmDataTable.cellWidget(i,0), QCheckBox):
						self.opmDataTable.cellWidget(i,0).setCheckState(Qt.Checked)
		
		else:
			self.selectAllOPMdataButton.setIcon(QIcon(unCheckAllUserIconPath))

			for i in range(self.opmDataTable.rowCount()):
				if not self.opmDataTable.isRowHidden(i):
					if isinstance(self.opmDataTable.cellWidget(i,0), QCheckBox):
						self.opmDataTable.cellWidget(i,0).setCheckState(Qt.Unchecked)

	self.selectAllOPMdataButton.toggled.connect(onclicking_selectall_OPMDT2)



	def on_filter_opm_data_table():
		searchText = self.serachBarOfOPMDataTable.text().lower()

		for row in range(self.opmDataTable.rowCount()):
			self.opmDataTable.setRowHidden(row, True)
			date_item = self.opmDataTable.item(row, 8)

			if searchText in self.opmDataTable.cellWidget(row, 1).text().lower():
				self.opmDataTable.setRowHidden(row, False)

			for col in range(1, self.opmDataTable.columnCount()):
				item = self.opmDataTable.item(row, col)
				if item is not None and searchText in item.text().lower():
					self.opmDataTable.setRowHidden(row, False)
					break

	self.serachBarOfOPMDataTable.textChanged.connect(on_filter_opm_data_table)



	def find_totalDuration(datetime_pairs):
		totalDuration = timedelta()

		# Sort datetime pairs by start datetime
		if datetime_pairs:
			sorted_datetime_pairs = sorted(datetime_pairs, key=lambda x: x[0])
			# #print(sorted_datetime_pairs)
			# Initialize variables to keep track of the current start and end datetime
			current_start = sorted_datetime_pairs[0][0]
			current_end = sorted_datetime_pairs[0][1]

			# Iterate through the sorted datetime pairs
			for start, end in sorted_datetime_pairs[1:]:
				# Check for overlap
				if start < current_end:
					# Update the current end datetime if there is an overlap
					current_end = max(current_end, end)
				else:
					# Add the overlapping duration to the total
					totalDuration += current_end - current_start

					# Update the current start and end datetimes
					current_start = start
					current_end = end

			# Add the final overlapping duration (if any)
			totalDuration += current_end - current_start

			return totalDuration

	self.opmDataTable.insertColumn(self.opmDataTable.columnCount())
	self.opmDataTable.setHorizontalHeaderItem(self.opmDataTable.columnCount() - 1, QTableWidgetItem("DownTime after Overlap"))

	def onClickingApplyBtn_OPMDT():
		self.totalDataToFindOverlapIds_OPM = []
		self.opmDataTable.clearContents()
		self.opmDataTable.setRowCount(0)

		self.opmDataTable.removeColumn(8)
		self.opmDataTable.removeColumn(7)


		queryToFetchOpmData = '''SELECT 
			other_preventive_maintenance.opm_id,
			other_preventive_maintenance.event_datetime,
			other_preventive_maintenance.depot_id,
			trainsets.trainset,
			other_preventive_maintenance.car_number,
			other_preventive_maintenance.opm_type,
			other_preventive_maintenance.opm_fault_details,
			other_preventive_maintenance.opm_investigation_details,
			bom_sys.equipment,
			bom_sub.equipment,
			other_preventive_maintenance.other_subsystem,
			other_preventive_maintenance.jobcard,
			other_preventive_maintenance.work_start_at,
			other_preventive_maintenance.work_end_at,
			other_preventive_maintenance.downtime,
			other_preventive_maintenance.trainset_id,
			other_preventive_maintenance.t_c_no,
			other_preventive_maintenance.t_c_rev

		FROM
			other_preventive_maintenance
		LEFT JOIN
			trainsets ON other_preventive_maintenance.trainset_id = trainsets.id
		LEFT JOIN
			bom bom_sys ON other_preventive_maintenance.system_id = bom_sys.id
		LEFT JOIN
			bom bom_sub ON other_preventive_maintenance.subsystem_id = bom_sub.id
		WHERE
			other_preventive_maintenance.work_start_at BETWEEN %s AND %s

		'''


		from_date = self.fromDateEditBox_OPMDT.date().toString("yyyy-MM-dd")
		to_date_ = self.toDateEditBox_OPMDT.date()
		to_date_ = to_date_.addDays(1)
		to_date = to_date_.toString("yyyy-MM-dd")


		self.cursor.execute(queryToFetchOpmData, (from_date, to_date))
		opmDataTableResult = self.cursor.fetchall()
		self.opmDataTable.setRowCount(len(opmDataTableResult))

		dataToFindOverlappIds_OPM = [((row[12], row[13]), row[0], row[15]) for row in opmDataTableResult]
		self.totalDataToFindOverlapIds_OPM += dataToFindOverlappIds_OPM



		query1 = '''SELECT
		corrective_maintenance.cm_id,
		corrective_maintenance.work_start_at,
		corrective_maintenance.work_end_at,
		corrective_maintenance.trainset_id
		FROM
			corrective_maintenance
		
		WHERE
			corrective_maintenance.work_start_at BETWEEN %s AND %s
		ORDER BY work_start_at
		'''


		self.cursor.execute(query1, (from_date, to_date))
		CMDataResult2 = self.cursor.fetchall()

		
		dataToFindOverlappIds_CM3 = [((row[1], row[2]), row[0], row[3]) for row in CMDataResult2]
		self.totalDataToFindOverlapIds_OPM += dataToFindOverlappIds_CM3



		query = '''SELECT
			service_checks.sc_id,
			service_checks.trainset_id,
			trainsets.trainset,
			service_checks.A_1,
			service_checks.A_2,
			service_checks.A_3,
			service_checks.B1_1,
			service_checks.B1_2,
			service_checks.B4,
			service_checks.B8,
			service_checks.C1,
			service_checks.C2
		FROM
			service_checks
		LEFT JOIN
			trainsets ON service_checks.trainset_id = trainsets.id
		'''

		self.cursor.execute(query)
		dataForOverLaps = self.cursor.fetchall()


		
		dataToFindOverlappIds_SC = []
		for row in dataForOverLaps:
			for i, val in enumerate(row[3:]):
				if val:
					if i == 0:
						endDate = val + timedelta(hours=self.ASCHours)
						strr = 'A1'
					
					if i == 1:
						endDate = val + timedelta(hours=self.ASCHours)
						strr = 'A2'

					if i == 2:
						endDate = val + timedelta(hours=self.ASCHours)
						strr = 'A3'

					if i == 3:
						endDate = val + timedelta(hours=self.B1SCHours)
						strr = 'B1_1'

					if i == 4:
						endDate = val + timedelta(hours=self.B1SCHours)
						strr = 'B1_2'

					if i == 5:
						endDate = val + timedelta(hours=self.B4SCHours)
						strr = 'B4'

					if i == 6:
						endDate = val + timedelta(hours=self.B8SCHours)
						strr = 'B8'

					if i == 7:
						endDate = val + timedelta(hours=self.C1SCHours)
						strr = 'C1'

					if i == 8:
						endDate = val + timedelta(hours=self.C2SCHours)
						strr = 'C2'

					dataToFindOverlappIds_SC.append(((val, endDate), row[0]+' tr' +str(row[2].split('#')[1]) + ' ' + strr, row[1]))

		self.totalDataToFindOverlapIds_OPM += dataToFindOverlappIds_SC


		

		current_date = datetime.now()

		# Calculate the start of the current month
		start_of_current_month = datetime(current_date.year, current_date.month, 1)

		# Calculate the start of the previous month
		start_of_previous_month = start_of_current_month - relativedelta(months=1)

		# Calculate the end of the current month
		end_of_current_month = start_of_current_month + relativedelta(months=1, days=-1)

		# Calculate the end of the previous month
		end_of_previous_month = start_of_current_month + relativedelta(days=-1)


		def onStateChangedOf_OPMCheckBox():
			all_checked = True
			all_unchecked = True

			for i in range(self.opmDataTable.rowCount()):
				if not self.opmDataTable.isRowHidden(i):
					if isinstance(self.opmDataTable.cellWidget(i,0), QCheckBox):
						if self.opmDataTable.cellWidget(i,0).isChecked():
							all_unchecked = False
						else:
							all_checked = False

			if all_checked or all_unchecked:
				some_checked = False
			else:
				some_checked = True


			if all_checked:
				self.deleteButton_OPMDT.show()
				self.selectAllOPMdataButton.setIcon(QIcon(checkAllUserIconPath))
				self.selectAllOPMdataButton.setChecked(True)

			if all_unchecked:
				self.deleteButton_OPMDT.hide()
				self.selectAllOPMdataButton.setIcon(QIcon(unCheckAllUserIconPath))

			if some_checked:
				self.deleteButton_OPMDT.show()
				self.selectAllOPMdataButton.setIcon(QIcon(partiallyCheckedIconPath))



		def connect_button_clicked(button, on_clicked_function, rowNum):
			button.clicked.connect(lambda : on_clicked_function(self, button.text(), rowNum))


		for row, rowData in enumerate(opmDataTableResult):
			work_start_date = rowData[-6]

			if start_of_previous_month <= work_start_date <= end_of_current_month:
				opmCheckBoxWidget = QCheckBox('')
				opmCheckBoxWidget.setStyleSheet(self.checkBoxQSS)
				self.opmDataTable.setCellWidget(row, 0, opmCheckBoxWidget)
				opmCheckBoxWidget.stateChanged.connect(onStateChangedOf_OPMCheckBox)

			for col, value in enumerate(rowData[:-3]):
				if isinstance(value, datetime):
					value = value.strftime('%Y-%m-%d %H:%M')

				if col == 0:
					button = QPushButton(str(value))
					connect_button_clicked(button, onButtonClicked_opmData, row)

					button.setStyleSheet(self.tableButtonQSS)
					button.setCursor(Qt.PointingHandCursor)
					self.opmDataTable.setCellWidget(row, col+1, button)
				else:
					if value != None:
						item = QTableWidgetItem(str(value))
					else:
						item = QTableWidgetItem('')
					item.setFlags(item.flags() & ~Qt.ItemIsEditable)
					item.setTextAlignment(Qt.AlignCenter)
					item.setToolTip(item.text())
					self.opmDataTable.setItem(row, col+1, item)


		###########################prasa##########################


		self.opmDataTable.insertColumn(7)
		self.opmDataTable.setHorizontalHeaderItem(7, QTableWidgetItem("T&C No"))
		self.opmDataTable.insertColumn(8)
		self.opmDataTable.setHorizontalHeaderItem(8, QTableWidgetItem("T&C Rev"))


		for row, rowData in enumerate(opmDataTableResult):	
			if rowData[-2] == None:
				value = ''
			else:
				value = rowData[-2]
			item = QTableWidgetItem(str(value))
			item.setTextAlignment(Qt.AlignCenter)
			item.setToolTip(item.text())
			self.opmDataTable.setItem(row, 7, item)

		# for row, rowData in enumerate(opmDataTableResult):	
			if rowData[-1] == None:
					value = ''
			else:
				value = rowData[-1]
			item = QTableWidgetItem(str(value))
			item.setTextAlignment(Qt.AlignCenter)
			item.setToolTip(item.text())
			self.opmDataTable.setItem(row, 8, item)

		#############################prasa#####################	

		# self.opmDataTable.setColumnHidden(self.opmDataTable.columnCount()-1, True)
		train_id_dict = {}

		for tup in self.totalDataToFindOverlapIds_OPM:
			train_id = tup[2]
			if train_id not in train_id_dict:
				train_id_dict[train_id] = []

			train_id_dict[train_id].append(tup)


		def find_overlapping_sets_with_ids(datetime_pairs):

			# Sort datetime pairs by start datetime
			sorted_datetime_pairs = sorted(datetime_pairs, key=lambda x: x[0][0])

			checkedIds = []
			totalSets = []
			totalSetsDurations = []
			totalSetsStartEndPairs = []
			checkedTrain = []
			# print(sorted_datetime_pairs)
			# print('--------------------------')
			for i, ((start, end), current_id, trainId) in enumerate(sorted_datetime_pairs):
				if current_id not in checkedIds:
					currentSet = [current_id]
					currentSetDurations = [end - start]
					CurrentStartEndPair = [(start, end)]
					for j in range(i+1, len(sorted_datetime_pairs)):
						if trainId == sorted_datetime_pairs[j][2]:
							if end > sorted_datetime_pairs[j][0][0]:
								# print(sorted_datetime_pairs[j][1])
								currentSet.append(sorted_datetime_pairs[j][1])
								currentSetDurations.append(sorted_datetime_pairs[j][0][1] - sorted_datetime_pairs[j][0][0])
								CurrentStartEndPair.append((sorted_datetime_pairs[j][0][0], sorted_datetime_pairs[j][0][1]))
								end = max(end, sorted_datetime_pairs[j][0][1])
					totalSets.append(currentSet)
					totalSetsDurations.append(currentSetDurations)
					totalSetsStartEndPairs.append(CurrentStartEndPair)
					checkedIds += currentSet

			return totalSets, totalSetsDurations, totalSetsStartEndPairs
		

		allSets = []
		for train_id, listt in train_id_dict.items():
			sett, settDurations, settStartEndPairs = find_overlapping_sets_with_ids(listt)
			allSets.append([sett, settDurations, settStartEndPairs])

		for i in range(self.opmDataTable.rowCount()):
			tableId = self.opmDataTable.cellWidget(i, 1).text()
			for a, trainIdsData in enumerate(allSets):
				for b, lisst in enumerate(trainIdsData[0]):
					if tableId in lisst:
						if len(lisst) > 1:
							totalTimeOfLisst = sum(allSets[a][1][b], timedelta())
							totalTimeOfLisstInMinutes = totalTimeOfLisst.total_seconds() / 60

							totalTimeOfLisstWithoutOverlap = find_totalDuration(allSets[a][2][b])
							totalTimeOfLisstWithoutOverlapInMinutes = totalTimeOfLisstWithoutOverlap.total_seconds() / 60

							item = QTableWidgetItem(str(lisst))
							item.setFlags(item.flags() & ~Qt.ItemIsEditable)
							item.setTextAlignment(Qt.AlignCenter)
							item.setToolTip(item.text())
							self.opmDataTable.setItem(i, self.opmDataTable.columnCount()-2, item)

							currentDurationInList = allSets[a][1][b][lisst.index(tableId)]
							currentDurationInListInMinutes = currentDurationInList.total_seconds() / 60

							overlapDuration = (currentDurationInListInMinutes/totalTimeOfLisstInMinutes)*totalTimeOfLisstWithoutOverlapInMinutes
							item = QTableWidgetItem(str(round(overlapDuration,2)))
							item.setFlags(item.flags() & ~Qt.ItemIsEditable)
							item.setTextAlignment(Qt.AlignCenter)
							item.setToolTip(item.text())
							self.opmDataTable.setItem(i, self.opmDataTable.columnCount()-1, item)

			if not self.opmDataTable.item(i, self.opmDataTable.columnCount()-1):
				item = QTableWidgetItem(self.opmDataTable.item(i, self.opmDataTable.columnCount()-3).text())
				item.setFlags(item.flags() & ~Qt.ItemIsEditable)
				item.setTextAlignment(Qt.AlignCenter)
				item.setToolTip(item.text())
				self.opmDataTable.setItem(i, self.opmDataTable.columnCount()-1, item)







		on_filter_opm_data_table()

	self.apply_OPMDT.clicked.connect(onClickingApplyBtn_OPMDT)



	## Function to clear the filter:
	def onClickingClearBtnOf_OPMDT():
		current_date = datetime.now()

		date1 = datetime(self.startingYear, self.startingMonth, 1)
		date2 = datetime(current_date.year, current_date.month, 1)

		# Calculate the difference in months
		difference_in_months = (date2.year - date1.year) * 12 + date2.month - date1.month

		if difference_in_months <= 3:
			self.fromDateEditBox_OPMDT.setDate(start_date)

		else:
			six_months_before = current_date - relativedelta(months = 3)
			sixMonthsBeforeDate = (datetime(six_months_before.date().year, six_months_before.date().month, 1)).date()

			self.fromDateEditBox_OPMDT.setDate(sixMonthsBeforeDate)
		
		self.toDateEditBox_OPMDT.setDate(QDate.currentDate())

		self.serachBarOfOPMDataTable.clear()

		onClickingApplyBtn_OPMDT()

	self.clearAllFiltersButton_OPMDT.clicked.connect(onClickingClearBtnOf_OPMDT)


	def onClickingDownloadButton_OPMDT():
		file_path, _ = QFileDialog.getSaveFileName(self, "Save Excel File", "", "Excel Files (*.xlsx)")
		if file_path:

			wb = Workbook()
			ws = wb.active
			
			headers = []
			for col in range(1, self.opmDataTable.columnCount()):
				if not self.opmDataTable.isColumnHidden(col):
					header_item = self.opmDataTable.horizontalHeaderItem(col)
					if header_item is not None:
						headers.append(header_item.text())

			ws.append(headers)

			row_index = 2
			for row in range(self.opmDataTable.rowCount()):
				if not self.opmDataTable.isRowHidden(row):
					# ws.cell(row=row_index, column=1).value = self.opmDataTable.cellWidget(row, 0).text()
					for col in range(1, self.opmDataTable.columnCount()):
						if col == 1:
							wid = self.opmDataTable.cellWidget(row, col)
							if isinstance(wid, QPushButton):
								ws.cell(row=row_index, column=col).value = wid.text()
						else:
							item = self.opmDataTable.item(row, col)
							if item is not None:
								ws.cell(row=row_index, column=col).value = item.text()

					row_index += 1
					

			wb.save(file_path)

			opmDownloadMsgBox = QMessageBox()
			opmDownloadMsgBox.setIcon(QMessageBox.Information) 
			opmDownloadMsgBox.setText(f'Data downloaded successfully')
			opmDownloadMsgBox.setWindowTitle("Message")
			opmDownloadMsgBox.setWindowIcon(QIcon('Media/ramsify.png'))
			opmDownloadMsgBox.setStandardButtons(QMessageBox.Ok)
			opmDownloadMsgBox.exec_()


	self.downloadButton_OPMDT.clicked.connect(onClickingDownloadButton_OPMDT)



	def connect_button_clicked(opmDataIdButton, on_clicked_function):
		opmDataIdButton.clicked.connect(lambda : on_clicked_function(self, opmDataIdButton.text()))


	
	onClickingClearBtnOf_OPMDT()

def onButtonClicked_opmData(self, opmId, rowNum):
	from PySide6.QtWidgets import QApplication
	
	# OPMDataTableWindowWidth = int(0.6* QApplication.primaryScreen().availableGeometry().width())
	# OPMDataTableWindowHeight = int(0.4 * QApplication.primaryScreen().availableGeometry().height())

	self.opmWindow = QWidget()
	self.opmWindow.setWindowTitle(opmId)
	self.opmWindow.setWindowIcon(QIcon('Media/ramsify.png'))
	self.opmWindow.move(700, 50)
	self.opmWindow.setMinimumWidth(680)
	self.opmWindow.setMinimumHeight(900)
	
	scrollArea = QScrollArea()
	scrollArea.setWidgetResizable(True)
	scrollArea.setStyleSheet(self.scrollAreaQSS)

	self.opmWindow.setLayout(QVBoxLayout())
	self.opmWindow.layout().addWidget(scrollArea)

	contentsWidget = QWidget()
	vLayout = QVBoxLayout()
	hLayout = QHBoxLayout()
	contentsWidget.setLayout(vLayout)
	scrollArea.setWidget(contentsWidget)

	self.opmWindow.setLayout(vLayout)
	vLayout.addLayout(hLayout)

	formLayout1 =QFormLayout()
	hLayout.addLayout(formLayout1)



	## Construct a query to fetch the neccessary data from the db to display in the table.
	queryToFetchSelectedOPMId = ''' 

	SELECT 
		other_preventive_maintenance.opm_id,
		other_preventive_maintenance.event_datetime,
		other_preventive_maintenance.depot_id,
		trainsets.trainset,
		other_preventive_maintenance.car_number,
		other_preventive_maintenance.opm_type,
		other_preventive_maintenance.opm_fault_details,
		other_preventive_maintenance.opm_investigation_details,
		bom_sys.equipment,
		bom_sub.equipment,
		other_preventive_maintenance.other_subsystem,
		other_preventive_maintenance.jobcard,
		other_preventive_maintenance.attachments,
		other_preventive_maintenance.work_start_at,
		other_preventive_maintenance.work_end_at,
		other_preventive_maintenance.downtime,
		other_preventive_maintenance.t_c_no,
		other_preventive_maintenance.t_c_rev

	FROM
		other_preventive_maintenance
	LEFT JOIN
		trainsets ON other_preventive_maintenance.trainset_id = trainsets.id
	LEFT JOIN
		bom bom_sys ON other_preventive_maintenance.system_id = bom_sys.id
	LEFT JOIN
		bom bom_sub ON other_preventive_maintenance.subsystem_id = bom_sub.id
		WHERE opm_id = "{}"
	
	'''.format(opmId)

	self.cursor.execute(queryToFetchSelectedOPMId)
	selectedOPMIdDataRow = self.cursor.fetchone()

	selected_year, selected_month = selectedOPMIdDataRow[13].year, selectedOPMIdDataRow[13].month
	current_date_ = datetime.now()
	currentMonthStartingDate = datetime(current_date_.year, current_date_.month, 1)
	previous_month = currentMonthStartingDate - timedelta(days=1)
	six_months_ago = current_date_ - relativedelta(months=6)
	six_months_ago = six_months_ago.replace(day=1)

	if (selected_year == previous_month.year and selected_month == previous_month.month) or (selected_year == current_date_.year and selected_month == current_date_.month):
		prevMonth = True
	else:
		prevMonth = False

	if ((self.userName == 'Ravikumar') and (self.editableOptionMaxDate > datetime.now().date())):
		prevMonth = True
		
	if self.userRole == 0:
		prevMonth = True

	if (self.userRole == 1) and (six_months_ago <= selectedOPMIdDataRow[13] <= current_date_):
		prevMonth = True


	self.createDateEditBox('eventDateEdit_OPM_')
	self.createTimeEditBox('eventTimeEdit_OPM_')
	self.createComboBox(self.depotsList, 'depotCombobox_OPM_')
	self.createComboBox([], 'trainCombobox_OPM_')
	self.createComboBox(self.carsList, 'carCombobox_OPM_')
	self.createComboBox(self.typeOfOPMList, 'typeOf_OPM_')

	self.createLineEditBox('modificationNoLineEditData_OPM_')
	self.createNumberLineEditBox('revLineEditData_OPM_')
	self.createLineEditBox('swverchangeLineEditData_OPM_')

	self.createTextEditBox('faultDetailsTextBox_OPM_', 'Describe the fault')
	self.createTextEditBox('workdoneTextBox_OPM_', 'Describe the work details')
	self.createComboBox(self.BOMSystemDictionary.keys(), 'systemComboBox_OPM_')
	self.createComboBox([], 'subSystemComboBox_OPM_')

	self.createLineEditBox('otherSubSystemLineEdit_OPM_')
	self.createLineEditBox('jobcardLineEdit_OPM_')

	self.createDateEditBox('workStartDate_OPM_')
	self.createTimeEditBox('workStartTime_OPM_')
	self.createDateEditBox('workEndDate_OPM_')
	self.createTimeEditBox('workEndTime_OPM_')

	self.createAttachmentWidget('mianAttachment_OPM_')
	self.mianAttachment_OPM_.fileListWidget.setMinimumHeight(140)


	self.downTime_opm_ = QLabel('')







	hLayoutForEventDateTime_OPMTab_ = QHBoxLayout()
	hLayoutForEventDateTime_OPMTab_.addWidget(self.eventDateEdit_OPM_)
	hLayoutForEventDateTime_OPMTab_.addWidget(self.eventTimeEdit_OPM_)

	hLayoutForWorkStartDateAndTime_OPMTab_ = QHBoxLayout()
	hLayoutForWorkStartDateAndTime_OPMTab_.addWidget(self.workStartDate_OPM_)
	hLayoutForWorkStartDateAndTime_OPMTab_.addWidget(self.workStartTime_OPM_)


	hLayoutForWorkEndDateAndTime_OPMTab_ = QHBoxLayout()
	hLayoutForWorkEndDateAndTime_OPMTab_.addWidget(self.workEndDate_OPM_)
	hLayoutForWorkEndDateAndTime_OPMTab_.addWidget(self.workEndTime_OPM_)



	formLayout1.addRow('Event Date & Time:<font color="red">*</font>', hLayoutForEventDateTime_OPMTab_)
	formLayout1.addRow('Depot:<font color="red">*</font>', self.depotCombobox_OPM_)
	formLayout1.addRow('Trainset:<font color="red">*</font>', self.trainCombobox_OPM_)
	formLayout1.addRow('Car No:', self.carCombobox_OPM_)

	vLayoutForTypeOf_OPMTab_ = QVBoxLayout()
	vLayoutForTypeOf_OPMTab_.addWidget(self.typeOf_OPM_)
	vLayoutForTypeOf_OPMTab_.addWidget(self.modificationNoLineEditData_OPM_)
	vLayoutForTypeOf_OPMTab_.addWidget(self.revLineEditData_OPM_)
	vLayoutForTypeOf_OPMTab_.addWidget(self.swverchangeLineEditData_OPM_)

	formLayout1.addRow('Type of OPM:<font color="red">*</font>', vLayoutForTypeOf_OPMTab_)
	# formLayout1.addRow('Type of OPM:<font color="red">*</font>', self.typeOf_OPM_)
	formLayout1.addRow('Fault Details/Nature of work:', self.faultDetailsTextBox_OPM_)
	formLayout1.addRow('Investigation/Workdone details:', self.workdoneTextBox_OPM_)
	formLayout1.addRow('System:<font color="red">*</font>', self.systemComboBox_OPM_)
	# formLayout1.addRow('Sub-System:<font color="red">*</font>', self.subSystemComboBox_OPM_)

	hLayoutForSubSystemAndOtherSubsystem_OPM_ = QHBoxLayout()
	hLayoutForSubSystemAndOtherSubsystem_OPM_.addWidget(self.subSystemComboBox_OPM_)
	hLayoutForSubSystemAndOtherSubsystem_OPM_.addWidget(self.otherSubSystemLineEdit_OPM_)
	# self.othersubsystemLineEdit_OPM_.setEnabled(False)
	formLayout1.addRow('Sub-Sytem:<font color="red">*</font>', hLayoutForSubSystemAndOtherSubsystem_OPM_)

	formLayout1.addRow('Work Start Date & Time:<font color="red">*</font>', hLayoutForWorkStartDateAndTime_OPMTab_)
	formLayout1.addRow('Work End Date & Time:<font color="red">*</font>', hLayoutForWorkEndDateAndTime_OPMTab_)
	formLayout1.addRow('Actual Downtime (Minutes):', self.downTime_opm_)

	formLayout1.addRow('Jobcard No:', self.jobcardLineEdit_OPM_)
	formLayout1.addRow('Attachments:', self.mianAttachment_OPM_)



	def onChangingDepotComboboxOPM_():
		self.trainCombobox_OPM_.setEnabled(True)
		self.trainCombobox_OPM_.clear()
		self.trainCombobox_OPM_.addItems(self.depotTrainDictionary[self.depotCombobox_OPM_.currentText()])
	
	self.depotCombobox_OPM_.currentIndexChanged.connect(lambda: onChangingDepotComboboxOPM_())

	opmType = self.typeOf_OPM_.currentText()
	if opmType in ['Testing', 'Fleet Check', 'Cyclic Check', 'Others']:
		self.revLineEditData_OPM_.hide()
		self.modificationNoLineEditData_OPM_.hide()
		self.swverchangeLineEditData_OPM_.hide()

		self.revLineEditData_OPM_.setEnabled(False)
		self.modificationNoLineEditData_OPM_.setEnabled(False)
		self.swverchangeLineEditData_OPM_.setEnabled(False)

	def onSystemComboboxChangedOPM_():
		self.subSystemComboBox_OPM_.setEnabled(True)
		self.subSystemComboBox_OPM_.clear()
		self.subSystemComboBox_OPM_.addItems(self.BOMSystemDictionary[self.systemComboBox_OPM_.currentText()])		
	self.systemComboBox_OPM_.currentIndexChanged.connect(lambda: onSystemComboboxChangedOPM_())


	def onSubsystemComboboxChanged_OPM_():
		selected_subsystem = self.subSystemComboBox_OPM_.currentText()
		if selected_subsystem =='Others':
			self.otherSubSystemLineEdit_OPM_.setEnabled(True)
		else:
			self.otherSubSystemLineEdit_OPM_.clear()
			self.otherSubSystemLineEdit_OPM_.setEnabled(False)
	self.subSystemComboBox_OPM_.currentIndexChanged.connect(onSubsystemComboboxChanged_OPM_)

	def onWorkDateTimeChangedOPM_():
		workStartDate_ = self.workStartDate_OPM_.date().toPython()
		workStartTime_ = self.workStartTime_OPM_.time().toPython().replace(second=0, microsecond=0)
		workEndDate_ = self.workEndDate_OPM_.date().toPython()
		workEndTime_ = self.workEndTime_OPM_.time().toPython().replace(second=0, microsecond=0)

		startDateTime_ = datetime.combine(workStartDate_, workStartTime_)
		endDateTime_ = datetime.combine(workEndDate_, workEndTime_)

		timeDifference_ = endDateTime_ - startDateTime_
		minutesDifference_ = timeDifference_.total_seconds() / 60

		if endDateTime_ < startDateTime_:
			self.workEndDate_OPM_.setDate(self.workStartDate_OPM_.date())
			self.workEndTime_OPM_.setTime(self.workStartTime_OPM_.time())

			endDateTime_ = datetime.combine(workStartDate_, workStartTime_)
			timeDifference_ = endDateTime_ - startDateTime_
			minutesDifference_ = timeDifference_.total_seconds() / 60

		self.downTime_opm_.setText(str(int(minutesDifference_)))

	self.workStartDate_OPM_.dateChanged.connect(onWorkDateTimeChangedOPM_)
	self.workStartTime_OPM_.timeChanged.connect(onWorkDateTimeChangedOPM_)
	self.workEndDate_OPM_.dateChanged.connect(onWorkDateTimeChangedOPM_)
	self.workEndTime_OPM_.timeChanged.connect(onWorkDateTimeChangedOPM_)


	def onTypeofComboboxChanged_OpmData():
		selected_typeof = self.typeOf_OPM_.currentText() 
		if selected_typeof =='VCC':
			self.modificationNoLineEditData_OPM_.setEnabled(True)
			self.modificationNoLineEditData_OPM_.clear()
			self.modificationNoLineEditData_OPM_.setPlaceholderText('Modification No')
			self.modificationNoLineEditData_OPM_.show()
 
			self.revLineEditData_OPM_.setEnabled(True)
			self.revLineEditData_OPM_.clear()
			self.revLineEditData_OPM_.setPlaceholderText('Rev')
			self.revLineEditData_OPM_.show()
 
			self.swverchangeLineEditData_OPM_.setEnabled(False)
			self.swverchangeLineEditData_OPM_.clear()
			self.swverchangeLineEditData_OPM_.hide()
 
		elif selected_typeof =='HECP':
			self.modificationNoLineEditData_OPM_.setEnabled(True)
			self.modificationNoLineEditData_OPM_.clear()
			self.modificationNoLineEditData_OPM_.setPlaceholderText('HECP No')
			self.modificationNoLineEditData_OPM_.show()
 
			self.revLineEditData_OPM_.setEnabled(True)
			self.revLineEditData_OPM_.clear()
			self.revLineEditData_OPM_.setPlaceholderText('Rev')
			self.revLineEditData_OPM_.show()
 
			self.swverchangeLineEditData_OPM_.setEnabled(False)
			self.swverchangeLineEditData_OPM_.clear()
			self.swverchangeLineEditData_OPM_.hide()
 
 
		elif selected_typeof =='SECP':
			self.modificationNoLineEditData_OPM_.setEnabled(True)
			self.modificationNoLineEditData_OPM_.clear()
			self.modificationNoLineEditData_OPM_.setPlaceholderText('SECP No')
			self.modificationNoLineEditData_OPM_.show()
 
			self.revLineEditData_OPM_.clear()
			self.revLineEditData_OPM_.setEnabled(False)
			self.revLineEditData_OPM_.hide()
 
			self.swverchangeLineEditData_OPM_.setEnabled(True)
			self.swverchangeLineEditData_OPM_.clear()
			self.swverchangeLineEditData_OPM_.setPlaceholderText('SW Ver Change')
			self.swverchangeLineEditData_OPM_.show()
 
		else:
			self.modificationNoLineEditData_OPM_.clear()
			self.revLineEditData_OPM_.clear()
			self.swverchangeLineEditData_OPM_.clear()
 
			self.modificationNoLineEditData_OPM_.setEnabled(False)
			self.revLineEditData_OPM_.setEnabled(False)
			self.swverchangeLineEditData_OPM_.setEnabled(False)
 
			self.modificationNoLineEditData_OPM_.hide()
			self.revLineEditData_OPM_.hide()
			self.swverchangeLineEditData_OPM_.hide()


	self.typeOf_OPM_.currentIndexChanged.connect(onTypeofComboboxChanged_OpmData)
	onTypeofComboboxChanged_OpmData()




















	self.eventDateEdit_OPM_.setDate(selectedOPMIdDataRow[1].date())
	self.eventTimeEdit_OPM_.setTime(selectedOPMIdDataRow[1].time())
	self.depotCombobox_OPM_.setCurrentText(selectedOPMIdDataRow[2])
	self.trainCombobox_OPM_.setCurrentText(selectedOPMIdDataRow[3])
	self.carCombobox_OPM_.setCurrentText(selectedOPMIdDataRow[4])
	self.typeOf_OPM_.setCurrentText(selectedOPMIdDataRow[5])

	self.modificationNoLineEditData_OPM_.setText(selectedOPMIdDataRow[-2])
	if self.typeOf_OPM_.currentText() == 'VCC' or self.typeOf_OPM_.currentText() == 'HECP':
		self.revLineEditData_OPM_.setText(selectedOPMIdDataRow[-1])
	elif self.typeOf_OPM_.currentText() == 'SECP':
		self.swverchangeLineEditData_OPM_.setText(selectedOPMIdDataRow[-1])

	self.faultDetailsTextBox_OPM_.setText(selectedOPMIdDataRow[6])
	self.workdoneTextBox_OPM_.setText(selectedOPMIdDataRow[7])

	self.systemComboBox_OPM_.setCurrentText(selectedOPMIdDataRow[8])
	self.subSystemComboBox_OPM_.setCurrentText(selectedOPMIdDataRow[9])
	self.otherSubSystemLineEdit_OPM_.setText(selectedOPMIdDataRow[10])
	self.jobcardLineEdit_OPM_.setText(selectedOPMIdDataRow[11])

	self.workStartDate_OPM_.setDate(selectedOPMIdDataRow[13].date())
	self.workStartTime_OPM_.setTime(selectedOPMIdDataRow[13].time())
	self.workEndDate_OPM_.setDate(selectedOPMIdDataRow[14].date())
	self.workEndTime_OPM_.setTime(selectedOPMIdDataRow[14].time())
	self.downTime_opm_.setText(str(selectedOPMIdDataRow[15]))
	
	
	
	import ast
	attachedItemsList = ast.literal_eval(selectedOPMIdDataRow[12]) if selectedOPMIdDataRow[12] is not None else []
	if len(attachedItemsList) > 0:
		for attachment in attachedItemsList:
			self.mianAttachment_OPM_.fileListWidget.addItem(attachment)
			self.mianAttachment_OPM_.fileListWidget.setVisible(True)
			self.mianAttachment_OPM_.removeButton.setEnabled(True)


	

	


	


	




	



	self.listOfWidgets_OPM_ = [self.eventDateEdit_OPM_, self.eventTimeEdit_OPM_, self.depotCombobox_OPM_, self.trainCombobox_OPM_, self.carCombobox_OPM_, self.typeOf_OPM_,
								self.faultDetailsTextBox_OPM_, self.workdoneTextBox_OPM_, self.systemComboBox_OPM_, self.subSystemComboBox_OPM_, self.otherSubSystemLineEdit_OPM_, self.jobcardLineEdit_OPM_, self.mianAttachment_OPM_,
								self.workStartDate_OPM_, self.workStartTime_OPM_, self.workEndDate_OPM_, self.workEndTime_OPM_ , self.downTime_opm_, self.modificationNoLineEditData_OPM_, self.revLineEditData_OPM_, self.swverchangeLineEditData_OPM_]




	self.createPushButton('updateBtn_opmData', 'Update',  width=int(0.070 * QApplication.primaryScreen().availableGeometry().width()), tooltip='Update OPM data with table')
	
	if not prevMonth:
		for wid in self.listOfWidgets_OPM_:
			wid.setEnabled(False)
			self.updateBtn_opmData.hide()

	self.opmWindow.show()


	def setToolTip(wid, text):
		wid.setToolTip(text)

	def settingToolTipp(wid, text):
		wid.textChanged.connect(lambda: setToolTip(wid, text))

	for wid in self.listOfWidgets_OPM_:
		if isinstance(wid, QLineEdit):
			settingToolTipp(wid, wid.text())

		if isinstance(wid, QTextEdit):
			settingToolTipp(wid, wid.toPlainText())


	



	



	

	if prevMonth:
		def onClickingUpdate_OPMData():

			mandatoryVerification_OPM_ = True
			mandatoryIndexes_OPM_ = [0, 1, 2, 3, 5, 8, 9, 13, 14, 15, 16]

			
			OPM_Row_ = []

			for i, wid in enumerate(self.listOfWidgets_OPM_):

				if i == 12:
					OPM_Row_.append(None)
					continue

				if isinstance(wid, QDateEdit):
					if isinstance(self.listOfWidgets_OPM_[i+1], QTimeEdit):
						datetime_ = QDateTime(wid.date(), self.listOfWidgets_OPM_[i+1].time())
						OPM_Row_.append(datetime_.toPython())

				elif isinstance(wid, QComboBox):
					if wid.isEnabled():
						if wid.currentText() == '':
							OPM_Row_.append(None)

							if i in mandatoryIndexes_OPM_:
								mandatoryVerification_OPM_ = False
								wid.setProperty("error", True)
								wid.setStyleSheet(self.comboBoxQSS)

						else:
							if i == 8:
								query = "SELECT id FROM bom WHERE equipment = %s AND parent_id = 0"
								self.cursor.execute(query, (wid.currentText(),))
								result = self.cursor.fetchone()
								OPM_Row_.append(result[0])
								wid.setProperty("error", False)
								wid.setStyleSheet(self.comboBoxQSS)
							
							elif i == 9:
								query = "SELECT id FROM bom WHERE parent_id = (SELECT id FROM bom WHERE equipment = %s AND parent_id = 0) AND equipment = %s"
								self.cursor.execute(query, (self.listOfWidgets_OPM_[8].currentText(), wid.currentText()))
								result = self.cursor.fetchone()
								OPM_Row_.append(result[0])
								wid.setProperty("error", False)
								wid.setStyleSheet(self.comboBoxQSS)

							else:
								OPM_Row_.append(wid.currentText())
								wid.setProperty("error", False)
								wid.setStyleSheet(self.comboBoxQSS)

					else:
						OPM_Row_.append(None)

				elif isinstance(wid, QLineEdit):
					if wid.isEnabled():
						if wid.text() == '':
							OPM_Row_.append(None)
						else:
							OPM_Row_.append(wid.text())
					else:
						OPM_Row_.append(None)


				elif isinstance(wid, QTextEdit):
					if wid.isEnabled():
						if wid.toPlainText() == '':
							OPM_Row_.append(None)
						else:
							OPM_Row_.append(wid.toPlainText())
					else:
						OPM_Row_.append(None)

				elif isinstance(wid, QLabel):
					OPM_Row_.append(int(wid.text()))

			


			if not mandatoryVerification_OPM_:
				pass

			else:

				OPM_Row_.append(self.user_id)
				OPM_Row_.append(opmId)


				selected_files = [self.mianAttachment_OPM_.fileListWidget.item(i).text() for i in range(self.mianAttachment_OPM_.fileListWidget.count())]

				vall = 0
				allFileNames = []
				for file in selected_files:
					if '/' in file:
						dest_folder = "C:\\ProgramData\\RAMSify\\Attachments"
						file_name = os.path.basename(file)
						
						fVal = str(vall)
						if len(str(vall)) == 1:
							fVal = '00'+str(vall)
						elif len(str(vall)) == 2:
							fVal = '0'+str(vall)
						else:
							fVal = str(vall)


						base_name, file_extension = os.path.splitext(file_name)
						new_filename = f"{base_name}_{datetime.now().strftime('%Y%m%d%H%M%S')}{fVal}{file_extension}"
						allFileNames.append(new_filename)
						dest_file = os.path.join(dest_folder, new_filename)
						shutil.copy(file, dest_file)

					else:
						allFileNames.append(file)


				attachmentsString = str(allFileNames)

				OPM_Row_[11] = attachmentsString


				update_opm_query = """
					UPDATE other_preventive_maintenance 
					SET 
						event_datetime = %s, 
						depot_id = %s, 
						trainset_id = (SELECT id FROM trainsets WHERE trainset = %s), 
						car_number = %s, 
						opm_type = %s, 
						opm_fault_details = %s, 
						opm_investigation_details = %s, 
						system_id = %s, 
						subsystem_id = %s,
						other_subsystem = %s,
						jobcard = %s,
						attachments =%s,
						work_start_at = %s,
						work_end_at = %s,
						downtime = %s,
						t_c_no = %s,
						t_c_rev = %s,
						user_id = %s
					WHERE 
						opm_id = %s
					"""

				if OPM_Row_[4] == 'VCC' or OPM_Row_[4] == 'HECP' :
					opmDataToInsert = OPM_Row_[:17] + OPM_Row_[18:]
				elif OPM_Row_[4] == 'SECP':
					opmDataToInsert = OPM_Row_[:16] + OPM_Row_[17:]
				else:
					opmDataToInsert = OPM_Row_[:16] + OPM_Row_[17:]


				self.cursor.execute(update_opm_query, tuple(opmDataToInsert))
				self.mydb.commit()

				if OPM_Row_[4] in ['VCC', 'SECP', 'HECP']:
					revOrSwer = [self.modificationNoLineEditData_OPM_.text()]
					if self.revLineEditData_OPM_.isEnabled():
						revOrSwer.append(self.revLineEditData_OPM_.text())
					elif self.swverchangeLineEditData_OPM_.isEnabled():
						revOrSwer.append(self.swverchangeLineEditData_OPM_.text())
				else:
					revOrSwer = ['', '']
					

				dataOfTableRowToUpdate = OPM_Row_[0:5] + revOrSwer + OPM_Row_[5:7] + [self.systemComboBox_OPM_.currentText(), self.subSystemComboBox_OPM_.currentText()]  + OPM_Row_[9:11] + OPM_Row_[12:15]


				for c in range(self.opmDataTable.columnCount()-4):
					if dataOfTableRowToUpdate[c] != None:
						item = QTableWidgetItem(str(dataOfTableRowToUpdate[c]))
						item.setTextAlignment(Qt.AlignCenter)
						item.setToolTip(item.text())
						self.opmDataTable.setItem(rowNum, c+2, item)
					else:
						item = QTableWidgetItem('')
						item.setTextAlignment(Qt.AlignCenter)
						self.opmDataTable.setItem(rowNum, c+2, item)
							

				opmMsgBox = QMessageBox()
				opmMsgBox.setIcon(QMessageBox.Information) 
				opmMsgBox.setText('OPM Data of ID:{} updated successfully'.format(opmId))
				opmMsgBox.setWindowTitle("Message")
				opmMsgBox.setWindowIcon(QIcon('Media/ramsify.png'))
				opmMsgBox.setStandardButtons(QMessageBox.Ok)
				opmMsgBox.exec_()

				self.opmWindow.close()
		
		self.updateBtn_opmData.clicked.connect(onClickingUpdate_OPMData)
		
		hLayoutForSubmitCancelOfOPM = QHBoxLayout()
		vLayout.addLayout(hLayoutForSubmitCancelOfOPM)
		
		hLayoutForSubmitCancelOfOPM.addWidget(self.updateBtn_opmData, alignment=Qt.AlignCenter)