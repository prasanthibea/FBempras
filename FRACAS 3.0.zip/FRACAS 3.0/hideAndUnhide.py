from functions import *
from configuration import *
from PySide6.QtCore import QDate

def hideOrUnhideFunction(self):

	self.settingsBtn.hide()
	self.actionsettings.setVisible(False)
	self.actionimport.setVisible(False)
	if self.userRole in [0,1,2]:
		self.configurationBtn.show()
	else:
		self.configurationBtn.hide()


	if self.userRole == 0:
		self.BOMEditButton.show()
		self.trainsetEditButton.show()
	else:
		self.BOMEditButton.hide()
		self.trainsetEditButton.hide()

	################################
	
	if self.userRole in [0, 1]:
		self.dbBackupButton.show()
	else:
		self.dbBackupButton.hide()

	###################################