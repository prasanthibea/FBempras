from PySide6.QtWidgets import QTableWidgetItem, QSpacerItem, QSizePolicy, QMessageBox, QPushButton, QDateEdit, QTextEdit, QFileDialog, QCheckBox, QComboBox, QAbstractItemView, QLineEdit, QWidget, QLabel, QHBoxLayout, QVBoxLayout, QFormLayout, QHeaderView
from functions import TableWidget
from PySide6.QtCore import Qt, QDate
from PySide6.QtGui import QIcon, QColor
from openpyxl import Workbook
from datetime import date, datetime

def dlpsparesDataUI(self):
	from PySide6.QtWidgets import QApplication
	self.verticalBoxLayout = QVBoxLayout()

	checkAllUserIconPath = self.currentTheme.get('oppositeColorCheckBoxIcon')
	unCheckAllUserIconPath = self.currentTheme.get('oppositeColorUnCheckBoxIcon')
	partiallyCheckedIconPath = self.currentTheme.get('oppositeColorPartiallyCheckedBoxIcon')
	deleteIconPath = self.currentTheme.get('whiteDeleteIcon')
	downloadIconPath = self.currentTheme.get('downloadIcon')
	refreshTableIconPath = self.currentTheme.get('refreshIcon')

	self.createPushButton('selectAllDlpspareButton', '', unCheckAllUserIconPath, 30)
	self.createPushButton('deleteButton_Dlp', '', deleteIconPath, 35, 'Delete')
	self.createLineEditBox('serachBarOfDlp', 'Search...' )
	self.serachBarOfDlp.setClearButtonEnabled(True)
	self.serachBarOfDlp.setFixedWidth(self.geometryWidth(0.2))
	self.createPushButton('download_Dlp', '', downloadIconPath, 35, 'Download')
	self.createPushButton('refreshButton_Dlp', '', refreshTableIconPath, 35, 'Refresh')
	self.createPushButton('newButton_Dlp', '+ New DLP Spares', '', self.geometryWidth(0.078))
	
	self.dlpHBoxLayout = QHBoxLayout()
	self.dlpHBoxLayout.addWidget(self.selectAllDlpspareButton)
	self.dlpHBoxLayout.addWidget(self.deleteButton_Dlp)
	self.dlpHBoxLayout.addWidget(self.serachBarOfDlp)
	self.dlpHBoxLayout.addWidget(self.download_Dlp)
	self.dlpHBoxLayout.addWidget(self.refreshButton_Dlp)
	self.dlpHBoxLayout.addItem(QSpacerItem(1, 0, QSizePolicy.Expanding, QSizePolicy.Minimum))
	self.dlpHBoxLayout.addWidget(self.newButton_Dlp)
	self.verticalBoxLayout.addLayout(self.dlpHBoxLayout)

	
	self.dlpsparesDataTable = TableWidget()	
	self.headersOfdlpsparesDataTable  = [' ','MTL S. No', 'DLP S. No', 'Description', 'Part No', 'Unit', 'OEM Recommended Qty\n(To be ensured at Charkop Depot)',
	 'Issued Qty', 'Available Quantity', 'Issued for Train Set', 'Car No.', 'Vendor Name', 'Serial No. IN', 'Serial No. Out', 'Issue Date', 'Jobcard No', 'NCR No',
	 'MGP No', 'GIR No', 'Remarks']

	self.dlpsparesDataTable.setColumnCount(len(self.headersOfdlpsparesDataTable))
	self.dlpsparesDataTable.setHorizontalHeaderLabels(self.headersOfdlpsparesDataTable)
	self.dlpsparesDataTable.setStyleSheet(self.tableWidgetQSS)
	self.dlpsparesDataTable.horizontalHeader().setStyleSheet(self.headerHorizontalQSS)
	self.dlpsparesDataTable.setAlternatingRowColors(True)
	self.dlpsparesDataTable.setShowGrid(False)
	self.dlpsparesDataTable.setEditTriggers(QAbstractItemView.NoEditTriggers)
	
	self.verticalBoxLayout.addWidget(self.dlpsparesDataTable)

	self.selectAllDlpspareButton.setCheckable(True)

	self.dlpsparesDataTable.setMinimumHeight(self.geometryHeight(0.78))

	self.mainVerticalLayout_DLPSpares.addLayout(self.verticalBoxLayout)

	self.dlpsparesDataTable.setColumnWidth(0,self.geometryWidth(0.04))
	self.dlpsparesDataTable.setColumnWidth(1,self.geometryWidth(0.09))
	self.dlpsparesDataTable.setColumnWidth(2,self.geometryWidth(0.12))
	self.dlpsparesDataTable.setColumnWidth(3,self.geometryWidth(0.09))
	self.dlpsparesDataTable.setColumnWidth(4,self.geometryWidth(0.10))
	self.dlpsparesDataTable.setColumnWidth(5,self.geometryWidth(0.09))
	self.dlpsparesDataTable.setColumnWidth(6,self.geometryWidth(0.15))
	self.dlpsparesDataTable.setColumnWidth(7,self.geometryWidth(0.12))
	self.dlpsparesDataTable.setColumnWidth(8,self.geometryWidth(0.09))
	self.dlpsparesDataTable.setColumnWidth(9,self.geometryWidth(0.09))
	self.dlpsparesDataTable.setColumnWidth(10,self.geometryWidth(0.09))
	self.dlpsparesDataTable.setColumnWidth(11,self.geometryWidth(0.09))
	self.dlpsparesDataTable.setColumnWidth(12,self.geometryWidth(0.09))
	self.dlpsparesDataTable.setColumnWidth(13,self.geometryWidth(0.1))
	self.dlpsparesDataTable.setColumnWidth(14,self.geometryWidth(0.1))
	self.dlpsparesDataTable.setColumnWidth(15,self.geometryWidth(0.09))
	self.dlpsparesDataTable.setColumnWidth(16,self.geometryWidth(0.09))
	self.dlpsparesDataTable.setColumnWidth(17,self.geometryWidth(0.09))
	self.dlpsparesDataTable.setColumnWidth(18,self.geometryWidth(0.12))
	self.dlpsparesDataTable.setColumnWidth(19,self.geometryWidth(0.12))

	def onClickingButtonNewDlpSpares_dlp():
		self.newDlpSparesWindow = QWidget()
		# self.newDlpSparesWindow.move(800, 100)
		# self.newDlpSparesWindow.resize(700, 800)
		self.newDlpSparesWindow.setFixedHeight(self.geometryHeight(0.85))
		self.newDlpSparesWindow.setFixedWidth(self.geometryWidth(0.4))

		self.newDlpSparesWindow.setWindowTitle('DLP Number')
		self.newDlpSparesWindow.setWindowIcon(QIcon('Media/ramsify.png'))

		vBoxLayout = QVBoxLayout()
		formLayout = QFormLayout()
		vBoxLayout.addLayout(formLayout)

		self.newDlpSparesWindow.setLayout(vBoxLayout)

		self.createNumberLineEditBox('mtlSrNoLineEdit_dlp')
		self.createLineEditBox('dlpSrNoLineEdit_dlp')
		self.createLineEditBox('descriptionLineEdit_dlp')
		self.createLineEditBox('partNoLineEdit_dlp')
		self.createLineEditBox('unitLineEdit_dlp')
		self.createFloatLineEditBox('oemRecomendedQtyLineEdit_dlp')
		self.createFloatLineEditBox('issuedQtyLineEdit_dlp')
		self.createFloatLineEditBox('avaliabilityQtyLineEdit_dlp')
		self.createCheckableComboBox(self.trainsetsList, 'issuedForTrainsetLineEdit_dlp')
		self.createCheckableComboBox(self.carsList, 'carNoLineEdit_dlp')

		self.createLineEditBox('vendorNameLineEdit_dlp')
		self.createLineEditBox('srnoInLineEdit_dlp')
		self.createLineEditBox('srnoOuLineEdit_dlp')

		self.createEmptyDateEditBox('issueDate_dlp') 

		self.createLineEditBox('jobcardNoLineEdit_dlp')
		self.createLineEditBox('ncrLineEdit_dlp')
		self.createLineEditBox('mgpLineEdit_dlp')
		self.createLineEditBox('girLineEdit_dlp')
		self.createTextEditBox('remarksLineEdit_dlp')
		self.createNumberLineEditBox('rownumLineEdit_dlp')


		rowcount = self.dlpsparesDataTable.rowCount()
		self.rownumLineEdit_dlp.setText(str(rowcount+1))


		def onChangingRownumLineEdit_dlp(num):
			if num:
				rowcount = self.dlpsparesDataTable.rowCount()
				currValue = int(num)

				if (currValue > rowcount+1) or (currValue<1):
					self.rownumLineEdit_dlp.setText(str(rowcount+1))
				else:
					self.rownumLineEdit_dlp.setText(str(currValue))


		self.rownumLineEdit_dlp.textChanged.connect(onChangingRownumLineEdit_dlp)



		formLayout.addRow('MTL S. No: ', self.mtlSrNoLineEdit_dlp)
		formLayout.addRow('DLP S. No: <font color="red">*</font>', self.dlpSrNoLineEdit_dlp)
		formLayout.addRow('Description: <font color="red">*</font>', self.descriptionLineEdit_dlp)
		formLayout.addRow('Part No: <font color="red">*</font>', self.partNoLineEdit_dlp)
		formLayout.addRow('Unit : <font color="red">*</font>', self.unitLineEdit_dlp)
		formLayout.addRow('OEM Recommended Qty: <font color="red">*</font>', self.oemRecomendedQtyLineEdit_dlp)
		formLayout.addRow('Issued Qty: <font color="red">*</font>', self.issuedQtyLineEdit_dlp)
		formLayout.addRow('Available Quantity: <font color="red">*</font>', self.avaliabilityQtyLineEdit_dlp)
		formLayout.addRow('Issued for Train Set : <font color="red">*</font>', self.issuedForTrainsetLineEdit_dlp)
		formLayout.addRow('Car No: ', self.carNoLineEdit_dlp)
		formLayout.addRow('Vendor Name: ', self.vendorNameLineEdit_dlp)
		formLayout.addRow('Serial No. IN: ', self.srnoInLineEdit_dlp)
		formLayout.addRow('Serial No. Out: ', self.srnoOuLineEdit_dlp)
		formLayout.addRow('Issue Date: ', self.issueDate_dlp)
		formLayout.addRow('Jobcard No: ', self.jobcardNoLineEdit_dlp)
		formLayout.addRow('NCR No: ', self.ncrLineEdit_dlp)
		formLayout.addRow('MGP No: ', self.mgpLineEdit_dlp)
		formLayout.addRow('GIR No: ', self.girLineEdit_dlp)
		formLayout.addRow('Remarks: ', self.remarksLineEdit_dlp)
		formLayout.addRow('Row No: <font color="red">*</font>', self.rownumLineEdit_dlp)

		self.createPushButton('submitBtn_dlp', 'Submit', '', self.geometryWidth(0.04))
		self.createPushButton('cancelBtn_dlp', 'Cancel', '', self.geometryWidth(0.04))
		hBoxLayout = QHBoxLayout()
		hBoxLayout.addWidget(self.submitBtn_dlp, alignment = Qt.AlignRight)
		hBoxLayout.addWidget(self.cancelBtn_dlp, alignment = Qt.AlignLeft)

		vBoxLayout.addLayout(hBoxLayout)
			
		allFieldsData = [self.mtlSrNoLineEdit_dlp, self.dlpSrNoLineEdit_dlp, self.descriptionLineEdit_dlp, self.partNoLineEdit_dlp, self.unitLineEdit_dlp, 
						self.oemRecomendedQtyLineEdit_dlp, self.issuedQtyLineEdit_dlp, self.avaliabilityQtyLineEdit_dlp, self.issuedForTrainsetLineEdit_dlp,   
						self.carNoLineEdit_dlp, self.vendorNameLineEdit_dlp, self.srnoInLineEdit_dlp, self.srnoOuLineEdit_dlp, self.issueDate_dlp, 
						self.jobcardNoLineEdit_dlp, self.ncrLineEdit_dlp, self.mgpLineEdit_dlp, self.girLineEdit_dlp, self.remarksLineEdit_dlp, self.rownumLineEdit_dlp ]

		
		def onClickingSubmit_dlp():
			mandatoryVerification_dlp = True
			mandatoryIndexesdlp = [1, 2, 3, 4, 5, 6, 7, 8, 19]
			dlpFormData = []

			for i, wid in enumerate(allFieldsData[:-1]):
				if isinstance(wid, QLineEdit):
					if wid.text() == '':
						dlpFormData.append(None)
						if i in mandatoryIndexesdlp:
							mandatoryVerification_dlp = False
							wid.setProperty("error", True)
							wid.setStyleSheet(self.lineEditBoxQSS)
					else:
						if wid.text().isdigit():
							if '.' in wid.text():
								dlpFormData.append(float(wid.text()))
							else:
								dlpFormData.append(int(wid.text()))
						else:
							dlpFormData.append(wid.text()) 	

						wid.setProperty("error", False)
						wid.setStyleSheet(self.lineEditBoxQSS)

				if isinstance(wid, QTextEdit):
					if wid.toPlainText() == '':
						dlpFormData.append(None)
						if i in mandatoryIndexesdlp:
							mandatoryVerification_dlp = False
							wid.setProperty("error", True)
							wid.setStyleSheet(self.textEditBoxQSS)		

					else:
						dlpFormData.append(wid.toPlainText())	
						wid.setProperty("error", False)
						wid.setStyleSheet(self.textEditBoxQSS)


				if isinstance(wid, QComboBox):
					if wid.isEnabled():
						if wid.currentText() == '':
							dlpFormData.append(None)
							if i in mandatoryIndexesdlp:
								mandatoryVerification_dlp = False
								wid.setProperty("error", True)
								wid.setStyleSheet(self.comboBoxQSS)

						else:
							dlpFormData.append(wid.currentText())
							wid.setProperty("error", False)
							wid.setStyleSheet(self.comboBoxQSS)

					else:
						dlpFormData.append(None)

				elif isinstance(wid, QDateEdit):
					if wid.lineEdit().text() == ' ':
						dlpFormData.append(None)
					else:
						qdate = wid.date()
						py_date = date(qdate.year(), qdate.month(), qdate.day())  # Convert QDate to Python date
						dlpFormData.append(py_date)


			
			if not mandatoryVerification_dlp:
				print('Mandatory fields missing.')

			else:

				# Finding Row Order to be inserted in DB table
				entered_row = int(self.rownumLineEdit_dlp.text())
				if self.dlpsparesDataTable.rowCount() == 0:
					if entered_row == 1:
						new_row_order = 1.0
					else:
						QMessageBox.warning(self, "Error", "Incorrect Row No.")
						return

				else:
					if 0 < entered_row <= self.dlpsparesDataTable.rowCount() + 1:
						if entered_row == self.dlpsparesDataTable.rowCount() + 1:
							# Insert at the last row, increment row_order
							button_previous = self.dlpsparesDataTable.cellWidget(entered_row - 2, 3)  # Last row's button
							if not button_previous:
								QMessageBox.warning(self, "Error", "Button data not found for the previous row.")
								return

							row_order_previous = button_previous.property("row_order")
							new_row_order = int(row_order_previous + 1)
						else:
							if entered_row == 1:
								button_current = self.dlpsparesDataTable.cellWidget(0, 3)
								row_order_current = button_current.property("row_order")

								new_row_order = row_order_current / 2


							else:
								# For rows in between, calculate the new row_order using the current and previous rows
								button_current = self.dlpsparesDataTable.cellWidget(entered_row - 1, 3)  # Current row's button
								button_previous = self.dlpsparesDataTable.cellWidget(entered_row - 2, 3)  # Previous row's button

								if not button_current or not button_previous:
									QMessageBox.warning(self, "Error", "Button data not found for the specified rows.")
									return

								row_order_current = button_current.property("row_order")
								row_order_previous = button_previous.property("row_order")

								new_row_order = (row_order_current + row_order_previous) / 2

					else:
						# Handle invalid row number case
						QMessageBox.warning(self, "Invalid Row", "Please enter a correct row number.")
						return  # Exit the function to avoid further execution
				


				querry = ''' SELECT row_order FROM dlpspares WHERE row_order = %s AND deleted_at IS NULL '''
				self.cursor.execute(querry,(new_row_order,))
				result = self.cursor.fetchone()
				
				if result:
					QMessageBox.warning(self, "Invalid Row", "Please enter a correct row number.")
					return

				else:
					new_row_order = float(new_row_order)
					dlpFormData.append(new_row_order)
					dlpFormData.append(self.user_id)
					query = """
						INSERT INTO dlpspares
						(mtl_srno, dlp_srno, description, part_no, unit, oemrecommended_qty, issued_qty, available_qty, issued_for_train_set, car_no,
						vendor_name, serial_no_in, serial_no_ou, issue_date, jobcard_no, ncr_no, mgp_no, gir_no, remarks, row_order, user_id) 
						VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
					"""
					
					self.cursor.execute(query, tuple(dlpFormData))
					self.mydb.commit()
					self.refreshButton_Dlp.click()
					dlpSubmitMsgBox = QMessageBox()
					dlpSubmitMsgBox.setIcon(QMessageBox.Information) 
					dlpSubmitMsgBox.setText(f'Data Submitted successfully.')
					dlpSubmitMsgBox.setWindowTitle("Message")
					dlpSubmitMsgBox.setWindowIcon(QIcon('Media/ramsify.png'))
					dlpSubmitMsgBox.setStandardButtons(QMessageBox.Ok)
					dlpSubmitMsgBox.exec_()
					self.newDlpSparesWindow.close()
								
		self.submitBtn_dlp.clicked.connect(onClickingSubmit_dlp)
		self.newDlpSparesWindow.show()

		def onClickingCancel_dlp():
			for wid in allFieldsData[:-1]:
				if isinstance(wid, QLineEdit):
					wid.clear()
					wid.setProperty("error", False)
					wid.setStyleSheet(self.lineEditBoxQSS)

			self.issuedForTrainsetLineEdit_dlp.clearItems()
			self.carNoLineEdit_dlp.clearItems()
			self.issueDate_dlp.setDate(QDate())
			self.issueDate_dlp.lineEdit().setText(' ')
			self.remarksLineEdit_dlp.clear()

		self.cancelBtn_dlp.clicked.connect(onClickingCancel_dlp)

	self.newButton_Dlp.clicked.connect(onClickingButtonNewDlpSpares_dlp)					


	def onClickingrefreshbutton_dlp():
		self.deleteButton_Dlp.hide()
		self.selectAllDlpspareButton.setIcon(QIcon(unCheckAllUserIconPath))
		self.selectAllDlpspareButton.setChecked(False)

		queryone = '''
			SELECT
				id,
				row_order,
				mtl_srno,
				dlp_srno,
				description,
				part_no,
				unit,
				oemrecommended_qty,
				issued_qty,
				available_Qty,
				issued_for_train_set,
				car_no,
				vendor_name,
				serial_no_in,
				serial_no_ou,
				issue_date,
				jobcard_no,
				ncr_no,
				mgp_no,
				gir_no,
				remarks
				
			FROM
				dlpspares 

			WHERE
				deleted_at IS NULL

			ORDER BY
				row_order ASC
				
		'''
		self.cursor.execute(queryone)
		dlpDataResult = self.cursor.fetchall()
		

		def givingFunctionalityToButton(button, funct, rowData, rowCount):
			button.clicked.connect(lambda:funct(rowData, rowCount))

		def onbuttonClickedDlp(dlpData, rowcount):
			from PySide6.QtWidgets import QApplication

			self.dlpsparesUpdateWindow = QWidget()
			self.dlpsparesUpdateWindow.move(680, 100)

			self.dlpsparesUpdateWindow.setWindowTitle(str(dlpData[4]))
			self.dlpsparesUpdateWindow.setWindowIcon(QIcon('Media/ramsify.png'))

			self.dlpsparesUpdateWindow.setFixedHeight(self.geometryHeight(0.85))
			self.dlpsparesUpdateWindow.setFixedWidth(self.geometryWidth(0.4))

			vboxLayout = QVBoxLayout()
			formLayout = QFormLayout()
			vboxLayout.addLayout(formLayout)

			self.dlpsparesUpdateWindow.setLayout(vboxLayout)

			self.createNumberLineEditBox('mtlSrNoLineEdit_dlp_')
			if dlpData[2]:
				self.mtlSrNoLineEdit_dlp_.setText(str(dlpData[2]))
				self.mtlSrNoLineEdit_dlp_.setToolTip(str(dlpData[2]))
			else:
				pass

			self.createLineEditBox('dlpSrNoLineEdit_dlp_')
			self.dlpSrNoLineEdit_dlp_.setText(str(dlpData[3]))
			self.dlpSrNoLineEdit_dlp_.setToolTip(str(dlpData[3]))

			self.createLineEditBox('descriptionLineEdit_dlp_')
			self.descriptionLineEdit_dlp_.setText(str(dlpData[4]))
			self.descriptionLineEdit_dlp_.setToolTip(str(dlpData[4]))

			self.createLineEditBox('partNoLineEdit_dlp_')
			self.partNoLineEdit_dlp_.setText(str(dlpData[5]))
			self.partNoLineEdit_dlp_.setToolTip(str(dlpData[5]))

			self.createLineEditBox('unitLineEdit_dlp_')
			self.unitLineEdit_dlp_.setText(str(dlpData[6]))
			self.unitLineEdit_dlp_.setToolTip(str(dlpData[6]))

			self.createFloatLineEditBox('oemRecomendedQtyLineEdit_dlp_')
			if dlpData[7]:
				self.oemRecomendedQtyLineEdit_dlp_.setText(str(dlpData[7]))
				self.oemRecomendedQtyLineEdit_dlp_.setToolTip(str(dlpData[7]))
			else:
				pass

			self.createFloatLineEditBox('issuedQtyLineEdit_dlp_')
			if dlpData[8]:
				self.issuedQtyLineEdit_dlp_.setText(str(dlpData[8]))
				self.issuedQtyLineEdit_dlp_.setToolTip(str(dlpData[8]))
			else:
				pass

			self.createFloatLineEditBox('avaliabilityQtyLineEdit_dlp_')
			if dlpData[9]:
				self.avaliabilityQtyLineEdit_dlp_.setText(str(dlpData[9]))
				self.avaliabilityQtyLineEdit_dlp_.setToolTip(str(dlpData[9]))
			else:
				pass

			self.createCheckableComboBox(self.trainsetsList, 'issuedForTrainsetLineEdit_dlp_')
			selected_trainitems = [dlpData[10]]
			self.issuedForTrainsetLineEdit_dlp_.selectItems(str(selected_trainitems))
			
			self.createCheckableComboBox(self.carsList, 'carNoLineEdit_dlp_')
			if dlpData[11] is None:
				self.carNoLineEdit_dlp_.selectItems('')
			else:
				selected_caritems = [dlpData[11]]
				self.carNoLineEdit_dlp_.selectItems(str(selected_caritems))
		
			self.createLineEditBox('vendorNameLineEdit_dlp_')
			self.vendorNameLineEdit_dlp_.setText(dlpData[12])
			self.vendorNameLineEdit_dlp_.setToolTip(dlpData[12])

			self.createLineEditBox('srnoInLineEdit_dlp_')		
			self.srnoInLineEdit_dlp_.setText(dlpData[13])
			self.srnoInLineEdit_dlp_.setToolTip(dlpData[13])

				
			self.createLineEditBox('srnoOuLineEdit_dlp_')
			self.srnoOuLineEdit_dlp_.setText(dlpData[14])
			self.srnoOuLineEdit_dlp_.setToolTip(dlpData[14])

			self.createEmptyDateEditBox('issueDate_dlp_')
			if dlpData[15]:
				self.issueDate_dlp_.setDate(QDate(dlpData[15].year, dlpData[15].month, dlpData[15].day))
			else:
				self.issueDate_dlp_.setDate(QDate())
				self.issueDate_dlp_.lineEdit().setText(' ')

			
			self.createLineEditBox('jobcardNoLineEdit_dlp_')
			self.jobcardNoLineEdit_dlp_.setText(dlpData[16])			
			self.jobcardNoLineEdit_dlp_.setToolTip(dlpData[16])


			self.createLineEditBox('ncrLineEdit_dlp_')
			self.ncrLineEdit_dlp_.setText(dlpData[17])
			self.ncrLineEdit_dlp_.setToolTip(dlpData[17])


			self.createLineEditBox('mgpLineEdit_dlp_')
			self.mgpLineEdit_dlp_.setText(dlpData[18])
			self.mgpLineEdit_dlp_.setToolTip(dlpData[18])

			self.createLineEditBox('girLineEdit_dlp_')
			self.girLineEdit_dlp_.setText(dlpData[19])
			self.girLineEdit_dlp_.setToolTip(dlpData[19])

			self.createTextEditBox('remarksLineEdit_dlp_')
			self.remarksLineEdit_dlp_.setText(dlpData[20])
			self.remarksLineEdit_dlp_.setToolTip(dlpData[20])


			self.createNumberLineEditBox('rownumLineEdit_dlp_')
			self.rownumLineEdit_dlp_.setText(str(rowcount))

			def onChangingRownumLineEdit_dlp_(num):
				if num:
					rowcount = self.dlpsparesDataTable.rowCount()
					currValue = int(float(num))
					if (currValue > rowcount+1) or (currValue<1):
						self.rownumLineEdit_dlp_.setText(str(rowcount+1))
					else:
						self.rownumLineEdit_dlp_.setText(str(currValue))

			self.rownumLineEdit_dlp_.textChanged.connect(onChangingRownumLineEdit_dlp_)
			

			formLayout.addRow('MTL S. No: ',self.mtlSrNoLineEdit_dlp_)
			formLayout.addRow('DLP S. No: <font color="red">*</font>', self.dlpSrNoLineEdit_dlp_)
			formLayout.addRow('Description: <font color="red">*</font>', self.descriptionLineEdit_dlp_)
			formLayout.addRow('Part No: <font color="red">*</font>',self.partNoLineEdit_dlp_)
			formLayout.addRow('Unit : <font color="red">*</font>',self.unitLineEdit_dlp_)
			formLayout.addRow('OEM Recommended Qty: <font color="red">*</font>',self.oemRecomendedQtyLineEdit_dlp_)
			formLayout.addRow('Issued Qty: <font color="red">*</font>', self.issuedQtyLineEdit_dlp_)
			formLayout.addRow('Available Quantity: <font color="red">*</font>', self.avaliabilityQtyLineEdit_dlp_)
			formLayout.addRow('Issued for Train Set : <font color="red">*</font>', self.issuedForTrainsetLineEdit_dlp_)
			formLayout.addRow('Car No: ', self.carNoLineEdit_dlp_)
			formLayout.addRow('Vendor Name: ', self.vendorNameLineEdit_dlp_)
			formLayout.addRow('Serial No. IN: ', self.srnoInLineEdit_dlp_)
			formLayout.addRow('Serial No. Out: ', self.srnoOuLineEdit_dlp_)
			formLayout.addRow('Issue Date: ', self.issueDate_dlp_)
			formLayout.addRow('Jobcard No: ', self.jobcardNoLineEdit_dlp_)
			formLayout.addRow('NCR No: ', self.ncrLineEdit_dlp_)
			formLayout.addRow('MGP No: ', self.mgpLineEdit_dlp_)
			formLayout.addRow('GIR No: ', self.girLineEdit_dlp_)
			formLayout.addRow('Remarks: ', self.remarksLineEdit_dlp_)
			formLayout.addRow('Row No: <font color="red">*</font>', self.rownumLineEdit_dlp_)


			self.createPushButton('updateBtn_dlp', 'Update', '', self.geometryWidth(0.042))

			vboxLayout.addWidget(self.updateBtn_dlp, alignment = Qt.AlignCenter)

			allFieldsData_ = [self.mtlSrNoLineEdit_dlp_, self.dlpSrNoLineEdit_dlp_, self.descriptionLineEdit_dlp_, self.partNoLineEdit_dlp_, self.unitLineEdit_dlp_, 
							self.oemRecomendedQtyLineEdit_dlp_, self.issuedQtyLineEdit_dlp_, self.avaliabilityQtyLineEdit_dlp_, self.issuedForTrainsetLineEdit_dlp_,   
							self.carNoLineEdit_dlp_, self.vendorNameLineEdit_dlp_, self.srnoInLineEdit_dlp_, self.srnoOuLineEdit_dlp_, self.issueDate_dlp_, 
							self.jobcardNoLineEdit_dlp_, self.ncrLineEdit_dlp_, self.mgpLineEdit_dlp_, self.girLineEdit_dlp_, self.remarksLineEdit_dlp_, self.rownumLineEdit_dlp_ ]

			def setToolTip(wid, text):
				wid.setToolTip(text)

			def settingToolTipToLineEdits(wid):
				wid.textChanged.connect(lambda: setToolTip(wid, wid.text()))

			def settingToolTipToTextEdits(wid):
				wid.textChanged.connect(lambda: setToolTip(wid, wid.toPlainText()))

			for wid in allFieldsData_:
				if isinstance(wid, QLineEdit):
					settingToolTipToLineEdits(wid)
			
				if isinstance(wid, QTextEdit):
					settingToolTipToTextEdits(wid)
			
			def onClickingUpdateButtonDlp():
				mandatoryVerification_dlp = True
				mandatoryIndexesdlp = [1, 2, 3, 4, 5, 6, 7, 8, 19]
				dlpUpdateFormData = []

				for i, wid in enumerate(allFieldsData_):
					if isinstance(wid, QLineEdit):
						if wid.text() == '':
							dlpUpdateFormData.append(None)
							if i in mandatoryIndexesdlp:
								mandatoryVerification_dlp = False
								wid.setProperty("error", True)
								wid.setStyleSheet(self.lineEditBoxQSS)
						else:
							if wid.text().isdigit():
								if '.' in wid.text():
									dlpUpdateFormData.append(float(wid.text()))
								else:
									dlpUpdateFormData.append(int(wid.text()))
							else:
								dlpUpdateFormData.append(wid.text()) 	

							wid.setProperty("error", False)
							wid.setStyleSheet(self.lineEditBoxQSS)

					if isinstance(wid, QTextEdit):
						if wid.toPlainText() == '':
							dlpUpdateFormData.append(None)
							if i in mandatoryIndexesdlp:
								mandatoryVerification_dlp = False
								wid.setProperty("error", True)
								wid.setStyleSheet(self.textEditBoxQSS)		

						else:
							dlpUpdateFormData.append(wid.toPlainText())	
							wid.setProperty("error", False)
							wid.setStyleSheet(self.textEditBoxQSS)


					if isinstance(wid, QComboBox):
						if wid.isEnabled():
							if wid.currentText() == '':
								dlpUpdateFormData.append(None)
								if i in mandatoryIndexesdlp:
									mandatoryVerification_dlp = False
									wid.setProperty("error", True)
									wid.setStyleSheet(self.comboBoxQSS)

							else:
								dlpUpdateFormData.append(wid.currentText())
								wid.setProperty("error", False)
								wid.setStyleSheet(self.comboBoxQSS)
						else:
							dlpUpdateFormData.append(None)


					elif isinstance(wid, QDateEdit):
						if wid.lineEdit().text() == ' ':
							dlpUpdateFormData.append(None)
						else:
							qdate = wid.date()
							py_date = date(qdate.year(), qdate.month(), qdate.day())  # Convert QDate to Python date
							dlpUpdateFormData.append(py_date)

	


				if not mandatoryVerification_dlp:
					print('Mandatory fields missing.')

				else:
					
					rowNumLineEditText = int(self.rownumLineEdit_dlp_.text())
					
					if rowcount == rowNumLineEditText:
						dlpUpdateFormData = dlpUpdateFormData[:-1]
						dlpId = dlpData[0]
						dlpUpdateFormData.append(dlpId)
						update_querryone = """
												UPDATE dlpspares
												SET 
													mtl_srno = %s,
													dlp_srno = %s,
													description = %s,
													part_no = %s,
													unit = %s,
													oemrecommended_qty = %s,
													issued_qty = %s,
													available_qty = %s,
													issued_for_train_set = %s,
													car_no = %s,
													vendor_name = %s,
													serial_no_in = %s,
													serial_no_ou = %s,
													issue_date = %s,
													jobcard_no = %s,
													ncr_no	= %s,
													mgp_no	= %s,
													gir_no	= %s,
													remarks = %s
												WHERE id = %s
											"""
						self.cursor.execute(update_querryone, tuple(dlpUpdateFormData))
						self.mydb.commit()

						dlpUpdateMsgBox = QMessageBox()
						dlpUpdateMsgBox.setIcon(QMessageBox.Information) 
						dlpUpdateMsgBox.setText(f'Data Updated successfully.')
						dlpUpdateMsgBox.setWindowTitle("Message")
						dlpUpdateMsgBox.setWindowIcon(QIcon('Media/ramsify.png'))
						dlpUpdateMsgBox.setStandardButtons(QMessageBox.Ok)
						dlpUpdateMsgBox.exec_()

					else:
						if rowcount < rowNumLineEditText:
							if rowNumLineEditText != self.dlpsparesDataTable.rowCount():
								tableButton = self.dlpsparesDataTable.cellWidget(rowNumLineEditText-1, 3)
								rowOrder = tableButton.property("row_order")

								prevTableButton = self.dlpsparesDataTable.cellWidget(rowNumLineEditText, 3)
								prevRoworder = prevTableButton.property("row_order")

								newRoworder = (rowOrder + prevRoworder) / 2
							else:
								tableButton = self.dlpsparesDataTable.cellWidget(rowNumLineEditText-1, 3)
								rowOrder = tableButton.property("row_order")
								newRoworder = int(rowOrder + 1)


							
						else:
							if rowNumLineEditText == 1:
								tableButton = self.dlpsparesDataTable.cellWidget(0, 3)
								rowOrder = tableButton.property("row_order")

								newRoworder = rowOrder / 2
							else:

								tableButton = self.dlpsparesDataTable.cellWidget(rowNumLineEditText-1, 3)
								rowOrder = tableButton.property("row_order")

								prevTableButton = self.dlpsparesDataTable.cellWidget(rowNumLineEditText-2, 3)
								prevRoworder = prevTableButton.property("row_order")

								newRoworder = (rowOrder + prevRoworder) / 2

							
						querry = ''' SELECT row_order FROM dlpspares WHERE row_order = %s AND deleted_at IS NULL '''
						self.cursor.execute(querry,(newRoworder,))
						result = self.cursor.fetchone()
					
						if result:
							QMessageBox.warning(self, "Invalid Row", "Please enter a correct row number.")
							return
							
						else:

							dlpUpdateFormData = dlpUpdateFormData[:-1]
							dlpUpdateFormData.append(newRoworder)

							dlpId = dlpData[0]
							dlpUpdateFormData.append(dlpId)

							update_querryone = """
								UPDATE dlpspares
								SET 
									mtl_srno = %s,
									dlp_srno = %s,
									description = %s,
									part_no = %s,
									unit = %s,
									oemrecommended_qty = %s,
									issued_qty = %s,
									available_qty = %s,
									issued_for_train_set = %s,
									car_no = %s,
									vendor_name = %s,
									serial_no_in = %s,
									serial_no_ou = %s,
									issue_date = %s,
									jobcard_no = %s,
									ncr_no	= %s,
									mgp_no	= %s,
									gir_no	= %s,
									remarks = %s,
									row_order = %s
								WHERE id = %s
								"""
							self.cursor.execute(update_querryone, tuple(dlpUpdateFormData))
							self.mydb.commit()

							dlpUpdateMsgBox = QMessageBox()
							dlpUpdateMsgBox.setIcon(QMessageBox.Information) 
							dlpUpdateMsgBox.setText(f'Data Updated successfully.')
							dlpUpdateMsgBox.setWindowTitle("Message")
							dlpUpdateMsgBox.setWindowIcon(QIcon('Media/ramsify.png'))
							dlpUpdateMsgBox.setStandardButtons(QMessageBox.Ok)
							dlpUpdateMsgBox.exec_()

					self.refreshButton_Dlp.click()
					self.dlpsparesUpdateWindow.close()

			self.updateBtn_dlp.clicked.connect(onClickingUpdateButtonDlp)

			self.dlpsparesUpdateWindow.show()


		self.dlpsparesDataTable.setRowCount(0)

		for row, rowData in enumerate(dlpDataResult):
			self.dlpsparesDataTable.insertRow(self.dlpsparesDataTable.rowCount())
			rowCount = self.dlpsparesDataTable.rowCount()
			dlpCheckBoxWidget = QCheckBox('')
			dlpCheckBoxWidget.setProperty("id", rowData[0])
			dlpCheckBoxWidget.setStyleSheet(self.checkBoxQSS)
			self.dlpsparesDataTable.setCellWidget(self.dlpsparesDataTable.rowCount()-1, 0, dlpCheckBoxWidget)
			dlpCheckBoxWidget.stateChanged.connect(onStateChangedOf_DlpCheckBox)

			for col, value in enumerate(rowData[2:]):			
				if col == 2 :
					button = QPushButton()					
					button.setText(str(value))
					givingFunctionalityToButton(button, onbuttonClickedDlp, rowData, rowCount)
					button.setStyleSheet(self.tableButtonQSS)
					button.setCursor(Qt.PointingHandCursor)
					button.setProperty("id",rowData[0])
					button.setProperty("row_order",rowData[1])	
					self.dlpsparesDataTable.setCellWidget(row, 3, button)

				else:
					if value is not None:
						item = QTableWidgetItem(str(value))
					else:
						item = QTableWidgetItem('')

					item.setTextAlignment(Qt.AlignCenter)
					item.setToolTip(item.text())
					self.dlpsparesDataTable.setItem(row, col+1, item)
		

	self.refreshButton_Dlp.clicked.connect(onClickingrefreshbutton_dlp)


	def onSearchBox_Dlp_Button():

		searchText = self.serachBarOfDlp.text().lower()

		for row in range(self.dlpsparesDataTable.rowCount()):
			self.dlpsparesDataTable.setRowHidden(row, True)

			if self.dlpsparesDataTable.cellWidget(row, 3) and (searchText in self.dlpsparesDataTable.cellWidget(row, 3).text().lower()):
				self.dlpsparesDataTable.setRowHidden(row, False)
				continue

			for col in range(1, self.dlpsparesDataTable.columnCount()):
				if col != 3:
					item = self.dlpsparesDataTable.item(row, col)
					if item is not None and searchText in item.text().lower():
						self.dlpsparesDataTable.setRowHidden(row, False)
						break

	self.serachBarOfDlp.textChanged.connect(onSearchBox_Dlp_Button)


	def onClickingDownloadBtn_DLPSparesDT():

		file_path, _ = QFileDialog.getSaveFileName(self, "Save Excel File", "", "Excel Files (*.xlsx)")

		if file_path:

			wb = Workbook()
			ws = wb.active

			headers = []
			for col in range(1, self.dlpsparesDataTable.columnCount()):
				if not self.dlpsparesDataTable.isColumnHidden(col):
					header_item = self.dlpsparesDataTable.horizontalHeaderItem(col)
					if header_item is not None:
						headers.append(header_item.text())

			ws.append(headers)

			row_index = 2
			for row in range(self.dlpsparesDataTable.rowCount()):
				if not self.dlpsparesDataTable.isRowHidden(row):
					for col in range(1, self.dlpsparesDataTable.columnCount()):
						if col == 3:
							wid = self.dlpsparesDataTable.cellWidget(row, col)
							if isinstance(wid, QPushButton):
								ws.cell(row= row_index, column= col).value = wid.text()
						else:	
							item = self.dlpsparesDataTable.item(row, col)
							if item is not None:
								ws.cell(row=row_index, column= col).value = item.text()

					row_index += 1



			wb.save(file_path)

			dlpDownloadedMsgBox = QMessageBox()
			dlpDownloadedMsgBox.setIcon(QMessageBox.Information) 
			dlpDownloadedMsgBox.setText(f'Data downloaded successfully')
			dlpDownloadedMsgBox.setWindowTitle("Message")
			dlpDownloadedMsgBox.setWindowIcon(QIcon('Media/ramsify.png'))
			dlpDownloadedMsgBox.setStandardButtons(QMessageBox.Ok)
			dlpDownloadedMsgBox.exec_()

	self.download_Dlp.clicked.connect(onClickingDownloadBtn_DLPSparesDT)



	def onClicking_SelectAll_DlpDT(checked):
		if checked:
			self.selectAllDlpspareButton.setIcon(QIcon(checkAllUserIconPath))

			for i in range(self.dlpsparesDataTable.rowCount()):
				if not self.dlpsparesDataTable.isRowHidden(i):
					if isinstance(self.dlpsparesDataTable.cellWidget(i,0), QCheckBox):
						self.dlpsparesDataTable.cellWidget(i,0).setCheckState(Qt.Checked)
		
		else:
			self.selectAllDlpspareButton.setIcon(QIcon(unCheckAllUserIconPath))

			for i in range(self.dlpsparesDataTable.rowCount()):
				if not self.dlpsparesDataTable.isRowHidden(i):
					if isinstance(self.dlpsparesDataTable.cellWidget(i,0), QCheckBox):
						self.dlpsparesDataTable.cellWidget(i,0).setCheckState(Qt.Unchecked)

	
	self.selectAllDlpspareButton.toggled.connect(onClicking_SelectAll_DlpDT)


	def onStateChangedOf_DlpCheckBox():
		all_checked = True
		all_unchecked = True

		for i in range(self.dlpsparesDataTable.rowCount()):
			if not self.dlpsparesDataTable.isRowHidden(i):
				if isinstance(self.dlpsparesDataTable.cellWidget(i,0), QCheckBox):
					if self.dlpsparesDataTable.cellWidget(i,0).isChecked():
						all_unchecked = False
					else:
						all_checked = False

		if all_checked or all_unchecked:
			some_checked = False
		else:
			some_checked = True


		if all_checked:
			self.deleteButton_Dlp.show()
			self.selectAllDlpspareButton.setIcon(QIcon(checkAllUserIconPath))
			self.selectAllDlpspareButton.setChecked(True)
			

		if all_unchecked:
			self.deleteButton_Dlp.hide()
			self.selectAllDlpspareButton.setIcon(QIcon(unCheckAllUserIconPath))
			self.selectAllDlpspareButton.setChecked(False)

		if some_checked:
			self.deleteButton_Dlp.show()
			self.selectAllDlpspareButton.setIcon(QIcon(partiallyCheckedIconPath))




	def onClicking_Delete_DlpDT():
		selecteddlpIndices_ = []
		selectedIndicesInUITable = []

		numberOfSelectedDlp = 0

		for i in range(self.dlpsparesDataTable.rowCount()):
			if not self.dlpsparesDataTable.isRowHidden(i):
				if isinstance(self.dlpsparesDataTable.cellWidget(i,0), QCheckBox):
					currentCheckBox = self.dlpsparesDataTable.cellWidget(i,0)
					if currentCheckBox.checkState() == Qt.Checked:
						selectedIndicesInUITable.append(i)
						selecteddlpIndices_.append(currentCheckBox.property("id"))

						dlpButton = self.dlpsparesDataTable.cellWidget(i, 1)
						if dlpButton:
							selectedIndicesInUITable.append(dlpButton.text())
						numberOfSelectedDlp += 1
		

		if selecteddlpIndices_:

			confirmDeleteRefMsgBox = QMessageBox()
			confirmDeleteRefMsgBox.setIcon(QMessageBox.Question) 
			confirmDeleteRefMsgBox.setText(f"Are you sure you want to delete {numberOfSelectedDlp} dlpnos?")
			confirmDeleteRefMsgBox.setWindowTitle("Confirm")
			confirmDeleteRefMsgBox.setWindowIcon(QIcon('Media/ramsify.png'))
			confirmDeleteRefMsgBox.setStandardButtons(QMessageBox.Ok | QMessageBox.No)
			
			userResponse = confirmDeleteRefMsgBox.exec()

			if userResponse == QMessageBox.Ok:
				current_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
				for ind in sorted(selecteddlpIndices_, reverse=True):
					dlpnoToDelete = selectedIndicesInUITable[selecteddlpIndices_.index(ind)]
					sql = "UPDATE dlpspares SET deleted_at = %s, user_id = %s WHERE id = %s"
					values = (current_time, self.user_id, ind)
					self.cursor.execute(sql, values)
					self.mydb.commit()
					self.dlpsparesDataTable.removeRow(dlpnoToDelete)

				dlpDeleteSuccessMsgBox = QMessageBox()
				dlpDeleteSuccessMsgBox.setIcon(QMessageBox.Information) 
				dlpDeleteSuccessMsgBox.setText(f'{numberOfSelectedDlp} Dlps deleted successfully.')
				dlpDeleteSuccessMsgBox.setWindowTitle("Message")
				dlpDeleteSuccessMsgBox.setWindowIcon(QIcon('Media/ramsify.png'))
				dlpDeleteSuccessMsgBox.setStandardButtons(QMessageBox.Ok)
				dlpDeleteSuccessMsgBox.exec()
			
				self.deleteButton_Dlp.hide()
				self.selectAllDlpspareButton.setIcon(QIcon(unCheckAllUserIconPath))

				self.refreshButton_Dlp.click()
			
			else:
				pass

	self.deleteButton_Dlp.clicked.connect(onClicking_Delete_DlpDT)

	onClickingrefreshbutton_dlp()