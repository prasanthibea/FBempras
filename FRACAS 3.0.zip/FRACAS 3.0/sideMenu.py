from PySide6.QtWidgets import QTreeWidgetItem
from PySide6.QtCore import QPropertyAnimation, QEasingCurve

from QSSS import *
from datetime import datetime

from functions import *

def on_menu_button_clicked(self):


	if self.sideMenuSize == 0:
		self.animation1 = QPropertyAnimation(self.leftMenu, b"minimumWidth")
		self.animation1.setDuration(500)
		self.animation1.setStartValue(198)
		self.animation1.setEndValue(0)
		self.animation1.setEasingCurve(QEasingCurve.InOutQuart)
		self.animation1.start()

		self.animation2 = QPropertyAnimation(self.leftMenu, b"maximumWidth")
		self.animation2.setDuration(500)
		self.animation2.setStartValue(198)
		self.animation2.setEndValue(0)
		self.animation2.setEasingCurve(QEasingCurve.InOutQuart)
		self.animation2.start()
		self.sideMenuSize = 1
	else:
		self.animation3 = QPropertyAnimation(self.leftMenu, b"minimumWidth")
		self.animation3.setDuration(500)
		self.animation3.setStartValue(0)
		self.animation3.setEndValue(198)
		self.animation3.setEasingCurve(QEasingCurve.InOutQuart)
		self.animation3.start()

		self.animation4 = QPropertyAnimation(self.leftMenu, b"maximumWidth")
		self.animation4.setDuration(500)
		self.animation4.setStartValue(0)
		self.animation4.setEndValue(198)
		self.animation4.setEasingCurve(QEasingCurve.InOutQuart)
		self.animation4.start()
		self.sideMenuSize = 0
		
def onSideMenuTreeItemClicked(self, item, col):
	
	stackedWidgetIndicesDict = {0:'', 1: self.RMFormTreeItem,
								2: self.maintenanceFormTreeItem, 3: self.RMDataItem,
								4: self.maintenanceDataItem, 5: self.runningMileageTreeItem,
								6: self.availabilityTreeItem, 7: self.MTTR_TreeItem,
								8: self.MDBFTreeItem, 9: self.MDBCFTreeItem,
								10: self.trainSummaryTreeItem, 11: self.failuresTreeItem,
								12: self.patternFailuresTreeItem, 14: self.ncrTreeItem,
								16: self.tncTreeItem, 17: self.consumablesTreeItem,
								18: self.dlpSparesTreeItem

								}


	if self.sideMenuTree.currentItem() == self.RMFormTreeItem:
		self.stackedWidget.setCurrentIndex(1)
	if self.sideMenuTree.currentItem() == self.maintenanceFormTreeItem:
		self.stackedWidget.setCurrentIndex(2)

	if self.sideMenuTree.currentItem() == self.RMDataItem:
		self.stackedWidget.setCurrentIndex(3)
	if self.sideMenuTree.currentItem() == self.maintenanceDataItem:
		self.stackedWidget.setCurrentIndex(4)

	if self.sideMenuTree.currentItem() == self.runningMileageTreeItem:
		self.stackedWidget.setCurrentIndex(5)
	if self.sideMenuTree.currentItem() == self.availabilityTreeItem:
		self.stackedWidget.setCurrentIndex(6)
	if self.sideMenuTree.currentItem() == self.MTTR_TreeItem:
		self.stackedWidget.setCurrentIndex(7)
	if self.sideMenuTree.currentItem() == self.MDBFTreeItem:
		self.stackedWidget.setCurrentIndex(8)
	if self.sideMenuTree.currentItem() == self.MDBCFTreeItem:
		self.stackedWidget.setCurrentIndex(9)
	if self.sideMenuTree.currentItem() == self.trainSummaryTreeItem:
		self.stackedWidget.setCurrentIndex(10)
	if self.sideMenuTree.currentItem() == self.failuresTreeItem:
		self.stackedWidget.setCurrentIndex(11)
	if self.sideMenuTree.currentItem() == self.patternFailuresTreeItem:
		self.stackedWidget.setCurrentIndex(12)

	if self.sideMenuTree.currentItem() == self.ncrTreeItem:
		self.stackedWidget.setCurrentIndex(self.currentNCRIndex)

	if self.sideMenuTree.currentItem() == self.tncTreeItem:
		self.stackedWidget.setCurrentIndex(16)

	if self.sideMenuTree.currentItem() == self.consumablesTreeItem:
		self.stackedWidget.setCurrentIndex(17)

	if self.sideMenuTree.currentItem() == self.dlpSparesTreeItem:
		self.stackedWidget.setCurrentIndex(18)


	if self.sideMenuTree.currentItem() == self.inputsTreeHead or self.dashboardTreeHead or self.dataTreeHead or self.moreTreeHead:
		if self.stackedWidget.currentIndex() != 0:
			if self.stackedWidget.currentIndex() == 15:
				pass
			else:
				self.sideMenuTree.setCurrentItem(stackedWidgetIndicesDict[self.stackedWidget.currentIndex()])



def on_home_btn_clicked(self):
	self.sideMenuTree.clearSelection()
	self.stackedWidget.setCurrentIndex(0)



def sideTreeMenu(self):

	self.inputsTreeHead = QTreeWidgetItem(['INPUTS'])
	self.sideMenuTree.addTopLevelItem(self.inputsTreeHead)
	self.sideMenuTree.expandItem(self.inputsTreeHead)

	self.RMFormTreeItem = QTreeWidgetItem(['Running Mileage'])
	self.RMFormTreeItem.setIcon(0, QIcon("Media/registration.png"))
	self.inputsTreeHead.addChild(self.RMFormTreeItem)

	self.maintenanceFormTreeItem = QTreeWidgetItem(['Maintenance'])
	self.maintenanceFormTreeItem.setIcon(0, QIcon("Media/form4.png"))
	self.inputsTreeHead.addChild(self.maintenanceFormTreeItem)

	self.dataTreeHead = QTreeWidgetItem(['DATA'])
	self.sideMenuTree.addTopLevelItem(self.dataTreeHead)
	self.sideMenuTree.expandItem(self.dataTreeHead)

	self.RMDataItem = QTreeWidgetItem(['Running Mileage'])
	self.RMDataItem.setIcon(0, QIcon("Media/form.png"))
	self.dataTreeHead.addChild(self.RMDataItem)

	self.maintenanceDataItem = QTreeWidgetItem(['Maintenance'])
	self.maintenanceDataItem.setIcon(0, QIcon("Media/form2.png"))
	self.dataTreeHead.addChild(self.maintenanceDataItem)


	self.dashboardTreeHead = QTreeWidgetItem(['DASHBOARD'])
	self.sideMenuTree.addTopLevelItem(self.dashboardTreeHead)
	self.sideMenuTree.expandItem(self.dashboardTreeHead)

	self.trainSummaryTreeItem = QTreeWidgetItem(['Train Summary'])
	self.trainSummaryTreeItem.setIcon(0, QIcon("Media/railway.png"))
	self.dashboardTreeHead.addChild(self.trainSummaryTreeItem)	

	self.runningMileageTreeItem = QTreeWidgetItem(['Running Mileage'])
	self.runningMileageTreeItem.setIcon(0, QIcon("Media/runningMileage.png"))
	self.dashboardTreeHead.addChild(self.runningMileageTreeItem)

	self.MDBFTreeItem = QTreeWidgetItem(['MDBF'])
	self.MDBFTreeItem.setIcon(0, QIcon('Media/mdbf.png'))
	self.dashboardTreeHead.addChild(self.MDBFTreeItem)

	self.failuresTreeItem = QTreeWidgetItem(['Relavent & Service\nFailures'])
	self.failuresTreeItem.setIcon(0, QIcon('Media/remove.png'))
	self.dashboardTreeHead.addChild(self.failuresTreeItem)

	self.MDBCFTreeItem = QTreeWidgetItem(['MDBCF'])
	self.MDBCFTreeItem.setIcon(0, QIcon('Media/mdbcf.png'))
	self.dashboardTreeHead.addChild(self.MDBCFTreeItem)

	self.patternFailuresTreeItem = QTreeWidgetItem(['Pattern Failures'])
	self.patternFailuresTreeItem.setIcon(0, QIcon('Media/pattern-lock.png'))
	self.dashboardTreeHead.addChild(self.patternFailuresTreeItem)

	self.availabilityTreeItem = QTreeWidgetItem(['Availability'])
	self.availabilityTreeItem.setIcon(0, QIcon('Media/availability.png'))
	self.dashboardTreeHead.addChild(self.availabilityTreeItem)

	self.MTTR_TreeItem = QTreeWidgetItem(['MTTR'])
	self.MTTR_TreeItem.setIcon(0, QIcon('Media/mttr.png'))
	self.dashboardTreeHead.addChild(self.MTTR_TreeItem)

	self.moreTreeHead = QTreeWidgetItem(['MORE'])
	self.sideMenuTree.addTopLevelItem(self.moreTreeHead)
	self.sideMenuTree.expandItem(self.moreTreeHead)

	self.ncrTreeItem = QTreeWidgetItem(['NCR'])
	self.ncrTreeItem.setIcon(0, QIcon("Media/ncrim.png"))
	self.moreTreeHead.addChild(self.ncrTreeItem)

	self.tncTreeItem = QTreeWidgetItem(['T&C Status'])
	self.tncTreeItem.setIcon(0, QIcon("Media/tncim.png"))
	self.moreTreeHead.addChild(self.tncTreeItem)

	self.consumablesTreeItem = QTreeWidgetItem(['Consumables'])
	self.consumablesTreeItem.setIcon(0, QIcon("Media/consumable.png"))
	self.moreTreeHead.addChild(self.consumablesTreeItem)

	self.dlpSparesTreeItem = QTreeWidgetItem(['DLP Spares'])
	self.dlpSparesTreeItem.setIcon(0, QIcon("Media/spares.png"))
	self.moreTreeHead.addChild(self.dlpSparesTreeItem)







	# def setToolTipsForItems(item):
	# 	for i in range(item.childCount()):
	# 		child = item.child(i)
	# 		name = child.text(0)
	# 		child.setToolTip(0, name)

	# 		setToolTipsForItems(child)

	# setToolTipsForItems(self.sideMenuTree.invisibleRootItem())

	self.sideMenuTree.currentItemChanged.connect(self.onSideMenuTreeItemClicked)
	self.sideMenuTree.itemClicked.connect(self.onSideMenuTreeItemClicked)
	#self.sideMenuTree.setWindowIcon(QIcon('Media/original_svg/search.svg'))

def buttonsOnSideMenu(self):
	self.homeBtn.setIcon(QIcon('Media/home.png'))
	self.allLeftMenuButtons = [self.homeBtn, self.settingsBtn, self.configurationBtn]
	self.menuBtn.clicked.connect(self.on_menu_button_clicked)
	self.homeBtn.clicked.connect(self.on_home_btn_clicked)
	self.settingsBtn.clicked.connect(self.on_settings_btn_clicked)
	self.configurationBtn.clicked.connect(self.onClickingConfigurationBtn)




def on_settings_btn_clicked(self):
	self.sideMenuTree.clearSelection()
	self.settingsWidget.show()



def onClickingConfigurationBtn(self):
	self.sideMenuTree.clearSelection()
	self.stackedWidget.setCurrentIndex(13)