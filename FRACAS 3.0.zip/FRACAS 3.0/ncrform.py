from PySide6.QtWidgets import QLabel, QWidget, QVBoxLayout, QSpacerItem, QDialog, QMessageBox, QSizePolicy, QFileDialog, QHBoxLayout, QScrollBar, QDateEdit, QScrollArea, QTabWidget, QTableWidget, QTableWidgetItem, QAbstractItemView, QFormLayout, QLineEdit, QTextEdit, QComboBox, QGridLayout, QPushButton, QSpinBox
from PySide6.QtCore import Qt, QDate, QDateTime
from PySide6.QtGui import QIcon, QBrush, QColor
from datetime import date, datetime
import shutil
import os

def ncrformUI(self):
	from PySide6.QtWidgets import QApplication, QDateEdit
	from functions import checkableComboBox, FileAttachmentWidget, CustomDateEdit
	
	NCRHLayout = QHBoxLayout()
	
	NCRFormLayout1 = QFormLayout()
	NCRFormLayout2 = QFormLayout()


	self.createPushButton('backButton_NCR', 'BACK',self.currentTheme['leftArrow'], self.geometryWidth(0.045))
	
	def on_back_button_clicked():
		self.currentNCRIndex = 14
		self.stackedWidget.setCurrentIndex(14)

	self.backButton_NCR.clicked.connect(on_back_button_clicked)

	self.mainVerticalLayout_NcrForm.addWidget(self.backButton_NCR)
	self.mainVerticalLayout_NcrForm.addLayout(NCRHLayout)


	NCRHLayout.addLayout(NCRFormLayout1)
	spacer_item = QSpacerItem(self.geometryWidth(0.01), 5, QSizePolicy.Fixed, QSizePolicy.Minimum)
	NCRHLayout.addItem(spacer_item)
	NCRHLayout.addLayout(NCRFormLayout2)
	

	self.ckdmndl_NCR = QPushButton('CKD')
	self.ckdmndl_NCR.setFixedWidth(37)
	self.ckdmndl_NCR.setFixedHeight(25)
	self.ckdmndl_NCR.setStyleSheet('border-radius: 2px; background:white; border: 1px solid grey;padding: 2px;')

	self.current_ncr = QLabel()
	self.reportno = QLabel('NCR-BEML MRS1-T&C-')

	self.cursor.execute("SELECT report_no FROM ncr ORDER BY id DESC LIMIT 1")
	repoResul = self.cursor.fetchone()
	
	if repoResul:
		report_no = repoResul[0]  # Extract the first item from the tuple
		
		parts = report_no.split('-')  # Now split the string based on '-'
		cur_number = int(parts[-1].strip())  # Assuming the number is at the end
		newnumber = cur_number + 1
		self.current_ncr.setText(f"-{newnumber}")
	else:
		self.current_ncr.setText("-1")
		

	self.createLineEditBox('projectLineEdit_NCR')
	self.createLineEditBox('productLineEdit_NCR')
	self.createNumberLineEditBox('quantityLineEdit_NCR')
	self.createLineEditBox('supplierLineEdit_NCR')
	self.createLineEditBox('detectionLineEdit_NCR')
	self.createComboBox2(['CKD', 'Mandala'], 'placeComboBox_NCR')
	self.createLineEditBox('storedLineEdit_NCR')
	self.createComboBox2(['Major', 'Minor'],'severityComboBox_NCR')
	self.createLineEditBox('distributiontoLineEdit_NCR')
	self.createCheckableComboBox(self.trainsetsList, 'trainComboBox_NCR')
	self.createCheckableComboBox(self.carsList, 'carComboBox_NCR')
	self.createLineEditBox('assyDwgNoLineEdit_NCR')
	self.createNumberLineEditBox('revLineEdit_NCR')
	self.createLineEditBox('partnoLineEdit_NCR')
	self.createLineEditBox('assySNoLineEdit_NCR')
	self.createLineEditBox('partSerialNoLineEdit_NCR')
	self.createLineEditBox('blnoLineEdit_NCR')
	self.createLineEditBox('invoicenoLineEdit_NCR')
	self.createLineEditBox('responsiblePartyLineEdit_NCR')
	self.createComboBox2(['Before Installation', 'Installed', 'Disassembled', 'Before receiving'], 'materialstatusComboBox_NCR')
	self.createTextEditBox('descriptionofnonconform_NCR')
	self.createAttachmentWidget('attachedDocuments1_NCR')

	# current_date = QDate.currentDate()
	# start_of_month = QDate(current_date.year(), current_date.month(), 1)
	self.createEmptyDateEditBox('date_NCR')
	# self.date_NCR.setMinimumDate(QDate(1000, 1, 1))
	# self.date_NCR.setMaximumDate(QDate(3000, 12, 31))
	# self.date_NCR.setDate(start_of_month)

	self.createLineEditBox('teamLineEdit_NCR')
	self.createLineEditBox('issuedbyLineEdit_NCR')
	self.createLineEditBox('reviewedbyLineEdit_NCR')
	self.createLineEditBox('approvedbyLineEdit_NCR')
	self.createTextEditBox('causeofnonconformity_NCR')
	self.createAttachmentWidget('attacheddocuments2_NCR')
	self.createTextEditBox('correctionOrCorrectiveActionLineEdit_NCR')
	self.createTextEditBox('actionplan_NCR')
	self.createAttachmentWidget('attacheddocuments3_NCR')
	self.createEmptyDateEditBox('date1_NCR')
	self.createLineEditBox('actionbyLineEdit_NCR')
	self.createLineEditBox('issuedby1LineEdit_NCR')
	self.createLineEditBox('reviewedby1LineEdit_NCR')
	self.createLineEditBox('approvedby1LineEdit_NCR')
	self.createComboBox2(['Claim', 'Holding', 'Use as is', 'Rework', 'Waiver', 'Scrap', 'Repair'], 'decisionComboBox_NCR')
	self.createComboBox2(['Yes', 'No'], 'repairprocedureComboBox_NCR')	
	self.createLineEditBox('name1LineEdit_NCR')
	self.createEmptyDateEditBox('date2_NCR')	
	self.createLineEditBox('sign1LineEdit_NCR')
	self.createLineEditBox('name2LineEdit_NCR')
	self.createEmptyDateEditBox('date3_NCR')	
	self.createLineEditBox('sign2LineEdit_NCR')
	self.createComboBox2(['Internal', 'Customer'], 'approvalScopeComboBox_NCR')     	
	self.createLineEditBox('entityLineEdit_NCR')
	self.createLineEditBox('positionLineEdit_NCR')
	self.createLineEditBox('name3LineEdit_NCR')
	self.createEmptyDateEditBox('date4_NCR')
	self.createLineEditBox('sign3LineEdit_NCR')
	self.createAttachmentWidget('attacheddocuments4_NCR')
	self.attacheddocuments4_NCR.fileListWidget.setMinimumHeight(140)


	layoutForReportNo_NCR = QHBoxLayout()
	layoutForReportNo_NCR.addWidget(self.reportno, alignment = Qt.AlignRight )
	layoutForReportNo_NCR.addWidget(self.ckdmndl_NCR, alignment = Qt.AlignLeft )
	layoutForReportNo_NCR.addWidget(self.current_ncr,alignment = Qt.AlignLeft)
	layoutForReportNo_NCR.addItem(QSpacerItem(1, 0, QSizePolicy.Expanding, QSizePolicy.Minimum))

	NCRFormLayout1.addRow('Report No: <font color="red">*</font>', layoutForReportNo_NCR)
	NCRFormLayout1.addRow('Project:', self.projectLineEdit_NCR)
	NCRFormLayout1.addRow('Product:', self.productLineEdit_NCR)
	NCRFormLayout1.addRow('Quantity: <font color="red">*</font>', self.quantityLineEdit_NCR)
	
	NCRFormLayout1.addRow('Supplier: <font color="red">*</font>', self.supplierLineEdit_NCR)
	NCRFormLayout1.addRow('Detection: <font color="red">*</font>', self.detectionLineEdit_NCR)
	NCRFormLayout1.addRow('Place:', self.placeComboBox_NCR)
	NCRFormLayout1.addRow('Stored at:', self.storedLineEdit_NCR)	
	NCRFormLayout1.addRow('Severity:', self.severityComboBox_NCR)
	NCRFormLayout1.addRow('Distribution to: <font color="red">*</font>', self.distributiontoLineEdit_NCR)
	NCRFormLayout1.addRow('Trainset: <font color="red">*</font>', self.trainComboBox_NCR)
	NCRFormLayout1.addRow('Car:', self.carComboBox_NCR)

	NCRFormLayout1.addRow('Assy dwg no:', self.assyDwgNoLineEdit_NCR)
	NCRFormLayout1.addRow('Rev:', self.revLineEdit_NCR)
	NCRFormLayout1.addRow('Part No:', self.partnoLineEdit_NCR)

	NCRFormLayout1.addRow('Assy Serial No:', self.assySNoLineEdit_NCR)
	NCRFormLayout1.addRow('Part Serial No:', self.partSerialNoLineEdit_NCR)


	NCRFormLayout1.addRow('B/L No:', self.blnoLineEdit_NCR)
	NCRFormLayout1.addRow('Invoice no:', self.invoicenoLineEdit_NCR)
	NCRFormLayout1.addRow('Responsible party: <font color="red">*</font>', self.responsiblePartyLineEdit_NCR)
	NCRFormLayout1.addRow('Material status:', self.materialstatusComboBox_NCR)

	NCRFormLayout1.addRow('Description of non-conform: <font color="red">*</font>', self.descriptionofnonconform_NCR)
	NCRFormLayout1.addRow('Attached documents (if any):', self.attachedDocuments1_NCR)

	NCRFormLayout1.addRow('Date: <font color="red">*</font>' , self.date_NCR)
	NCRFormLayout1.addRow('Team :', self.teamLineEdit_NCR)
	NCRFormLayout1.addRow('Issued by: <font color="red">*</font>', self.issuedbyLineEdit_NCR)
	NCRFormLayout1.addRow('Reviewed by: <font color="red">*</font>', self.reviewedbyLineEdit_NCR)
	NCRFormLayout1.addRow('Approved by: <font color="red">*</font>', self.approvedbyLineEdit_NCR)

	NCRFormLayout1.addRow('Cause of nonconformity: ', self.causeofnonconformity_NCR)
	NCRFormLayout2.addRow('Attached documents (if any):', self.attacheddocuments2_NCR)
	NCRFormLayout2.addRow('A. Correction/corrective action result: <font color="red">*</font>', self.correctionOrCorrectiveActionLineEdit_NCR)
	NCRFormLayout2.addRow('B. Action Plan: ', self.actionplan_NCR)
	NCRFormLayout2.addRow('Attached documents (if any):', self.attacheddocuments3_NCR)
	NCRFormLayout2.addRow('Date: ' , self.date1_NCR)
	NCRFormLayout2.addRow('Action by:', self.actionbyLineEdit_NCR)
	NCRFormLayout2.addRow('Issued by:', self.issuedby1LineEdit_NCR)
	NCRFormLayout2.addRow('Reviewed by:', self.reviewedby1LineEdit_NCR)
	NCRFormLayout2.addRow('Approved by:', self.approvedby1LineEdit_NCR)
	NCRFormLayout2.addRow('Decision :', self.decisionComboBox_NCR)
	NCRFormLayout2.addRow('Repair procedure:', self.repairprocedureComboBox_NCR)
	NCRFormLayout2.addRow(QLabel('Verification on correction:	'))
	NCRFormLayout2.addRow('            Names:', self.name1LineEdit_NCR)
	NCRFormLayout2.addRow('            Date:' , self.date2_NCR)
	NCRFormLayout2.addRow('            Sign:', self.sign1LineEdit_NCR)
	NCRFormLayout2.addRow(QLabel('Verification on corrective action:	'))
	NCRFormLayout2.addRow('            Name:', self.name2LineEdit_NCR)
	NCRFormLayout2.addRow('            Date: ' , self.date3_NCR)
	NCRFormLayout2.addRow('            Sign:', self.sign2LineEdit_NCR)
	NCRFormLayout2.addRow('Approval Scope:', self.approvalScopeComboBox_NCR)

	NCRFormLayout2.addRow('Entity:', self.entityLineEdit_NCR)
	NCRFormLayout2.addRow('Position:', self.positionLineEdit_NCR)
	NCRFormLayout2.addRow('Name:', self.name3LineEdit_NCR)
	NCRFormLayout2.addRow('Date:', self.date4_NCR)
	NCRFormLayout2.addRow('Sign:', self.sign3LineEdit_NCR)
	NCRFormLayout2.addRow('Signed NCR:', self.attacheddocuments4_NCR)


	def toggleLabelText():
		currentText = self.ckdmndl_NCR.text()
		if currentText == 'CKD':
			self.ckdmndl_NCR.setText('Mandala')		
			self.ckdmndl_NCR.setFixedWidth(65)	
		else:
			self.ckdmndl_NCR.setText('CKD')
			self.ckdmndl_NCR.setFixedWidth(37)	
	self.ckdmndl_NCR.clicked.connect(toggleLabelText)


	self.createPushButton('submit_NCR', 'SUBMIT', '', self.geometryWidth(0.075))
	self.createPushButton('cancel_NCR', 'CANCEL', '', self.geometryWidth(0.075))

	layoutForSubmit_NCR = QHBoxLayout()
	layoutForSubmit_NCR.addWidget(self.submit_NCR, alignment = Qt.AlignRight)
	layoutForSubmit_NCR.addWidget(self.cancel_NCR, alignment = Qt.AlignLeft)

	self.mainVerticalLayout_NcrForm.addLayout(layoutForSubmit_NCR)

	self.allFields = [self.reportno, self.projectLineEdit_NCR, self.productLineEdit_NCR, self.quantityLineEdit_NCR, self.supplierLineEdit_NCR,
					self.detectionLineEdit_NCR,self.placeComboBox_NCR, self.storedLineEdit_NCR, self.severityComboBox_NCR,self.distributiontoLineEdit_NCR,
					self.trainComboBox_NCR, self.carComboBox_NCR, self.assyDwgNoLineEdit_NCR, self.revLineEdit_NCR, self.partnoLineEdit_NCR,
					self.assySNoLineEdit_NCR, self.partSerialNoLineEdit_NCR, self.blnoLineEdit_NCR, self.invoicenoLineEdit_NCR, self.responsiblePartyLineEdit_NCR,
					self.materialstatusComboBox_NCR, self.descriptionofnonconform_NCR,self.attachedDocuments1_NCR, self.date_NCR, self.teamLineEdit_NCR, 
					self.issuedbyLineEdit_NCR, self.reviewedbyLineEdit_NCR, self.approvedbyLineEdit_NCR, self.causeofnonconformity_NCR, 
					self.attacheddocuments2_NCR, self.correctionOrCorrectiveActionLineEdit_NCR, self.actionplan_NCR, self.attacheddocuments3_NCR, 
					self.date1_NCR, self.actionbyLineEdit_NCR, self.issuedby1LineEdit_NCR, self.reviewedby1LineEdit_NCR, self.approvedby1LineEdit_NCR, 
					self.decisionComboBox_NCR, self.repairprocedureComboBox_NCR, self.name1LineEdit_NCR, self.date2_NCR, self.sign1LineEdit_NCR, 
					self.name2LineEdit_NCR, self.date3_NCR, self.sign2LineEdit_NCR, self.approvalScopeComboBox_NCR, self.entityLineEdit_NCR, 
					self.positionLineEdit_NCR, self.name3LineEdit_NCR, self.date4_NCR, self.sign3LineEdit_NCR, self.attacheddocuments4_NCR]

	
	def onClickingsubmit_Ncr():
		mandatoryVerification_NCR = True
		mandatoryIndexesNcr = [0, 3, 4, 5, 9, 10, 19, 21, 23, 25, 26, 27, 30]
	
		ncrFormData =[]
		
		for i, wid in enumerate(self.allFields):
			if i ==0:
				ReportNo = f'{self.reportno.text()}{self.ckdmndl_NCR.text()}{self.current_ncr.text()}'
				ncrFormData.append(ReportNo)
			else:	
				if isinstance(wid, QComboBox):
					if wid.isEnabled():
						if wid.currentText() == '':
							ncrFormData.append(None)
							if i in mandatoryIndexesNcr:
								mandatoryVerification_NCR = False
								wid.setProperty("error", True)
								wid.setStyleSheet(self.comboBoxQSS)

						else:
							ncrFormData.append(wid.currentText())
							wid.setProperty("error", False)
							wid.setStyleSheet(self.comboBoxQSS)
					else:
						ncrFormData.append(None)


				elif isinstance(wid, QLineEdit):
					if wid.text() == '':
						ncrFormData.append(None)
						if i in mandatoryIndexesNcr:
							mandatoryVerification_NCR = False
							wid.setProperty("error", True)
							wid.setStyleSheet(self.lineEditBoxQSS)
					else:
						if wid.text().isdigit():
							ncrFormData.append(int(wid.text().strip()))
						else:
							ncrFormData.append(wid.text().strip()) 	

						wid.setProperty("error", False)
						wid.setStyleSheet(self.lineEditBoxQSS)
	

				elif isinstance(wid, QTextEdit):
					if wid.isEnabled():
						text_value = wid.toPlainText().strip()
						if text_value == '':
							ncrFormData.append(None)
							if i in mandatoryIndexesNcr:
								mandatoryVerification_NCR = False
								wid.setProperty("error", True)
								wid.setStyleSheet(self.textEditBoxQSS)

						else:
							ncrFormData.append(text_value)
							wid.setProperty("error", False)
							wid.setStyleSheet(self.textEditBoxQSS)

					else:
						ncrFormData.append(None)

				elif isinstance(wid, QDateEdit):
					if i in mandatoryIndexesNcr:
						if wid.lineEdit().text() == ' ':
							mandatoryVerification_NCR = False
							wid.setProperty("error", True)
							wid.setStyleSheet(self.dateEditBoxQSS)
							ncrFormData.append(None)
						else:
							qdate = wid.date()
							py_date = date(qdate.year(), qdate.month(), qdate.day())  # Convert QDate to Python date
							ncrFormData.append(py_date)
							wid.setProperty("error", False)
							wid.setStyleSheet(self.dateEditBoxQSS)
					else:
						if wid.lineEdit().text() == ' ':
							ncrFormData.append(None)
						else:
							qdate = wid.date()
							py_date = date(qdate.year(), qdate.month(), qdate.day())  # Convert QDate to Python date
							ncrFormData.append(py_date)



		dest_folder = "C:\\ProgramData\\RAMSify\\Attachments"
		
		selected_files1 = [self.attachedDocuments1_NCR.fileListWidget.item(i).text() for i in range(self.attachedDocuments1_NCR.fileListWidget.count())]
		selected_files2 = [self.attacheddocuments2_NCR.fileListWidget.item(i).text() for i in range(self.attacheddocuments2_NCR.fileListWidget.count())]
		selected_files3	= [self.attacheddocuments3_NCR.fileListWidget.item(i).text() for i in range(self.attacheddocuments3_NCR.fileListWidget.count())]		
		selected_files4	= [self.attacheddocuments4_NCR.fileListWidget.item(i).text() for i in range(self.attacheddocuments4_NCR.fileListWidget.count())]		

		listOfAttachmentsNames1 = []
		vall = 0
		for file_path in selected_files1:
			if os.path.exists(file_path):
				file_name = os.path.basename(file_path)
				file_extension = os.path.splitext(file_name)[1]
				current_datetime = datetime.now().strftime("%Y%m%d%H%M%S")
				
				fVal = str(vall)
				if len(fVal) == 1:
					fVal = '00'+fVal
				elif len(fVal) == 2:
					fVal = '0'+fVal

				vall += 1

				new_file_name = f"{os.path.splitext(file_name)[0]}_{current_datetime}{fVal}{file_extension}"
				listOfAttachmentsNames1.append(new_file_name)

				dest_path = os.path.join(dest_folder, new_file_name)
				shutil.copy(file_path, dest_path)
			else:
				QMessageBox.warning(self, "Warning", f"File {file_path} does not exist.", QMessageBox.Ok)
			
		listOfAttachmentsNames2 = []
		for file_path in selected_files2:
			if os.path.exists(file_path):
				file_name = os.path.basename(file_path)
				file_extension = os.path.splitext(file_name)[1]
				current_datetime = datetime.now().strftime("%Y%m%d%H%M%S")
				
				fVal = str(vall)
				if len(fVal) == 1:
					fVal = '00'+ fVal
				elif len(fVal) == 2:
					fVal = '0'+ fVal

				vall += 1

				new_file_name = f"{os.path.splitext(file_name)[0]}_{current_datetime}{fVal}{file_extension}"
				listOfAttachmentsNames2.append(new_file_name)

				dest_path = os.path.join(dest_folder, new_file_name)
				shutil.copy(file_path, dest_path)
			else:
				QMessageBox.warning(self, "Warning", f"File {file_path} does not exist.", QMessageBox.Ok)
		

		listOfAttachmentsNames3 = []
		for file_path in selected_files3:
			if os.path.exists(file_path):
				file_name = os.path.basename(file_path)
				file_extension = os.path.splitext(file_name)[1]
				current_datetime = datetime.now().strftime("%Y%m%d%H%M%S")
				
				fVal = str(vall)
				if len(fVal) == 1:
					fVal = '00'+ fVal
				elif len(fVal) == 2:
					fVal = '0'+ fVal
				

				new_file_name = f"{os.path.splitext(file_name)[0]}_{current_datetime}{fVal}{file_extension}"
				listOfAttachmentsNames3.append(new_file_name)

				dest_path = os.path.join(dest_folder, new_file_name)
				shutil.copy(file_path, dest_path)
			else:
				QMessageBox.warning(self, "Warning", f"File {file_path} does not exist.", QMessageBox.Ok)
		

		listOfAttachmentsNamesSigned = []
		for file_path in selected_files4:
			if os.path.exists(file_path):
				file_name = os.path.basename(file_path)
				file_extension = os.path.splitext(file_name)[1]
				current_datetime = datetime.now().strftime("%Y%m%d%H%M%S")
				
				fVal = str(vall)
				if len(fVal) == 1:
					fVal = '00'+fVal
				elif len(fVal) == 2:
					fVal = '0'+fVal
				vall += 1

				new_file_name = f"{os.path.splitext(file_name)[0]}_{current_datetime}{fVal}{file_extension}"
				listOfAttachmentsNamesSigned.append(new_file_name)

				dest_path = os.path.join(dest_folder, new_file_name)
				shutil.copy(file_path, dest_path)
			else:
				QMessageBox.warning(self, "Warning", f"File {file_path} does not exist.", QMessageBox.Ok)
			

		if listOfAttachmentsNames1:
			ncrFormData.insert(22, str(listOfAttachmentsNames1))
		else:
			ncrFormData.insert(22, None) 
		
		if listOfAttachmentsNames2:
			ncrFormData.insert(29, str(listOfAttachmentsNames2))
		else:
			ncrFormData.insert(29, None)

		if listOfAttachmentsNames3:
			ncrFormData.insert(32, str(listOfAttachmentsNames3))
		else:
			ncrFormData.insert(32, None)

		if listOfAttachmentsNamesSigned:
			ncrFormData.append(str(listOfAttachmentsNamesSigned))
		else:
			ncrFormData.append(None)
		
		ncrFormData.append(self.user_id)

		if not mandatoryVerification_NCR:
			print('Mandatory fields missing.')

		else:
			query = """
				INSERT INTO ncr
				(report_no, project, product, quantity, supplier, detection, place, stored_at, severity, distribution_to, trainset, car, 
				assy_dwg_no, rev, part_no, assy_serial_no, part_serial_no, bl_no, invoice_no, responsible_party, material_status, 
				description_of_nonconform, attachments_one, attachments_one_date, attachments_one_team, attachments_one_issued_by, 
				attachments_one_reviewed_by, attachments_one_approved_by, cause_of_nonconformity, attached_documents_two, 
				correction_corrective_action_result, action_plan, attachments_three, attachments_three_date, attachments_three_action_by,
				attachments_three_issued_by, attachments_three_reviewed_by, attachments_three_approved_by, decision, repair_procedure,
				correction_name, correction_date, correction_sign, correctiveaction_name, correctiveaction_date, correctiveaction_sign,
				approval_scope, approvedby_entity, approvedby_position, approvedby_name, approvedby_date, approvedby_sign, signed_ncr, user_id
				) 
				VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s,
						%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
			""" 


			try:
				self.cursor.execute(query, tuple(ncrFormData))
				self.mydb.commit()
				self.refreshButton_ncr.click()
				
				ncrSubmitMsgBox = QMessageBox()
				ncrSubmitMsgBox.setIcon(QMessageBox.Information) 
				ncrSubmitMsgBox.setText(f'Data Submitted successfully.')
				ncrSubmitMsgBox.setWindowTitle("Message")
				ncrSubmitMsgBox.setWindowIcon(QIcon('Media/ramsify.png'))
				ncrSubmitMsgBox.setStandardButtons(QMessageBox.Ok)
				ncrSubmitMsgBox.exec_()

				self.cancel_NCR.click()
				parts = self.current_ncr.text().split('-')
				cur_number = int(parts[-1].strip())
				newnumber = cur_number + 1
				formatted_report_no = f"- {newnumber}"
				self.current_ncr.setText(formatted_report_no)


			except Exception as e:
				QMessageBox.critical(self, "Database Error", f"An error occurred: {e}")
			
	self.submit_NCR.clicked.connect(onClickingsubmit_Ncr)



	def onClickingcancel_Ncr():
		for i, wid in enumerate(self.allFields):
			if isinstance(wid, QLineEdit):
				wid.clear()
				wid.setProperty("error", False)
				wid.setStyleSheet(self.lineEditBoxQSS)

			elif isinstance(wid, checkableComboBox):
				wid.clearItems()
				wid.setProperty("error", False)
				wid.setStyleSheet(self.comboBoxQSS)

			elif isinstance(wid, QComboBox):
				wid.setCurrentIndex(-1)
				wid.setProperty("error", False)
				wid.setStyleSheet(self.comboBoxQSS)

			elif isinstance(wid, QTextEdit):
				wid.clear()
				wid.setProperty("error", False)
				wid.setStyleSheet(self.textEditBoxQSS)


			elif isinstance(wid, QDateEdit):
				wid.setDate(QDate())
				wid.lineEdit().setText(' ')
				wid.setProperty("error", False)
				wid.setStyleSheet(self.dateEditBoxQSS)

			elif isinstance(wid, FileAttachmentWidget):
				wid.fileListWidget.clear()
				wid.fileListWidget.setVisible(False)
				wid.removeButton.setEnabled(False)
	
	self.cancel_NCR.clicked.connect(onClickingcancel_Ncr)