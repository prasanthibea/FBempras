import sys
from PySide6.QtWidgets import *
from PySide6.QtGui import QPixmap
from PySide6.QtCore import QTimer

from QSSS import *

from datetime import datetime, timedelta
from main import *
import wmi
import hashlib

# from qtwidgets import PasswordEdit
from configuration import *
from functools import wraps
import logging

logging.basicConfig(filename='C:/ProgramData/RAMSify/app_log.txt', level=logging.ERROR, format='%(asctime)s - %(levelname)s - %(filename)s:%(lineno)d - %(message)s')

def logErrors(func):
	@wraps(func)
	def wrapper(*args, **kwargs):
		# return func(*args, **kwargs)
		try:
			return func(*args, **kwargs)
		except Exception as e:
			logging.error(f"An error occurred in {func.__name__}: {str(e)}", exc_info=sys.exc_info())
			# Display an error message to the user (optional)
			# QMessageBox.critical(None, "Error", f"An error occurred: {str(e)}", QMessageBox.Ok)
			errorMsgBox = QMessageBox()
			errorMsgBox.setIcon(QMessageBox.Critical) 
			errorMsgBox.setText(f"An error occurred: {str(e)}")
			errorMsgBox.setWindowTitle("Error")
			errorMsgBox.setWindowIcon(QIcon('Media/ramsify.png'))
			errorMsgBox.setStandardButtons(QMessageBox.Ok)
			errorMsgBox.exec_()
	return wrapper

class LoginForm(QWidget):

	from functions import readIniFile, connectDB, logout, create_folder_if_not_exists
	from tables import createTables
	from functions import dbBackup
	
	@logErrors
	def __init__(self):
		super().__init__()
		self.licenseCreatorAndChecker()
		if self.licenseCreatorAndChecker() == 1:
			#self.settings = QSettings("RAMSify", "BeAnalytic")
			#self.settings.setValue("licenseKey", '')
			self.readIniFile()
			
			self.initUI()
		else:
			self.createLicenseWindow = QWidget()
			self.createLicenseWindow.setWindowTitle('Enter LicenseKey')
			self.createLicenseWindow.setWindowIcon(QIcon('Media/ramsify.png'))

			layoutForCreateLicenseWindow = QVBoxLayout()
			internerLabel = QLabel('This requires internet connection')
			enterKeyFormLayout = QFormLayout()
			liceseKeyLineEdit = QLineEdit()
			enterKeyFormLayout.addRow(QLabel('Enter LicenseKey:'),liceseKeyLineEdit)

			@logErrors
			def onClickingOKButtonInCreateLicenseWindow():
				if len(liceseKeyLineEdit.text()) == 64:
					import requests
					import wmi
					import uuid

					url = 'https://beanalytic.com/fracas-api/wp-json/beanalytic/v1/api_key'
					data = {}

					mac_address = '-'.join(['{:02x}'.format((uuid.getnode() >> ele) & 0xFF) for ele in range(0, 8 * 6, 8)][::-1])
					mac_address = mac_address.replace(':', '-')
					data['mac_id'] = mac_address.lower()

					w = wmi.WMI()
					cpu_serial = w.Win32_Processor()[0].ProcessorId.strip()
					data['cpu_id'] = cpu_serial.lower()

					data['api_key'] = liceseKeyLineEdit.text()
					response = requests.post(url, json=data)

					if response.status_code == 200:
						result = response.json()
						if (result['data']['key_valid']) and ((result['data']['expiry_date']) or (result['data']['expiry_date'] == None)):

							self.settings = QSettings("RAMSify", "BeAnalytic")

							self.settings.setValue("licenseKey", liceseKeyLineEdit.text())

							self.successWindow = QWidget()
							self.successWindow.setWindowTitle('License Created')
							successLayout = QVBoxLayout()
							successLabel = QLabel('Your License is successfully created.')
							successLayout.addWidget(successLabel)

							@logErrors
							def okButtonClicled():
								self.successWindow.close()
								self.initUI()

							okButton = QPushButton('ok')
							okButton.clicked.connect(okButtonClicled)
							successLayout.addWidget(okButton)
							self.successWindow.setLayout(successLayout)

							self.createLicenseWindow.close()
							self.successWindow.show()

						else:

							if layoutForCreateLicenseWindow.count() == 3:
								invalidKey = QLabel()
								invalidKey.setOpenExternalLinks(True)
								if not result['data']['key_valid']:
									invalidKey.setText('Your Key is inalid or your PC is unauthorized. Please visit <a href="https://www.beanalytic.com/contact-us/">www.beanalytic.com/contact-us</a>.')
								elif not result['data']['date_codition']:
									invalidKey.setText('Your Key is Expired. Please visit <a href="https://www.beanalytic.com/contact-us/">www.beanalytic.com/contact-us</a>.')

								invalidKey.setStyleSheet("color: red;")
								layoutForCreateLicenseWindow.insertWidget(2, invalidKey)
							elif layoutForCreateLicenseWindow.count() == 4:
								widget_to_remove = layoutForCreateLicenseWindow.itemAt(2).widget()
								layoutForCreateLicenseWindow.takeAt(2)
								widget_to_remove.deleteLater()
								invalidKey = QLabel()
								invalidKey.setOpenExternalLinks(True)
								invalidKey.setText('Your Key is inalid or your PC is unauthorized. Please visit <a href="www.beanalytic.com/contact-us/">www.beanalytic.com/contact-us</a>.')
								invalidKey.setStyleSheet("color: red;")
								layoutForCreateLicenseWindow.insertWidget(2, invalidKey)

					else:
						invalidResopMsgBox = QMessageBox()
						invalidResopMsgBox.setIcon(QMessageBox.Information) 
						invalidResopMsgBox.setText('Invalid Response')
						invalidResopMsgBox.setWindowTitle("Message")
						invalidResopMsgBox.setWindowIcon(QIcon('Media/ramsify.png'))
						invalidResopMsgBox.setStandardButtons(QMessageBox.Ok)
						invalidResopMsgBox.exec_()
				else:
					if layoutForCreateLicenseWindow.count() == 3:
						invalidKey = QLabel()
						invalidKey.setOpenExternalLinks(True)
						invalidKey.setText('Your Key is inalid. Please visit <a href="www.beanalytic.com/contact-us/">www.beanalytic.com/contact-us</a>.')
						invalidKey.setStyleSheet("color: red;")
						layoutForCreateLicenseWindow.insertWidget(2, invalidKey)
					elif layoutForCreateLicenseWindow.count() == 4:
						widget_to_remove = layoutForCreateLicenseWindow.itemAt(2).widget()
						layoutForCreateLicenseWindow.takeAt(2)
						widget_to_remove.deleteLater()
						invalidKey = QLabel()
						invalidKey.setOpenExternalLinks(True)
						invalidKey.setText('Your Key is inalid. Please visit <a href="www.beanalytic.com/contact-us/">www.beanalytic.com/contact-us</a>.')
						invalidKey.setStyleSheet("color: red;")
						layoutForCreateLicenseWindow.insertWidget(2, invalidKey)

			@logErrors
			def onClickingCancelButtonInCreateLicenseWindow():
				self.createLicenseWindow.close()

			okButtonCreateLicenseWindow = QPushButton('OK')
			cancelButtonCreateLicenseWindow = QPushButton('Cancel')

			okButtonCreateLicenseWindow.clicked.connect(onClickingOKButtonInCreateLicenseWindow)
			cancelButtonCreateLicenseWindow.clicked.connect(onClickingCancelButtonInCreateLicenseWindow)

			layoutForOKAndCancelBtns_createLicense = QHBoxLayout()
			layoutForOKAndCancelBtns_createLicense.addWidget(okButtonCreateLicenseWindow)
			layoutForOKAndCancelBtns_createLicense.addWidget(cancelButtonCreateLicenseWindow)

			layoutForCreateLicenseWindow.addWidget(internerLabel, alignment = Qt.AlignCenter)
			layoutForCreateLicenseWindow.addLayout(enterKeyFormLayout)
			layoutForCreateLicenseWindow.addLayout(layoutForOKAndCancelBtns_createLicense)


			self.createLicenseWindow.setLayout(layoutForCreateLicenseWindow)
			self.createLicenseWindow.resize(400,120)
			self.createLicenseWindow.show()


	@logErrors
	def licenseCreatorAndChecker(self):
		self.settings = QSettings("RAMSify", "BeAnalytic")
		key = self.settings.value('licenseKey')
		if key != None and len(key) == 64:
			return 1
		else:
			return 0
			

	@logErrors
	def initUI(self):
		self.connectDB()
		self.createTables()
		self.dbBackup()
		self.loginWindow = QWidget()
		self.loginWindow.setWindowTitle('Login')
		self.loginWindow.setWindowIcon(QIcon('Media/ramsify.png'))


		font_id = QFontDatabase.addApplicationFont("Roboto-Regular.ttf")
		font_family = QFontDatabase.applicationFontFamilies(font_id)[0]
		custom_font = QFont(font_family)
		QApplication.setFont(custom_font)



		self.loginWindow.setStyleSheet('background-color: #FFFFFF')

		self.lineEditBoxQSS = f'''QLineEdit
						{{
							background-color: #F3EFF8;
							selection-background-color: #AECBFA;
							selection-color: black;
							border: none;
							border-radius: 4px;
							color: black;
							font-size: 15px;
						}}
						
					QLineEdit:hover
						{{
							border-bottom: 1px solid #43444F;
							border-bottom-left-radius: 0px;
							border-bottom-right-radius: 0px;
						}}
					QLineEdit:focus
						{{
						border-bottom: 2px solid #43444F;
						border-bottom-left-radius: 0px;
						border-bottom-right-radius: 0px;
						}}'''

		self.pushbuttonQSS =  f'''
				QPushButton {{
					outline: none;
					font-size: 20px;
					line-height: 20px;
					border-radius: 8px;
					border: none;
					text-align: center;
					padding: 14px 24px;
					background: #9147ff;
					color: #fff;
				}}
				QPushButton:hover {{
					background: #8A3CFE;
				}}
				QPushButton:pressed {{
					background: #6919DF;
				}}
			'''


		self.emailLabel = QLabel('Email')
		font = self.emailLabel.font()
		font.setPointSize(12)
		self.emailLabel.setFont(font)

		self.emailLineEdit = QLineEdit()
		# self.emailLineEdit.setText('admin@gmail.com')
		self.emailLineEdit.setFixedHeight(30)
		self.emailLineEdit.setStyleSheet(self.lineEditBoxQSS)

		self.passwordLabel = QLabel('Password')
		font = self.emailLabel.font()
		font.setPointSize(12)
		self.passwordLabel.setFont(font)
		#self.passwordEdit = QLineEdit()
		self.passwordEdit = QLineEdit()
		self.passwordEdit.setEchoMode(QLineEdit.Password)
		# self.passwordEdit.setText('123')
		self.passwordEdit.setFixedHeight(30)
		self.passwordEdit.setStyleSheet(self.lineEditBoxQSS)

		self.passwordEdit.setEchoMode(QLineEdit.Password)

		self.loginButton = QPushButton('Login')
		self.loginButton.setFixedWidth(100)
		self.loginButton.setFixedHeight(50)
		self.loginButton.setStyleSheet(self.pushbuttonQSS)
		self.passwordEdit.returnPressed.connect(self.loginButton.click)
		
		# Create the radio buttons
		self.oneYearRadioBtn = QRadioButton("Calculate last 1 year data")
		self.twoYearsRadioBtn = QRadioButton("Calculate last 2 years data")
		self.completeDataRadioBtn = QRadioButton("Calculate complete data")

		# Add them to a button group for exclusive selection
		self.radioGroupForDataSize = QButtonGroup(self)
		self.radioGroupForDataSize.addButton(self.oneYearRadioBtn, 0)
		self.radioGroupForDataSize.addButton(self.twoYearsRadioBtn, 1)
		self.radioGroupForDataSize.addButton(self.completeDataRadioBtn, 2)

		self.oneYearRadioBtn.setChecked(True)

		loginLayout = QVBoxLayout()

		
		#########################################################################
		### To place company logo in the login page:
		self.companyLogo = QLabel()
		companyLogoPixmap = QPixmap('Media/ramsify2.png')
		self.companyLogo.setPixmap(companyLogoPixmap)
		loginLayout.addWidget(self.companyLogo, alignment = Qt.AlignCenter)

		#########################################################################
		loginLayout.addWidget(self.emailLabel)
		loginLayout.addWidget(self.emailLineEdit)
		loginLayout.addItem(QSpacerItem(0, 10, QSizePolicy.Expanding, QSizePolicy.Maximum))
		loginLayout.addWidget(self.passwordLabel)
		loginLayout.addWidget(self.passwordEdit)
		loginLayout.addItem(QSpacerItem(0, 5, QSizePolicy.Expanding, QSizePolicy.Expanding))

		self.invalidEmailLabel = QLabel('Invalid email or password')
		self.invalidEmailLabel.setStyleSheet("color: red;")
		loginLayout.addWidget(self.invalidEmailLabel)
		self.invalidEmailLabel.setVisible(False)
		
		# Add the radio buttons to the layout
		loginLayout.addWidget(self.oneYearRadioBtn)
		loginLayout.addWidget(self.twoYearsRadioBtn)
		loginLayout.addWidget(self.completeDataRadioBtn)


		loginLayout.addWidget(self.loginButton, alignment = Qt.AlignCenter)
		loginLayout.setSpacing(1)
		self.loginWindow.setLayout(loginLayout)

		self.loginWindow.setFixedSize(350, 320)

		self.cursor.execute("""
			CREATE TABLE IF NOT EXISTS users (
				id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
				username VARCHAR(255) NOT NULL,
				email VARCHAR(255) UNIQUE NOT NULL,
				password VARCHAR(255) NOT NULL,
				admin_password BOOLEAN NOT NULL,
				role INT UNSIGNED NOT NULL,
				status INT UNSIGNED NOT NULL,
				created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
				updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
				deleted_at TIMESTAMP NULL
					)
				""")





		self.cursor.execute("SELECT COUNT(*) FROM users")
		result = self.cursor.fetchone()
		if result[0] == 0:
			query = "INSERT INTO users (username, email, password, admin_password, role, status) VALUES (%s, %s, %s, %s, %s, %s)"
			Values = ('admin', 'admin@gmail.com', '688787d8ff144c502c7f5cffaafe2cc588d86079f9de88304c26b0cb99ce91c6', False, 1, 1)
			self.cursor.execute(query,Values)

			query = "INSERT INTO users (username, email, password, admin_password, role, status) VALUES (%s, %s, %s, %s, %s, %s)"
			Values = ('swadmin', 'sw-admin@gmail.com', '688787d8ff144c502c7f5cffaafe2cc588d86079f9de88304c26b0cb99ce91c6', False, 0, 1)
			self.cursor.execute(query,Values)


			self.mydb.commit()


		@logErrors
		def showApp():
			@logErrors
			def enterLog(userName, user_id, role, logType):
				sql = "INSERT INTO loginlog (username, user_id, role, log_type) VALUES (%s, %s, %s, %s)"
				val = (userName, user_id, role, logType)
				
				self.cursor.execute(sql,val)
				self.mydb.commit()
				self.cursor.close()


			
			# self.cursor.execute('''CREATE TABLE IF NOT EXISTS users (
			# 	id INT AUTO_INCREMENT PRIMARY KEY,
			# 	username VARCHAR(255) NOT NULL,
			# 	email VARCHAR(500) NOT NULL UNIQUE,
			# 	password VARCHAR(255) NOT NULL,
			# 	created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
			# 	updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
			# 	role VARCHAR(255) NOT NULL
			# 	)''')

			



			enteredEmail = self.emailLineEdit.text()
			enteredPassword = self.passwordEdit.text()
			selectedSizeIndex = self.radioGroupForDataSize.checkedId()

			self.cursor.execute('SELECT id,password,username,role, status, admin_password, id FROM users where email = "{}"'.format(enteredEmail))
			results = self.cursor.fetchone()
			if results != None:
				password_ = enteredPassword
				hash_object = hashlib.sha256()
				hash_object.update(password_.encode('utf-8'))
				hashed_text = hash_object.hexdigest()
				if hashed_text == results[1]:
					if results[4]:
						if results[5] == 0:
							self.loginWindow.close()
							enterLog(results[2], results[0], results[3], 'login')
							try:
								ex = MainWindow
								ex.userName = results[2]
								ex.userRole = results[3]
								ex.email = results[0]
								ex.user_id = results[6]

								self.settings = QSettings("RAMSify", "BeAnalytic")
								self.settings.setValue("selectedSizeIndex", selectedSizeIndex)

								# pixmap = QPixmap("Media/Splashscreen11.png")
								# ex.splashScreen = QSplashScreen(pixmap)
								# ex.splashScreen.show()

								ex()
								# ex.userNameButton.setText(ex.userName)
								# ex.hideOrUnhideFunction()
								# ex.show()
							except Exception as e:
								msg = QMessageBox()
								msg.setIcon(QMessageBox.Information)
								msg.setText(str(e))
								msg.setWindowTitle("Message")
								msg.setWindowIcon(QIcon('Media/ramsify.png'))
								msg.exec_()
							
						else:
							self.loginWindow.close()

							self.passwordEdit.clear()
							self.emailLineEdit.clear()


							createNewPasswordWindow = QWidget()
							createNewPasswordWindow.setStyleSheet('background-color: #FFFFFF')
							createNewPasswordWindow.setWindowIcon(QIcon('Media/ramsify.png'))
							createNewPasswordWindow.setWindowTitle("Set New Password")
							
							layoutForCreateNewPasswordWindow = QVBoxLayout()

							formLayout1 = QFormLayout()
							label1 = QLabel('New Password: ')
							# label1.setFont(self.labelsAndPushBtnsFont)
							#linedit1 = QLineEdit()
							# linedit1 = PasswordEdit()
							linedit1 = QLineEdit()
							linedit1.setEchoMode(QLineEdit.Password)
							linedit1.setFixedHeight(30)
							linedit1.setStyleSheet(self.lineEditBoxQSS)
							linedit1.setEchoMode(QLineEdit.Password)
							#linedit1.setFont(self.labelsAndPushBtnsFont)
							formLayout1.addRow(label1, linedit1)

							formLayout2 = QFormLayout()
							label2 = QLabel('Repeat Password: ')
							# label2.setFont(self.labelsAndPushBtnsFont)
							#linedit2 = QLineEdit()
							# linedit2 = PasswordEdit()
							linedit2 = QLineEdit()
							linedit2.setEchoMode(QLineEdit.Password)
							linedit2.setFixedHeight(30)
							linedit2.setStyleSheet(self.lineEditBoxQSS)
							linedit2.setEchoMode(QLineEdit.Password)
							#linedit2.setFont(self.labelsAndPushBtnsFont)
							formLayout2.addRow(label2, linedit2)

							layoutForCreateNewPasswordWindow.addLayout(formLayout1)
							layoutForCreateNewPasswordWindow.addLayout(formLayout2)

							saveButtonInResetPassword = QPushButton('Save')
							saveButtonInResetPassword.setStyleSheet(self.pushbuttonQSS)
							saveButtonInResetPassword.setFixedWidth(100)
							saveButtonInResetPassword.setFixedHeight(50)
							layoutForCreateNewPasswordWindow.addWidget(saveButtonInResetPassword , alignment = Qt.AlignCenter)
							layoutForCreateNewPasswordWindow.setSpacing(1)
							createNewPasswordWindow.setLayout(layoutForCreateNewPasswordWindow)

							@logErrors
							def onClickingSaveButtonInResetPassword():
								if linedit1.text() == linedit2.text():
									
									newPassword = linedit1.text()
									hash_object = hashlib.sha256()
									hash_object.update(newPassword.encode('utf-8'))
									hashed_password = hash_object.hexdigest()

									sql = "UPDATE users SET admin_password = 0, password = %s WHERE email = %s"
									values = (hashed_password,enteredEmail)

									
									self.cursor.execute(sql, values)
									self.mydb.commit()

									createNewPasswordWindow.close()
									self.loginWindow.show()




							saveButtonInResetPassword.clicked.connect(onClickingSaveButtonInResetPassword)

							createNewPasswordWindow.show()


					else:
						self.lableWindow = QLabel('Your account is disabled. Please contact the admin to enable')
						self.lableWindow.show()

				else:
					self.invalidEmailLabel.setVisible(True)
			else:
				self.invalidEmailLabel.setVisible(True)


		self.cursor.execute("SELECT * FROM logInLog ORDER BY sno DESC LIMIT 1")
		last_row = self.cursor.fetchone()
		if last_row:
			if last_row[-1] == 'login':
				logTime = last_row[3]
				time_diff = datetime.now().replace(microsecond=0) - logTime
				if time_diff < timedelta(minutes = int(self.config.get('loginTime', 'loginTime'))):
					if self.sender() == None:
						try:
							ex = MainWindow
							ex.userName = last_row[1]
							ex.userRole = last_row[4]
							ex.user_id = last_row[2]
							
							# pixmap = QPixmap("Media/Splashscreen11.png")
							# ex.splashScreen = QSplashScreen(pixmap)
							# ex.splashScreen.show()
								
							ex()
							# ex.userNameButton.setText(ex.userName)
							# ex.hideOrUnhideFunction(ex)
							# ex.show()
						except Exception as e:
							logging.error(f"An error occurred: {str(e)} \n \n  \n \n", exc_info=sys.exc_info())
							msg = QMessageBox()
							msg.setIcon(QMessageBox.Information)
							msg.setText(str(e))
							msg.setWindowTitle("Message")
							msg.setWindowIcon(QIcon('Media/ramsify.png'))
							msg.exec_()
						
					else:
						self.loginWindow.show()

				else:
					self.loginWindow.show()
			else:
				self.loginWindow.show()
		else:
			self.loginWindow.show()

		
		
		self.loginButton.clicked.connect(showApp)
		