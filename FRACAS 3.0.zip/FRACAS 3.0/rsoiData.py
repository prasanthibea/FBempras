from PySide6.QtWidgets import QTableWidgetItem, QSpacerItem, QDateEdit, QSizePolicy, QComboBox, QFileDialog, QCheckBox, QMessageBox, QPushButton, QAbstractItemView, QLineEdit, QTextEdit, QWidget, QLabel, QHBoxLayout, QVBoxLayout, QFormLayout, QHeaderView
from functions import TableWidget
from PySide6.QtCore import Qt, QDate, QTime, QDateTime
from PySide6.QtGui import QIcon
from openpyxl import Workbook
from datetime import date, datetime

def rsoiDataUI(self, layout):
	from PySide6.QtWidgets import QApplication, QLabel

	checkAllUserIconPath = self.currentTheme.get('oppositeColorCheckBoxIcon')
	unCheckAllUserIconPath = self.currentTheme.get('oppositeColorUnCheckBoxIcon')
	partiallyCheckedIconPath = self.currentTheme.get('oppositeColorPartiallyCheckedBoxIcon')
	deleteIconPath = self.currentTheme.get('whiteDeleteIcon')	
	downloadIconPath = self.currentTheme.get('downloadIcon')
	refreshTableIconPath = self.currentTheme.get('refreshIcon')

	self.createPushButton('selectAllRsoiButton', '', unCheckAllUserIconPath, 30)
	self.createPushButton('deleteButton_Rsoi', '', deleteIconPath, 35, 'Delete')
	self.createLineEditBox('serachBarOfRsoiTable', 'Search..' )
	self.serachBarOfRsoiTable.setClearButtonEnabled(True)
	self.serachBarOfRsoiTable.setFixedWidth(self.geometryWidth(0.2))
	self.createPushButton('download_Rsoi', '', downloadIconPath, 35, 'Download')
	self.createPushButton('newRsoi_RefNo', '+ New Ref No', '', self.geometryWidth(0.059))
	self.createPushButton('refreshButton_Rsoi', '', refreshTableIconPath, 35, 'Refresh')
		
	self.rsoiHboxLayout = QHBoxLayout()
	self.rsoiHboxLayout.addWidget(self.selectAllRsoiButton)
	self.rsoiHboxLayout.addWidget(self.deleteButton_Rsoi)
	self.rsoiHboxLayout.addWidget(self.serachBarOfRsoiTable)
	self.rsoiHboxLayout.addWidget(self.download_Rsoi)
	self.rsoiHboxLayout.addWidget(self.refreshButton_Rsoi)
	self.rsoiHboxLayout.addItem(QSpacerItem(1, 0, QSizePolicy.Expanding, QSizePolicy.Minimum))
	self.rsoiHboxLayout.addWidget(self.newRsoi_RefNo)
	layout.addLayout(self.rsoiHboxLayout)


	self.dataTable_RSOI = TableWidget()
	self.headersOfRSOITable  = ['', 'Ref No', 'RSOI No', 'Applicability', 'Issued On', 'System', 'Subject', 'Status', 'PDC' ]
	self.dataTable_RSOI.setColumnCount(len(self.headersOfRSOITable))
	self.dataTable_RSOI.setHorizontalHeaderLabels(self.headersOfRSOITable)
	self.dataTable_RSOI.setStyleSheet(self.tableWidgetQSS)
	self.dataTable_RSOI.horizontalHeader().setStyleSheet(self.headerHorizontalQSS)
	self.dataTable_RSOI.setAlternatingRowColors(True)
	self.dataTable_RSOI.setShowGrid(False)
	self.dataTable_RSOI.setEditTriggers(QAbstractItemView.NoEditTriggers)
	layout.addWidget(self.dataTable_RSOI)

	self.selectAllRsoiButton.setCheckable(True)

	self.dataTable_RSOI.setColumnWidth(1, self.geometryWidth(0.1))
	self.dataTable_RSOI.setColumnWidth(2, self.geometryWidth(0.08))
	self.dataTable_RSOI.setColumnWidth(3, self.geometryWidth(0.14))
	self.dataTable_RSOI.setColumnWidth(4, self.geometryWidth(0.08))
	self.dataTable_RSOI.setColumnWidth(5, self.geometryWidth(0.11))
	self.dataTable_RSOI.setColumnWidth(6, self.geometryWidth(0.11))
	self.dataTable_RSOI.setColumnWidth(7, self.geometryWidth(0.08))
	self.dataTable_RSOI.setColumnWidth(8, self.geometryWidth(0.08))
	

	def OnClickingNewRefNoButton():
		self.rsoiWindow = QWidget()
		self.rsoiWindow.move(600, 200)
		self.rsoiWindow.resize(800, 400)
		self.rsoiWindow.setWindowTitle('New RSOI')
		self.rsoiWindow.setWindowIcon(QIcon('Media/ramsify.png'))

		vBoxLayout = QVBoxLayout()
		formLayout = QFormLayout()
		vBoxLayout.addLayout(formLayout)

		self.rsoiWindow.setLayout(vBoxLayout)

		self.createLineEditBox('refNoLineEdit_RSOI')
		self.createNumberLineEditBox('rsoiNumber_RSOI')
		self.createTextEditBox('applicability_RSOI')
		self.createEmptyDateEditBox('dateIssuedOn_RSOI')
		self.createComboBox2(self.BOMSystemDictionary.keys(), 'systemComboBox_RSOI')
		self.createTextEditBox('subject_RSOI')
		self.createTextEditBox('status_RSOI')
		self.createEmptyDateEditBox('datePdc_RSOI')


		formLayout.addRow('Ref No: <font color="red">*</font>', self.refNoLineEdit_RSOI)
		formLayout.addRow('RSOI No: <font color="red">*</font>', self.rsoiNumber_RSOI)
		formLayout.addRow('Applicability: ', self.applicability_RSOI)
		formLayout.addRow('Issued On: ', self.dateIssuedOn_RSOI)
		formLayout.addRow('System: <font color="red">*</font>', self.systemComboBox_RSOI)
		formLayout.addRow('Subject: <font color="red">*</font>', self.subject_RSOI)
		formLayout.addRow('Status: <font color="red">*</font>', self.status_RSOI)
		formLayout.addRow('PDC:', self.datePdc_RSOI)


		self.createPushButton('submit_RSOI', 'Submit', '', self.geometryWidth(0.04))
		self.createPushButton('cancelBtn_RSOI', 'Cancel', '', self.geometryWidth(0.04))
		# vBoxLayout.addWidget(self.submit_RSOI, alignment = Qt.AlignCenter)
		hBoxLayout = QHBoxLayout()
		hBoxLayout.addWidget(self.submit_RSOI, alignment = Qt.AlignRight)
		hBoxLayout.addWidget(self.cancelBtn_RSOI, alignment = Qt.AlignLeft)
		vBoxLayout.addLayout(hBoxLayout)


		
		self.allFielsData = [self.refNoLineEdit_RSOI, self.rsoiNumber_RSOI, self.applicability_RSOI, self.dateIssuedOn_RSOI, 
							self.systemComboBox_RSOI, self.subject_RSOI, self.status_RSOI, self.datePdc_RSOI]

		def onClickingSubmit_RSOI():
			mandatoryVerification_RSOI = True
			mandatoryIndexesRsoi = [0, 1, 4, 5, 6]
			rsoiFormData = []

			for i, wid in enumerate(self.allFielsData):
				if isinstance(wid, QLineEdit):
					if wid.text() == '':
						rsoiFormData.append(None)
						if i in mandatoryIndexesRsoi:
							mandatoryVerification_RSOI = False
							wid.setProperty("error", True)
							wid.setStyleSheet(self.lineEditBoxQSS)
					else:
						if wid.text().isdigit():
							rsoiFormData.append(int(wid.text().strip()))
						else:
							rsoiFormData.append(wid.text().strip()) 	

						wid.setProperty("error", False)
						wid.setStyleSheet(self.lineEditBoxQSS)

				if isinstance(wid, QTextEdit):
					if wid.toPlainText() == '':
						rsoiFormData.append(None)
						if i in mandatoryIndexesRsoi:
							mandatoryVerification_RSOI = False
							wid.setProperty("error", True)
							wid.setStyleSheet(self.textEditBoxQSS)		
					else:
						rsoiFormData.append(wid.toPlainText().strip())	
						wid.setProperty("error", False)
						wid.setStyleSheet(self.textEditBoxQSS)

				if isinstance(wid, QComboBox):
					if wid.isEnabled():
						if wid.currentText() == '':
							rsoiFormData.append(None)
							if i in mandatoryIndexesRsoi:
								mandatoryVerification_RSOI = False
								wid.setProperty("error", True)
								wid.setStyleSheet(self.comboBoxQSS)

						else:
							rsoiFormData.append(wid.currentText())
							wid.setProperty("error", False)
							wid.setStyleSheet(self.comboBoxQSS)

					else:
						rsoiFormData.append(None)

				elif isinstance(wid, QDateEdit):
					if i in mandatoryIndexesRsoi:
						if wid.lineEdit().text() == ' ':
							mandatoryVerification_RSOI = False
							wid.setProperty("error", True)
							wid.setStyleSheet(self.dateEditBoxQSS)
							rsoiFormData.append(None)
						else:
							qdate = wid.date()
							py_date = date(qdate.year(), qdate.month(), qdate.day())  # Convert QDate to Python date
							rsoiFormData.append(py_date)
							wid.setProperty("error", False)
							wid.setStyleSheet(self.dateEditBoxQSS)
					else:
						if wid.lineEdit().text() == ' ':
							rsoiFormData.append(None)
						else:
							qdate = wid.date()
							py_date = date(qdate.year(), qdate.month(), qdate.day())  # Convert QDate to Python date
							rsoiFormData.append(py_date)
	

			if not mandatoryVerification_RSOI:
				print('Mandatory fields missing.')

			else:
				
				rsoiFormData.append(self.user_id)
				query = """
							INSERT INTO rsoi				
							(ref_no, rsoi, applicability, issued_on, system_id, subject, status, pdc, user_id) 
							VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
						"""

				try:
					self.cursor.execute(query, tuple(rsoiFormData))
					self.mydb.commit()					
					self.refreshButton_Rsoi.click()

					rsoiSubmitMsgBox = QMessageBox()
					rsoiSubmitMsgBox.setIcon(QMessageBox.Information) 
					rsoiSubmitMsgBox.setText(f'Data Submitted successfully.')
					rsoiSubmitMsgBox.setWindowTitle("Message")
					rsoiSubmitMsgBox.setWindowIcon(QIcon('Media/ramsify.png'))
					rsoiSubmitMsgBox.setStandardButtons(QMessageBox.Ok)
					rsoiSubmitMsgBox.exec_()
					self.rsoiWindow.close()

				except Exception as e:
					QMessageBox.critical(self, "Database Error", f"An error occurred: {e}")		

		self.submit_RSOI.clicked.connect(onClickingSubmit_RSOI)

		self.rsoiWindow.show()

		def onClickingCancelButton_RSOI():
			self.refNoLineEdit_RSOI.clear()
			self.rsoiNumber_RSOI.clear()
			self.applicability_RSOI.clear()
			self.dateIssuedOn_RSOI.setDate(QDate())
			self.dateIssuedOn_RSOI.lineEdit().setText(' ')
			self.systemComboBox_RSOI.setCurrentIndex(-1)
			self.subject_RSOI.clear()
			self.status_RSOI.clear()
			self.datePdc_RSOI.setDate(QDate())
			self.datePdc_RSOI.lineEdit().setText(' ')

		self.cancelBtn_RSOI.clicked.connect(onClickingCancelButton_RSOI)

	self.newRsoi_RefNo.clicked.connect(OnClickingNewRefNoButton)

	def onClickingRefreshButton_rsoi():
		self.deleteButton_Rsoi.hide()
		self.selectAllRsoiButton.setIcon(QIcon(unCheckAllUserIconPath))	

		queryone = '''
						SELECT
							ref_no,
							rsoi,
							applicability,
							issued_on,
							system_id,
							subject,
							status,
							pdc,
							id
						FROM
							rsoi
						WHERE deleted_at IS NULL
						ORDER BY
							ref_no ASC
					'''
		self.cursor.execute(queryone)
		rsoiDataResult = self.cursor.fetchall()
		
		def givingFunctionalityToButton(button, func, data):
			button.clicked.connect(lambda: func(data))

		def onbuttonClickedRsoi(dataOfRsoi):
			from PySide6.QtWidgets import QApplication

			self.rsoiUpdateWindow = QWidget()
			self.rsoiUpdateWindow.move(400, 100)
			self.rsoiUpdateWindow.resize(700, 800)

			self.rsoiUpdateWindow.setWindowTitle(dataOfRsoi[0])
			self.rsoiUpdateWindow.setWindowIcon(QIcon('Media/ramsify.png'))

			vBoxLayout = QVBoxLayout()
			formLayout = QFormLayout()
			vBoxLayout.addLayout(formLayout)

			self.rsoiUpdateWindow.setLayout(vBoxLayout)

			self.createLineEditBox('refNoLineEdit_RSOI_')
			if dataOfRsoi[0]:
				self.refNoLineEdit_RSOI_.setText(dataOfRsoi[0])
				self.refNoLineEdit_RSOI_.setToolTip(dataOfRsoi[0])

			self.createNumberLineEditBox('rsoiNumber_RSOI_')
			if dataOfRsoi[1]:
				self.rsoiNumber_RSOI_.setText(str(dataOfRsoi[1]))
				self.rsoiNumber_RSOI_.setToolTip(str(dataOfRsoi[1]))

			self.createTextEditBox('applicability_RSOI_')
			if dataOfRsoi[2]:
				self.applicability_RSOI_.setText(str(dataOfRsoi[2]))
				self.applicability_RSOI_.setToolTip(str(dataOfRsoi[2]))

		
			self.createEmptyDateEditBox('dateIssuedOn_RSOI_')
			if dataOfRsoi[3]:
				self.dateIssuedOn_RSOI_.setDate(QDate(dataOfRsoi[3].year, dataOfRsoi[3].month, dataOfRsoi[3].day))
			else:
				self.dateIssuedOn_RSOI_.setDate(QDate())

			self.createComboBox2(self.BOMSystemDictionary.keys(), 'systemComboBox_RSOI_')
			if dataOfRsoi[4]:
				self.systemComboBox_RSOI_.setCurrentText(dataOfRsoi[4])

			self.createTextEditBox('subject_RSOI_')
			if dataOfRsoi[5]:
				self.subject_RSOI_.setText(dataOfRsoi[5])
				self.subject_RSOI_.setToolTip(dataOfRsoi[5])

			self.createTextEditBox('status_RSOI_')
			if dataOfRsoi[6]:
				self.status_RSOI_.setText(dataOfRsoi[6])
				self.status_RSOI_.setToolTip(dataOfRsoi[6])
		
			self.createEmptyDateEditBox('datePdc_RSOI_')
			if dataOfRsoi[7]:
				self.datePdc_RSOI_.setDate(QDate(dataOfRsoi[7].year, dataOfRsoi[7].month, dataOfRsoi[7].day))
			else:
				self.dateIssuedOn_RSOI_.setDate(QDate())

			formLayout.addRow('Ref No: <font color="red">*</font>', self.refNoLineEdit_RSOI_)
			formLayout.addRow('RSOI No: <font color="red">*</font>', self.rsoiNumber_RSOI_)
			formLayout.addRow('Applicability: ', self.applicability_RSOI_)
			formLayout.addRow('Issued On: ', self.dateIssuedOn_RSOI_)
			formLayout.addRow('System: <font color="red">*</font>', self.systemComboBox_RSOI_)
			formLayout.addRow('Subject: <font color="red">*</font>', self.subject_RSOI_)
			formLayout.addRow('Status: <font color="red">*</font>', self.status_RSOI_)
			formLayout.addRow('PDC:', self.datePdc_RSOI_)

			self.createPushButton('updateBtn_RSOI', 'Update', '', self.geometryWidth(0.04))

			vBoxLayout.addWidget(self.updateBtn_RSOI, alignment = Qt.AlignCenter)
			

			allFieldsDataRsoi_ = [self.refNoLineEdit_RSOI_, self.rsoiNumber_RSOI_, self.applicability_RSOI_, self.dateIssuedOn_RSOI_, 
								self.systemComboBox_RSOI_, self.subject_RSOI_, self.status_RSOI_, self.datePdc_RSOI_]


			def setToolTip(wid, text):
				wid.setToolTip(text)

			def settingToolTipToLineEdits(wid):
				wid.textChanged.connect(lambda: setToolTip(wid, wid.text()))

			def settingToolTipToTextEdits(wid):
				wid.textChanged.connect(lambda: setToolTip(wid, wid.toPlainText()))

			for wid in allFieldsDataRsoi_:
				if isinstance(wid, QLineEdit):
					settingToolTipToLineEdits(wid)

				if isinstance(wid, QTextEdit):
					settingToolTipToTextEdits(wid)


			def onClickingUpdateRsoi():
				mandatoryVerification_RSOI = True
				mandatoryIndexesRsoi = [0, 1, 4, 5, 6]
			
				rsoiUpdateFormData =[]
				for i, wid in enumerate(allFieldsDataRsoi_):
					if isinstance(wid, QLineEdit):
						if wid.text() == '':
							rsoiUpdateFormData.append(None)
							if i in mandatoryIndexesRsoi:
								mandatoryVerification_RSOI = False
								wid.setProperty("error", True)
								wid.setStyleSheet(self.lineEditBoxQSS)
						else:
							if wid.text().isdigit():
								rsoiUpdateFormData.append(int(wid.text().strip()))
							else:
								rsoiUpdateFormData.append(wid.text().strip()) 	

							wid.setProperty("error", False)
							wid.setStyleSheet(self.lineEditBoxQSS)

					if isinstance(wid, QTextEdit):
						if wid.toPlainText() == '':
							rsoiUpdateFormData.append(None)
							if i in mandatoryIndexesRsoi:
								mandatoryVerification_RSOI = False
								wid.setProperty("error", True)
								wid.setStyleSheet(self.textEditBoxQSS)		

						else:
							rsoiUpdateFormData.append(wid.toPlainText().strip())	
							wid.setProperty("error", False)
							wid.setStyleSheet(self.textEditBoxQSS)

					if isinstance(wid, QComboBox):
						if wid.isEnabled():
							if wid.currentText() == '':
								rsoiUpdateFormData.append(None)
								if i in mandatoryIndexesRsoi:
									mandatoryVerification_RSOI = False
									wid.setProperty("error", True)
									wid.setStyleSheet(self.comboBoxQSS)

							else:
								rsoiUpdateFormData.append(wid.currentText())
								wid.setProperty("error", False)
								wid.setStyleSheet(self.comboBoxQSS)
						else:
							rsoiUpdateFormData.append(None)

					elif isinstance(wid, QDateEdit):
						if i in mandatoryIndexesRsoi:
							if wid.lineEdit().text() == ' ':
								mandatoryVerification_RSOI = False
								wid.setProperty("error", True)
								wid.setStyleSheet(self.dateEditBoxQSS)
								rsoiUpdateFormData.append(None)
							else:
								qdate = wid.date()
								py_date = date(qdate.year(), qdate.month(), qdate.day())  # Convert QDate to Python date
								rsoiUpdateFormData.append(py_date)
								wid.setProperty("error", False)
								wid.setStyleSheet(self.dateEditBoxQSS)
						else:
							if wid.lineEdit().text() == ' ':
								rsoiUpdateFormData.append(None)
							else:
								qdate = wid.date()
								py_date = date(qdate.year(), qdate.month(), qdate.day())  # Convert QDate to Python date
								rsoiUpdateFormData.append(py_date)	

			
				if not mandatoryVerification_RSOI:
					pass

				else:
					rsoiUpdateFormData.append(self.user_id)						
					
					update_queryone = """
										UPDATE rsoi
										SET
											ref_no = %s,
											rsoi = %s,
											applicability = %s,
											issued_on = %s,
											system_id = %s,
											subject = %s,
											status = %s,
											pdc = %s,
											user_id = %s

										WHERE id = %s
									"""									
					idNum = dataOfRsoi[8]		
					rsoiUpdateFormData.append(idNum)

					try:
						self.cursor.execute(update_queryone, tuple(rsoiUpdateFormData))
						self.mydb.commit()
						self.refreshButton_Rsoi.click()

						rsoiUpdateMsgBox = QMessageBox()
						rsoiUpdateMsgBox.setIcon(QMessageBox.Information) 
						rsoiUpdateMsgBox.setText(f'Data Updated successfully.')
						rsoiUpdateMsgBox.setWindowTitle("Message")
						rsoiUpdateMsgBox.setWindowIcon(QIcon('Media/ramsify.png'))
						rsoiUpdateMsgBox.setStandardButtons(QMessageBox.Ok)
						rsoiUpdateMsgBox.exec_()

						self.rsoiUpdateWindow.close()
					
					except Exception as e:
						QMessageBox.critical(self, "Database Error", f"An error occurred: {e}")
					

			self.updateBtn_RSOI.clicked.connect(onClickingUpdateRsoi)			
			self.rsoiUpdateWindow.show()

		self.dataTable_RSOI.setRowCount(0)

		for rowIndex, rowData in enumerate(rsoiDataResult):
			self.dataTable_RSOI.insertRow(self.dataTable_RSOI.rowCount()) 

			rsoiCheckBoxWidget = QCheckBox('')
			rsoiCheckBoxWidget.setStyleSheet(self.checkBoxQSS)
			self.dataTable_RSOI.setCellWidget(self.dataTable_RSOI.rowCount()-1, 0, rsoiCheckBoxWidget)
			rsoiCheckBoxWidget.stateChanged.connect(onStateChangedOf_RSOICheckBox)

			for colIndex, rsData in enumerate(rowData[:-1]):
				if colIndex == 0: 
					button = QPushButton(str(rsData))
					givingFunctionalityToButton(button, onbuttonClickedRsoi, rowData)
					button.setStyleSheet(self.tableButtonQSS)
					button.setCursor(Qt.PointingHandCursor)
					self.dataTable_RSOI.setCellWidget(self.dataTable_RSOI.rowCount()-1, 1, button)

				else: 
					if rsData is not None:
						item = QTableWidgetItem(str(rsData))
					else:
						item = QTableWidgetItem('') 
					item.setTextAlignment(Qt.AlignCenter)
					item.setToolTip(item.text())
					self.dataTable_RSOI.setItem(self.dataTable_RSOI.rowCount()-1, colIndex + 1, item)

	self.refreshButton_Rsoi.clicked.connect(onClickingRefreshButton_rsoi)


	def onSearchBox_Rsoi_Button():
		searchText = self.serachBarOfRsoiTable.text().lower()
		for row in range(self.dataTable_RSOI.rowCount()):
			self.dataTable_RSOI.setRowHidden(row, True)

			if self.dataTable_RSOI.cellWidget(row, 1) and (searchText in self.dataTable_RSOI.cellWidget(row, 1).text().lower()):
				self.dataTable_RSOI.setRowHidden(row, False)
				continue

			for col in range(2, self.dataTable_RSOI.columnCount()):
				item = self.dataTable_RSOI.item(row, col)
				if item is not None and searchText in item.text().lower():
					self.dataTable_RSOI.setRowHidden(row, False)
					break

	self.serachBarOfRsoiTable.textChanged.connect(onSearchBox_Rsoi_Button)

	def onClickingDownloadBtn_RSOIDT():
		file_path, _ = QFileDialog.getSaveFileName(self, "Save Excel File", "", "Excel Files (*.xlsx)")

		if file_path:

			wb = Workbook()
			ws = wb.active

			headers = []
			for col in range(1, self.dataTable_RSOI.columnCount()):
				if not self.dataTable_RSOI.isColumnHidden(col):
					header_item = self.dataTable_RSOI.horizontalHeaderItem(col)
					if header_item is not None:
						headers.append(header_item.text())


			ws.append(headers)

			row_index = 2
			for row in range(self.dataTable_RSOI.rowCount()):
				if not self.dataTable_RSOI.isRowHidden(row):
					# ws.cell(row=row_index, column=1).value = self.dataTable_RSOI.cellWidget(row, 0).text()
					for col in range(1, self.dataTable_RSOI.columnCount()):
						if col == 1:
							wid = self.dataTable_RSOI.cellWidget(row, col)
							if isinstance(wid, QPushButton):
								ws.cell(row=row_index, column=col).value = wid.text()
						else:	
							item = self.dataTable_RSOI.item(row, col)
							if item is not None:
								ws.cell(row=row_index, column=col).value = item.text()

					row_index += 1

			wb.save(file_path)

			rsoiDownloadedMsgBox = QMessageBox()
			rsoiDownloadedMsgBox.setIcon(QMessageBox.Information) 
			rsoiDownloadedMsgBox.setText(f'Data downloaded successfully')
			rsoiDownloadedMsgBox.setWindowTitle("Message")
			rsoiDownloadedMsgBox.setWindowIcon(QIcon('Media/ramsify.png'))
			rsoiDownloadedMsgBox.setStandardButtons(QMessageBox.Ok)
			rsoiDownloadedMsgBox.exec_()

	self.download_Rsoi.clicked.connect(onClickingDownloadBtn_RSOIDT)

	def onClicking_SelectAll_RSOIDT(checked):
		if checked:
			self.selectAllRsoiButton.setIcon(QIcon(checkAllUserIconPath))

			for i in range(self.dataTable_RSOI.rowCount()):
				if not self.dataTable_RSOI.isRowHidden(i):
					if isinstance(self.dataTable_RSOI.cellWidget(i,0), QCheckBox):
						self.dataTable_RSOI.cellWidget(i,0).setCheckState(Qt.Checked)
		
		else:
			self.selectAllRsoiButton.setIcon(QIcon(unCheckAllUserIconPath))

			for i in range(self.dataTable_RSOI.rowCount()):
				if not self.dataTable_RSOI.isRowHidden(i):
					if isinstance(self.dataTable_RSOI.cellWidget(i,0), QCheckBox):
						self.dataTable_RSOI.cellWidget(i,0).setCheckState(Qt.Unchecked)

	self.selectAllRsoiButton.toggled.connect(onClicking_SelectAll_RSOIDT)


	def onStateChangedOf_RSOICheckBox():
		all_checked = True
		all_unchecked = True

		for i in range(self.dataTable_RSOI.rowCount()):
			if not self.dataTable_RSOI.isRowHidden(i):
				if isinstance(self.dataTable_RSOI.cellWidget(i,0), QCheckBox):
					if self.dataTable_RSOI.cellWidget(i,0).isChecked():
						all_unchecked = False
					else:
						all_checked = False

		if all_checked or all_unchecked:
			some_checked = False
		else:
			some_checked = True


		if all_checked:
			self.deleteButton_Rsoi.show()
			self.selectAllRsoiButton.setIcon(QIcon(checkAllUserIconPath))
			self.selectAllRsoiButton.setChecked(True)
			

		if all_unchecked:
			self.deleteButton_Rsoi.hide()
			self.selectAllRsoiButton.setIcon(QIcon(unCheckAllUserIconPath))
			self.selectAllRsoiButton.setChecked(False)
			

		if some_checked:
			self.deleteButton_Rsoi.show()
			self.selectAllRsoiButton.setIcon(QIcon(partiallyCheckedIconPath))

	def onclicking_Delete_RSOIDT():	
		selectedRefnoIndices_ = []
		selectedRefnos = []

		numberOfSelectedRefnos = 0

		for i in range(self.dataTable_RSOI.rowCount()):
			if not self.dataTable_RSOI.isRowHidden(i):
				if isinstance(self.dataTable_RSOI.cellWidget(i,0), QCheckBox):
					if self.dataTable_RSOI.cellWidget(i,0).checkState() == Qt.Checked:
						selectedRefnoIndices_.append(i)

						RefnoButton = self.dataTable_RSOI.cellWidget(i, 1)
						if RefnoButton:
							selectedRefnos.append(RefnoButton.text())
							numberOfSelectedRefnos += 1
		

		if selectedRefnos:

			confirmDeleteRSOIMsgBox = QMessageBox()
			confirmDeleteRSOIMsgBox.setIcon(QMessageBox.Question) 
			confirmDeleteRSOIMsgBox.setText(f"Are you sure you want to delete {numberOfSelectedRefnos} RefNo(s)?")
			confirmDeleteRSOIMsgBox.setWindowTitle("Confirm")
			confirmDeleteRSOIMsgBox.setWindowIcon(QIcon('Media/ramsify.png'))
			confirmDeleteRSOIMsgBox.setStandardButtons(QMessageBox.Ok | QMessageBox.No)
			
			userResponse = confirmDeleteRSOIMsgBox.exec()

			if userResponse == QMessageBox.Ok:
				current_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
				for ind in sorted(selectedRefnoIndices_, reverse=True):
					refnoToDelete = selectedRefnos[selectedRefnoIndices_.index(ind)]
					sql = "UPDATE rsoi SET deleted_at = %s, user_id = %s WHERE ref_no = %s"
					values = (current_time,  self.user_id, refnoToDelete)
					self.cursor.execute(sql, values)
					self.mydb.commit()
					self.dataTable_RSOI.removeRow(ind)

				rsoiDeleteSuccessMsgBox = QMessageBox()
				rsoiDeleteSuccessMsgBox.setIcon(QMessageBox.Information) 
				rsoiDeleteSuccessMsgBox.setText(f'{numberOfSelectedRefnos} RSOIs deleted successfully.')
				rsoiDeleteSuccessMsgBox.setWindowTitle("Message")
				rsoiDeleteSuccessMsgBox.setWindowIcon(QIcon('Media/ramsify.png'))
				rsoiDeleteSuccessMsgBox.setStandardButtons(QMessageBox.Ok)
				rsoiDeleteSuccessMsgBox.exec()
			
				self.deleteButton_Rsoi.hide()
				self.selectAllRsoiButton.setIcon(QIcon(unCheckAllUserIconPath))
			
			else:
				pass

	self.deleteButton_Rsoi.clicked.connect(onclicking_Delete_RSOIDT)

	onClickingRefreshButton_rsoi()